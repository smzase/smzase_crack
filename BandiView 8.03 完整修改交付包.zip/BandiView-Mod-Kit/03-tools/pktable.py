# -*- coding: utf-8 -*-
"""Print the patch table parsed out of make_bat.py (for docs / verification)."""
import re, sys, os

SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'make_bat.py')
s = open(SRC, encoding='utf-8').read()

PAT = re.compile(
    r"name\s*=\s*'([^']*)'\s*rva\s*=\s*0x([0-9A-Fa-f]+)\s*;\s*stub\s*=\s*'([0-9A-Fa-f]+)'"
    r"\s*old\s*=\s*'([0-9A-Fa-f]+)'")

rows = []
for m in PAT.finditer(s):
    name, rva, stub, old = m.group(1), m.group(2), m.group(3), m.group(4)
    nb, ns = len(old) // 2, len(stub) // 2
    rows.append((name, rva, nb, ns, nb - ns, old, stub))

for name, rva, nb, ns, pad, old, stub in rows:
    print('RVA=0x%-6s old=%2dB code=%2dB padCC=%2dB  %s' % (rva, nb, ns, pad, name))
print('total patches:', len(rows))

# verify against the original binary
here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
orig = os.path.join(here, 'BandiView.exe.orig')
if os.path.exists(orig):
    data = open(orig, 'rb').read()
    for name, rva, nb, ns, pad, old, stub in rows:
        b = bytes.fromhex(old)
        print('  %-58s hits=%d' % (name.split()[0], data.count(b)))
