import os, glob, zlib, io

root = r'D:\11github\BandiView'
needles = ['太多的设备', '该设备上的注册信息', '重置该设备', '注册状态', 'too many devices', 'Device registration']

def variants(txt):
    out = []
    for enc in ('utf-16-le', 'gbk', 'utf-8'):
        try:
            out.append((enc, txt.encode(enc)))
        except Exception:
            pass
    return out

def search(buf, label):
    for n in needles:
        for enc, b in variants(n):
            i = buf.find(b)
            if i >= 0:
                print('HIT %-60s 0x%X [%s] %r' % (label, i, enc, n))
                print('     ctx:', buf[max(0, i-60):i+160])
                return True
    return False

def try_gunzip(buf, label):
    for wbits in (31, 15, -15):
        try:
            d = zlib.decompress(buf, wbits)
        except Exception:
            continue
        if search(d, label + ' [inflated]'):
            return
        # maybe double
        try:
            d2 = zlib.decompress(d, 31)
            search(d2, label + ' [inflated2]')
        except Exception:
            pass

for dirpath, dirnames, filenames in os.walk(root):
    if '_work' in dirpath:
        continue
    for fn in filenames:
        p = os.path.join(dirpath, fn)
        try:
            buf = open(p, 'rb').read()
        except Exception:
            continue
        rel = os.path.relpath(p, root)
        if search(buf, rel):
            continue
        try_gunzip(buf, rel)

print('--- header samples ---')
for p in [os.path.join(root, 'langs', 'SimpChinese.lang'), os.path.join(root, 'data', 'resource.data'), os.path.join(root, 'data', 'skin.data')]:
    b = open(p, 'rb').read(64)
    print(os.path.basename(p), len(open(p, 'rb').read()), b[:32].hex())
