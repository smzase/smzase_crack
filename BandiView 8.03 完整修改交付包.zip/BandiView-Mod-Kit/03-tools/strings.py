import sys, re, os, glob

def strings(path, minlen=4, wide=True, ascii_=True):
    data = open(path,'rb').read()
    out=[]
    if ascii_:
        for m in re.finditer(rb'[\x20-\x7e]{%d,}'%minlen, data):
            out.append((m.start(), m.group().decode('latin1')))
    if wide:
        for m in re.finditer((rb'(?:[\x20-\x7e]\x00){%d,}'%minlen), data):
            out.append((m.start(), m.group().decode('utf-16-le')))
    out.sort()
    return out

if __name__=='__main__':
    pats = [p for p in sys.argv[2:] if p]
    for off,s in strings(sys.argv[1]):
        if not pats or any(re.search(p,s) for p in pats):
            print('%08x\t%s'%(off,s))
