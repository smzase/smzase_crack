a=open(r"D:\11github\BandiView\BandiView.exe.orig","rb").read()
b=open(r"D:\11github\BandiView\BandiView.exe","rb").read()
print("size same:", len(a)==len(b), len(a), len(b))
diffs=[i for i in range(len(a)) if a[i]!=b[i]]
print("diff bytes:", len(diffs))
# group
groups=[]
for i in diffs:
    if groups and i==groups[-1][1]+1: groups[-1][1]=i
    else: groups.append([i,i])
for s,e in groups:
    print(f"  off {s:#x}..{e:#x}  {a[s:e+1].hex(' ')}  ->  {b[s:e+1].hex(' ')}")
