import os, re, struct, subprocess, sys, time

ROOT = r'D:\11github\BandiView'
EXE = os.path.join(ROOT, 'BandiView.exe')
ORIG = os.path.join(ROOT, 'BandiView.exe.orig')

# import patch table from make_bat.py source
src = open(os.path.join(ROOT, '_work', 'make_bat.py'), encoding='utf-8').read()
m = re.search(r'PS\s*=\s*r?\'\'\'(.*?)\'\'\'', src, re.S)
ps = m.group(1)


def patches():
    out = []
    # blocks like:  @{ name = 'AD-1' ; rva = 0x65210 ; stub = '...' ; old = '...' }
    for mm in re.finditer(r"@\{\s*name\s*=\s*'([^']*)'\s*rva\s*=\s*0x([0-9A-Fa-f]+)\s*;\s*stub\s*=\s*'([0-9A-Fa-f]+)'\s*old\s*=\s*'([0-9A-Fa-f]+)'", ps):
        out.append((mm.group(1).split()[0], int(mm.group(2), 16), mm.group(3).upper(), mm.group(4).upper()))
    return out


PATCHES = patches()
print('parsed %d patches:' % len(PATCHES))
for n, rva, stub, old in PATCHES:
    print('   %-6s rva=0x%X  old=%dB stub=%dB' % (n, rva, len(old) // 2, len(stub) // 2))


def build(names, out_path):
    b = bytearray(open(ORIG, 'rb').read())
    for n, rva, stub, old in PATCHES:
        if n not in names:
            continue
        o = bytes.fromhex(old)
        if n.startswith('ED-'):
            new = bytes.fromhex(stub)
        else:
            s = bytes.fromhex(stub)
            new = s + b'\x90' * (len(o) - len(s))
        i = b.find(o)
        if i < 0:
            raise SystemExit('sig not found for ' + n)
        b[i:i + len(new)] = new
    open(out_path, 'wb').write(bytes(b))
    return out_path


if __name__ == '__main__':
    names = sys.argv[1].split(',') if len(sys.argv) > 1 and sys.argv[1] != 'none' else []
    out = sys.argv[2] if len(sys.argv) > 2 else EXE
    if not os.path.exists(ORIG):
        raise SystemExit('missing .orig')
    build(names, out)
    print('built', out, 'with', names)
