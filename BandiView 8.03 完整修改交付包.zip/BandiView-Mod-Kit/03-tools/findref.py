import struct, sys

EXE = r'D:\11github\BandiView\BandiView.exe'
b = open(EXE, 'rb').read()

# --- PE section map ---
pe = struct.unpack_from('<I', b, 0x3C)[0]
nsec = struct.unpack_from('<H', b, pe + 6)[0]
optsz = struct.unpack_from('<H', b, pe + 20)[0]
opt = pe + 24
imagebase = struct.unpack_from('<Q', b, opt + 24)[0]
secs = []
so = opt + optsz
for i in range(nsec):
    o = so + i * 40
    name = b[o:o+8].rstrip(b'\x00').decode('latin1')
    vsize, va, rsize, raw = struct.unpack_from('<IIII', b, o + 8)
    secs.append((name, va, vsize, raw, rsize))

def off2va(off):
    for name, va, vsize, raw, rsize in secs:
        if raw <= off < raw + rsize:
            return imagebase + va + (off - raw)
    return None

def va2off(v):
    r = v - imagebase
    for name, va, vsize, raw, rsize in secs:
        if va <= r < va + max(vsize, rsize):
            return raw + (r - va)
    return None

def find_all(buf, n):
    out, s = [], 0
    while True:
        i = buf.find(n, s)
        if i < 0:
            return out
        out.append(i)
        s = i + 1

target = sys.argv[1] if len(sys.argv) > 1 else 'TEXT_CLEAR_REGISTRATION'
hits = find_all(b, target.encode('ascii'))
print('string "%s" occurrences:' % target, [hex(h) for h in hits])
for h in hits:
    print('  file off 0x%X -> VA 0x%X' % (h, off2va(h)))

strvas = set(off2va(h) for h in hits)
# find rip-relative lea/mov referencing those VAs
text = None
for name, va, vsize, raw, rsize in secs:
    if name == '.text':
        text = (va, raw, rsize)
tv, tr, tsz = text
tb = b[tr:tr+tsz]
refs = []
for i in range(len(tb) - 7):
    op = tb[i]
    if op == 0x48 or op == 0x4C:
        modrm = tb[i+1]
        # lea r64, [rip+disp32] : 48/4C 8D /r  with mod=00 rm=101
        if tb[i+1] == 0x8D and (tb[i+2] & 0xC7) == 0x05:
            disp = struct.unpack_from('<i', tb, i+3)[0]
            insn_va = imagebase + tv + i
            tgt = insn_va + 7 + disp
            if tgt in strvas:
                reg = (tb[i+2] >> 3) & 7
                refs.append((insn_va, tgt, 'lea r%d' % reg, i))
        # mov r64, [rip+disp32] : REX.W 8B /r mod=00 rm=101
        if tb[i+1] == 0x8B and (tb[i+2] & 0xC7) == 0x05:
            disp = struct.unpack_from('<i', tb, i+3)[0]
            insn_va = imagebase + tv + i
            tgt = insn_va + 7 + disp
            if tgt in strvas:
                refs.append((insn_va, tgt, 'mov r', i))
print('\ncode refs:')
for va, tgt, kind, i in refs:
    print('  0x%X (%s) -> 0x%X   [file off 0x%X]' % (va, kind, tgt, tr + i))
    # print surrounding bytes
    print('     bytes:', tb[max(0, i-24):i+24].hex())
