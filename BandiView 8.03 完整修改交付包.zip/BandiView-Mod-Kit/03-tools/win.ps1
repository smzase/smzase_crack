Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections.Generic;
public class Win {
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr h, EnumWindowsProc cb, IntPtr l);
  public delegate bool EnumWindowsProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);

  public static List<string> Dump(uint pid) {
    var res = new List<string>();
    EnumWindows((h, l) => {
      uint p; GetWindowThreadProcessId(h, out p);
      if (p == pid) {
        var sb = new StringBuilder(1024); GetWindowText(h, sb, 1024);
        var cn = new StringBuilder(256); GetClassName(h, cn, 256);
        string line = "[TOP ] " + cn.ToString() + " :: " + sb.ToString();
        res.Add(line);
        EnumChildWindows(h, (h2, l2) => {
          var s2 = new StringBuilder(1024); GetWindowText(h2, s2, 1024);
          var c2 = new StringBuilder(256); GetClassName(h2, c2, 256);
          if (s2.Length > 0) res.Add("   [CHLD] " + c2.ToString() + " :: " + s2.ToString());
          return true;
        }, IntPtr.Zero);
      }
      return true;
    }, IntPtr.Zero);
    return res;
  }
}
"@
