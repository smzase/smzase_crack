import os, glob, sys

needles = ['太多的设备', '注册信息', '重置该设备', '太多', '设备',
           'reset the registration', 'too many', 'Too many', 'device']
root = r'D:\11github\BandiView'

def scan(p):
    try:
        b = open(p, 'rb').read()
    except Exception:
        return
    hits = []
    for n in needles:
        for enc in ('utf-16-le', 'gbk', 'utf-8'):
            try:
                b2 = n.encode(enc)
            except Exception:
                continue
            start = 0
            while True:
                i = b.find(b2, start)
                if i < 0:
                    break
                hits.append((i, enc, n))
                start = i + 1
                if len(hits) > 40:
                    break
    if hits:
        print('==', p)
        for i, enc, n in hits[:20]:
            ctx = b[max(0, i-40):i+120]
            print('   0x%X [%s] %r  ctx=%r' % (i, enc, n, ctx))

for p in ['BandiView.exe', 'bv.exe', 'lm.x64.dll', 'Uninstall.exe']:
    scan(os.path.join(root, p))
for pat in ['langs/*.lang', 'langs/*/*', 'data/*']:
    for p in glob.glob(os.path.join(root, pat)):
        if os.path.isfile(p):
            scan(p)
