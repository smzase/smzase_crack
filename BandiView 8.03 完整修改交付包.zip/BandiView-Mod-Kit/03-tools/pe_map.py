import struct, sys, json
P=r"D:\11github\BandiView\BandiView.exe"
d=open(P,'rb').read()
# PE headers
pe=struct.unpack_from('<I', d, 0x3C)[0]
assert d[pe:pe+4]==b'PE\0\0'
nsec=struct.unpack_from('<H', d, pe+6)[0]
optsz=struct.unpack_from('<H', d, pe+20)[0]
opt=pe+24
magic=struct.unpack_from('<H', d, opt)[0]
print("PE32+" if magic==0x20b else "PE32", "nsec",nsec)
imgbase=struct.unpack_from('<Q', d, opt+24)[0]
print("imagebase", hex(imgbase))
sec=opt+optsz
secs=[]
for i in range(nsec):
    o=sec+i*40
    name=d[o:o+8].rstrip(b'\0').decode()
    vsz,va,rsz,roff=struct.unpack_from('<IIII', d, o+8)
    secs.append((name,va,vsz,roff,rsz))
    print(f"  {name:10s} VA {va:#010x} VSize {vsz:#x} RAW {roff:#010x} RAWsize {rsz:#x}")
print("sections end (max roff+rsz):", hex(max(r+rsz for _,_,_,r,rsz in secs)))
# checksum / signature dir
csum=struct.unpack_from('<I', d, opt+64)[0]
print("optional checksum field:", hex(csum))
ndd=struct.unpack_from('<I', d, opt+108)[0]
for i in range(min(ndd,16)):
    rva,sz=struct.unpack_from('<II', d, opt+112+i*8)
    if sz: print(f"  datadir[{i}] rva {rva:#x} size {sz:#x}")

def rva2off(rva):
    for name,va,vsz,roff,rsz in secs:
        if va<=rva<va+max(vsz,rsz):
            return roff+(rva-va)
    return None

SIGS={
 "AD1 popup-ad launcher sub_140065210": bytes.fromhex("48895C2410488974241 857 4883EC50".replace(" ","")),
}
# use explicit
sigs=[
 ("AD1", "sub_140065210 popup-ad launcher", "48895C24104889742418574883EC50", "31C0C3909090909090"),
 ("AD2", "sub_140064EC0 AdWnd creator",      "4055535657415641574 88D6C24D14881EC".replace(" ",""), "31C0C3909090909090"),
 ("UP1", "sub_14009E9C0 CheckHavetoUpdate",  "405553565741544155415641574 88D6C24F84881EC08010000".replace(" ",""), "31C0C3909090909090"),
 ("UP2", "sub_1400D5520 update fetch+UpdateDlg","405553565741544155415641574 88DAC24C8F6FFFF4881EC38 0A0000".replace(" ",""), "C3909090909090909090"),
 ("UP3", "sub_14011D3F0 CHK_UPDATE task handler","48895C2408488954241055 56574156415 7488D6C24C9".replace(" ",""), "31C0C3909090909090"),
 ("ED1", "sub_140082560 force licensed branch","803D82A36500000F8482000000", "803D82A3650000 0E95600000090".replace(" ","")),
 ("ED2", "edition state TRI->licensed",       "C70565636700398B5E2C", "C7056563670039F85D2C"),
]
for tag,desc,sig,rep in sigs:
    s=bytes.fromhex(sig); r=bytes.fromhex(rep)
    hits=[]
    i=d.find(s)
    while i>=0:
        hits.append(i); i=d.find(s,i+1)
    print(f"{tag} len(sig)={len(s)} hits={len(hits)} at {[hex(h) for h in hits]}")
    if len(hits)==1:
        print(f"    fileoffset {hex(hits[0])} rva {hex(hits[0])} ")
