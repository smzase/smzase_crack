import struct

VA_BASE = 0x140000000
REGION_VA = 0x1400826B3
REGION_OFF = 0x81AB3
CONFIG_GETTER = 0x140075FE0
WSTR_ASSIGN = 0x14005FCF0
STATE_VAR = 0x1406F8958
A_TRI = 0x140628108
A_SUB = 0x140628110
A_PRO = 0x14062B790
TRI_STATE = 0x2C5E8B39
LIC_STATE = 0x2C5DF839


def stub(str_va, state, size=79):
    b = bytearray()
    def rel32(target, site_off):
        here = REGION_VA + site_off
        return struct.pack('<i', target - (here + 5))
    def disp32(target, site_off, insn_len):
        here = REGION_VA + site_off
        return struct.pack('<i', target - (here + insn_len))

    b += b'\xE8' + rel32(CONFIG_GETTER, 0)          # call config getter
    b += b'\x48\x8D\x78\x08'                        # lea rdi,[rax+8]
    b += b'\x41\xB8\x03\x00\x00\x00'                # mov r8d,3
    assert len(b) == 15
    b += b'\x48\x8D\x15' + disp32(str_va, 15, 7)    # lea rdx,[str]
    assert len(b) == 22
    b += b'\x48\x8B\xCF'                            # mov rcx,rdi
    assert len(b) == 25
    b += b'\xE8' + rel32(WSTR_ASSIGN, 25)           # call assign
    assert len(b) == 30
    b += b'\xC7\x05' + disp32(STATE_VAR, 30, 10) + struct.pack('<I', state)
    assert len(b) == 40
    b += b'\x48\x83\xC4\x30'                        # add rsp,30h
    b += b'\x5F\x5E\x5B\xC3'                        # pop rdi,rsi,rbx ; ret
    assert len(b) == 48
    b += b'\xCC' * (size - len(b))
    return bytes(b)


if __name__ == '__main__':
    known = 'E82839FFFF488D780841B803000000488D15C7905A00488BCFE81FD6FDFFC7057D62670039F85D2C4883C4305F5E5BC3'
    made = stub(A_PRO, LIC_STATE)
    print('matches known stub prefix:', made.hex().upper().startswith(known))
    for name, s, st in [('PRO+TRI', A_PRO, TRI_STATE), ('TRI+LIC', A_TRI, LIC_STATE), ('PRO+LIC', A_PRO, LIC_STATE)]:
        x = stub(s, st)
        print('%-8s %s' % (name, x[:48].hex().upper()))
