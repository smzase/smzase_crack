import struct
P=r"D:\11github\BandiView\BandiView.exe"
d=open(P,'rb').read()
pe=struct.unpack_from('<I',d,0x3C)[0]; nsec=struct.unpack_from('<H',d,pe+6)[0]; optsz=struct.unpack_from('<H',d,pe+20)[0]
opt=pe+24; imgbase=struct.unpack_from('<Q',d,opt+24)[0]; sec=opt+optsz
S=[]
for i in range(nsec):
    o=sec+i*40; nm=d[o:o+8].rstrip(b'\0').decode(); vsz,va,rsz,ro=struct.unpack_from('<IIII',d,o+8)
    S.append((nm,va,max(vsz,rsz),ro))
def rva2off(rva):
    for nm,va,vsz,ro in S:
        if va<=rva<va+vsz: return ro+(rva-va)
    return None
def off2rva(off):
    for nm,va,vsz,ro in S:
        if ro<=off<ro+ (vsz if va!=0x1000 else 0x592400): pass
    return None
def findall(s):
    out=[];i=d.find(s)
    while i>=0:
        out.append(i); i=d.find(s,i+1)
    return out
tg={"AD1":0x140065210,"AD2":0x140064EC0,"UP1":0x14009E9C0,"UP2":0x1400D5520,"UP3":0x14011D3F0}
for nm,ea in tg.items():
    rva=ea-imgbase; off=rva2off(rva)
    old=d[off:off+32]
    hits=findall(old)
    print(f"{nm} rva={rva:#x} off={off:#x} 32B-sig hits={len(hits)} {[hex(h) for h in hits]}")
    print(f"    old={old.hex().upper()}")
print()
for nm,old in [("ED1",bytes.fromhex("803D82A36500000F8482000000")),("ED2",bytes.fromhex("C70565636700398B5E2C"))]:
    hits=findall(old); print(nm,"hits",len(hits),[hex(h) for h in hits])
pat=bytes.fromhex("488D480841B803000000488D15")
hits=findall(pat); print("ED3 pattern hits",len(hits))
for h in hits:
    disp=struct.unpack_from('<i',d,h+13)[0]
    for nm,va,vsz,ro in S:
        if va<=h<va+vsz:
            rva=h-ro+va
            break
    tgt=rva+17+disp
    to=rva2off(tgt)
    print("   site",hex(h),"rva",hex(rva),"target rva",hex(tgt),"off",hex(to) if to else None, d[to:to+8].hex() if to else "")
