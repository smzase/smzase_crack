Add-Type @"
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class CU {
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumW cb, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr h, EnumW cb, IntPtr l);
  public delegate bool EnumW(IntPtr h, IntPtr l);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr h);
  [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
  public struct RECT { public int l, t, r, b; }
  public static IntPtr Main(uint pid) {
    IntPtr found = IntPtr.Zero;
    EnumWindows((h, l) => {
      uint p; GetWindowThreadProcessId(h, out p);
      if (p == pid) {
        var cn = new StringBuilder(128); GetClassName(h, cn, 128);
        if (cn.ToString() == "BandiViewClass") { found = h; return false; }
      }
      return true;
    }, IntPtr.Zero);
    return found;
  }
  public static List<string> Kids(IntPtr parent) {
    var r = new List<string>();
    EnumChildWindows(parent, (h, l) => {
      var cn = new StringBuilder(128); GetClassName(h, cn, 128);
      var tx = new StringBuilder(256); GetWindowText(h, tx, 256);
      RECT rc; GetWindowRect(h, out rc);
      if (IsWindowVisible(h) && cn.ToString() != "IME" && cn.ToString() != "MSCTFIME UI")
        r.Add(string.Format("{0,-22} id={1,-6} rect={2},{3} {4}x{5} :: {6}",
           cn.ToString(), GetDlgCtrlID(h), rc.l, rc.t, rc.r - rc.l, rc.b - rc.t, tx.ToString()));
      return true;
    }, IntPtr.Zero);
    return r;
  }
  public static void Click(IntPtr h) {
    PostMessageW(h, 0x0201, (IntPtr)1, (IntPtr)((10 << 16) | 10));
    PostMessageW(h, 0x0202, IntPtr.Zero, (IntPtr)((10 << 16) | 10));
  }
}
"@
