Add-Type @"
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class MU {
  [DllImport("user32.dll")] public static extern IntPtr GetMenu(IntPtr h);
  [DllImport("user32.dll")] public static extern int GetMenuItemCount(IntPtr m);
  [DllImport("user32.dll")] public static extern IntPtr GetSubMenu(IntPtr m, int i);
  [DllImport("user32.dll")] public static extern int GetMenuItemID(IntPtr m, int i);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetMenuStringW(IntPtr m, int i, StringBuilder s, int n, uint flags);
  [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr h, uint msg, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] public static extern IntPtr FindWindowEx(IntPtr p, IntPtr c, string cls, string name);
  public const uint WM_COMMAND = 0x0111;
  public const uint MF_BYPOSITION = 0x400;
  static void Walk(IntPtr m, int depth, List<string> o) {
    int n = GetMenuItemCount(m);
    for (int i = 0; i < n; i++) {
      var sb = new StringBuilder(256);
      GetMenuStringW(m, i, sb, 256, MF_BYPOSITION);
      int id = GetMenuItemID(m, i);
      IntPtr sub = GetSubMenu(m, i);
      o.Add(new string(' ', depth*2) + (sub != IntPtr.Zero ? "[SUB] " : "      ") + sb.ToString() + "  id=" + id);
      if (sub != IntPtr.Zero) Walk(sub, depth+1, o);
    }
  }
  public static List<string> Dump(IntPtr hwnd) {
    var l = new List<string>();
    IntPtr m = GetMenu(hwnd);
    if (m == IntPtr.Zero) { l.Add("<no menu>"); return l; }
    Walk(m, 0, l);
    return l;
  }
  public static void Cmd(IntPtr hwnd, int id) { PostMessageW(hwnd, WM_COMMAND, (IntPtr)id, IntPtr.Zero); }
}
"@
