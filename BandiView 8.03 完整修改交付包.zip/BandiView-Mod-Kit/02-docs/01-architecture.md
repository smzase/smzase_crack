# 01 · 软件结构与加固面

基准：`BandiView.exe` 8.03 / build 34280，x64，ImageBase `0x140000000`。

---

## 1. PE 布局

| 节 | 虚拟地址 RVA | 文件偏移 | 大小 |
|---|---|---|---|
| `.text` | `0x00001000` | `0x00000400` | `0x0592400` |
| `IPPCODE` | `0x00594000` | `0x00592800` | — |
| `.rdata` | `0x00595000` | `0x00593200` | `0x0144200` |
| `.data` | `0x006DA000` | `0x006D7400` | `0x002C600` |
| `.pdata` | `0x00720000` | — | — |
| `.fptable` | `0x00752000` | — | — |
| `ve_share` | `0x00753000` | — | — |
| `_RDATA` | `0x00754000` | — | — |
| `.rsrc` | `0x00761000` | `0x00741A00` | — |
| `.reloc` | `0x00775000` | — | — |

**换算（本文档全篇通用）：**

```
.text ：file_offset = RVA - 0xC00        RVA = file_offset + 0xC00
.rdata：file_offset = RVA - 0x1E00       RVA = file_offset + 0x1E00
VA    ：VA = RVA + 0x140000000
```

例：ED 补丁点在 RVA `0x826B3` → 文件偏移 `0x81AB3` → VA `0x1400826B3`。

程序未加壳、无 VM、无自校验（改完 302 字节照常启动，说明没有 CRC 校验 exe 自身）。

---

## 2. 授权模型：exe 只认识 4 个"版本枚举"

### 2.1 枚举 → 显示名

`sub_14007D760(int edition)`（RVA `0x7D760`）：

| 枚举值 | 返回字符串 | 含义 |
|---|---|---|
| `0` | `L"Trial"` | 试用 |
| `255` | `L"Professional"` | **永久专业版** |
| `365` | `L"Professional"` | 订阅专业版（按天算，语义不同） |
| 其它 | `L""` | 未知 |

调用点只有两处，都是**构造窗口标题**：
- `0x14007E1B7`（在 `sub_14007DF40`，主窗口标题）
- `0x14019E0C5`（在 `sub_14019E010`，转换器窗口标题）

这就是**最可靠的运行时判据**：标题栏后缀 `- BandiView (Professional)` = 已授权；`(Trial)` = 未授权。

### 2.2 枚举的存储：混淆过的全局状态

全局变量 `dword_1406F8958`（RVA `0x6F8958`）里存的不是枚举本身，而是混淆值：

```python
MASK = 0xABCDEF12
K    = 0x543210EE          # = 1412567278

def rol32(x, n): return ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF
def ror32(x, n): return ((x >> n) | (x << (32 - n))) & 0xFFFFFFFF

def enc(e):   return rol32((rol32(e ^ MASK, 5) - K) & 0xFFFFFFFF, 3)
def dec(s):   return ror32((ror32(s, 3) + K) & 0xFFFFFFFF, 5) ^ MASK
```

已实测的三个值：

| 枚举 | 混淆状态 |
|---|---|
| `0`（Trial） | `0x2C5E8B39` |
| `365`（订阅 Professional） | `0x2C5DF839` |
| **`255`（永久 Professional，本包采用）** | **`0x2C5F6639`** |

> 为什么用 255 不用 365：程序里有若干 `edition == 0xFF` 的专业版门（例如 `sub_14009F6B0`
> 给 updateinfo URL 追加 `/pro/`），255 才走专业分支；365 会残留"订阅还有多少天"的语义。

反混淆的原始指令在 `sub_140082560` 尾部：

```asm
1400826B3  mov  eax, [rsp+50h]
1400826B9  xor  eax, 0ABCDEF12h
1400826BF  ror  eax, 1Bh        ; 27
1400826C2  sub  eax, 543210EEh
1400826C8  ror  eax, 1Dh        ; 29
1400826C7  mov  dword_1406F8958, eax
```

（等价于 `dec()`，只是把两次旋转换成了反方向的对偶写法。）

### 2.3 谁在写这个状态

- **唯一直接写入者**：`sub_140082560`（RVA `0x82560`，429 字节）——本包 ED 补丁就改它的尾部。
- **22 处把 `&dword_1406F8958` 当指针传给授权模块**（`lm.x64.dll` 的 vtable+112 / +120），
  理论上模块可以改写回来。已实测（空闲 30 秒 / 开图 / 按 F1 打开关于框）**没有发生回写**，
  所以没有再补一层。
- **只读 3 处**：`0x14007DF40`（主标题）、`0x14019E010`（转换器标题）、`0x14009F6B0`（URL 拼装）。

### 2.4 版本字符串与状态的关系（重要，别搞混）

`config+8`（全局配置结构 `&word_14070CE70` 的 `+8`，即 RVA `0x70CE78`）里存的是**版本名字符串**，
它**不参与**标题栏显示。实测证据：

| 实验 | `config+8` 字符串 | `dword_1406F8958` | 标题栏 |
|---|---|---|---|
| A | `"PRO"` | TRI 状态 | `(Trial)` |
| B | `"TRI"` | 已授权状态 | `(Professional)` |

→ **标题只看状态值**。所以只改 `config+8` 或用注册表 `appEditionStrEn=PRO` 都没用（早期试过，失败）。

---

## 3. 授权模块 `lm.x64.dll`

- 2,680,256 字节，与 exe 同目录，`sub_14007D020`（RVA `0x7D020`，`LoadLmModule`）负责加载：
  拼路径 → `LoadLibrary` → 取接口；失败弹 `Error: Cannot load %s. Code: 0x%x (%u, %s)`，
  超时弹 `Error: It takes too long to load lm.dll [%dms]`。
- 模块里带着版本字符串常量（文件偏移）：`ENT`@221288、`PRV`@221296、`PRO`@221304、`TRI`@221336，
  以及注册表值名 `c`/`r`/`u`/`f`/`a`@221312…221328、`g`/`h`/`m`/`t`。
- **结论：PRO / ENT / PRV 三种版本判定全在模块侧**，exe 侧只区分 TRI 与 SUB。
  因此"在 exe 侧强制已授权状态"是唯一自洽的改法（本包做法），而不是去猜模块内部校验。
- 模块必须继续被加载：`sub_140082560` 的模块分支里调 `LoadLmModule` 之后还有
  `sub_14007D5E0` 等初始化，链路被跳过就会**空指针崩溃**（见 05-pitfalls.md 的 ED-1 事故）。

相关注册表（读取侧，未被本包修改）：
- `HKLM\SOFTWARE\BandiView\l`：值 `g`(32 位十六进制 GUID)、`l`、`k`、`h`、`P`、`m`、`t`，六个全有才算数（`sub_1400A2540`，RVA `0xA2540`）。
- `HKCU\SOFTWARE\BandiView\l`：值 `c`、`r`、`u`、`f`、`a`（`sub_1400A2F20` / `sub_1400A36B0`，RVA `0xA2F20` / `0xA36B0`）。
- `HKCU\SOFTWARE\BandiView\` 主项：`appEditionStrEn`(字符串)、`serverBuildNo`、`serverBuildNoCur`、
  `lastUpdateCheckDay`、`lastShowADDay`、`updateChk`、`updateBeta` —— 全部在 `sub_140076F50`（RVA `0x76F50`）里读写。

---

## 4. 更新链（本包 UP-1/2/3 全断）

```
启动 / 定时器 / 菜单
   └─> sub_14011C7F0 .. sub_14011D3F0   构造任务名 "CHK_UPDATE_0" / "CHK_UPDATE_1"
         └─> sub_14011D3F0 (RVA 0x11D3F0)  任务处理器 ................ [UP-3 砍这里]
               ├─ 调 lm 模块 vtable+112 看是否有新版本
               └─ 无新版且未授权 -> 弹 CLicenseGuideDlg（"立即购买"引导框）
   └─> sub_14009E9C0 (RVA 0x9E9C0) CheckHavetoUpdate() ................ [UP-1 恒返回 0]
         日志 "CheckHavetoUpdate() - local:%d, server:%d, serverCur:%d"，返回 0/1/2
   └─> sub_1400D5520 (RVA 0xD5520) 拉取 + 更新弹窗 ................... [UP-2 直接 ret]
         下载 https://ver.bandi.so/bandiview/versioninfo.ini
         （config 的 +181 字节非 0 时换 .beta/ 分支）
         失败弹 TEXT_UPDATE_DOWNLOAD_FAILED
         └─> CUpdateDlg：sub_140135390 (RVA 0x135390) 建 IDD_UPDATE + skin_update_dlg.xml
             窗口过程 sub_140134D40 (RVA 0x134D40)，vftable 0x140639108
             内容用 WebView2（WINDOW_WEB64）渲染 → 是网页，不是原生控件
```

相关 URL 常量：`https://ver.bandi.so/bandiview/versioninfo.ini`（VA `0x1405E9C00`）、
`…/bandiview.beta/versioninfo.ini`（`0x1405E9B90`）、`https://www.bandisoft.com/bandiview/updateinfo/`（`0x14062B520`）。

三条路径全断的效果：程序**永远不会自己联网升级**，也不会有"发现新版本"提示；
只有手工下载官方安装包覆盖安装才能更新。

---

## 5. 广告链（本包 AD-1/AD-2 全断）

```
启动 / 打开图片 / 切换图片 (param <= 2 或 == 14)
   └─> sub_140065210 (RVA 0x65210)  LaunchPopupAdWindow ............ [AD-1 恒返回 0]
         if (dword_1406F8958 == 0)
           v8 = sub_140074720()           # 今天，格式 tm_mday + 100*(mon+190001+100*year)
           if (v8 != *(config+44)          # 今天还没弹过 -> 0x70CE9C
               && (*a2 <= 2 || *a2 == 14))
             *(config+44) = v8 ; 存盘
             lpFile = sub_14006EAE0()
             ShellExecuteW(NULL,"open",lpFile,"/ad",NULL,5)   # 另起一个进程 BandiView.exe /ad
   └─> 子进程 /ad 走命令行解析 sub_1400847A0 (RVA 0x847A0)
         └─> sub_140065730 (RVA 0x65730) -> sub_140065210 再来一次
              └─> sub_140064EC0 (RVA 0x64EC0) CreateAdWindow ...... [AD-2 恒返回 0]
                    注册窗口类 L"BandiViewAdWnd" (sub_14005D8B0)
                    窗口过程 sub_14005D630：
                      WM_COMMAND 0xFDE8 -> SetTimer 10ms + GetWindowRect
                      WM_COMMAND 0xFDE9 -> ShellExecuteW "https://notice.bandisoft.com/ad/bandiview/"
                      WM_DESTROY       -> FreeLibrary(WebView2) + PostQuitMessage
                    皮肤 L"skin_ad.xml"，宽高来自 config.ini 的 popup_ad_wnd_w / popup_ad_wnd_h
```

`/ad` 参数的三个引用点：`0x14006539a`、`0x1400653b5`（在 `sub_140065210` 内）、`0x140085514`（命令行解析内）。

砍 AD-1 之后 `ShellExecuteW(..."/ad")` 不再发生；砍 AD-2 之后即使有人直接 `BandiView.exe /ad`
也建不出广告窗。实测两者都生效：打完补丁 `/ad` 进程立即退出、子进程 0 个。

---

## 6. 授权联网校验（本包 LV-1/2 封印，这是"设备过多"弹窗的来源）

```
sub_1400E9E50 (RVA 0xE9E50)  授权校验驱动 ........................ [LV-1 恒返回 0]
  ├─ 取 lm 模块接口，调 vtable+120(接口, &dword_1406F8958, 4)   ← 会把状态写回来
  ├─ 读 app-info 的 +80 三连 wstring，判断 [2] == L"ok"
  ├─ 若存在时间戳：v10 = 解析(v7[1])，v11 = time(NULL)
  │    v10 > v11 或 (v11 - v10) >= 259200（3 天）→ 跳过
  └─ LABEL_19：堆上建 0x60 字节上下文
       *(QWORD*)ctx = 539164945 (0x2023_0BF1 魔数)
       ctx+8 = 窗口句柄；ctx+20 = dword_140709AB8；ctx+21 = 539103776
       beginthreadex(0,0, sub_1400CC460, ctx, 0, &ctx[12])
         └─> sub_1400CC460 (RVA 0xCC460) 校验线程 ................. [LV-2 恒返回 0]
               if (*(DWORD*)a1 != 539164945) return 0;
               sub_1400CADE0(...)             # 联网校验
               sub_1400A36B0(...)             # 无论成败都写 HKCU\...\l
               失败分支：PostMessageW(hwnd, 539103776, 539103776 >> 16, 0)
                 └─> 主窗口弹「该产品已经在太多的设备上注册…是否重置该设备的注册状态?」
```

弹窗文案不在 exe 里，在语言文件：
- `langs\SimpChinese.lang` `0xE67`：`TEXT_CLEAR_REGISTRATION = 该产品已经在太多的设备上注册，并且该设备上的注册信息已经被删除。[br]是否重置该设备的注册状态？`
- `langs\English.lang` `0xE5E`：对应英文。

按钮是 `是` / `否` / `帮助`，**没有 `&Y`/`&N` 助记符**，所以不是 `MessageBoxW` 发的
（扫描 29 处 `MessageBoxW` 调用，uType 只有 0 / 0x30 / 0x1030 / 0x1015 / 0x1034，没有 `MB_YESNO`）。

`sub_1400E9E50` 的调用者：`sub_1400D11D0`@`0x1400D1FC5`、`sub_1400E9DB0`@`0x1400E9E38`。
`sub_1400CC460` 无直接 CodeRef（只被 `beginthreadex` 取地址传进去），所以**只能按函数入口地址定位**。

---

## 7. 配置与注册表

| 位置 | 内容 | 谁读写 |
|---|---|---|
| `config.ini [setting]` | `config_id`(std/appx/test)、`beta_version`、`popup_ad_wnd_w/h` | `sub_140073D60`（RVA `0x73D60`）|
| `version.ini [Version]` | `BuildNo=34280` | `sub_140074440`（RVA `0x74440`）拼版本串 `8.03(编译# 34280, …)` |
| 全局配置结构 | `&word_14070CE70`，取用函数 `sub_140075FE0`（RVA `0x75FE0`）| 到处 |
| `config+8` | 版本名字符串（wstring） | 不影响标题（见 2.4）|
| `config+44`（`0x70CE9C`）| 上次弹广告的日期 | 广告日期闸 |
| `config+181` | 非 0 → 走 beta 更新通道 | `sub_1400D5520` |

`config.ini` 里那个空的 `[url]` 段没有任何代码消费（`GetPrivateProfileStringW` 只有 2 个调用点，
一个是 About 对话框，一个是数据区 `0x1406D4290`）。

---

## 8. UI 特征（自动化验证时用得上）

- 主窗口类名 `BandiViewClass`；**没有标准菜单**（`GetMenu` 返回空），**没有可见子控件**
  （`EnumChildWindows` 只有自绘皮肤），所以只能发键盘消息驱动。
- **F1 → 打开"关于/注册"对话框**（类 `#32770`，标题 `BandiView 8.03 (编译# 34280, 2026/10/13, x64)`）：
  按钮 `确定` / `正在检查软件版本` / `立即注册` / `立即购买` / `取消注册` / `网站`（类名都是 `ShadowWindowClass`），
  `Edit id=32836` 是「邮箱地址 / 产品密钥」输入框，`RICHEDIT50W` 是开源许可证正文。
  按 F9（对话框里等于触发"检查软件版本"）→ 状态文字变「版本检查失败」，**无弹窗**（UP 补丁的预期表现）。
- 崩溃弹窗特征：标题 `BandiView`，子 Static 含
  `BandiView 遇到问题需要关闭。是否将错误报告发送给 BandiView 的开发者?`，按钮 `是(&Y)` / `否(&N)`。
  **进程"还活着"不等于正常** —— 可能只是挂着这个崩溃框。
