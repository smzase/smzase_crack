# 06 · 后续维护手册（换版本 / 加补丁 / 回滚）

---

## 0. 铁律（违反任何一条都会把程序改坏）

1. **只做同长度原位改写** —— 不增删节、不改文件大小、不动文件头。
2. **不写绝对地址** —— 全部用 RIP 相对（`E8 rel32` / `48 8D 15 rel32` / `C7 05 rel32 imm32`），否则 ASLR 下必崩。
3. **签名必须唯一** —— 每条 `old` 在原始文件里必须 `hits == 1`，否则可能在错误位置写入。
4. **不跳过模块初始化** —— `sub_140082560` 的 `jz` 那个分支里含 `LoadLmModule`，见 `05-pitfalls.md` §3。
5. **改完必须能启动、标题正确、无 `#32770` 弹窗**，三条同时满足才算过。

---

## 1. 补丁表在哪儿

只有一处：`03-tools/make_bat.py` 里的 `$PATCHES`（第 67–92 行附近）。格式：

```python
@{ name = 'AD-1  弹窗广告启动器  LaunchPopupAdWindow'
   rva  = 0x65210            # 仅用于"是否已打过"的判定，不参与定位
   stub = '31C0C3'           # 要写入的字节（不足 32 字节时自动用 90 补齐）
   old  = '48895C24...' },   # 32 字节唯一签名（ED 用 79 字节）
```

运行逻辑（在 bat 里）：
- `old` 能在文件里找到 → 写入 `new`，打印 `[ OK ]`；
- 找不到但 `rva` 处的前几字节已等于 `stub` → 打印 `[SKIP]`（已打过）；
- 都不满足 → 打印 `[MISS]`（版本变了），**跳过不改**。

> `name` 以 `ED-` 开头时会走特例分支（`$p.name.StartsWith('ED-')`），即**完整使用 79 字节 stub，不补 nop**。
> 如果以后加别的长补丁，把前缀改成 `ED-` 或改这个判断。

---

## 2. 重新生成 bat

```powershell
cd D:\11github\BandiView
python _work\make_bat.py          # 或 03-tools\make_bat.py（两者内容相同）
```

⚠️ `make_bat.py` 末尾的**输出路径是硬编码**的：

```python
p = os.path.join(r'D:\11github\BandiView', 'BandiView-Patch.bat')
```

换机器/换目录时先改这一行。脚本会顺便检查「PS 段里不能出现 `%`」（cmd 会吃掉），有的话会打印出来。

生成的 bat 结构（不要手工改，改生成器）：
```
@echo off / setlocal / cd /d "%~dp0" / chcp 936 / title ...
set "BV_PATCH_BAT=%~f0" ; set "BV_WHERE=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "<读自身文件 -> 找 #::PSSTART 行 -> Invoke-Expression 后半段>"
pause
#::PSSTART
<PowerShell 脚本正文>
```
> `('#::PS'+'START')` 故意拆开写，否则标记会在 cmd 命令行里被提前命中。

---

## 3. 官方升级了，怎么把补丁搬到新版本

### 3.1 先看还能不能直接复用

```powershell
python 03-tools\pktable.py
```
输出每条签名的 `hits`。**全 `hits=1` → 直接跑 bat 就行，什么都不用改。**
出现 `hits=0` → 该函数在新版本里改了，继续往下。

### 3.2 用特征字符串重新定位（最省事）

IDA 打开新的 `BandiView.exe`，按下面的**特征串**找 xref，再取函数入口前 32 字节作为新 `old`：

| 补丁 | 特征串（宽字符串，UTF-16LE） | 备注 |
|---|---|---|
| AD-1 | `@@rLaunchPopupAdWindow() - param:%s` | 就在函数体里 |
| AD-1 | `L"/ad"` | 只有 3 处引用：`sub_140065210`×2 + 命令行解析×1 |
| AD-2 | `skin_ad.xml` / `BandiViewAdWnd` | 广告窗创建 + 类注册 |
| UP-1 | `CheckHavetoUpdate() - local:%d, server:%d, serverCur:%d` | 日志格式串，最可靠 |
| UP-2 | `https://ver.bandi.so/bandiview/versioninfo.ini` | 更新拉取 |
| UP-2 | `IDD_UPDATE` / `skin_update_dlg.xml` / `WINDOW_WEB64` | 更新弹窗 |
| UP-3 | `L"CHK_UPDATE_0"` / `L"CHK_UPDATE_1"` | 任务名 |
| ED | `mov dword ptr [GLOBAL], 2C5E8B39h` / `2C5DF839h` | 搜立即数 `39 8B 5E 2C` / `39 F8 5D 2C` |
| LV-1 | 调 `LoadLmModule` 后跟 `beginthreadex` 的那个函数 | 见下 |
| LV-2 | `539164945`（`0x20230BF1`）/ `539103776` | 魔数与消息号，搜立即数最稳 |

**LV-2 特别说明**：它**没有直接 CodeRef**（只被 `beginthreadex` 当参数传进去），
所以必须从 LV-1 里跟 `beginthreadex(0, 0, <线程函数>, ...)` 的第三个参数取地址。

### 3.3 取签名 + 校验唯一性

```powershell
python 03-tools\strings.py BandiView.exe "LaunchPopupAdWindow"   # 看字符串在不在、在哪
python 03-tools\pe_map.py  BandiView.exe                        # 节表映射 + 签名命中数
python 03-tools\sigs.py    BandiView.exe                        # 唯一性 + lea 目标跟随
```

`sigs.py` 里的**指针跟随**技巧值得记住：`48 8D 48 08 41 B8 03 00 00 00 48 8D 15 <disp32>`
这串在文件里出现 2 次（一次指向 `aSub`，一次指向 `aTri`），
按 `target = site_rva + 17 + disp32` 解析就能分清谁是谁 —— 找"某个字符串被哪个函数用"时非常好使。

### 3.4 版本枚举可能变了怎么办

ED 桩写死 `0x2C5F6639`（枚举 255）。如果新版本换了混淆常量，这个值会失效（表现为标题不对/回退 Trial）。
**校验方法**：在 IDA 里看 ED 补丁点附近的 `xor / ror / sub / ror` 指令，取出其中的
`0xABCDEF12`、`0x543210EE` 两个常量，用 `04-disassembly.md` §2 的 Python 公式重算 `enc(255)`。
常量没变就不用动；变了就把新值填进 `$PATCHES` 里 ED 那条的 `39665F2C`（小端 imm32）。

同理，如果 `sub_140075FE0` / `sub_14005FCF0` / `aPro` 的地址变了，**必须重新生成 ED 桩**：

```python
# 03-tools/mk_ed.py
stub(str_va=A_PRO, state=0x2C5F6639, size=79)   # 自动算 E8/lea/C7 的 rel32
```

### 3.5 如果某条补丁彻底找不到了

先判断"这条还要不要"：
- AD/UP/LV 这类只要**函数还在**就能打；函数名没了就用 §3.2 的特征串找。
- 实在找不到，**宁可让 bat 报 `[MISS]` 跳过**，也不要瞎猜位置写字节。

---

## 4. 加第 9 处补丁的模板

在 `$PATCHES` 里加一条：

```python
  @{ name = 'XX-1  一句话说明  FunctionName'
     rva  = 0x123456 ; stub = '31C0C3'
     old  = '十六进制64个字符' },
```

要求：
- `old` 是 **32 字节**（64 个 hex 字符），在原始文件里唯一；
- `stub` 不超过 32 字节，不足自动补 `90`；
- 如果新补丁会改变返回值语义，**先确认调用方检查返回值**，否则可能引入新分支；
- 加完跑 `python 03-tools\pktable.py` 确认 `hits=1`，再跑 bat 验证。

---

## 5. 验证流程（每次都走一遍，别省）

```powershell
cd D:\11github\BandiView

# 0) 确保没有实例在跑
Get-Process BandiView,bv -ErrorAction SilentlyContinue | Stop-Process -Force

# 1) 干净状态打补丁（从原始文件开始）
Copy-Item .\BandiView.exe.orig .\BandiView.exe -Force
cmd /c BandiView-Patch.bat
#   期望：8 条 [ OK ]，输出「已写入 8 处修改」

# 2) 字节差异必须正好 302 / 8 区域
python _work\diffcheck.py

# 3) 运行验证：标题 + 无弹窗
. .\_work\win.ps1
$p = Start-Process .\BandiView.exe -ArgumentList "`"$env:TEMP\bvtest.png`"" -PassThru
Start-Sleep 12
[Win]::Dump([uint32]$p.Id)
#   期望：只有 BandiViewClass，标题含 (Professional)，没有 #32770
Start-Sleep 18 ; [Win]::Dump([uint32]$p.Id)   # 空闲 30 秒再看一次
Stop-Process -Id $p.Id -Force

# 4) 广告验证
$q = Start-Process .\BandiView.exe -ArgumentList "/ad" -PassThru
Start-Sleep 6
"exited=$($q.HasExited) children=$((Get-CimInstance Win32_Process -Filter "ParentProcessId=$($q.Id)"|Measure-Object).Count)"
#   期望：exited=True children=0

# 5) 幂等
cmd /c BandiView-Patch.bat
#   期望：8 条 [SKIP] + 1 条注册表 [ OK ]
```

`win.ps1` 提供 `[Win]::Dump($pid)`，输出每行 `[TOP ] 类名 :: 标题` 或 `[CHLD] 类名 :: 文本`；
`child.ps1` 提供 `[CU]::Main($pid)` 取主窗口句柄（配合 `K::Key()` 发键盘消息做 UI 探测，比如 F1 打开关于框）。

---

## 6. 回滚

| 想回到 | 做法 |
|---|---|
| 官方原版 | `Copy-Item .\BandiView.exe.orig .\BandiView.exe -Force` |
| 只回滚某一处 | 把该处 `new` 字节写回 `old`（32 字节），或用 `03-tools/mkvar.py` 生成排除该补丁的变体 |
| 注册表 | `updateChk`/`updateBeta`/`appEditionStrEn`/`lastShowADDay` 改回 0/0/`TRI`/原值 |

`mkvar.py` 用法：从补丁表生成"只打某几个"或"排除某几个"的变体，用于二分定位回归：
```python
import mkvar
mkvar.build(['AD-1','AD-2','UP-1','UP-2','UP-3','LV-1','LV-2'], 'out_noED.exe')   # 排除 ED
```
> 变体生成后**必须** `Copy-Item 变体 BandiView.exe` 再从该路径启动（见 `05-pitfalls.md` §5）。

---

## 7. 环境依赖

| 需要 | 说明 |
|---|---|
| PowerShell 5.1 | bat 里内嵌 PS；**不要用** `Get-FileHash`（此环境没有）|
| Python 3 | 跑 `03-tools\*.py`；只用了标准库（`re`/`struct`/`os`/`sys`）|
| IDA + Hex-Rays | 重定位/加补丁时用；`04-decompiled` 里已有本版本的 251 个函数伪代码 |
| `lm.x64.dll` | **必须与 exe 同目录**，否则弹 `Error: Cannot load ... Code: 0xbad10000 (126)` |

---

## 8. 已知的可改进点（没做，因为不影响目标）

- `sub_1400957D0`（About 对话框）里有个**隐藏后门**：按住 Shift 或 Ctrl 打开关于框，
  会读 `c:\bandiview-test.ini` 的 `[test] email` / `[test] key` 填进输入框。想彻底干净可以一起砍。
- 22 处把 `&dword_1406F8958` 传给模块的函数理论上能把状态写回 TRI，**实测未发生**；
  若未来发现状态回退，优先在这里加"写后立即复原"的补丁。
- `C LicenseGuideDlg`（购买引导，vftable `0x14062A7D0`）在 UP-3 之后已无入口；
  如需再保险可直接砍它的窗口过程。
