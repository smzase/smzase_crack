# 03 · 关键函数与字符串地址索引

全部为 `BandiView.exe`（build 34280，ImageBase `0x140000000`）。
`VA = 0x140000000 + RVA`；`.text` 文件偏移 `= RVA − 0xC00`；`.rdata` 文件偏移 `= RVA − 0x1E00`。

---

## 1. 函数索引

| 函数（IDA 名 / RVA） | 语义 | 在本文档体系里的角色 |
|---|---|---|
| `sub_140082560` / `0x82560` | **版本/授权状态决策 + 模块判定采纳**（429 字节） | **ED 补丁** 改其尾部 79 字节 |
| `sub_14007D760` / `0x7D760` | `enum → 显示名`：0→Trial，255→Professional，365→Professional | 标题栏判据的实现 |
| `sub_14007DF40` / `0x7DF40` | 主窗口标题构造（读 `dword_1406F8958`，调 `0x7D760`） | 运行时验证要靠它 |
| `sub_14019E010` / `0x19E010` | 转换器窗口标题构造 | 同上 |
| `sub_14009F6B0` / `0x9F6B0` | URL 拼装（`== 0xFF` 时追加 `updateinfo/pro/`） | 255 语义的证据 |
| `sub_140075FE0` / `0x75FE0` | **返回全局配置结构** `&word_14070CE70`（TLS 懒初始化） | ED 桩调用它 |
| `sub_14005FCF0` / `0x5FCF0` | `wstring assign(dst, src, len)` | ED 桩调用它 |
| `sub_140076F50` / `0x76F50` | 配置读写：`HKCU\Software\BandiView` 全部值 | 注册表开关的证据 |
| `sub_140073D60` / `0x73D60` | 解析 `config.ini [setting]` | 配置来源 |
| `sub_140074440` / `0x74440` | 拼版本串（`version.ini` + PE FILEVERSION） | About 标题 `8.03 (编译# 34280…)` |
| `sub_140074720` / `0x74720` | 返回"今天"整数：`tm_mday + 100*(tm_mon+190001+100*tm_year)` | 广告日期闸 |
| `sub_140079B50` / `0x79B50` | 写 `appEditionStrEn` 字符串 | 注册表遗留物 |
| `sub_14007D020` / `0x7D020` | **`LoadLmModule`**：加载 `lm.x64.dll` 取接口 | 崩溃事故的关键（不能跳过）|
| `sub_14007D5E0` / `0x7D5E0` | 加载后初始化（`+0xC0` 接口块） | 同上 |
| `sub_1400A1680` / `0xA1680` | app-info 单例，返回 `&dword_14071E910`，懒建 5 个 wstring | 授权校验读它 `+80` |
| `sub_1400A2270` / `0xA2270` | `RefreshEdition`：读 HKLM 授权 + HKCU 授权，交叉校验 | 授权模型 |
| `sub_1400A2540` / `0xA2540` | 读 `HKLM\SOFTWARE\BandiView\l` 的 `g/l/k/h/P/m/t`（六个全有才行） | 授权模型 |
| `sub_1400A2F20` / `0xA2F20` | 读 `HKCU\SOFTWARE\BandiView\l` 的 `c/r/u/f/a` | 授权模型 |
| `sub_1400A36B0` / `0xA36B0` | 写 `HKCU\...\l`（`c/r/u/f/a`） | 授权模型 |
| `sub_1400A3600` / `0xA3600` | 版本标签校验：只接受 `TRI` / `PRO` / `PRV`，否则清空 | 为什么不能把 TRI 常量改成乱码 |
| `sub_1400A0DB0` / `0xA0DB0` | 读 `HKCU\...\s` 的 `d`+`r`，用密钥 `test_plan` 解密，按到期时间给 `SUB`/`TRI` | 订阅版逻辑 |
| `sub_1400A0860` / `0xA0860` | 检查 `HKCU\SOFTWARE\BandiView\SubsEdition` | 订阅判定 |
| `sub_1400E9E50` / `0xE9E50` | **授权联网校验驱动** | **LV-1 补丁** |
| `sub_1400CC460` / `0xCC460` | **授权联网校验线程体**（失败 → `PostMessageW` 弹框）| **LV-2 补丁** |
| `sub_1400CADE0` / `0xCADE0` | 联网校验请求（`checkProductKey.php` / `checkValidGUID.php`）| 被 LV-2 封住 |
| `sub_1400D11D0` / `0xD11D0` | 调 `sub_1400E9E50`（`0x1400D1FC5`）| 调用者 |
| `sub_1400E9DB0` / `0xE9DB0` | 调 `sub_1400E9E50`（`0x1400E9E38`）| 调用者 |
| `sub_14009E9C0` / `0x9E9C0` | `CheckHavetoUpdate()` | **UP-1 补丁** |
| `sub_1400D5520` / `0xD5520` | 拉 `versioninfo.ini` + 建 `CUpdateDlg` | **UP-2 补丁** |
| `sub_14011C7F0` / `0x11C7F0` | 构造 `CHK_UPDATE_0` 任务并入队 | 更新任务链 |
| `sub_14011D050` / `0x11D050` | 同上（`914` 字节）| 更新任务链 |
| `sub_14011D3F0` / `0x11D3F0` | `CHK_UPDATE` 任务处理器（含 `CLicenseGuideDlg` 购买引导） | **UP-3 补丁** |
| `sub_14011D6E0` / `0x11D6E0` | 任务收尾 | 更新任务链 |
| `sub_140135390` / `0x135390` | `IDD_UPDATE` OnInitDialog（WebView2 `WINDOW_WEB64`） | 更新弹窗本体 |
| `sub_140134D40` / `0x134D40` | `CUpdateDlg` 窗口过程（vftable `0x140639108`）| 更新弹窗本体 |
| `sub_140135A20` / `0x135A20` | 弹窗内下载步骤 | 更新弹窗本体 |
| `sub_140136230` / `0x136230` | 弹窗内 CRC/校验步骤 | 更新弹窗本体 |
| `sub_140065210` / `0x65210` | `LaunchPopupAdWindow` | **AD-1 补丁** |
| `sub_140064EC0` / `0x64EC0` | `CreateAdWindow` | **AD-2 补丁** |
| `sub_14005D8B0` / `0x5D8B0` | 注册窗口类 `L"BandiViewAdWnd"` | 广告窗 |
| `sub_14005D630` / `0x5D630` | `BandiViewAdWnd` 窗口过程 | 广告窗 |
| `sub_1400651F0` / `0x651F0` | 21 字节包装：`call CreateAdWindow; return 1` | 未改动 |
| `sub_140065730` / `0x65730` | 调 `LaunchPopupAdWindow`（`0x1400657C9`）| 广告链 |
| `sub_140065AF0` / `0x65AF0` | 5 字节 thunk `jmp sub_140065730` | 广告链 |
| `sub_1400847A0` / `0x847A0` | 命令行解析（`/runtest` `/ad` `/gdi` `/usemmf`）| `/ad` 入口 |
| `sub_1400957D0` / `0x957D0` | About/注册对话框 `IDD_ABOUT`；按住 Shift/Ctrl 会读 `c:\bandiview-test.ini [test] email/key`（**隐藏后门**）| UI 探测 |
| `sub_1400BFCD0` / `0xBFCD0` | 12,320 字节，也引用 `CHK_UPDATE_1` | 更新任务链 |

---

## 2. 字符串索引（RVA / VA）

### 2.1 版本标签（`.rdata`）

| 内容 | RVA | VA |
|---|---|---|
| `L"TRI"` (`aTri`) | `0x628108` | `0x140628108` |
| `L"SUB"` (`aSub`) | `0x628110` | `0x140628110` |
| `L"PRO"` (`aPro`) | `0x62B790` | `0x14062B790` |
| `L"PRV"` (`aPrv`) | `0x62B218` | `0x14062B218` |
| `L"ENT"` (`aEnt`) | `0x62B210` | `0x14062B210` |
| `L"HKLM\\SOFTWARE\\$app$\\Edition"` | `0x62B738` | `0x14062B738` |

### 2.2 注册表值名（**全是 UTF-16LE**，ASCII 搜不到）

| 内容 | RVA | VA |
|---|---|---|
| `appEditionStrEn` | `0x5E8848` | `0x1405E8848` |
| `serverBuildNo` | `0x5E88B0` | `0x1405E88B0` |
| `serverBuildNoCur` | `0x5E88D0` | `0x1405E88D0` |
| `lastUpdateCheckDay` | `0x5E88F8` | `0x1405E88F8` |
| `lastShowADDay` | `0x5E8920` | `0x1405E8920` |
| `updateChk` | `0x5E8DD0` | `0x1405E8DD0` |
| `updateBeta` | `0x5E8DE8` | `0x1405E8DE8` |

### 2.3 广告相关

| 内容 | RVA | VA |
|---|---|---|
| `https://notice.bandisoft.com/ad/bandiview/` | `0x5E60D0` | `0x1405E60D0` |
| `BandiViewAdWnd`（窗口类名） | `0x5E5F18` | `0x1405E5F18` |
| `skin_ad.xml` | `0x5E6A00` | `0x1405E6A00` |
| `@@rLaunchPopupAdWindow() - param:%s` | `0x5E6A20` | `0x1405E6A20` |
| `L"/ad"` | `0x5E6A68` | `0x1405E6A68` |

### 2.4 更新相关

| 内容 | RVA | VA |
|---|---|---|
| `https://ver.bandi.so/bandiview/versioninfo.ini` | `0x5E9C00` | `0x1405E9C00` |
| `…/bandiview.beta/versioninfo.ini` | `0x5E9B90` | `0x1405E9B90` |
| `https://www.bandisoft.com/bandiview/updateinfo/` | `0x62B520` | `0x14062B520` |
| `updateinfo.beta/` | `0x62B464` | `0x14062B464` |
| `updateinfo/pro/` | `0x62B5B4` | `0x14062B5B4` |
| `updateinfo.beta/pro/` | `0x62B4D4` | `0x14062B4D4` |
| `L"CHK_UPDATE_0"` | `0x62EE98` | `0x14062EE98` |
| `L"CHK_UPDATE_1"` | `0x6369C0` | `0x1406369C0` |
| `IDD_UPDATE` | `0x638ED8` | `0x140638ED8` |
| `skin_update_dlg.xml` | `0x638EA8` | `0x140638EA8` |

### 2.5 注册/授权 UI 与 URL

| 内容 | RVA / VA |
|---|---|
| `IDD_REGISTER` | `0x62A500` / `0x14062A500` |
| `IDD_LICENSE_GUIDE` | `0x62A3E0` / `0x14062A3E0` |
| `IDD_ABOUT` | `0x629FA0` / `0x140629FA0` |
| `IDD_REGDLG`（`.rsrc`） | `0x7626F6` / `0x1407626F6` |
| `IDD_LICENSE_GUIDE_WEB` | `0x762B46` / `0x140762B46` |
| `bandiview/buy/` | `0x629EC4` / `0x140629EC4` |
| `checkProductKey.php` | `0x62F7DA`+`0x62F8D8` |
| `checkValidGUID.php` | `0x62F97A` / `0x14062F97A` |
| `how-to-register/` | `0x62A762` |
| `edition-comparison/` | `0x62A6E2` |
| `app.licenseguide` | `0x63A258` |
| `.rsrc` 字符串表：`CMD_UPDATE` / `CMD_REGISTER` / `CMD_REGISTER_ONLINE_CHECK` | `0x7644A4` / `0x76487C` / `0x7648C0` |

### 2.6 全局变量

| 变量 | RVA | 说明 |
|---|---|---|
| `dword_1406F8958` | `0x6F8958` | **混淆后的版本枚举**（TRI `0x2C5E8B39` / 订阅 `0x2C5DF839` / 永久PRO `0x2C5F6639`）|
| `word_14070CE70` | `0x70CE70` | 全局配置结构基址；`+8` 版本名 wstring；`+44` 上次弹广告日期；`+181` beta 标志 |
| `byte_1406DC8F5` | `0x6DC8F5` | **只读恒 0**（20 处引用全是 `cmp`/`movzx`，零写入）→ `sub_140082560` 的 `jz` 恒跳向模块分支 |
| `dword_14071E910` | `0x71E910` | app-info 单例；`+80` 起 3 个 wstring（`[2]=="ok"` 判据）|
| `dword_140709AB8` | `0x709AB8` | 校验线程上下文里的消息号之一 |

---

## 3. 语言文件键（弹窗文案都不在 exe 里）

| 键 | 文件与偏移 | 中文内容 |
|---|---|---|
| `TEXT_CLEAR_REGISTRATION` | `langs\SimpChinese.lang:0xE67` | 该产品已经在太多的设备上注册，并且该设备上的注册信息已经被删除。[br]是否重置该设备的注册状态？ |
| 同上（英文） | `langs\English.lang:0xE5E` | The product has been registered on too many devices and the registration info on this device has been deleted.[br]Do you want to reset the registration state on the device? |
| `TEXT_UPDATE_DOWNLOAD_FAILED` | `langs\*.lang` | 更新下载失败（UPDATE-2 断掉后不会再出现）|

> 定位技巧：先在 `langs\` 里搜文案 → 拿到键名 → 再想 exe 里谁用它。但这个软件的 exe 用**数字 ID** 查表，
> 键名不在 exe 里，所以字符串搜索会**一无所获**（这点踩过坑，见 `05-pitfalls.md`）。
