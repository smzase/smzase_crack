# 05 · 踩坑与失败记录

按"踩到的顺序"记录，每条都带**根因**和**正确做法**，避免以后在同一个地方再花时间。

---

## 1. 子代理给的"入口字节签名"全是编造的

**现象**：把反编译结果丢给并行子代理做分析，返回的补丁表里每条都带 32 字节签名，看起来很像真的。
**验证结果**：拿回 IDA 里一对，真入口完全不同。例如 `sub_14009E9C0` 真实前 32 字节是
`40 55 53 56 57 41 54 41 55 41 56 41 57 48 8D 6C 24 F8 48 81 EC 08 01 00 00`，
而子代理给的是 `48 89 5C 24 08 57 48 83 EC 20` 之类的通用模板。

**结论**：**函数定位可以参考，签名一律自己从 IDA/文件里取**。本包 8 条签名全部由文件原文提取，
并用 `03-tools\pktable.py` 校验 `hits == 1`。

---

## 2. 只改注册表 = 完全没用

**实验**：把 `HKCU\Software\BandiView\l\a` 设为 `"PRO"`，启动程序 8 秒后退出，重新读注册表 ——
`appEditionStrEn` 仍是 `TRI`，标题仍是 `(Trial)`。
**根因**：导出值名在 `lm.x64.dll` 里就地校验，且 `sub_1400E9E50` 会把"不一致"的状态**打回 TRI**（见 `04-disassembly.md` §3）。

**同理无效的还有**：
- `config+8` 的版本名字符串（只影响"显示名"的来源，不影响判定）；
- `appEditionStrEn`（程序只在保存配置时才写它，启动时不读作判据）；
- 把 `aTri` 常量改成 `"PRO"`（会让所有 `edition == aTri` 的比较**误判成试用**，反而更糟）。

---

## 3. ★ ED-1 崩溃事故（最重要的一条）

**第一版设计**：把 `sub_140082560` 开头的
`80 3D 82 A3 65 00 00 / 0F 84 82 00 00 00`（`cmp byte,0` + `jz 距 0x82`）
改成 `cmp byte,0` + `E9 56 00 00 00`（`jmp` 到 `0x1400825CE`，即"写 TRI 的块"），
意图：跳过模块分支，直接落到能写状态的地方。

**结果**：打完补丁启动 → **必崩**（弹 `BandiView 遇到问题需要关闭…`）。
**二分定位**：把 8 处补丁拆成 unit 与 "all-but-one" 两种共 16 个变体逐一跑，结论极干净 ——
**只要含 ED-1 就崩，`not_ED1` 正常，其余 7 处任意组合都正常**。

**根因**：`0x1400825CE` 之前在 `0x1400825FB` 起的模块分支里做了大量初始化：
`sub_1400A1680` → `sub_1400601C0` → `sub_14007D020`(**LoadLmModule**) → `sub_14007D5E0`，
并且 `0x1400826B1 call rbx`（模块 vtable+0x58）。跳到 `0x1400825CE` 把这些**全部跳过**，
`lm.x64.dll` 的接口指针保持 NULL，后续任何一次解引用都崩。

**正确做法**：**只改尾部**（`0x1400826B3` 起 79 字节），模块照常加载、照常初始化，
只是最后"采纳模块判定"那一步换成写死值。改完一次通过。

**教训**：`jz` 恒跳的分支看起来像"可以绕过的无用分支"，其实它可能就是唯一的初始化路径。
**改分支前先确认分支内部有没有副作用（尤其 `LoadLibrary` 系）**。

---

## 4. `mkvariants.py` 的长度 bug → 所有变体都无法执行

```python
b[off:off+len(p)] = bytes.fromhex(p)     # 错：len(p) 是十六进制字符串长度(64)，不是字节数(32)
```
后果：每个变体被**插入了 32 字节垃圾**，全部报
`The specified executable is not a valid application for this OS platform.`（`ERROR_BAD_EXE_FORMAT`）——
看起来像"补丁把 PE 改坏了"，其实只是脚本 bug。

**正确**：`nb = bytes.fromhex(p); b[off:off+len(nb)] = nb`。

---

## 5. 变体必须覆盖 `BandiView.exe` 再启动

**现象**：把变体放在 `_work\var\only_XXX.exe` 直接启动 → 弹
`Error: Cannot load D:\...\lm.x64.dll. Code: 0xbad10000 (126, 找不到指定的模块。)`
**根因**：`LoadLmModule` 按**自身 exe 所在目录**找 `lm.x64.dll`；变体被放到别处就找不到。

**正确**：`Copy-Item 变体 -Destination BandiView.exe`，再从 `D:\11github\BandiView\BandiView.exe` 启动。
（同理，最终交付的 bat 必须和 `BandiView.exe` 同目录。）

---

## 6. 进程"还活着" ≠ 程序正常

崩溃时进程**不会退出**，它只是挂着一个模态崩溃框：

- 标题 `BandiView`
- 子 `Static` 文本 `BandiView 遇到问题需要关闭。是否将错误报告发送给 BandiView 的开发者?`
- 按钮 `是(&Y)` / `否(&N)`

只按 `HasExited` 判断会全线误报"OK"。**必须枚举窗口**：
用 `03-tools\win.ps1` 的 `[Win]::Dump($pid)` 检查有没有 `#32770` + 上述文案。

---

## 7. 这个环境没有 `Get-FileHash`

```
Invoke-Expression : 无法将"Get-FileHash"项识别为 cmdlet、函数、脚本文件或可运行程序的名称
```
**后果**：bat 里用 `Get-FileHash` 做备份判定的版本会**中途抛异常退出**（`$ErrorActionPreference='Stop'`），
用户看到的是"补丁跑一半就没了"。

**正确**：改用"能否找到任一原始签名"来判断是否需要刷新备份：

```powershell
$anyOrig = $false
foreach ($p in $PATCHES) {
  if ($src.IndexOf($enc.GetString((FromHex $p.old)), [StringComparison]::Ordinal) -ge 0) { $anyOrig = $true; break }
}
$refresh = ((-not (Test-Path -LiteralPath $bak)) -or $anyOrig)
```

同理别用 `Get-Item`/`Test-Path -PathType` 之类未验证的写法，**只用已验证可用的**：
`Test-Path`、`Copy-Item`、`Write-Host`、`[IO.File]`、`[StringComparison]`、`Set-ItemProperty`。

---

## 8. 弹窗文案不在 exe 里，而且不是 `MessageBoxW`

**现象**：想在 exe 里搜「该产品已经在太多的设备上注册」→ 一无所获。
**根因**：
1. 文案在 `langs\SimpChinese.lang`（键 `TEXT_CLEAR_REGISTRATION`，偏移 `0xE67`），exe 用**数字 ID** 查表；
2. 弹框按钮是 `是` / `否` / `帮助`，**没有 `&Y`/`&N` 助记符** → 不是 `MessageBoxW` 发的
   （扫了 29 处 `MessageBoxW`，uType 只有 `0 / 0x30 / 0x1030 / 0x1015 / 0x1034`，没有 `MB_YESNO`）。

**正确路径**：先在 `langs\` 里搜文案拿到键名 → 再**用变量二分**（"版本名字符串" vs "已授权状态"）确定触发条件
→ 顺着 `beginthreadex` 的参数找到线程体 → 找到 `PostMessageW`。

二分表（很关键，直接给出结论）：

| 变体 | `config+8` | `dword_1406F8958` | 标题 | 弹窗 |
|---|---|---|---|---|
| 原版 / 仅 AD+UP | `TRI` | TRI | `(Trial)` | 无 |
| ED-only / 全 8 处 | `PRO` | 已授权 | `(Professional)` | **有** |
| PRO 字符串 + TRI 状态 | `PRO` | TRI | `(Trial)` | 无 |
| TRI 字符串 + 已授权状态 | `TRI` | 已授权 | `(Professional)` | **有** |

→ **弹窗只由"已授权状态"触发**，与版本名字符串、与 `HKCU\...\l` 的 `c/r/u/f/a` 都无关
（把整个 `l` 键删掉照样弹）。

---

## 9. 误删原始备份，靠"逆补丁"重建

**事故**：清理文件时把 `BandiView.exe.orig` 删了，`BandiView.exe` 已是补丁状态。
**恢复**：写脚本把 8 处 new 逐个换回 old（5 个 32 字节函数入口 + ED 的 13 字节 + ED 的 10 字节 + 字符串），
重建出原始文件；验证方式：重建件 + 重打补丁 == 已知好件（**逐字节相同**）。

**教训**：
- `BandiView.exe.orig` 是**唯一**的还原凭据，别在脚本里对它有 `Remove-Item`；
- 只要补丁表（old/new）完整，原始文件**永远可重建** —— 这也是本包把补丁表放文档里的原因。

---

## 10. RTTI → VTable 重建得到假地址

想通过 `.?AVUpdateDlg@@` 之类的 RTTI 名找到 `vftable`：RTTI 确实存在
（`.?AVUpdateDlg@@` @`0x6FF4C8`、`CRegisterDlg` @`0x6FDCC8`、`RegDlg` @`0x6FDDD0`、`CLicenseGuideDlg` @`0x6FDE40`），
但按 COL→vftable 的标准布局去算，得到的 `0x14066A430`、`0x1406671A8` 这些地址里装的是
**打包的双字数据，不是 8 字节代码指针**。

**正确**：这个程序的对话框是**按 `IDD_*` 名字文本表**分发的（`IDD_UPDATE` / `IDD_REGISTER` / `IDD_ABOUT`…），
顺着 `IDD_*` / `skin_*.xml` 宽字符串的引用点找窗口过程更快。
（唯一例外：`CUpdateDlg` 的 vftable 明确在 `0x140639108`，因为它同时出现在注册数据表里。）

---

## 11. 字符串搜索的四个坑

| 坑 | 表现 | 正确做法 |
|---|---|---|
| 注册表值名是 UTF-16LE | ASCII 搜 `appEditionStrEn` 搜不到 | 按宽字符搜（`03-tools\strings.py` 支持） |
| `idautils.Strings()` 漏宽字符串 | 明明存在却列不出 | 直接扫节区原始字节 |
| `ida_strlist` 不全 | 同上 | 同上 |
| `ida_funcs.get_name` 不存在 | `AttributeError` | 用 `ida_name.get_name(ea)` |

其他 IDA API 坑：
- `idautils.DataRefsTo(...) + idautils.CodeRefsTo(...)` 是 **generator**，必须先 `list()`，否则报类型错误；
- `idautils.Segments()` 返回 **int**（不是 segment 对象），要 `ida_segment.getnseg(i)` 取 `.start_ea/.end_ea`；
- `ida_bytes.bin_search` 的 6 参重载需要 mask，干脆用 Python `bytes.find()` 在节区快照上搜。

---

## 12. `dword_1406F8958` 不是布尔开关

它的值是**编码后的枚举**（TRI=`0x2C5E8B39`、订阅=`0x2C5DF839`、永久PRO=`0x2C5F6639`），
不是 `0/1`。早期曾把它当"广告开关"来读，结论全错。

**广告日期闸其实在** `config+44`（RVA `0x70CE9C`），值是 `sub_140074720()` 的"今天"整数。

---

## 13. 交付前的两个自检清单（防止回归）

1. **标题**必须是 `- BandiView (Professional)`，且 `#32770` 窗口数 = 0（空闲 30 秒后仍为 0）。
2. **`/ad`** 必须 `exited=True children=0`；原版是 `alive + 1 个 WebView2 子进程`，这是最好的对照。
3. `python 03-tools\diffcheck.py` 的差异必须是**302 字节 / 8 个区域**，一个不多一个不少。
4. 连跑两次 bat，第二次应全 `[SKIP]`，字节数不变。

---

## 14. 控制台中文乱码（无害）

在 UTF-8 终端里跑 `cmd /c BandiView-Patch.bat` 抓输出，中文会显示成 `������` ——
这是**抓取端编码不匹配**（bat 内部 `chcp 936`，输出是 GBK），**不是 bat 本身有问题**。
要正确读取：`python -c "...decode('gbk')"`，或直接肉眼看 cmd 窗口。
