# 04 · 关键反汇编原文

---

## 1. `sub_140082560`（RVA `0x82560`，429 字节）—— 版本/授权状态决策

这是整个修改的核心函数。开头是个**恒真/恒假**的判断，把流程分成两支：

- **分支 A**（`0x140082579`..`0x1400825FA`）：只看 `HKCU\...\s` 订阅数据 + 时间，写 `SUB` 或 `TRI`。**实际是死代码。**
- **分支 B**（`0x1400825FB` 起）：加载 `lm.x64.dll`，把模块的判定**采纳**成全局状态。**这才是真正跑的路径。**

原因：`0x14008256C` 的 `cmp byte_1406DC8F5, 0` —— 这个字节在**整个二进制里只读不写**（20 处引用全是
`cmp`/`movzx`，零写入），所以恒等于 0，后面的 `jz` **永远跳转**到分支 B。

```asm
140082560  mov     [rsp+arg_0], rcx
140082565  push    rbx / rsi / rdi
140082567  sub     rsp, 30h
14008256C  cmp     byte_1406DC8F5, 0
140082573  jz      loc_1400825FB              ; ★ 恒跳 -> 分支 B（模块判定）

; ---------------- 分支 A：死代码（订阅/Trial 写入器） ----------------
140082579  call    sub_1400A07F0
14008257E  mov     rbx, rax
140082584  call    sub_1400A0DB0
140082589  test    al, al
14008258B  jz      loc_1400825CE              ; -> 写 TRI
14008258D  cmp     qword ptr [rbx+8], 0
140082591  jz      loc_1400825CE
140082594  xor     ecx, ecx
140082597  call    unknown_libname_553        ; time(NULL)
14008259B  cmp     [rbx+8], rax
14008259E  jl      loc_1400825CE
1400825A1  call    sub_140075FE0
1400825A7  lea     rcx, [rax+8]
1400825AB  mov     r8d, 3
1400825B1  lea     rdx, aSub                  ; "SUB"
1400825B7  call    sub_14005FCF0              ; wstring assign
1400825BC  mov     dword_1406F8958, 2C5DF839h ; = 枚举 365（订阅 Professional）
1400825C6  add     rsp, 30h
1400825C9  pop     rdi / rsi / rbx
1400825CF  retn
1400825CE  call    sub_140075FE0              ; loc_1400825CE：写 TRI
1400825D4  lea     rcx, [rax+8]
1400825D8  mov     r8d, 3
1400825DE  lea     rdx, aTri                  ; "TRI"
1400825E4  call    sub_14005FCF0
1400825E9  mov     dword_1406F8958, 2C5E8B39h ; = 枚举 0（Trial）
1400825F3  add     rsp, 30h
1400825F6  pop     rdi / rsi / rbx
1400825FC  retn

; ---------------- 分支 B：真正跑的路径（模块判定） ----------------
1400825FB  call    sub_1400A1680              ; app-info 单例
140082604  mov     rsi, rax
140082607  lea     rax, [rsp+58h]
14008260F  mov     [rsp+68h], rax
14008260D  call    sub_1400601C0
140082613  test    rax, rax
140082616  jz      loc_140082702              ; -> mov ecx,80004005h; call sub_14005FF30
14008261E  mov     rax, [rax]
140082621  call    qword ptr [rax+18h]
140082625  add     rax, 18h
14008262A  mov     [rsp+58h], rax
14008262D  lea     rdx, Data
140082634  lea     rcx, [rsp+58h]
140082639  call    sub_14005F980
14008263E  test    al, al
140082640  jnz     short loc_140082657
140082642  xor     r8d, r8d
140082645  lea     rdx, Data
14008264A  lea     rcx, [rsp+58h]
14008264F  call    sub_14005FCF0
140082655  nop
140082657  lea     rcx, [rsp+58h]
14008265B  call    sub_14007D020              ; ★ LoadLmModule —— 绝对不能跳过
140082661  mov     dword ptr [rsp+60h], 0     ; 版本名 out 参数清零
14008266A  mov     ecx, dword_1406F8958
140082670  ror     ecx, 3
140082673  add     ecx, 543210EEh
140082679  ror     ecx, 5
14008267C  xor     ecx, 0ABCDEF12h
140082682  mov     [rsp+50h], ecx             ; 会话密钥参数（r9）
140082686  mov     rdi, [rax+10h]
14008268A  mov     rax, [rdi]
14008268D  mov     rbx, [rax+58h]             ; 模块 vtable+0x58
140082691  call    sub_14007D5E0
140082697  add     rax, 0C0h
14008269D  mov     [rsp+28h], rax
1400826A1  lea     r9, [rsp+50h]
1400826A7  lea     r8, [rsp+60h]
1400826AC  mov     rdx, rsi
1400826AF  mov     rcx, rdi
1400826B1  call    rbx                        ; 模块判定：out 版本名 + out 状态
; ---------- ↓↓↓ 从这里开始的 79 字节被 ED 补丁整体替换 ↓↓↓ ----------
1400826B3  mov     eax, [rsp+50h]
1400826B8  xor     eax, 0ABCDEF12h
1400826BE  ror     eax, 1Bh
1400826C1  sub     eax, 543210EEh
1400826C7  ror     eax, 1Dh
1400826CA  mov     dword_1406F8958, eax       ; 采纳模块给的状态
1400826D0  mov     rbx, [rsp+60h]             ; 模块给的版本名 wstring
1400826D4  call    sub_140075FE0
1400826D9  lea     rdi, [rax+8]
1400826DD  test    rbx, rbx
1400826E0  jnz     short loc_1400826E6
1400826E2  xor     eax, eax
1400826E4  jmp     short loc_1400826EC
1400826E6  mov     rcx, rbx
1400826E9  call    sub_1404ADC20              ; wcslen
1400826EC  mov     r8d, eax
1400826EF  mov     rdx, rbx
1400826F2  mov     rcx, rdi
1400826F7  call    sub_14005FCF0              ; config+8 = 模块字符串
1400826FA  add     rsp, 30h
1400826FD  pop     rdi / rsi / rbx
140082701  retn
; ---------- ↑↑↑ 79 字节到此结束 ↑↑↑ ----------
140082702  mov     ecx, 80004005h
140082707  call    sub_14005FF30
14008270C  db 0CCh ...
```

### 替换后的 79 字节（ED 补丁 new）

```asm
1400826B3  call    sub_140075FE0              ; E8 28 39 FF FF
1400826B8  lea     rdi, [rax+8]               ; 48 8D 78 08   -> config+8
1400826BC  mov     r8d, 3                     ; 41 B8 03 00 00 00
1400826C2  lea     rdx, aPro                  ; 48 8D 15 C7 90 5A 00 -> "PRO" @14062B790
1400826C9  mov     rcx, rdi                   ; 48 8B CF
1400826CB  call    sub_14005FCF0              ; E8 1F D6 FD FF
1400826D0  mov     dword ptr [1406F8958h], 2C5F6639h
                                              ; C7 05 7D 62 67 00 39 66 5F 2C
                                              ; = 枚举 255 = 永久 Professional
1400826DA  add     rsp, 30h                   ; 48 83 C4 30
1400826DE  pop     rdi                        ; 5F
1400826DF  pop     rsi                        ; 5E
1400826E0  pop     rbx                        ; 5B
1400826E1  retn                               ; C3
1400826E2  int3 × 31                          ; CC 填充到 79 字节
```

**全部 RIP 相对**：`E8 rel32`、`48 8D 15 rel32`、`C7 05 rel32 imm32`，无绝对地址 → 镜像基址变了也不用改。

---

## 2. 状态混淆/反混淆（数值已验证）

```python
MASK = 0xABCDEF12
K    = 0x543210EE

rol32 = lambda x, n: ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF
ror32 = lambda x, n: ((x >> n) | (x << (32 - n))) & 0xFFFFFFFF

enc = lambda e: rol32((rol32(e ^ MASK, 5) - K) & 0xFFFFFFFF, 3)
dec = lambda s: ror32((ror32(s, 3) + K) & 0xFFFFFFFF, 5) ^ MASK

enc(0)   == 0x2C5E8B39     # Trial
enc(255) == 0x2C5F6639     # 永久 Professional  ← 本包用这个
enc(365) == 0x2C5DF839     # 订阅 Professional（旧版用过，已弃用）
```

对应到指令的两个方向：

| 位置 | 指令序列 | 等价表达式 |
|---|---|---|
| `0x14008266A`（加密，作会话密钥）| `ror 3` → `add 543210EE` → `ror 5` → `xor ABCDEF12` | `dec(state)` |
| `0x1400826B3`（原版解密）| `xor ABCDEF12` → `ror 1Bh` → `sub 543210EE` → `ror 1Dh` | `dec(state)`（对偶写法）|

---

## 3. `sub_1400E9E50` 授权校验驱动（LV-1 目标）

```c
// RVA 0xE9E50 —— 关键判断（伪代码）
if (a2) goto LABEL_19;                                  // 需要校验 -> 直接起线程
v5 = sub_14007D020(&v44);                               // 取 lm 模块接口
if (module->vtbl[30](v5[2], &dword_1406F8958, 4)) return;   // vtable+120，0x78/4 字节
if (byte_1406DC8F5) goto LABEL_19;                      // 恒 0，不走

v7 = (QWORD *)(sub_1400A1680() + 80);                   // app-info +80
sub_1400A2F20(v7, 1, &v43, &v44);
if (!ok || v7[0..2] 全为空) goto LABEL_19;

v8 = (WORD *)v7[2];                                     // 第 3 个 wstring
if (!(v8[0] == L'o' && v8[1] == L'k')) {                  // 不是 "ok"
    e = dec(dword_1406F8958);
    if (e != 0xABCDEF12) { dword_1406F8958 = 0x2C5E8B39; return; }   // 打回 Trial
} else {
    v10 = sub_1404BF238(v7[1]);                         // 解析时间戳
    v11 = time(NULL);
    if (v10 > v11 || v11 - v10 >= 259200) goto LABEL_19; // 3 天内才继续
}
LABEL_19:
    ctx = malloc(0x60);
    *(QWORD*)ctx      = 539164945;         // 0x20230BF1 魔数
    *(HWND*)(ctx+8)   = *(HWND*)(a1+8);
    *((DWORD*)ctx+20) = dword_140709AB8;
    *((DWORD*)ctx+21) = 539103776;
    beginthreadex(0, 0, sub_1400CC460, ctx, 0, ctx+48);
```

> 注意中间那段 `if (e != 0xABCDEF12) { state = TRI; return; }` —— 这正是**"改成已授权就被打回 Trial"
> 的地方**，也解释了为什么单纯写注册表没用。

## 4. `sub_1400CC460` 校验线程（LV-2 目标）

```c
// RVA 0xCC460
if (*(DWORD *)a1 != 539164945) return 0;   // 魔数校验
v2 = sub_1400CADE0(...);                   // 联网校验
sub_1400A36B0(...);                        // 写 HKCU\...\l（成败都写）
if (失败)
    PostMessageW(*(HWND *)(a1 + 16), *((DWORD *)a1 + 20), *((DWORD *)a1 + 21), 0);
```

`PostMessageW` 的 `wParam = dword_140709AB8`、`lParam = 539103776`，主窗口收到后弹
`TEXT_CLEAR_REGISTRATION`（「该产品已经在太多的设备上注册…」）。

---

## 5. 两处"看起来能改但没用"的地方（记录以省时间）

**(a) 开头的 `jz`（`0x140082573`）**：改成 `jmp` 指向 `0x1400825CE`（写 TRI 的块）会**跳过整个模块初始化**，
`lm.x64.dll` 未加载 → 下游空指针 → **启动即崩溃**。教科书式的陷阱，见 `05-pitfalls.md`。

**(b) `config+8` 版本名字符串 / 注册表 `appEditionStrEn`**：都不参与标题栏显示，改它们对版本判定无效。
实测：`config+8 = "PRO"` 但状态是 TRI 时，标题仍是 `(Trial)`。
