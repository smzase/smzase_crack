# BandiView 修改交付包（去更新 / 去广告 / 已注册 Professional）

> 基准版本：**BandiView 8.03，build 34280（x64，2026/10/13）**
> `BandiView.exe` 大小 7,722,944 字节，ImageBase `0x140000000`
> 打完全部补丁后与原始文件相差 **302 字节**（文件大小不变）

---

## 一、这个包是什么

一份可复现、可维护的修改套件：**交付成品 + 逆向思路文档 + 全部工具脚本 + 关键函数反编译参考**。
所有改动都是 **同长度原位字节补丁**，用 **32 字节唯一签名扫描**定位，**与文件偏移无关** ——
所以官方安装包升级替换 `BandiView.exe` 之后，只要重跑一次 bat 就能把补丁自动打回去。

---

## 二、30 秒上手

| 场景 | 操作 |
|---|---|
| 现在就想用 | 双击 `01-delivery\BandiView-Patch.bat` |
| 已经打过补丁 | 再双击一次即可（全部显示 `[SKIP]`，文件零改动） |
| 官方安装包更新后 | **先退出 BandiView**，双击同一个 bat |
| 想彻底还原官方原版 | 把 `01-delivery\BandiView.exe.orig` 改名覆盖成 `BandiView.exe` |
| 懒人直用成品 | `01-delivery\BandiView.exe.patched` 改名成 `BandiView.exe`（已含全部 8 处补丁） |

bat 必须和 `BandiView.exe` **放在同一个目录**（脚本用 `%~dp0` 定位目标文件）。
权限不足会提示「右键 → 以管理员身份运行」；BandiView 正在运行会 `[STOP]` 且**不写任何字节**。

---

## 三、改了什么（8 处补丁）

| # | 目标函数 | RVA | 手法 | 效果 |
|---|---|---|---|---|
| AD-1 | `LaunchPopupAdWindow` | `0x65210` | `xor eax,eax; ret` | 启动/切图时的**弹窗广告**不再拉起 |
| AD-2 | `CreateAdWindow` | `0x64EC0` | `xor eax,eax; ret` | 内嵌 **BandiViewAdWnd 广告窗**不再创建（`/ad` 参数一并失效） |
| UP-1 | `CheckHavetoUpdate` | `0x9E9C0` | `xor eax,eax; ret` | 版本判定恒返回 0 → **永远无更新** |
| UP-2 | `FetchVersionInfo + CUpdateDlg` | `0xD5520` | `ret` | 不联网拉 `versioninfo.ini`，**更新弹窗**永不出现 |
| UP-3 | `CHK_UPDATE` 任务处理器 | `0x11D3F0` | `xor eax,eax; ret` | 定时更新任务 + 顺带的**授权引导弹窗**一起停 |
| ED | `sub_140082560` 尾部 79 字节 | `0x826B3` | 尾部整体改写为定值桩 | 丢弃 lm 模块的判定，写入**枚举 255 = 永久 Professional** |
| LV-1 | `LicenceVerifyDriver` | `0xE9E50` | `xor eax,eax; ret` | 授权联网校验线程**不再启动** |
| LV-2 | `LicenceVerifyThread` | `0xCC460` | `xor eax,eax; ret` | 校验线程体直接返回，**不再 `PostMessage` 弹授权框** |

外加 bat 顺手写的注册表开关：`updateChk=0`、`updateBeta=0`、`appEditionStrEn=PRO`、
`lastShowADDay=<今天>`、`HKCU\Software\BandiView\l\a=PRO`。

> 广告是**彻底关掉**不是只挡住日期闸：广告窗口类 `BandiViewAdWnd` 的创建函数和它的启动器都被砍掉。
> 更新是**彻底断链**不是只改注册表开关：判定、拉取、弹窗、定时任务四条路径全断，只能靠安装包更新。

---

## 四、验证过的结果（实测）

| 项目 | 结果 |
|---|---|
| 干净状态运行 bat | 8 处全 `[ OK ]`，输出「已写入 8 处修改」 |
| 与原始文件对比 | 差 **302 字节**，尺寸不变 7,722,944 |
| 启动开图 | 标题栏 `… - BandiView (Professional)`（原版是 `(Trial)`），**无任何弹窗** |
| 空闲 30 秒 | 依然干净，状态不回退 |
| `BandiView.exe /ad` | 进程**立即退出**，子进程 0 个（原版会常驻 + 1 个 WebView2 子进程） |
| 按 F1 关于/注册对话框 | 正常打开，不崩、不弹「设备过多」、版本状态不变 |
| 幂等（连跑两次） | 第二次全部 `[SKIP]`，字节数不变 |
| 文件被占用 | 输出 `[STOP]`，**零字节改动** |

---

## 五、目录结构

```
BandiView-Mod-Kit/
├── README.md                        ← 本文件
├── 01-delivery/                     交付成品
│   ├── BandiView-Patch.bat          双击运行的补丁器（8 处补丁 + 注册表开关）
│   ├── BandiView.exe.orig           原始未修改备份（还原用）
│   └── BandiView.exe.patched        已打好全部补丁的成品
├── 02-docs/                         思路文档
│   ├── 01-architecture.md           软件结构 / 授权模型 / 更新链 / 广告链
│   ├── 02-patch-table.md            8 处补丁逐个：签名、原字节、新字节、语义、风险
│   ├── 03-symbols.md                关键函数与字符串地址索引
│   ├── 04-disassembly.md            关键反汇编原文（ED 桩、版本函数、校验链）
│   ├── 05-pitfalls.md               踩坑与失败记录（含两次崩溃/误判的根因）
│   └── 06-maintenance.md            以后换版本怎么改：重定位 / 加补丁 / 验证流程
├── 03-tools/                        全部工具脚本
│   ├── make_bat.py                  由补丁表生成 BandiView-Patch.bat（改补丁表就在这里）
│   ├── mk_ed.py                     ED 定值桩生成器（自动算 RIP 相对 rel32）
│   ├── pktable.py                   打印/校验补丁表（含签名唯一性命中数）
│   ├── mkvar.py                     从补丁表生成单/多补丁变体，用于二分定位
│   ├── pe_map.py                    PE 节表映射 + 签名命中统计
│   ├── sigs.py                      签名唯一性 + 指针跟随（解析 lea rdx,[rip+disp] 目标）
│   ├── diffcheck.py                 原始 vs 已打补丁 的分组字节差异
│   ├── strings.py                   ascii + UTF-16LE 字符串扫描器
│   ├── find_msg.py / find_msg2.py   全目录搜索文案（定位弹窗来自哪个语言文件）
│   ├── findref.py                   找某字符串的 RIP 相对引用（确认字符串是否在 exe 内）
│   ├── win.ps1                      枚举进程顶层/子窗口（诊断弹窗必备）
│   ├── child.ps1 / menu.ps1         UI 探测辅助
│   └── seed.json / funcset.json     IDA 侧导出数据
└── 04-decompiled/                   251 个 Hex-Rays 伪代码文件
    ├── _index.json                  EA → 文件名 / 函数名 / 大小
    ├── _strings.txt                 关键字符串 + 交叉引用
    └── 00000001400xxxxx_名字.c       按地址命名，直接搜索即可
```

---

> 注：文档里出现的 `_work\xxx.py` 就是本包 `03-tools\xxx.py`（同一批脚本，原件在工程目录 `D:\11github\BandiView\_work\`）。

## 六、最短修改路线（给未来的自己）

1. 官方升级了版本 → 先跑 `03-tools\pktable.py`，看 8 条签名是否还命中（`hits=1` 就是命中）。
2. 有 `[MISS]` → 打开 `04-decompiled` 找到对应函数，或按 `02-docs/06-maintenance.md` 用 IDA 重新定位。
3. 改动写进 `03-tools/make_bat.py` 的 `$PATCHES` 表（就一张表，别处不用碰）。
4. `python 03-tools\make_bat.py` 重新生成 bat → 跑一遍 → 看窗口标题是否是 `(Professional)`。
5. 校验：`python 03-tools\diffcheck.py`，差异应正好覆盖 8 个区域。

---

## 七、边界说明

- 本包只改 **本机文件**，不联网、不破解服务器、不伪造产品密钥，因此官方授权校验链被"绕过"而非被"欺骗"。
- 更新通道由 bat 主动断掉；要新功能请**自行下载官方安装包覆盖安装**，然后重跑 bat。
- 安装包若改了 exe 结构导致签名不命中，bat 会明确报 `[MISS]` 并跳过（**不会乱写**），此时按 `06-maintenance.md` 重定位。
