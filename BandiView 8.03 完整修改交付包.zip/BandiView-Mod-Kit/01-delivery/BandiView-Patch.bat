@echo off
setlocal
cd /d "%~dp0"
chcp 936 >nul 2>&1
title BandiView patch - no update / no ads / registered
set "BV_PATCH_BAT=%~f0"
set "BV_WHERE=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$a=[IO.File]::ReadAllLines($env:BV_PATCH_BAT,[Text.Encoding]::UTF8);$k=-1;for($j=0;$j -lt $a.Length;$j++){if($a[$j].Trim() -eq ('#::PS'+'START')){$k=$j+1;break}};if($k -lt 0){Write-Host 'marker not found';exit 9};Invoke-Expression ($a[$k..($a.Length-1)] -join [char]10)"
set "RC=%ERRORLEVEL%"
echo.
pause
exit /b %RC%
#::PSSTART
#Requires -Version 5
$ErrorActionPreference = 'Stop'
$enc = [Text.Encoding]::GetEncoding(28591)

function FromHex([string]$h) {
  $h = $h -replace '[^0-9A-Fa-f]', ''
  $n = [int]($h.Length / 2)
  $a = New-Object byte[] $n
  for ($i = 0; $i -lt $n; $i++) { $a[$i] = [Convert]::ToByte($h.Substring($i * 2, 2), 16) }
  return ,$a
}
function Say([string]$t, [string]$c) {
  if ($c) { Write-Host $t -ForegroundColor $c } else { Write-Host $t }
}
function Pad32([string]$stubHex) {
  while ($stubHex.Length -lt 64) { $stubHex = $stubHex + '90' }
  return $stubHex
}

$root = $env:BV_WHERE
if (-not $root) { $root = (Get-Location).Path }
$exe = Join-Path $root 'BandiView.exe'
$bak = Join-Path $root 'BandiView.exe.orig'

Say ''
Say '=========================================================='
Say '   BandiView   去更新 / 去广告 / 已注册版   一键补丁'
Say '   目标：BandiView build 34280  (x64)'
Say '=========================================================='
Say ''

if (-not (Test-Path -LiteralPath $exe)) {
  Say ('[错误] 当前目录没有 BandiView.exe ： ' + $exe) 'Red'
  exit 1
}

$bytes = [IO.File]::ReadAllBytes($exe)
$src   = $enc.GetString($bytes)

$peOff = [BitConverter]::ToInt32($bytes, 0x3C)
$nsec  = [BitConverter]::ToUInt16($bytes, $peOff + 6)
$optsz = [BitConverter]::ToUInt16($bytes, $peOff + 20)
$opt   = $peOff + 24
$secTab = $opt + $optsz
$secs = @()
for ($i = 0; $i -lt $nsec; $i++) {
  $o = $secTab + $i * 40
  $va  = [BitConverter]::ToUInt32($bytes, $o + 12)
  $vsz = [BitConverter]::ToUInt32($bytes, $o + 8)
  $rsz = [BitConverter]::ToUInt32($bytes, $o + 16)
  $ro  = [BitConverter]::ToUInt32($bytes, $o + 20)
  $secs += [pscustomobject]@{ VA = $va; SZ = [Math]::Max($vsz, $rsz); RO = $ro }
}
function Rva2Off([int64]$rva) {
  foreach ($x in $secs) {
    if ($rva -ge $x.VA -and $rva -lt ($x.VA + $x.SZ)) { return [int]($x.RO + ($rva - $x.VA)) }
  }
  return -1
}

# ---- 补丁表：old = 函数入口唯一签名(32B) / stub = 替换的前几字节 / rva = 本版本(仅用于已打过判定) ----
$PATCHES = @(
  @{ name = 'AD-1  弹窗广告启动器  LaunchPopupAdWindow'
     rva = 0x65210 ; stub = '31C0C3'
     old = '48895C24104889742418574883EC50488BFA488BF1488D4424304889442440E8' },
  @{ name = 'AD-2  广告窗口创建器  CreateAdWindow'
     rva = 0x64EC0 ; stub = '31C0C3'
     old = '405553565741564157488D6C24D14881EC98000000488B05645167004833C448' },
  @{ name = 'UP-1  更新判定  CheckHavetoUpdate -> 0 (永远无更新)'
     rva = 0x9E9C0 ; stub = '31C0C3'
     old = '40555356574154415541564157488D6C24F84881EC08010000488B0560B66300' },
  @{ name = 'UP-2  更新下载 + 更新弹窗  FetchVersionInfo + UpdateDlg'
     rva = 0xD5520 ; stub = 'C3'
     old = '40555356574154415541564157488DAC24C8F6FFFF4881EC380A0000488B05FD' },
  @{ name = 'UP-3  定时更新任务 + 授权引导弹窗  CHK_UPDATE handler'
     rva = 0x11D3F0 ; stub = '31C0C3'
     old = '48895C2408488954241055565741564157488D6C24C94881ECD0000000488BFA' },
  @{ name = 'ED    版本判定尾部改写 -> 已授权 Professional  (保留 lm 模块加载)'
     rva = 0x826B3 ; stub = 'E82839FFFF488D780841B803000000488D15C7905A00488BCFE81FD6FDFFC7057D62670039665F2C4883C4305F5E5BC3CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC'
     old = '8B4424503512EFCDABC1C81B2DEE103254C1C81D89058B626700488B5C2460E80939FFFF488D78084885DB750433C0EB08488BCBE834B54200448BC0488BD3488BCFE8F6D5FDFF4883C4305F5E5BC3' },
  @{ name = 'LV-1  授权联网校验驱动  LicenceVerifyDriver -> 0 (不再启动校验线程)'
     rva = 0xE9E50 ; stub = '31C0C3'
     old = '48895C24085556574154415541564157488BEC4883EC504C8BE94533E4448965' },
  @{ name = 'LV-2  授权联网校验线程  LicenceVerifyThread -> 0 (不会 PostMessage 弹框)'
     rva = 0xCC460 ; stub = '31C0C3'
     old = '488BC4555356574156488D68A14881ECB00000000F2970C80F2978B8488BF981' }
)

# ---- 备份策略：文件尚未打补丁（能找到原始签名）且与备份不同 -> 刷新备份 ----
$anyOrig = $false
foreach ($p in $PATCHES) {
  if ($src.IndexOf($enc.GetString((FromHex $p.old)), [StringComparison]::Ordinal) -ge 0) { $anyOrig = $true; break }
}
$refresh = ((-not (Test-Path -LiteralPath $bak)) -or $anyOrig)
if ($refresh) {
  Copy-Item -LiteralPath $exe -Destination $bak -Force
  Say '[备份] 已(重新)创建 BandiView.exe.orig —— 这是未修改的原始文件' 'Cyan'
} else {
  Say '[备份] 保留现有 BandiView.exe.orig' 'DarkGray'
}

Say '[1/2] 代码补丁'
$changed = 0
foreach ($p in $PATCHES) {
  $old = FromHex $p.old
  if ($p.name.StartsWith('ED-')) { $newHex = $p.stub }
  else { $newHex = Pad32 $p.stub }
  $new = FromHex $newHex
  if ($new.Length -ne $old.Length) {
    Say ('  [BUG ] ' + $p.name + ' 长度不一致 ' + $new.Length + '/' + $old.Length) 'Red'
    continue
  }
  $idx = $src.IndexOf($enc.GetString($old), [StringComparison]::Ordinal)
  if ($idx -ge 0) {
    for ($i = 0; $i -lt $new.Length; $i++) { $bytes[$idx + $i] = $new[$i] }
    $changed++
    Say ('  [ OK ] ' + $p.name) 'Green'
    continue
  }
  $done = $false
  $po = Rva2Off ([int64]$p.rva)
  if ($po -ge 0) {
    $stub = FromHex $p.stub
    $ok = $true
    for ($i = 0; $i -lt $stub.Length; $i++) {
      if ($po + $i -ge $bytes.Length) { $ok = $false; break }
      if ($bytes[$po + $i] -ne $stub[$i]) { $ok = $false; break }
    }
    $done = $ok
  }
  if ($done) { Say ('  [SKIP] ' + $p.name + '   (本文件已是补丁状态)') 'DarkGray' }
  else       { Say ('  [MISS] ' + $p.name + '   (签名未命中，版本结构可能已变，已跳过)') 'Yellow' }
}

Say ''
Say '[2/2] 写回文件'
if ($changed -gt 0) {
  $locked = $false ; $denied = $false
  try { $fs = [IO.File]::Open($exe, 'Open', 'ReadWrite', 'None'); $fs.Close() }
  catch {
    if ($_.Exception -is [System.UnauthorizedAccessException]) { $denied = $true } else { $locked = $true }
  }
  if ($denied) {
    Say '  [STOP] 没有写入权限，无法修改 BandiView.exe。' 'Red'
    Say '         请右键本文件 -> 以管理员身份运行。本次未做任何修改。' 'Red'
    return
  }
  if ($locked) {
    Say '  [STOP] BandiView 正在运行（或文件被占用），无法写入。' 'Red'
    Say '         请先彻底退出 BandiView（含托盘图标）后再运行本文件。' 'Red'
    Say '         本次未做任何修改。' 'Red'
    return
  }
  [IO.File]::WriteAllBytes($exe, $bytes)
  Say ('  已写入 ' + $changed + ' 处修改  ->  ' + $exe) 'Cyan'
} else {
  Say '  没有需要写入的修改（已是补丁状态，或全部未命中）' 'DarkGray'
}

Say ''
Say '注册表开关：关自动更新 / 标记为已注册 PRO'
$rk = 'HKCU:\Software\BandiView'
if (Test-Path -LiteralPath $rk) {
  $bad = $false
  try {
    Set-ItemProperty -LiteralPath $rk -Name 'updateChk'  -Value 0 -Type DWord
    Set-ItemProperty -LiteralPath $rk -Name 'updateBeta' -Value 0 -Type DWord
    Set-ItemProperty -LiteralPath $rk -Name 'appEditionStrEn' -Value 'PRO' -Type String
    $today = [int](Get-Date -Format 'yyyyMMdd')
    Set-ItemProperty -LiteralPath $rk -Name 'lastShowADDay' -Value $today -Type DWord
  } catch { $bad = $true ; Say ('  [WARN] ' + $_.Exception.Message) 'Yellow' }
  $rl = Join-Path $rk 'l'
  if (Test-Path -LiteralPath $rl) {
    try { Set-ItemProperty -LiteralPath $rl -Name 'a' -Value 'PRO' -Type String }
    catch { $bad = $true }
  }
  if (-not $bad) { Say '  [ OK ] updateChk=0   updateBeta=0   appEditionStrEn=PRO   广告日闸=今天   l\a=PRO' 'Green' }
} else {
  Say '  [SKIP] 注册表项还不存在：先启动一次 BandiView，再运行本补丁' 'DarkGray'
}

Say ''
Say '=========================================================='
Say '  全部完成。本次改动：'
Say '    1) 内置更新器全部停用：版本检查、版本拉取、更新弹窗、更新任务'
Say '       -> 程序再也不会自己联网升级，也不会有“发现新版本”提示'
Say '    2) 广告全部停用：内嵌广告窗口、启动/切换图片时的弹窗广告'
Say '       -> /ad 启动参数也失效'
Say '    3) 版本标识改为已注册 Professional（完整功能）'
Say '    4) 授权联网校验关闭：不再联网校验注册，也不会弹'
Say '       “该产品已经在太多的设备上注册…是否重置”之类的授权提示'
Say ''
Say '  * 以后更新只用官方安装包：下载后覆盖安装即可，程序不会自动更新。'
Say '  * 覆盖安装会替换 BandiView.exe，安装完成后重新双击本 bat 打一次补丁即可。'
Say '  * 想还原：把 BandiView.exe.orig 改名回 BandiView.exe。'
Say '=========================================================='
Say ''
