// EA 0x1400bf760  name sub_1400BF760  size 398
char __fastcall sub_1400BF760(__int64 *a1, int a2)
{
  __int64 v3; // rcx
  __int64 v4; // rsi
  __int64 v5; // rdi
  __int64 *v6; // rax
  int v7; // eax
  __int64 v8; // rcx
  __int64 v10; // rdi
  __int64 *v11; // rax
  __int64 v12; // rcx
  int *v13; // [rsp+40h] [rbp+18h] BYREF
  int **v14; // [rsp+48h] [rbp+20h]

  if ( a2 < 0 || (v3 = a1[131], a2 >= (int)((a1[132] - v3) >> 5)) )
  {
    *((_DWORD *)a1 + 269) = -1;
    v10 = *a1;
    v14 = &v13;
    v11 = sub_1400601C0();
    if ( v11 == nullptr )
      sub_14005FF30(0x80004005);
    v13 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24);
    if ( (unsigned __int8)sub_14005F980(&v13, (__int64)&Data) == 0 )
      sub_14005FCF0(&v13, &Data, 0);
    (*(void (__fastcall **)(__int64 *, int **))(v10 + 40))(a1, &v13);
    v12 = a1[66];
    if ( v12 != 0 )
      sub_1401BC8D0(v12, a1 + 33);
    return 0;
  }
  else
  {
    *((_DWORD *)a1 + 269) = a2;
    v4 = *a1;
    v14 = &v13;
    v5 = v3 + 32LL * a2;
    if ( *(_QWORD *)(v5 + 24) > 7u )
      v5 = *(_QWORD *)v5;
    v6 = sub_1400601C0();
    if ( v6 == nullptr )
      sub_14005FF30(0x80004005);
    v13 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
    if ( (unsigned __int8)sub_14005F980(&v13, v5) == 0 )
    {
      if ( v5 != 0 )
        v7 = sub_1404ADC20(v5);
      else
        v7 = 0;
      sub_14005FCF0(&v13, (_BYTE *)v5, v7);
    }
    (*(void (__fastcall **)(__int64 *, int **))(v4 + 40))(a1, &v13);
    v8 = a1[66];
    if ( v8 != 0 )
      sub_1401BC8D0(v8, a1 + 33);
    return 1;
  }
}
