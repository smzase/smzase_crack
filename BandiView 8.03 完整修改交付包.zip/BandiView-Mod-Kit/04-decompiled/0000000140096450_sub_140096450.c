// EA 0x140096450  name sub_140096450  size 212
__int64 __fastcall sub_140096450(HWND *a1, int a2, int **a3)
{
  HWND DlgItem; // rax
  HWND v5; // rsi
  int v6; // edi
  int WindowTextW; // eax
  unsigned int v8; // edi

  DlgItem = GetDlgItem(*a1, a2);
  v5 = DlgItem;
  if ( DlgItem != nullptr )
  {
    v6 = GetWindowTextLengthW(DlgItem) + 1;
    if ( v6 < 0 )
      goto LABEL_13;
    if ( ((*(*a3 - 3) - v6) | (1 - *(*a3 - 2))) < 0 )
      sub_14005FC80(a3, v6);
    WindowTextW = GetWindowTextW(v5, (LPWSTR)*a3, v6);
    v8 = WindowTextW;
    if ( WindowTextW == -1 )
    {
      if ( *a3 != nullptr )
        WindowTextW = sub_1404ADD70(*a3, *(*a3 - 3));
      else
        WindowTextW = 0;
    }
    if ( WindowTextW < 0 || WindowTextW > *(*a3 - 3) )
LABEL_13:
      sub_14005FF30(0x80070057);
    *(*a3 - 4) = WindowTextW;
    *((_WORD *)*a3 + WindowTextW) = 0;
    return v8;
  }
  else
  {
    sub_14005FA90(a3);
    return 0;
  }
}
