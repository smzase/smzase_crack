// EA 0x140064ec0  name sub_140064EC0  size 814
__int64 sub_140064EC0()
{
  __int64 *v0; // rax
  int v1; // ebx
  bool v2; // bl
  HANDLE MutexW; // r14
  bool v4; // zf
  int v5; // eax
  unsigned int v6; // esi
  char *v7; // rdi
  char *v8; // rbx
  __int64 *v9; // rax
  _QWORD *v10; // rax
  int *v12; // [rsp+20h] [rbp-49h] BYREF
  int **v13; // [rsp+28h] [rbp-41h] BYREF
  __int128 v14; // [rsp+30h] [rbp-39h]
  char *v15; // [rsp+40h] [rbp-29h]
  int **v16; // [rsp+48h] [rbp-21h]
  struct tagMSG Msg; // [rsp+58h] [rbp-11h] BYREF

  v13 = &v12;
  v0 = sub_1400601C0();
  if ( v0 == nullptr )
    sub_14005FF30(0x80004005);
  v12 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v0 + 24))(v0) + 24);
  if ( (unsigned __int8)sub_14005F980(&v12, (__int64)L"HKLM/SOFTWARE/BandiView/InstDate") == 0 )
    sub_14005FCF0(&v12, L"HKLM/SOFTWARE/BandiView/InstDate", 32);
  v1 = sub_140083540(&v12);
  v2 = v1 == (unsigned int)sub_140074720();
  v14 = 0;
  MutexW = CreateMutexW(nullptr, false, L"BandiViewAD");
  *(_QWORD *)&v14 = MutexW;
  if ( MutexW == nullptr || (v4 = GetLastError() == 183, v5 = 0, !v4) )
    v5 = 1;
  DWORD2(v14) = v5;
  if ( v5 != 0 )
  {
    v7 = (char *)operator new(0x928u);
    v13 = (int **)v7;
    memset(v7, 0, 0x928u);
    *((_QWORD *)v7 + 1) = 0;
    *((_QWORD *)v7 + 5) = 0;
    *((_QWORD *)v7 + 6) = 0;
    *((_DWORD *)v7 + 14) = 0;
    *((_QWORD *)v7 + 8) = DefWindowProcW;
    *(_QWORD *)v7 = &AdWnd::`vftable';
    *((_QWORD *)v7 + 9) = &AdWnd::`vftable';
    v7[80] = 0;
    sub_1401B9500(v7 + 88);
    *((_QWORD *)v7 + 251) = 0;
    *((_QWORD *)v7 + 252) = 0;
    *((_QWORD *)v7 + 253) = 0;
    *((_QWORD *)v7 + 254) = 0;
    *((_DWORD *)v7 + 510) = 0;
    sub_14006B880(v7 + 2048);
    v7[2088] = 0;
    sub_14006C980(v7 + 2096);
    *((_WORD *)v7 + 1160) = 0;
    *((_QWORD *)v7 + 291) = GetTickCount64();
    v7[2336] = 0;
    *((_DWORD *)v7 + 585) = 15;
    v7[80] = v2;
    v8 = v7;
    v15 = v7;
    memset(&Msg, 0, sizeof(Msg));
    if ( (unsigned int)sub_14005D8B0((__int64)v7) != 0 )
    {
      v16 = &v12;
      v9 = sub_1400601C0();
      if ( v9 == nullptr )
        sub_14005FF30(0x80004005);
      v12 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
      if ( (unsigned __int8)sub_14005F980(&v12, (__int64)L"skin_ad.xml") == 0 )
        sub_14005FCF0(&v12, L"skin_ad.xml", 11);
      v10 = (_QWORD *)sub_1400697A0(&v13);
      if ( (unsigned int)sub_14005DF70((__int64)v7, v10, &v12) != 0 )
      {
        SetTimer(*((HWND *)v7 + 1), 9u, 0x3E8u, nullptr);
        while ( GetMessageW(&Msg, nullptr, 0, 0) )
        {
          TranslateMessage(&Msg);
          DispatchMessageW(&Msg);
        }
        v8 = nullptr;
        (*(void (__fastcall **)(char *, __int64))(*(_QWORD *)v7 + 8LL))(v7, 1);
        v6 = 0;
        v7 = nullptr;
      }
      else
      {
        v6 = 3;
      }
    }
    else
    {
      v6 = 1;
    }
    if ( v8 != nullptr && v7 != nullptr )
      (*(void (__fastcall **)(char *, __int64))(*(_QWORD *)v7 + 8LL))(v7, 1);
  }
  else
  {
    v6 = 0;
  }
  if ( MutexW != nullptr )
    CloseHandle(MutexW);
  return v6;
}
