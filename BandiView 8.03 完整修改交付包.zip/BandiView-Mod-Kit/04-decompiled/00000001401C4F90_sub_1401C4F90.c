// EA 0x1401c4f90  name sub_1401C4F90  size 131
__int64 __fastcall sub_1401C4F90(__int64 a1, _QWORD *a2, unsigned int a3)
{
  __int64 v6; // rax
  volatile signed __int32 *v7; // rdx
  signed __int32 v8; // eax
  bool v9; // cc
  __int64 result; // rax
  __int64 v11; // [rsp+48h] [rbp+20h] BYREF

  v11 = sub_14005F710((volatile signed __int32 *)(*a2 - 24LL)) + 24;
  v6 = sub_1401BE5D0(a1, &v11);
  if ( v6 != 0 )
    (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v6 + 256LL))(v6, a3);
  v7 = (volatile signed __int32 *)(*a2 - 24LL);
  v8 = _InterlockedExchangeAdd(v7 + 4, 0xFFFFFFFF);
  v9 = v8 <= 1;
  result = (unsigned int)(v8 - 1);
  if ( v9 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v7 + 8LL))(*(_QWORD *)v7);
  return result;
}
