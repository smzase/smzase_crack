// EA 0x1404bf238  name sub_1404BF238  size 178
__int64 sub_1404BF238()
{
  __int64 v0; // rdi
  int v1; // ebx
  int v2; // ebx
  _QWORD v4[2]; // [rsp+30h] [rbp-40h] BYREF
  char v5; // [rsp+40h] [rbp-30h]
  __int128 v6; // [rsp+48h] [rbp-28h]
  char v7; // [rsp+58h] [rbp-18h]
  int v8; // [rsp+5Ch] [rbp-14h]
  char v9; // [rsp+60h] [rbp-10h]
  int v10; // [rsp+64h] [rbp-Ch]
  char v11; // [rsp+68h] [rbp-8h]

  v4[0] = 0;
  v5 = 0;
  v7 = 0;
  v9 = 0;
  v11 = 0;
  if ( dword_140706A14 == 0 )
  {
    v7 = 1;
    v6 = *(_OWORD *)&off_1406DA408;
  }
  v0 = __crt_strtox::parse_integer<unsigned __int64,__crt_strtox::c_string_character_source<wchar_t>,1>((__crt_cached_ptd_host *)v4);
  if ( v7 == 2 )
    *(_DWORD *)(v4[0] + 936LL) &= ~2u;
  if ( v9 != 0 )
  {
    v1 = v8;
    *(_DWORD *)(unknown_libname_531(v4) + 32) = v1;
  }
  if ( v11 != 0 )
  {
    v2 = v10;
    *(_DWORD *)(unknown_libname_531(v4) + 36) = v2;
  }
  return v0;
}
