// EA 0x140065af0  name sub_140065AF0  size 5
// attributes: thunk
__int64 __fastcall sub_140065AF0(__int64 a1, const WCHAR *a2)
{
  return sub_140065730(a1, a2);
}
