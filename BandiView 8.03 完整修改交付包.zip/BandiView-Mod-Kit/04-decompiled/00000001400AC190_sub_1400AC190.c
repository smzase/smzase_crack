// EA 0x1400ac190  name sub_1400AC190  size 171
__int64 __fastcall sub_1400AC190(_QWORD *a1)
{
  volatile signed __int32 *v2; // rdx
  signed __int32 v3; // eax
  bool v4; // cc
  __int64 result; // rax
  __int64 v6; // [rsp+38h] [rbp+10h] BYREF

  v6 = sub_14005F710((volatile signed __int32 *)(*a1 - 24LL)) + 24;
  sub_1400ABC90(&v6, -2147483647);
  v6 = sub_14005F710((volatile signed __int32 *)(*a1 - 24LL)) + 24;
  sub_1400ABC90(&v6, -2147483646);
  v6 = sub_14005F710((volatile signed __int32 *)(*a1 - 24LL)) + 24;
  sub_1400ABC90(&v6, 0xFFFFFFFF80000000uLL);
  v2 = (volatile signed __int32 *)(*a1 - 24LL);
  v3 = _InterlockedExchangeAdd(v2 + 4, 0xFFFFFFFF);
  v4 = v3 <= 1;
  result = (unsigned int)(v3 - 1);
  if ( v4 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v2 + 8LL))(*(_QWORD *)v2);
  return result;
}
