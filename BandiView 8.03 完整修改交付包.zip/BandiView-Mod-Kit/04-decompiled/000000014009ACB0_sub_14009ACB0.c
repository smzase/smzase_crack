// EA 0x14009acb0  name sub_14009ACB0  size 309
__int64 *__fastcall sub_14009ACB0(__int64 *a1)
{
  __int64 *v2; // rax
  __int64 v3; // rax
  int v4; // eax
  _QWORD *v5; // rax
  bool v6; // di
  _QWORD *v7; // rdx
  __int64 v9; // [rsp+58h] [rbp+10h] BYREF

  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  v3 = (*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24;
  *a1 = v3;
  if ( ((*(_DWORD *)(v3 - 12) - 260) | (1 - *(_DWORD *)(v3 - 8))) < 0 )
    sub_14005FC80(a1, 260);
  SHGetFolderPathW(nullptr, 39, nullptr, 0, (LPWSTR)*a1);
  if ( *a1 != 0 )
  {
    v4 = sub_1404ADD70(*a1, *(int *)(*a1 - 12));
    if ( v4 < 0 )
      goto LABEL_18;
  }
  else
  {
    v4 = 0;
  }
  if ( v4 > *(_DWORD *)(*a1 - 12) )
LABEL_18:
    sub_14005FF30(0x80070057);
  *(_DWORD *)(*a1 - 16) = v4;
  *(_WORD *)(*a1 + 2LL * (unsigned int)v4) = 0;
  v5 = (_QWORD *)sub_14006B260(a1, &v9, 1);
  v6 = *(_DWORD *)(*v5 - 16LL) != 1 || *(_WORD *)*v5 != 92;
  v7 = (_QWORD *)(v9 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v9 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v7 + 8LL))(*v7);
  if ( v6 )
    sub_14006B780(a1, 92);
  return a1;
}
