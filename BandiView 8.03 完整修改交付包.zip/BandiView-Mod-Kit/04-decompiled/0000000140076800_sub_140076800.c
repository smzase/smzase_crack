// EA 0x140076800  name sub_140076800  size 1865
__int64 __fastcall sub_140076800(__int64 a1)
{
  __int64 v2; // rcx
  __int64 v3; // rbx
  int *v4; // rax
  int v5; // edi
  int v6; // r10d
  int v7; // r9d
  int v8; // r8d
  int v9; // eax
  int v10; // edx
  _BYTE **v11; // rax
  _QWORD *v12; // rdx
  __int64 *v13; // rax
  int v14; // eax
  _QWORD *v15; // rdx
  __int64 result; // rax
  __int128 pvParam; // [rsp+20h] [rbp-248h] BYREF
  WCHAR Buffer[264]; // [rsp+30h] [rbp-238h] BYREF

  sub_14005FA90((int **)(a1 + 16));
  *(_QWORD *)(a1 + 24) = 0;
  *(_QWORD *)(a1 + 32) = 0;
  *(_QWORD *)(a1 + 40) = 0;
  *(_QWORD *)(a1 + 48) = 0;
  sub_140065D40(v2, *(_QWORD ***)(a1 + 56));
  **(_QWORD **)(a1 + 56) = *(_QWORD *)(a1 + 56);
  *(_QWORD *)(*(_QWORD *)(a1 + 56) + 8LL) = *(_QWORD *)(a1 + 56);
  *(_QWORD *)(a1 + 64) = 0;
  *(_BYTE *)(a1 + 72) = 0;
  *(_DWORD *)(a1 + 76) = 0;
  pvParam = 0;
  SystemParametersInfoW(0x30u, 0, &pvParam, 0);
  v3 = 1000LL * *(int *)sub_1401C0040() / 96;
  v4 = (int *)sub_1401C0040();
  v5 = DWORD2(pvParam);
  v6 = (DWORD2(pvParam) - (int)v3 - (int)pvParam) / 2;
  v7 = HIDWORD(pvParam);
  v8 = DWORD1(pvParam);
  v9 = (int)(HIDWORD(pvParam) - 800LL * *v4 / 96 - DWORD1(pvParam)) / 2;
  v10 = v9;
  if ( v6 < 0 )
    v6 = 0;
  if ( v9 < 0 )
    v10 = 0;
  *(_DWORD *)(a1 + 80) = v6 + pvParam;
  *(_DWORD *)(a1 + 88) = v5 - v6;
  *(_DWORD *)(a1 + 84) = v10 + v8;
  *(_DWORD *)(a1 + 92) = v7 - v10;
  SetRectEmpty((LPRECT)(a1 + 96));
  *(_DWORD *)(a1 + 112) = 0;
  SetRectEmpty((LPRECT)(a1 + 116));
  *(_QWORD *)(a1 + 132) = 0;
  *(_DWORD *)(a1 + 140) = 300;
  *(_DWORD *)(a1 + 144) = 180;
  *(_DWORD *)(a1 + 148) = 100;
  *(_QWORD *)(a1 + 152) = 100;
  *(_DWORD *)(a1 + 160) = 0;
  *(_DWORD *)(a1 + 164) = 65537;
  *(_BYTE *)(a1 + 168) = 0;
  *(_DWORD *)(a1 + 172) = 2;
  *(_DWORD *)(a1 + 176) = 1;
  *(_DWORD *)(a1 + 180) = 16777217;
  *(_DWORD *)(a1 + 184) = 16843009;
  *(_WORD *)(a1 + 188) = 1;
  *(_BYTE *)(a1 + 190) = (unsigned int)sub_14006E550() < 0x12;
  *(_DWORD *)(a1 + 191) = 16843008;
  *(_BYTE *)(a1 + 195) = 1;
  *(_QWORD *)(a1 + 196) = 0;
  *(_DWORD *)(a1 + 204) = 2105376;
  *(_QWORD *)(a1 + 208) = 4473924;
  *(_BYTE *)(a1 + 216) = 1;
  sub_14005FCF0((int **)(a1 + 224), L"${folder} ${sep} ${file} [${page}/${total}]", 43);
  *(_WORD *)(a1 + 232) = 257;
  *(_DWORD *)(a1 + 236) = 600;
  *(_WORD *)(a1 + 240) = 257;
  *(_BYTE *)(a1 + 242) = 0;
  *(_DWORD *)(a1 + 244) = 4;
  *(_DWORD *)(a1 + 248) = 0xFFFFFF;
  *(_DWORD *)(a1 + 252) = 13158600;
  *(_BYTE *)(a1 + 256) = 0;
  *(_DWORD *)(a1 + 260) = 10;
  *(_BYTE *)(a1 + 264) = 0;
  *(_QWORD *)(a1 + 268) = 10;
  *(_BYTE *)(a1 + 276) = 0;
  sub_14007A100(a1 + 280);
  *(_BYTE *)(a1 + 304) = 0;
  sub_14005FCF0((int **)(a1 + 312), L"CMD_NULL", 8);
  *(_BYTE *)(a1 + 320) = 0;
  sub_14005FCF0((int **)(a1 + 328), L"CMD_NULL", 8);
  *(_BYTE *)(a1 + 320) = 1;
  sub_14005FCF0((int **)(a1 + 328), L"CMD_MAXIMIZE", 12);
  *(_BYTE *)(a1 + 336) = 0;
  sub_14005FCF0((int **)(a1 + 344), L"CMD_NULL", 8);
  *(_BYTE *)(a1 + 352) = 0;
  sub_14005FCF0((int **)(a1 + 360), L"CMD_NULL", 8);
  *(_BYTE *)(a1 + 368) = 0;
  sub_14005FCF0((int **)(a1 + 376), L"CMD_NULL", 8);
  *(_BYTE *)(a1 + 384) = 0;
  sub_14005FCF0((int **)(a1 + 392), L"CMD_NULL", 8);
  *(_BYTE *)(a1 + 400) = 0;
  sub_14005FCF0((int **)(a1 + 408), L"CMD_NULL", 8);
  *(_BYTE *)(a1 + 416) = 0;
  sub_14005FCF0((int **)(a1 + 424), L"CMD_NULL", 8);
  *(_BYTE *)(a1 + 432) = 0;
  *(_WORD *)(a1 + 440) = 256;
  *(_DWORD *)(a1 + 444) = 0;
  *(_DWORD *)(a1 + 448) = 16842753;
  *(_DWORD *)(a1 + 452) = 16842753;
  *(_BYTE *)(a1 + 456) = 0;
  v11 = (_BYTE **)sub_14009ADF0(&pvParam);
  sub_14006B500((int **)(a1 + 464), v11);
  v12 = (_QWORD *)(pvParam - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(pvParam - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v12 + 8LL))(*v12);
  sub_14005FA90((int **)(a1 + 472));
  *(_BYTE *)(a1 + 480) = 0;
  GetTempPathW(0x104u, Buffer);
  v13 = sub_1400601C0();
  if ( v13 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)&pvParam = (*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24;
  if ( (unsigned __int8)sub_14005F980(&pvParam, (__int64)Buffer) == 0 )
  {
    v14 = sub_1404ADC20(Buffer);
    sub_14005FCF0((int **)&pvParam, Buffer, v14);
  }
  sub_14006B500((int **)(a1 + 488), (_BYTE **)&pvParam);
  v15 = (_QWORD *)(pvParam - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(pvParam - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v15 + 8LL))(*v15);
  *(_DWORD *)(a1 + 496) = 0;
  *(_BYTE *)(a1 + 500) = 0;
  sub_14005FCF0((int **)(a1 + 504), L"mspaint.exe", 11);
  *(_DWORD *)(a1 + 512) = 0;
  *(_WORD *)(a1 + 516) = 0;
  sub_14005FCF0((int **)(a1 + 520), &Data, 0);
  *(_BYTE *)(a1 + 528) = 0;
  sub_14005FCF0((int **)(a1 + 536), &Data, 0);
  *(_DWORD *)(a1 + 556) = 0;
  *(_BYTE *)(a1 + 560) = 1;
  result = sub_140075E90(a1 + 568);
  *(_DWORD *)(a1 + 712) = 1;
  *(_BYTE *)(a1 + 716) = 1;
  *(_DWORD *)(a1 + 720) = 1;
  *(_BYTE *)(a1 + 724) = 1;
  *(_BYTE *)(a1 + 728) = 0;
  *(_DWORD *)(a1 + 732) = 0;
  *(_BYTE *)(a1 + 736) = 0;
  *(_QWORD *)(a1 + 740) = 0;
  *(_WORD *)(a1 + 748) = 0;
  *(_DWORD *)(a1 + 752) = 1;
  *(_DWORD *)(a1 + 756) = 15;
  *(_DWORD *)(a1 + 760) = 15;
  *(_DWORD *)(a1 + 764) = 15;
  *(_DWORD *)(a1 + 768) = 15;
  *(_DWORD *)(a1 + 772) = 100;
  *(_WORD *)(a1 + 776) = 0;
  *(_DWORD *)(a1 + 780) = 0;
  *(_QWORD *)(a1 + 784) = 0xFFFFFF;
  *(_DWORD *)(a1 + 796) = 1000;
  *(_DWORD *)(a1 + 800) = 2000;
  *(_DWORD *)(a1 + 804) = 3000;
  *(_DWORD *)(a1 + 808) = 4000;
  *(_DWORD *)(a1 + 812) = 5000;
  *(_DWORD *)(a1 + 816) = 6000;
  *(_DWORD *)(a1 + 820) = 7000;
  *(_DWORD *)(a1 + 824) = 8000;
  *(_QWORD *)(a1 + 828) = 9000;
  *(_WORD *)(a1 + 792) = 1;
  *(_BYTE *)(a1 + 794) = 0;
  *(_DWORD *)(a1 + 836) = 16777472;
  *(_WORD *)(a1 + 840) = 0;
  *(_BYTE *)(a1 + 842) = 0;
  *(_DWORD *)(a1 + 844) = 14120960;
  *(_DWORD *)(a1 + 848) = 15711594;
  *(_DWORD *)(a1 + 852) = 14063861;
  *(_DWORD *)(a1 + 856) = 4313086;
  *(_DWORD *)(a1 + 860) = 6281389;
  *(_DWORD *)(a1 + 864) = 12431127;
  *(_DWORD *)(a1 + 868) = 2133243;
  *(_DWORD *)(a1 + 872) = 4144364;
  *(_DWORD *)(a1 + 876) = 9786082;
  *(_DWORD *)(a1 + 880) = 6336039;
  *(_DWORD *)(a1 + 884) = 10639500;
  *(_DWORD *)(a1 + 888) = 9287118;
  *(_DWORD *)(a1 + 892) = 11841452;
  *(_DWORD *)(a1 + 896) = 3500439;
  *(_DWORD *)(a1 + 900) = 9473921;
  *(_QWORD *)(a1 + 904) = 2105376;
  return result;
}
