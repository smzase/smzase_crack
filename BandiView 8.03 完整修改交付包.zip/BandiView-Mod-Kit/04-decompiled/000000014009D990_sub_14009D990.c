// EA 0x14009d990  name sub_14009D990  size 117
_QWORD *__fastcall sub_14009D990(_QWORD *a1, int *a2)
{
  __int64 *v4; // rax
  int v6; // [rsp+20h] [rbp-28h]

  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  *a1 = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24;
  v6 = *a2;
  sub_14005EB50((__int64)a1, (__int64)L"%s|%x|%d", *((_QWORD *)a2 + 1), (unsigned int)a2[4], v6);
  return a1;
}
