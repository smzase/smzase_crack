// EA 0x1400a23e0  name sub_1400A23E0  size 338
char __fastcall sub_1400A23E0(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  __int64 v6; // rdx
  __int64 v7; // rdx
  __int64 v8; // rbx
  int v9; // eax
  volatile signed __int32 *v10; // rdx
  volatile signed __int32 *v11; // rdx
  volatile signed __int32 *v12; // rdx
  volatile signed __int32 *v14; // rdx
  volatile signed __int32 *v15; // rdx
  __int64 v16; // [rsp+50h] [rbp+8h] BYREF
  _QWORD *v17; // [rsp+58h] [rbp+10h]
  _QWORD *v18; // [rsp+60h] [rbp+18h]
  __int64 v19; // [rsp+68h] [rbp+20h] BYREF

  v18 = a3;
  v17 = a2;
  v6 = *a2;
  if ( v6 == 0 )
    sub_14005FF30(0x80004005);
  if ( (unsigned int)sub_1404A6F80(*(_QWORD *)(a1 + 8), v6) == 0 )
  {
    v16 = sub_14005F710((volatile signed __int32 *)(*a3 - 24LL)) + 24;
    sub_1400CC810(&v19, &v16, 8);
    v7 = *(_QWORD *)(a1 + 24);
    if ( v7 == 0 )
      sub_14005FF30(0x80004005);
    v8 = v19;
    v9 = sub_1404D8590(v19, v7);
    v10 = (volatile signed __int32 *)(v8 - 24);
    if ( v9 == 0 )
    {
      if ( _InterlockedExchangeAdd(v10 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v10 + 8LL))(*(_QWORD *)v10);
      v11 = (volatile signed __int32 *)(*a2 - 24LL);
      if ( _InterlockedExchangeAdd(v11 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v11 + 8LL))(*(_QWORD *)v11);
      v12 = (volatile signed __int32 *)(*a3 - 24LL);
      if ( _InterlockedExchangeAdd(v12 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v12 + 8LL))(*(_QWORD *)v12);
      return 1;
    }
    if ( _InterlockedExchangeAdd(v10 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v10 + 8LL))(*(_QWORD *)v10);
  }
  v14 = (volatile signed __int32 *)(*a2 - 24LL);
  if ( _InterlockedExchangeAdd(v14 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v14 + 8LL))(*(_QWORD *)v14);
  v15 = (volatile signed __int32 *)(*a3 - 24LL);
  if ( _InterlockedExchangeAdd(v15 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v15 + 8LL))(*(_QWORD *)v15);
  return 0;
}
