// EA 0x1400699f0  name sub_1400699F0  size 220
LPCWSTR *__fastcall sub_1400699F0(LPCWSTR *a1)
{
  __int64 v2; // rax
  _QWORD *v3; // rdx
  __int64 v4; // rax
  __int64 v5; // rax
  _QWORD *v6; // rdx
  _QWORD *v7; // rdx
  __int64 v9; // [rsp+58h] [rbp+10h] BYREF
  __int64 v10; // [rsp+60h] [rbp+18h] BYREF
  __int64 v11; // [rsp+68h] [rbp+20h] BYREF

  v2 = sub_14006EA30(&v9);
  sub_140060B30(a1, v2, L"data\\resource.data");
  v3 = (_QWORD *)(v9 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v9 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 8LL))(*v3);
  if ( (unsigned int)sub_14006FEE0(*a1) == 0 )
  {
    v4 = sub_14006EA30(&v11);
    v5 = sub_140060B30(&v10, v4, L"..\\BandiViewLib\\resource.h");
    sub_14006B500(a1, v5);
    v6 = (_QWORD *)(v10 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v10 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v6 + 8LL))(*v6);
    v7 = (_QWORD *)(v11 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v11 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v7 + 8LL))(*v7);
  }
  return a1;
}
