// EA 0x1401c0b50  name sub_1401C0B50  size 1191
__int64 __fastcall sub_1401C0B50(__int64 a1, __int64 a2, int a3, _QWORD *a4, int **a5, _QWORD *a6, __int64 a7)
{
  volatile signed __int32 *v10; // rdx
  int *v11; // rdx
  int **v12; // r14
  int *v13; // rdi
  __int64 *v14; // rax
  int v15; // r8d
  WCHAR *v16; // rdx
  int *i; // rbx
  __int16 v18; // ax
  __int64 *v19; // rax
  __int64 v20; // rbx
  int v21; // eax
  int *v22; // rdx
  __int64 v23; // rbx
  int v24; // eax
  __int64 v25; // rbx
  __int64 *v26; // rax
  int v27; // edx
  volatile signed __int32 *v28; // rbx
  _QWORD *v29; // rdx
  volatile signed __int32 *v30; // rdx
  volatile signed __int32 *v31; // rdx
  volatile signed __int32 *v32; // rdx
  _QWORD *v34; // r12
  unsigned int v35; // ebx
  _QWORD *v36; // rdx
  volatile signed __int32 *v37; // rdx
  volatile signed __int32 *v38; // rdx
  volatile signed __int32 *v39; // rdx
  __int64 v40; // [rsp+40h] [rbp-40h] BYREF
  __int64 v41; // [rsp+48h] [rbp-38h] BYREF
  _QWORD v42[2]; // [rsp+50h] [rbp-30h] BYREF
  __int128 v43; // [rsp+60h] [rbp-20h] BYREF
  int v44[4]; // [rsp+70h] [rbp-10h] BYREF
  int *v45; // [rsp+C0h] [rbp+40h] BYREF
  __int64 v46; // [rsp+C8h] [rbp+48h]
  _QWORD *v47; // [rsp+D8h] [rbp+58h]

  v47 = a4;
  v46 = a2;
  if ( *(_DWORD *)(a1 + 872) != 0 )
  {
    v10 = (volatile signed __int32 *)(*a4 - 24LL);
    if ( _InterlockedExchangeAdd(v10 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v10 + 8LL))(*(_QWORD *)v10);
    v11 = *a5;
LABEL_42:
    v31 = v11 - 6;
    if ( _InterlockedExchangeAdd(v31 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v31 + 8LL))(*(_QWORD *)v31);
    v32 = (volatile signed __int32 *)(*a6 - 24LL);
    if ( _InterlockedExchangeAdd(v32 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v32 + 8LL))(*(_QWORD *)v32);
    return 0;
  }
  v12 = a5;
  sub_14006EE60(&v40, a5);
  v13 = *v12;
  if ( *v12 == nullptr )
  {
    v14 = sub_1400601C0();
    if ( v14 != nullptr )
    {
      v45 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
      if ( (unsigned __int8)sub_14005F980(&v45, (__int64)&Data) != 0 )
        goto LABEL_21;
      v15 = 0;
      v16 = (WCHAR *)&Data;
      goto LABEL_20;
    }
LABEL_57:
    sub_14005FF30(0x80004005);
  }
  for ( i = (int *)((char *)v13 + 2 * sub_1404ADC20(*v12) - 2); i >= v13; i = (int *)((char *)i - 2) )
  {
    v18 = *(_WORD *)i;
    if ( *(_WORD *)i == 92 )
      break;
    if ( v18 == 47 )
      break;
    if ( v18 == 124 )
      break;
  }
  v19 = sub_1400601C0();
  if ( v19 == nullptr )
    goto LABEL_57;
  v20 = (__int64)i + 2;
  v45 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v19 + 24))(v19) + 24);
  if ( (unsigned __int8)sub_14005F980(&v45, v20) == 0 )
  {
    if ( v20 != 0 )
      v21 = sub_1404ADC20(v20);
    else
      v21 = 0;
    v15 = v21;
    v16 = (WCHAR *)v20;
LABEL_20:
    sub_14005FCF0(&v45, v16, v15);
  }
LABEL_21:
  sub_14006B500(v12, (_BYTE **)&v45);
  v22 = v45 - 6;
  if ( _InterlockedExchangeAdd(v45 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v22 + 8LL))(*(_QWORD *)v22);
  sub_1401C4C00(&v43, a1 + 1712);
  v23 = v43;
  v42[0] = &v45;
  v45 = (int *)(sub_14005F710((volatile signed __int32 *)(v40 - 24)) + 24);
  v41 = sub_14005F710((volatile signed __int32 *)(*a4 - 24LL)) + 24;
  v24 = sub_1402258E0(v23, a1, &v41, &v45);
  v42[1] = &v45;
  if ( v24 == 0 )
  {
    v25 = *(_QWORD *)(v23 + 128);
    v26 = sub_1400601C0();
    if ( (_DWORD)v25 != 0 )
    {
      if ( v26 == nullptr )
        sub_14005FF30(0x80004005);
      v45 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v26 + 24))(v26) + 24);
      if ( (unsigned __int8)sub_14005F980(&v45, (__int64)&Data) == 0 )
        sub_14005FCF0(&v45, &Data, 0);
      v41 = sub_14005F710((volatile signed __int32 *)(*a4 - 24LL)) + 24;
      v27 = v25;
    }
    else
    {
      if ( v26 == nullptr )
        sub_14005FF30(0x80004005);
      v45 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v26 + 24))(v26) + 24);
      if ( (unsigned __int8)sub_14005F980(&v45, (__int64)&Data) == 0 )
        sub_14005FCF0(&v45, &Data, 0);
      v41 = sub_14005F710((volatile signed __int32 *)(*a4 - 24LL)) + 24;
      v42[0] = 195932161;
      v27 = 195932161;
    }
    sub_1401BA670(a1, v27, (unsigned int)&v41, (unsigned int)&v45, 0, 0);
    v28 = *((volatile signed __int32 **)&v43 + 1);
    if ( *((_QWORD *)&v43 + 1) != 0
      && _InterlockedExchangeAdd((volatile signed __int32 *)(*((_QWORD *)&v43 + 1) + 8LL), 0xFFFFFFFF) == 1 )
    {
      (**(void (__fastcall ***)(volatile signed __int32 *))v28)(v28);
      if ( _InterlockedExchangeAdd(v28 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v28 + 8LL))(v28);
    }
    v29 = (_QWORD *)(v40 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v40 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v29 + 8LL))(*v29);
    v30 = (volatile signed __int32 *)(*a4 - 24LL);
    if ( _InterlockedExchangeAdd(v30 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v30 + 8LL))(*(_QWORD *)v30);
    v11 = *v12;
    goto LABEL_42;
  }
  v34 = a6;
  v45 = (int *)(sub_14005F710((volatile signed __int32 *)(*a6 - 24LL)) + 24);
  v42[0] = sub_14005F710(*v12 - 6) + 24;
  *(_OWORD *)v44 = v43;
  v43 = 0;
  v35 = sub_1401C1000(a1, v46, a3, (int)v44, v42, &v45, a7, 0);
  v36 = (_QWORD *)(v40 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v40 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v36 + 8LL))(*v36);
  v37 = (volatile signed __int32 *)(*a4 - 24LL);
  if ( _InterlockedExchangeAdd(v37 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v37 + 8LL))(*(_QWORD *)v37);
  v38 = *v12 - 6;
  if ( _InterlockedExchangeAdd(v38 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v38 + 8LL))(*(_QWORD *)v38);
  v39 = (volatile signed __int32 *)(*v34 - 24LL);
  if ( _InterlockedExchangeAdd(v39 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v39 + 8LL))(*(_QWORD *)v39);
  return v35;
}
