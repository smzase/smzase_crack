// EA 0x140083540  name sub_140083540  size 395
__int64 __fastcall sub_140083540(_QWORD *a1)
{
  __int64 *v2; // rax
  volatile signed __int32 *v3; // rdx
  LPCWSTR v4; // rbx
  unsigned int v5; // esi
  volatile signed __int32 *v6; // rdx
  volatile signed __int32 *v8; // rdx
  HKEY hKey; // [rsp+30h] [rbp-30h] BYREF
  DWORD Type[2]; // [rsp+38h] [rbp-28h] BYREF
  LPCWSTR lpValueName; // [rsp+40h] [rbp-20h] BYREF
  DWORD cbData[2]; // [rsp+48h] [rbp-18h] BYREF
  BYTE Data[16]; // [rsp+50h] [rbp-10h] BYREF

  *(_QWORD *)cbData = a1;
  hKey = nullptr;
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  lpValueName = (LPCWSTR)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  *(_QWORD *)Type = sub_14005F710((volatile signed __int32 *)(*a1 - 24LL)) + 24;
  if ( (unsigned int)sub_140082CB0(&hKey, (__int64)&lpValueName) == 0 )
  {
    v3 = (volatile signed __int32 *)(lpValueName - 12);
LABEL_13:
    if ( _InterlockedExchangeAdd(v3 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v3 + 8LL))(*(_QWORD *)v3);
    if ( hKey != nullptr )
      RegCloseKey(hKey);
    hKey = nullptr;
    v8 = (volatile signed __int32 *)(*a1 - 24LL);
    if ( _InterlockedExchangeAdd(v8 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v8 + 8LL))(*(_QWORD *)v8);
    return 0;
  }
  *(_DWORD *)Data = 0;
  cbData[0] = 4;
  Type[0] = 4;
  v4 = lpValueName;
  if ( RegQueryValueExW(hKey, lpValueName, nullptr, Type, Data, cbData) != 0 )
  {
    v3 = (volatile signed __int32 *)(v4 - 12);
    goto LABEL_13;
  }
  v5 = *(_DWORD *)Data;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v4 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v4 - 3) + 8LL))(*((_QWORD *)v4 - 3));
  if ( hKey != nullptr )
    RegCloseKey(hKey);
  hKey = nullptr;
  v6 = (volatile signed __int32 *)(*a1 - 24LL);
  if ( _InterlockedExchangeAdd(v6 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v6 + 8LL))(*(_QWORD *)v6);
  return v5;
}
