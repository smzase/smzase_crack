// EA 0x14009b860  name sub_14009B860  size 270
__int64 __fastcall sub_14009B860(__int64 a1, __int64 a2, __int64 a3, __int64 *a4)
{
  volatile signed __int32 *v7; // rdx
  int v9; // ecx
  __int64 v10; // rbx
  _QWORD *v11; // rax
  unsigned int v12; // esi
  __int64 v13; // rbx
  _QWORD *v14; // rax
  _QWORD *v15; // rdx
  volatile signed __int32 *v16; // rdx
  __int64 v17; // [rsp+50h] [rbp+8h] BYREF
  __int64 *v18; // [rsp+68h] [rbp+20h]

  v18 = a4;
  if ( *(_DWORD *)(a1 + 180) == 0 )
  {
LABEL_2:
    v7 = (volatile signed __int32 *)(*a4 - 24);
    if ( _InterlockedExchangeAdd(v7 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v7 + 8LL))(*(_QWORD *)v7);
    return 0;
  }
  v9 = *(_DWORD *)(a1 + 136) - 1;
  if ( v9 != 0 )
  {
    if ( v9 != 1 )
      goto LABEL_2;
    v10 = *a4;
    v11 = (_QWORD *)sub_140060B30(&v17, a1 + 184, a2);
    v12 = sub_1401EA050((int)a1 + 8, *(_QWORD *)(a1 + 168), *v11, a3, v10);
  }
  else
  {
    v13 = *a4;
    v14 = (_QWORD *)sub_140060B30(&v17, a1 + 184, a2);
    v12 = sub_1400829F0(a1, *v14, a3, v13);
  }
  v15 = (_QWORD *)(v17 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v17 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v15 + 8LL))(*v15);
  v16 = (volatile signed __int32 *)(*a4 - 24);
  if ( _InterlockedExchangeAdd(v16 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v16 + 8LL))(*(_QWORD *)v16);
  return v12;
}
