// EA 0x140075fe0  name sub_140075FE0  size 95
__int16 *sub_140075FE0()
{
  if ( dword_14070CE60 > *(_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL) )
  {
    sub_140496500(&dword_14070CE60);
    if ( dword_14070CE60 == -1 )
    {
      sub_140076040();
      atexit(sub_140592850);
      Init_thread_footer(&dword_14070CE60);
    }
  }
  return &word_14070CE70;
}
