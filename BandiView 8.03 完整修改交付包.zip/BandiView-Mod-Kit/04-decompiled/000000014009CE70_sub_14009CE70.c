// EA 0x14009ce70  name sub_14009CE70  size 444
int **__fastcall sub_14009CE70(int **a1)
{
  __int64 *v2; // rax
  __int64 *v3; // rax
  _BYTE **v4; // rax
  _QWORD *v5; // rdx
  LANGID UserDefaultLangID; // ax
  __int64 v7; // r8
  const char *v8; // rdx
  int *v10; // [rsp+50h] [rbp+18h] BYREF
  __int64 v11; // [rsp+58h] [rbp+20h] BYREF

  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  v10 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
  if ( (unsigned __int8)sub_14005F980(&v10, (__int64)L"HKEY_LOCAL_MACHINE\\SOFTWARE\\BandiView\\language") == 0 )
    sub_14005FCF0(&v10, L"HKEY_LOCAL_MACHINE\\SOFTWARE\\BandiView\\language", 46);
  v4 = (_BYTE **)sub_140083250(&v11, &v10, 0);
  sub_14006B500(a1, v4);
  v5 = (_QWORD *)(v11 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v11 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v5 + 8LL))(*v5);
  v10 = (int *)(sub_14005F710(*a1 - 6) + 24);
  if ( (unsigned __int8)sub_14009CC90(&v10) == 0 )
  {
    UserDefaultLangID = GetUserDefaultLangID();
    v7 = 0;
    while ( *((_WORD *)&unk_1405EACC0 + 12 * v7) != UserDefaultLangID )
    {
      v7 = (unsigned int)(v7 + 1);
      if ( (int)v7 >= 161 )
      {
        v8 = &Locale;
        goto LABEL_13;
      }
    }
    v8 = *((const char **)&unk_1405EACC0 + 3 * v7 + 1);
LABEL_13:
    sub_140073980(a1, v8);
    v10 = (int *)(sub_14005F710(*a1 - 6) + 24);
    if ( (unsigned __int8)sub_14009CC90(&v10) == 0 )
    {
      sub_14005FCF0(a1, L"English", 7);
      v10 = (int *)(sub_14005F710(*a1 - 6) + 24);
      sub_14009CC90(&v10);
    }
  }
  return a1;
}
