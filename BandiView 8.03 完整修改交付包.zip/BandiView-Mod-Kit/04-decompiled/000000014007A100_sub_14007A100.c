// EA 0x14007a100  name sub_14007A100  size 96
__int64 __fastcall sub_14007A100(__int64 *a1)
{
  __int64 v1; // rdi
  __int64 v3; // rbx
  volatile signed __int32 *v4; // rdx
  __int64 result; // rax

  v1 = a1[1];
  v3 = *a1;
  if ( *a1 != v1 )
  {
    do
    {
      v4 = (volatile signed __int32 *)(*(_QWORD *)(v3 + 8) - 24LL);
      if ( _InterlockedExchangeAdd(v4 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v4 + 8LL))(*(_QWORD *)v4);
      v3 += 24;
    }
    while ( v3 != v1 );
    result = *a1;
    a1[1] = *a1;
  }
  return result;
}
