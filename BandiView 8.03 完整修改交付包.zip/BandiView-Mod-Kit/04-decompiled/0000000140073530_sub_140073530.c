// EA 0x140073530  name sub_140073530  size 207
_BOOL8 __fastcall sub_140073530(_QWORD *a1, __int64 a2)
{
  __int64 v4; // rcx
  __int64 v5; // rcx
  __int64 *v6; // rax
  __int64 v7; // rbx
  bool v8; // di
  __int64 v10; // [rsp+30h] [rbp+8h] BYREF

  v4 = *(_QWORD *)(*a1 - 24LL);
  if ( v4 == 0 || (v5 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 32LL))(v4)) == 0 )
  {
    v6 = sub_1400601C0();
    v5 = (*(__int64 (__fastcall **)(__int64 *))(*v6 + 32))(v6);
    if ( v5 == 0 )
      sub_14005FF30(0x80004005);
  }
  v10 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v5 + 24LL))(v5) + 24;
  if ( (unsigned __int8)sub_14005F980(&v10, a2) == 0 )
    sub_140073980(&v10, a2);
  v7 = v10;
  if ( v10 == 0 )
    sub_14005FF30(0x80004005);
  v8 = (unsigned int)sub_1404D8590(*a1, v10) == 0;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v7 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v7 - 24) + 8LL))(*(_QWORD *)(v7 - 24));
  return v8;
}
