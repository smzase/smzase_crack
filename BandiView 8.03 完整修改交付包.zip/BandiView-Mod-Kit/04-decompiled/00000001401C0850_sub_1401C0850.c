// EA 0x1401c0850  name sub_1401C0850  size 582
int **__fastcall sub_1401C0850(int **a1, unsigned int *a2)
{
  __int64 *v4; // rax
  unsigned int v5; // r9d
  __int64 v6; // r8
  __int64 *v8; // rax
  _BYTE **v9; // rax
  wint_t *v10; // rdx
  wint_t **v11; // rax
  __int64 *v12; // rax
  wint_t **v13; // rax
  wint_t *v14; // rdx
  const wchar_t *v15; // rdx
  int *v16; // [rsp+50h] [rbp+18h] BYREF
  wint_t *v17; // [rsp+58h] [rbp+20h] BYREF

  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  v5 = a2[1];
  v6 = *a2;
  if ( v5 == 0 )
  {
    sub_14005EB50((__int64)a1, (__int64)L"0x%x", v6);
    return a1;
  }
  if ( (_DWORD)v6 == -1160708096 )
  {
    v8 = sub_1400601C0();
    if ( v8 == nullptr )
      sub_14005FF30(0x80004005);
    v16 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24);
    if ( (unsigned __int8)sub_14005F980(&v16, (__int64)&Data) == 0 )
      sub_14005FCF0(&v16, &Data, 0);
    v9 = (_BYTE **)sub_1401C0750(&v17, a2[1], &v16);
    sub_14006B500(a1, v9);
    v10 = v17 - 12;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v17 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v10 + 8LL))(*(_QWORD *)v10);
    v11 = sub_14007E480((wint_t **)a1);
    sub_14007E360(v11);
    return a1;
  }
  else
  {
    if ( v5 > 0x3DF8 )
    {
      v15 = L"0x%x(0x%x)";
      if ( (v5 & 0xF0000000) == 0 )
        v15 = L"0x%x(%u)";
      sub_14005EB50((__int64)a1, (__int64)v15);
    }
    else
    {
      v12 = sub_1400601C0();
      if ( v12 == nullptr )
        sub_14005FF30(0x80004005);
      v16 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24);
      if ( (unsigned __int8)sub_14005F980(&v16, (__int64)&Data) == 0 )
        sub_14005FCF0(&v16, &Data, 0);
      sub_1401C0750(&v17, a2[1], &v16);
      v13 = sub_14007E480(&v17);
      sub_14007E360(v13);
      sub_14005EB50((__int64)a1, (__int64)L"0x%x(%s)", *a2, v17, 1, &v16);
      v14 = v17 - 12;
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)v17 - 2, 0xFFFFFFFF) <= 1 )
      {
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v14 + 8LL))(*(_QWORD *)v14);
        return a1;
      }
    }
    return a1;
  }
}
