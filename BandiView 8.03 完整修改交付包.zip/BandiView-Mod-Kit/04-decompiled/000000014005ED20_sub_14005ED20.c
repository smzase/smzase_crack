// EA 0x14005ed20  name sub_14005ED20  size 122
_QWORD *__fastcall sub_14005ED20(_QWORD *Src, const void *a2, unsigned __int64 a3)
{
  __int64 v4; // rcx
  unsigned __int64 v5; // r9
  __int64 v6; // rsi
  _QWORD *v7; // rdi

  v4 = Src[2];
  v5 = Src[3];
  if ( a3 > v5 - v4 )
    return (_QWORD *)sub_14005EDA0(Src, a3);
  v6 = v4 + a3;
  Src[2] = v4 + a3;
  if ( v5 <= 7 )
    v7 = Src;
  else
    v7 = (_QWORD *)*Src;
  memcpy((char *)v7 + 2 * v4, a2, 2 * a3);
  *((_WORD *)v7 + v6) = 0;
  return Src;
}
