// EA 0x1400a07f0  name sub_1400A07F0  size 110
__int64 *sub_1400A07F0()
{
  if ( dword_14071E8D8 > *(_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL) )
  {
    sub_140496500(&dword_14071E8D8);
    if ( dword_14071E8D8 == -1 )
    {
      qword_14071E8E0 = 0;
      sub_1400A0990(&unk_14071E8E8);
      atexit(sub_140592B90);
      Init_thread_footer(&dword_14071E8D8);
    }
  }
  return &qword_14071E8E0;
}
