// EA 0x1400a3600  name sub_1400A3600  size 166
__int64 __fastcall sub_1400A3600(__int64 a1)
{
  __int64 v1; // r10
  __int64 v2; // r9
  __int64 v3; // rcx
  int v4; // edx
  __int64 result; // rax
  int v6; // edx
  __int64 v7; // rcx
  int v8; // edx
  int v9; // edx
  __int64 v10; // rdx
  int v11; // r8d
  int v12; // r8d

  v1 = a1 + 32;
  v2 = *(_QWORD *)(a1 + 32);
  if ( *(_DWORD *)(v2 - 16) != 0 )
  {
    v3 = 0;
    do
    {
      v4 = *(unsigned __int16 *)(v2 + 2 * v3++);
      result = aTri[v3 - 1];
      v6 = v4 - result;
    }
    while ( v6 == 0 && v3 != 4 );
    if ( v6 != 0 )
    {
      v7 = 0;
      do
      {
        v8 = *(unsigned __int16 *)(v2 + 2 * v7++);
        result = aPro[v7 - 1];
        v9 = v8 - result;
      }
      while ( v9 == 0 && v7 != 4 );
      if ( v9 != 0 )
      {
        v10 = 0;
        do
        {
          v11 = *(unsigned __int16 *)(v2 + 2 * v10++);
          result = aPrv[v10 - 1];
          v12 = v11 - result;
        }
        while ( v12 == 0 && v10 != 4 );
        if ( v12 != 0 )
          return sub_14005FA90(v1);
      }
    }
  }
  return result;
}
