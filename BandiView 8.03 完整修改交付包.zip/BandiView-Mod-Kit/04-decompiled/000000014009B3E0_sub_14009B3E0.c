// EA 0x14009b3e0  name sub_14009B3E0  size 377
__int64 __fastcall sub_14009B3E0(__int64 a1, _BYTE *a2)
{
  int v4; // eax
  __int64 v5; // rsi
  unsigned __int64 v6; // rax
  char v7; // bl
  __int16 v9; // [rsp+20h] [rbp-48h] BYREF
  void *v10; // [rsp+28h] [rbp-40h]
  __int128 v11; // [rsp+30h] [rbp-38h] BYREF
  __int64 v12; // [rsp+40h] [rbp-28h]
  __int64 v13; // [rsp+48h] [rbp-20h]

  *(_DWORD *)(a1 + 176) = 1;
  *(_DWORD *)(a1 + 136) = 3;
  if ( a2 != nullptr )
    v4 = sub_1404ADC20(a2);
  else
    v4 = 0;
  sub_14005FCF0((int **)(a1 + 144), a2, v4);
  *(_QWORD *)(a1 + 152) = -2147483647;
  sub_14005FCF0((int **)(a1 + 160), L"SOFTWARE\\BandiView", 18);
  *(_DWORD *)(a1 + 180) = 1;
  v5 = *(_QWORD *)(a1 + 128);
  if ( v5 == 0 )
  {
    v10 = operator new(0x58u);
    v5 = sub_1401CC580(v10);
    *(_QWORD *)(a1 + 128) = v5;
  }
  if ( a2 == nullptr )
    return 0;
  v11 = 0;
  v12 = 0;
  v13 = 0;
  v6 = sub_1404ADC20(a2);
  sub_140061270((char **)&v11, a2, v6);
  v7 = sub_1401CC890(v5, &v11);
  sub_14005D410((char **)&v11);
  if ( v7 == 0 )
    return 0;
  v9 = -257;
  if ( (*(unsigned __int8 (__fastcall **)(_QWORD, __int16 *, __int64))(**(_QWORD **)(a1 + 128) + 8LL))(
         *(_QWORD *)(a1 + 128),
         &v9,
         2) != 0
    && (unsigned int)sub_14009B050(a1 + 128, L"Windows Registry Editor Version 5.00\r\n") != 0 )
  {
    return sub_14009AFB0(a1 + 128);
  }
  else
  {
    return 0;
  }
}
