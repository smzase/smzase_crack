// EA 0x1400a13f0  name sub_1400A13F0  size 310
__int64 __fastcall sub_1400A13F0(__int64 a1)
{
  __int64 *v2; // rax
  __int64 *v3; // rax
  __int64 *v4; // rax
  __int64 *v5; // rax
  __int64 *v6; // rax
  __int64 *v7; // rax
  __int64 *v8; // rax

  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)a1 = (*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24;
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 8) = (*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 16) = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24;
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 24) = (*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 32) = (*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24;
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 56) = (*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24;
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 64) = (*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24;
  *(_OWORD *)(a1 + 40) = 0;
  return a1;
}
