// EA 0x14006bd70  name sub_14006BD70  size 181
char __fastcall sub_14006BD70(__int64 a1, _QWORD *a2)
{
  __int64 v4; // rcx
  __int64 v5; // rdx
  __int64 v6; // rdx
  volatile signed __int32 *v7; // rdx
  volatile signed __int32 *v9; // rdx

  v4 = *(_QWORD *)(a1 + 16);
  if ( v4 != 0 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v4 + 40LL))(v4, *a2) != 0 )
    {
      v5 = *a2;
      goto LABEL_11;
    }
    *(_QWORD *)(a1 + 8) = (*(unsigned int (__fastcall **)(_QWORD))(**(_QWORD **)(a1 + 16) + 24LL))(*(_QWORD *)(a1 + 16));
    v6 = *a2;
  }
  else
  {
    if ( *(_QWORD *)(a1 + 24) != 0 )
    {
      v5 = *a2;
LABEL_11:
      v9 = (volatile signed __int32 *)(v5 - 24);
      if ( _InterlockedExchangeAdd(v9 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v9 + 8LL))(*(_QWORD *)v9);
      return 1;
    }
    *(_DWORD *)(a1 + 12) = 0;
    *(_DWORD *)(a1 + 8) = -1159770107;
    v6 = *a2;
  }
  v7 = (volatile signed __int32 *)(v6 - 24);
  if ( _InterlockedExchangeAdd(v7 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v7 + 8LL))(*(_QWORD *)v7);
  return 0;
}
