// EA 0x140091e20  name sub_140091E20  size 537
BOOL __fastcall sub_140091E20(HWND *a1, HWND a2)
{
  LONG WindowLongW; // eax
  LONG v5; // ebx
  HWND v6; // rcx
  HWND Parent; // rax
  HWND v8; // rcx
  HMONITOR v9; // rax
  LONG left; // ebx
  LONG top; // r10d
  LONG right; // r14d
  LONG bottom; // r11d
  HWND v15; // rbx
  int v16; // r15d
  int v17; // edi
  int v18; // r9d
  struct tagRECT rcWork; // [rsp+40h] [rbp-29h] BYREF
  struct tagRECT v20; // [rsp+50h] [rbp-19h] BYREF
  struct tagRECT Rect; // [rsp+60h] [rbp-9h] BYREF
  struct tagMONITORINFO mi; // [rsp+70h] [rbp+7h] BYREF

  WindowLongW = GetWindowLongW(*a1, -16);
  v5 = WindowLongW;
  if ( a2 == nullptr )
  {
    v6 = *a1;
    if ( (WindowLongW & 0x40000000) != 0 )
      Parent = GetParent(v6);
    else
      Parent = GetWindow(v6, 4u);
    a2 = Parent;
  }
  GetWindowRect(*a1, &Rect);
  if ( (v5 & 0x40000000) != 0 )
  {
    v15 = GetParent(*a1);
    GetClientRect(v15, &rcWork);
    GetClientRect(a2, &v20);
    MapWindowPoints(a2, v15, (LPPOINT)&v20, 2u);
    goto LABEL_19;
  }
  if ( a2 != nullptr )
  {
    if ( (GetWindowLongW(a2, -16) & 0x30000000) == 0x10000000 )
    {
      v8 = a2;
      goto LABEL_11;
    }
    a2 = nullptr;
  }
  v8 = *a1;
LABEL_11:
  v9 = MonitorFromWindow(v8, 2u);
  if ( v9 == nullptr )
    return false;
  mi.cbSize = 40;
  if ( !GetMonitorInfoW(v9, &mi) )
    return false;
  left = mi.rcWork.left;
  top = mi.rcWork.top;
  right = mi.rcWork.right;
  bottom = mi.rcWork.bottom;
  rcWork = mi.rcWork;
  if ( a2 != nullptr )
  {
    GetWindowRect(a2, &v20);
LABEL_19:
    left = rcWork.left;
    top = rcWork.top;
    right = rcWork.right;
    bottom = rcWork.bottom;
    goto LABEL_20;
  }
  v20 = rcWork;
LABEL_20:
  v16 = Rect.bottom - Rect.top;
  v17 = (v20.left + v20.right) / 2 - (Rect.right - Rect.left) / 2;
  v18 = (v20.top + v20.bottom) / 2 - (Rect.bottom - Rect.top) / 2;
  if ( v17 + Rect.right - Rect.left > right )
    v17 = right - (Rect.right - Rect.left);
  if ( v17 < left )
    v17 = left;
  if ( v18 + v16 > bottom )
    v18 = bottom - v16;
  if ( v18 < top )
    v18 = top;
  return SetWindowPos(*a1, nullptr, v17, v18, -1, -1, 0x15u);
}
