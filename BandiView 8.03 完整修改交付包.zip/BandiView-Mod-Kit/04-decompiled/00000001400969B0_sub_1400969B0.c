// EA 0x1400969b0  name sub_1400969B0  size 2165
char __fastcall sub_1400969B0(__int64 *a1, wint_t **a2, _QWORD *a3, __int64 a4)
{
  __int64 *v8; // rax
  _QWORD *v9; // r15
  __int64 v10; // rbx
  int v11; // eax
  wint_t **v12; // rax
  wint_t **v13; // rax
  __int64 v14; // rbx
  volatile signed __int32 *v15; // rcx
  int *v16; // rbx
  __int64 *v17; // rax
  int *v18; // rbx
  int **v19; // rax
  int *v20; // rdx
  int *v21; // rdx
  __int64 v22; // rax
  __int64 v23; // rcx
  _QWORD *v24; // rbx
  __int64 *v25; // rax
  _BYTE **v26; // rax
  int ***v27; // rdx
  __int64 *v28; // rax
  int v29; // ecx
  char v30; // r13
  __int64 *v31; // rax
  int *v32; // rbx
  __int64 *v33; // rax
  _BYTE *v34; // rdx
  volatile signed __int32 *v35; // rcx
  volatile signed __int32 *v36; // r14
  __int64 v37; // rbx
  int **v38; // r13
  int *v39; // rbx
  __int64 v40; // rcx
  __int16 *v41; // rax
  int **v42; // rdx
  int *v43; // r14
  int *v44; // rdx
  volatile signed __int32 *v45; // rdx
  volatile signed __int32 *v46; // rdx
  volatile signed __int32 *v47; // rdx
  volatile signed __int32 *v49; // rdx
  volatile signed __int32 *v50; // rdx
  volatile signed __int32 *v51; // rdx
  __int64 v52; // [rsp+20h] [rbp-79h]
  __int64 v53; // [rsp+28h] [rbp-71h]
  int v54; // [rsp+30h] [rbp-69h]
  int *v55; // [rsp+40h] [rbp-59h] BYREF
  int *v56; // [rsp+48h] [rbp-51h] BYREF
  int ***v57; // [rsp+50h] [rbp-49h] BYREF
  HMODULE *v58; // [rsp+58h] [rbp-41h] BYREF
  int **v59; // [rsp+60h] [rbp-39h] BYREF
  int *v60; // [rsp+68h] [rbp-31h] BYREF
  int *v61; // [rsp+70h] [rbp-29h] BYREF
  int **v62; // [rsp+78h] [rbp-21h] BYREF
  int **v63; // [rsp+80h] [rbp-19h] BYREF
  HCURSOR CursorW; // [rsp+88h] [rbp-11h]
  HCURSOR hCursor; // [rsp+90h] [rbp-9h]
  unsigned __int64 *v66; // [rsp+98h] [rbp-1h]
  __int128 v67; // [rsp+A0h] [rbp+7h] BYREF
  int **v68; // [rsp+B0h] [rbp+17h]

  v62 = &v60;
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  v60 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24);
  if ( (unsigned __int8)sub_14005F980(&v60, (__int64)&Data) == 0 )
    sub_14005FCF0(&v60, &Data, 0);
  v58 = sub_14007D020(&v60);
  v62 = (int **)sub_1400A1680();
  v9 = v62 + 1;
  CursorW = LoadCursorW(nullptr, (LPCWSTR)0x7F02);
  hCursor = SetCursor(CursorW);
  *(_QWORD *)a4 = 0;
  sub_14005FA90((int **)v9);
  sub_14005FA90((int **)v9 + 1);
  sub_14005FA90((int **)v9 + 3);
  sub_14005FA90((int **)v9 + 4);
  sub_14005FA90((int **)v9 + 7);
  sub_14005FA90((int **)v9 + 8);
  *(_OWORD *)(v9 + 5) = 0;
  v10 = *a1;
  if ( ((*(_DWORD *)(*v9 - 12LL) - 4096) | (1 - *(_DWORD *)(*v9 - 8LL))) < 0 )
    sub_14005FC80(v9, 4096);
  (*(void (__fastcall **)(HMODULE, _QWORD, __int64, __int64))(*(_QWORD *)v58[2] + 72LL))(v58[2], *v9, 4096, v10);
  if ( *v9 != 0 )
  {
    v11 = sub_1404ADD70(*v9, *(int *)(*v9 - 12LL));
    if ( v11 < 0 )
      goto LABEL_79;
  }
  else
  {
    v11 = 0;
  }
  if ( v11 > *(_DWORD *)(*v9 - 12LL) )
    goto LABEL_79;
  *(_DWORD *)(*v9 - 16LL) = v11;
  *(_WORD *)(*v9 + 2LL * (unsigned int)v11) = 0;
  v12 = sub_14007E480((wint_t **)v9);
  sub_14007E360(v12);
  v13 = sub_14007E480(a2);
  sub_14007E360(v13);
  v14 = *((int *)*a2 - 4);
  if ( (int)v14 < 0 )
    goto LABEL_79;
  if ( (int)((*((_DWORD *)*a2 - 3) - v14) | (1 - *((_DWORD *)*a2 - 2))) < 0 )
    sub_14005FC80(a2, v14);
  sub_1404BD850(*a2, (int)v14 + 1);
  if ( (int)v14 > *((_DWORD *)*a2 - 3) )
LABEL_79:
    sub_14005FF30(0x80070057);
  *((_DWORD *)*a2 - 4) = v14;
  (*a2)[v14] = 0;
  if ( *(_DWORD *)(*v9 - 16LL) == 0 || *((_DWORD *)(v15 = (volatile signed __int32 *)(*a2 - 12)) + 2) == 0 )
  {
    *(_DWORD *)(a4 + 4) = 0;
    *(_DWORD *)a4 = -1159778304;
    SetCursor(hCursor);
    goto LABEL_71;
  }
  v16 = (int *)(sub_14005F710(v15) + 24);
  v56 = v16;
  v63 = &v56;
  v17 = sub_1400601C0();
  if ( v17 == nullptr )
    sub_14005FF30(0x80004005);
  v55 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v17 + 24))(v17) + 24);
  if ( (unsigned __int8)sub_140073860((LPSTR *)&v55, (__int64)v16) == 0 )
    sub_140097550(&v55, v16);
  sub_14006B500((int **)v9 + 1, (_BYTE **)&v56);
  v18 = v55;
  v19 = sub_140096900(&v61, (__int64)v55);
  sub_14006B500((int **)v9 + 3, (_BYTE **)v19);
  v20 = v61 - 6;
  if ( _InterlockedExchangeAdd(v61 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v20 + 8LL))(*(_QWORD *)v20);
  if ( _InterlockedExchangeAdd(v18 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v18 - 3) + 8LL))(*((_QWORD *)v18 - 3));
  v21 = v56 - 6;
  if ( _InterlockedExchangeAdd(v56 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v21 + 8LL))(*(_QWORD *)v21);
  if ( *(_DWORD *)(v9[1] - 16LL) != 38
    || *(int *)(*v9 - 16LL) < 0
    || (v22 = sub_1404A27AC(*v9, L"@")) == 0
    || (int)((v22 - *v9) >> 1) <= 0 )
  {
    *(_DWORD *)(a4 + 4) = 0;
    *(_DWORD *)a4 = -1159778298;
    SetCursor(hCursor);
    goto LABEL_71;
  }
  if ( (*(unsigned int (__fastcall **)(HMODULE, wint_t *))(*(_QWORD *)v58[2] + 64LL))(v58[2], *a2) != 0 )
  {
    *(_DWORD *)(a4 + 4) = 0;
    *(_DWORD *)a4 = -1159778297;
    SetCursor(hCursor);
LABEL_71:
    v49 = (volatile signed __int32 *)(*a1 - 24);
    if ( _InterlockedExchangeAdd(v49 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v49 + 8LL))(*(_QWORD *)v49);
    v50 = (volatile signed __int32 *)(*a2 - 12);
    if ( _InterlockedExchangeAdd(v50 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v50 + 8LL))(*(_QWORD *)v50);
    v51 = (volatile signed __int32 *)(*a3 - 24LL);
    if ( _InterlockedExchangeAdd(v51 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v51 + 8LL))(*(_QWORD *)v51);
    return 0;
  }
  v57 = &v63;
  sub_14007D5E0();
  v24 = sub_14007DE80(v23, &v63);
  v59 = &v56;
  v25 = sub_1400601C0();
  if ( v25 == nullptr )
    sub_14005FF30(0x80004005);
  v56 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v25 + 24))(v25) + 24);
  if ( (unsigned __int8)sub_14005F980(&v56, (__int64)L"BandiView") == 0 )
    sub_14005FCF0(&v56, L"BandiView", 9);
  sub_1400C9530(&v61, &v56, v24);
  v55 = (int *)(sub_14005F710((volatile signed __int32 *)(v9[1] - 24LL)) + 24);
  v26 = (_BYTE **)sub_1400CC810(&v57, &v55, 8);
  sub_14006B500((int **)v9 + 2, v26);
  v27 = v57 - 3;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v57 - 2, 0xFFFFFFFF) <= 1 )
    (*((void (__fastcall **)(int **))**v27 + 1))(*v27);
  v68 = &v55;
  v28 = sub_1400601C0();
  if ( v28 == nullptr )
    sub_14005FF30(0x80004005);
  v55 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24);
  if ( (unsigned __int8)sub_14005F980(&v55, (__int64)&Data) == 0 )
    sub_14005FCF0(&v55, &Data, 0);
  v66 = (unsigned __int64 *)&v59;
  v59 = (int **)(sub_14005F710(v61 - 6) + 24);
  v57 = (int ***)(sub_14005F710((volatile signed __int32 *)(*a3 - 24LL)) + 24);
  v30 = sub_1400CA010(v29, (_DWORD)v9, (unsigned int)&v57, (unsigned int)&v59, a4, (__int64)&v55);
  if ( v30 == 0 )
  {
    (*(void (__fastcall **)(HMODULE))(*(_QWORD *)v58[2] + 80LL))(v58[2]);
LABEL_41:
    v31 = sub_1400601C0();
    if ( v31 == nullptr )
      sub_14005FF30(0x80004005);
    v32 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v31 + 24))(v31) + 24);
    v58 = (HMODULE *)v32;
    v33 = sub_1400601C0();
    if ( v33 == nullptr )
      sub_14005FF30(0x80004005);
    v55 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v33 + 24))(v33) + 24);
    if ( (unsigned __int8)sub_14005F980(&v55, (__int64)L"registration") == 0 )
      sub_14005FCF0(&v55, L"registration", 12);
    v54 = sub_1400CCC00();
    LODWORD(v53) = *(_DWORD *)(a4 + 4);
    LODWORD(v52) = *(_DWORD *)a4;
    v34 = (_BYTE *)*sub_140072490(
                      &v62,
                      (__int64)L"BandiView-DoReg-onlineRegFailed() - email:%s, key:%s, licErr:0x%x, sysErr:%u, hid:0x%x",
                      *v9,
                      v9[1],
                      v52,
                      v53,
                      v54);
    v35 = (volatile signed __int32 *)(v34 - 24);
    v36 = v32 - 6;
    if ( v34 - 24 != (_BYTE *)(v32 - 6) )
    {
      if ( *((int *)v36 + 4) >= 0 && *(_QWORD *)v35 == *(_QWORD *)v36 )
      {
        v37 = sub_14005F710(v35);
        if ( _InterlockedExchangeAdd(v36 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v36 + 8LL))(*(_QWORD *)v36, v36);
        v32 = (int *)(v37 + 24);
        v58 = (HMODULE *)v32;
      }
      else
      {
        sub_14005FCF0((int **)&v58, v34, *((_DWORD *)v34 - 4));
        v32 = (int *)v58;
      }
    }
    v42 = v62 - 3;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v62 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(int *))(*(_QWORD *)*v42 + 8LL))(*v42);
    *(_QWORD *)&v67 = &v57;
    v43 = v55;
    v57 = (int ***)(sub_14005F710(v55 - 6) + 24);
    v59 = (int **)(sub_14005F710(v32 - 6) + 24);
    sub_140074840((unsigned __int64 *)&v59, &v57, 0);
    if ( _InterlockedExchangeAdd(v43 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD, int *))(**((_QWORD **)v43 - 3) + 8LL))(*((_QWORD *)v43 - 3), v43 - 6);
    if ( _InterlockedExchangeAdd(v32 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD, int *))(**((_QWORD **)v32 - 3) + 8LL))(*((_QWORD *)v32 - 3), v32 - 6);
    goto LABEL_60;
  }
  v38 = v62;
  sub_14005FA90(v62 + 10);
  sub_14005FA90(v38 + 11);
  sub_14005FA90(v38 + 12);
  v67 = *((_OWORD *)v38 + 3);
  sub_1400A36B0(v38 + 10, *(unsigned int *)v38, &v67, a4);
  v30 = sub_1400A19B0(v38, a4);
  if ( v30 == 0 )
    goto LABEL_41;
  v39 = sub_14007D5E0();
  sub_140082560(v40);
  sub_14005FA90((int **)v39 + 21);
  v41 = sub_140075FE0();
  sub_140079B50((__int64)v41);
LABEL_60:
  v44 = v61 - 6;
  if ( _InterlockedExchangeAdd(v61 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v44 + 8LL))(*(_QWORD *)v44);
  SetCursor(hCursor);
  v45 = (volatile signed __int32 *)(*a1 - 24);
  if ( _InterlockedExchangeAdd(v45 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v45 + 8LL))(*(_QWORD *)v45);
  v46 = (volatile signed __int32 *)(*a2 - 12);
  if ( _InterlockedExchangeAdd(v46 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v46 + 8LL))(*(_QWORD *)v46);
  v47 = (volatile signed __int32 *)(*a3 - 24LL);
  if ( _InterlockedExchangeAdd(v47 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v47 + 8LL))(*(_QWORD *)v47);
  return v30;
}
