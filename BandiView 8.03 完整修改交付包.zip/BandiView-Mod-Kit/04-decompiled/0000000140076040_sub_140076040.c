// EA 0x140076040  name sub_140076040  size 910
__int16 *sub_140076040()
{
  __int64 *v0; // rax
  __int64 *v1; // rax
  _QWORD *v2; // rax
  __int64 *v3; // rax
  __int64 *v4; // rax
  __int64 *v5; // rax
  __int64 *v6; // rax
  __int64 *v7; // rax
  __int64 *v8; // rax
  __int64 *v9; // rax
  __int64 *v10; // rax

  word_14070CE70 = 256;
  v0 = sub_1400601C0();
  if ( v0 == nullptr )
    sub_14005FF30(0x80004005);
  qword_14070CE78 = (*(__int64 (__fastcall **)(__int64 *))(*v0 + 24))(v0) + 24;
  v1 = sub_1400601C0();
  if ( v1 == nullptr )
    sub_14005FF30(0x80004005);
  qword_14070CE80 = (*(__int64 (__fastcall **)(__int64 *))(*v1 + 24))(v1) + 24;
  qword_14070CEA8 = 0;
  qword_14070CEB0 = 0;
  v2 = operator new(0x18u);
  *v2 = v2;
  v2[1] = v2;
  qword_14070CEA8 = (__int64)v2;
  xmmword_14070CEC0 = 0;
  xmmword_14070CED0 = 0;
  dword_14070CEE0 = 0;
  xmmword_14070CEE4 = 0;
  qword_14070CEF4 = 0;
  qword_14070CF0C = 0;
  qword_14070CF3C = 0;
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  qword_14070CF50 = (*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24;
  qword_14070CF88 = 0;
  xmmword_14070CF90 = 0;
  ((void (*)(void))sub_140076470)();
  sub_140076470(&unk_14070CFB0);
  sub_140076470(&unk_14070CFC0);
  sub_140076470(&unk_14070CFD0);
  sub_140076470(&unk_14070CFE0);
  sub_140076470(&unk_14070CFF0);
  sub_140076470(&unk_14070D000);
  sub_140076470(&unk_14070D010);
  byte_14070D020 = 0;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  qword_14070D040 = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24;
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  qword_14070D048 = (*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  qword_14070D058 = (*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24;
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  qword_14070D068 = (*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24;
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  qword_14070D078 = (*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24;
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    sub_14005FF30(0x80004005);
  qword_14070D088 = (*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24;
  v10 = sub_1400601C0();
  if ( v10 == nullptr )
    sub_14005FF30(0x80004005);
  qword_14070D090 = (*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24;
  byte_14070D098 = 0;
  sub_1400763D0(&dword_14070D0A8);
  dword_14070D138 = 0;
  byte_14070D13C = 1;
  dword_14070D140 = 0;
  byte_14070D144 = 1;
  qword_14070D154 = 0;
  word_14070D15C = 0;
  xmmword_14070D160 = (__int128)_mm_load_si128((const __m128i *)&xmmword_140663240);
  dword_14070D170 = 15;
  dword_14070D174 = 100;
  word_14070D178 = 0;
  word_14070D188 = 1;
  byte_14070D18A = 0;
  xmmword_14070D18C = 0;
  xmmword_14070D19C = 0;
  qword_14070D1AC = 0;
  dword_14070D1B4 = 16777472;
  word_14070D1B8 = 0;
  byte_14070D1BA = 0;
  dword_14070D1FC = 0;
  HIBYTE(word_14070CE70) = 1;
  dword_14070CEBC = 0;
  return &word_14070CE70;
}
