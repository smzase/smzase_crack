// EA 0x140065490  name sub_140065490  size 311
__int64 __fastcall sub_140065490(__int64 a1)
{
  _QWORD *v2; // rax
  _QWORD *v3; // rax
  __int64 *v4; // rax
  __int64 *v5; // rax

  *(_OWORD *)(a1 + 8) = 0;
  *(_QWORD *)(a1 + 24) = 0;
  *(_QWORD *)(a1 + 32) = 7;
  *(_WORD *)(a1 + 8) = 0;
  *(_OWORD *)(a1 + 40) = 0;
  *(_QWORD *)(a1 + 56) = 0;
  *(_QWORD *)(a1 + 64) = 7;
  *(_WORD *)(a1 + 40) = 0;
  *(_OWORD *)(a1 + 72) = 0;
  *(_QWORD *)(a1 + 88) = 0;
  *(_QWORD *)(a1 + 96) = 7;
  *(_WORD *)(a1 + 72) = 0;
  *(_QWORD *)(a1 + 104) = 0;
  *(_QWORD *)(a1 + 112) = 0;
  *(_QWORD *)(a1 + 120) = 0;
  *(_QWORD *)(a1 + 128) = 0;
  v2 = operator new(0x18u);
  *v2 = v2;
  v2[1] = v2;
  *(_QWORD *)(a1 + 120) = v2;
  *(_QWORD *)(a1 + 136) = 0;
  *(_QWORD *)(a1 + 144) = 0;
  v3 = operator new(0x20u);
  *v3 = v3;
  v3[1] = v3;
  *(_QWORD *)(a1 + 136) = v3;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 160) = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24;
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 168) = (*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24;
  *(_QWORD *)(a1 + 176) = 0;
  *(_QWORD *)(a1 + 184) = 0;
  *(_QWORD *)(a1 + 192) = 0;
  *(_DWORD *)(a1 + 200) = -1000;
  sub_140065680(a1);
  return a1;
}
