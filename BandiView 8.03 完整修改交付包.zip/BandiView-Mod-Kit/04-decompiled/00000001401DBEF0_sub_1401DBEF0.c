// EA 0x1401dbef0  name sub_1401DBEF0  size 1286
void __fastcall sub_1401DBEF0(__int64 a1, unsigned int a2)
{
  unsigned int v2; // esi
  __int64 v4; // rdi
  _QWORD *v5; // rbx
  __int64 v6; // rcx
  __int64 v7; // r14
  __int64 v8; // r8
  _QWORD *v9; // rax
  _QWORD *v10; // rax
  _QWORD *v11; // rax
  _QWORD *v12; // rax
  __int64 v13; // r8
  _QWORD *v14; // rdx
  __int64 v15; // rcx
  _QWORD *v16; // r15
  _QWORD *v17; // r14
  __int64 v18; // rax
  __int64 v19; // rdi
  _QWORD *v20; // rbx
  _QWORD *v21; // rax
  _QWORD *v22; // rdx
  _QWORD *i; // rcx
  _QWORD *v24; // rbx
  __int64 v25; // rdi
  _QWORD *v26; // rsi
  __int64 v27; // rcx
  _QWORD *v28; // rax
  _QWORD *v29; // rax
  int v30; // r8d
  __int64 v31; // rax
  __int64 v32; // rax
  __int64 v33; // rdi
  _QWORD *v34; // rcx
  _QWORD *v35; // rdi
  _QWORD *v36; // rbx
  volatile signed __int32 *v37; // rbx
  HWND v38; // rdi
  HWND v39; // rbx
  _QWORD **v40; // rcx
  _QWORD *v41; // rcx
  _QWORD *v42; // rbx
  _QWORD **v43; // rcx
  _QWORD *v44; // rcx
  _QWORD *v45; // rbx
  void *Block; // [rsp+30h] [rbp-59h] BYREF
  __int64 v47; // [rsp+38h] [rbp-51h]
  void *v48; // [rsp+40h] [rbp-49h] BYREF
  __int64 v49; // [rsp+48h] [rbp-41h]
  __int128 v50; // [rsp+50h] [rbp-39h] BYREF
  __int64 v51; // [rsp+60h] [rbp-29h]
  __int128 v52; // [rsp+68h] [rbp-21h]
  unsigned int v53; // [rsp+78h] [rbp-11h]
  unsigned int v54; // [rsp+80h] [rbp-9h]
  __int128 v55; // [rsp+90h] [rbp+7h] BYREF
  void **p_Block; // [rsp+A0h] [rbp+17h]
  __int64 v57; // [rsp+A8h] [rbp+1Fh]

  v2 = a2;
  v54 = a2;
  if ( *(_DWORD *)(a1 + 872) != 0 )
  {
    if ( *(_BYTE *)(a1 + 384) == 0 )
    {
      v4 = *(_QWORD *)(a1 + 904);
      if ( v4 == 0 )
        return;
      v5 = *(_QWORD **)(v4 + 104);
      sub_140120FE0(v4 + 104, v4 + 104, v5[1]);
      v5[1] = v5;
      *v5 = v5;
      v5[2] = v5;
      *(_QWORD *)(v4 + 112) = 0;
    }
    v6 = *(unsigned int *)(a1 + 1728);
    *(_DWORD *)(a1 + 1728) = v2;
    v7 = a1 + 888;
    sub_1401DC4A0(v6, *(_QWORD *)(a1 + 888), 0);
    LOBYTE(v8) = 1;
    sub_1401DC4A0(v2, *(_QWORD *)(a1 + 888), v8);
    v49 = 0;
    v9 = operator new(0x18u);
    *v9 = v9;
    v9[1] = v9;
    v48 = v9;
    v47 = 0;
    v10 = operator new(0x18u);
    *v10 = v10;
    v10[1] = v10;
    Block = v10;
    v50 = 0;
    v51 = 0;
    v52 = 0;
    v53 = 10;
    v11 = j__malloc_base(0xF8u);
    if ( v11 == nullptr )
LABEL_54:
      sub_14005FF30(0x8007000E);
    *v11 = v52;
    *(_QWORD *)&v52 = v11;
    v12 = &v11[3 * v53 - 2];
    v13 = v53 - 1;
    v14 = *((_QWORD **)&v52 + 1);
    if ( (int)(v53 - 1) >= 0 )
    {
      do
      {
        *v12 = v14;
        v14 = v12;
        *((_QWORD *)&v52 + 1) = v12;
        v12 -= 3;
        v13 = (unsigned int)(v13 - 1);
      }
      while ( (int)v13 >= 0 );
    }
    v15 = *v14;
    v14[2] = *(_QWORD *)(a1 + 880);
    *((_QWORD *)&v52 + 1) = v15;
    v14[1] = 0;
    *v14 = 0;
    ++v51;
    if ( *((_QWORD *)&v50 + 1) != 0 )
    {
      **((_QWORD **)&v50 + 1) = v14;
      v16 = (_QWORD *)v50;
    }
    else
    {
      v16 = v14;
      *(_QWORD *)&v50 = v14;
    }
    *((_QWORD *)&v50 + 1) = v14;
    if ( v16 != nullptr )
    {
      while ( 1 )
      {
        v17 = (_QWORD *)v16[2];
        v18 = sub_1404A362C(
                (_DWORD)v17,
                0,
                (unsigned int)&AControlBase `RTTI Type Descriptor',
                (unsigned int)&XXSkin `RTTI Type Descriptor',
                0);
        v19 = v18;
        if ( v18 != 0 && v18 != a1 && *(_BYTE *)(v18 + 384) != 0 )
        {
          if ( v47 == 0xAAAAAAAAAAAAAAALL )
            goto LABEL_53;
          v20 = Block;
          p_Block = &Block;
          v57 = 0;
          v21 = operator new(0x18u);
          v21[2] = v19;
          ++v47;
          v57 = 0;
        }
        else
        {
          if ( v17 == nullptr )
            goto LABEL_36;
          (*(void (__fastcall **)(_QWORD *))(*v17 + 72LL))(v17);
          v22 = (_QWORD *)v17[35];
          if ( v22 != nullptr )
          {
            i = *((_QWORD **)&v50 + 1);
            do
            {
              v24 = (_QWORD *)*v22;
              v25 = v22[2];
              v26 = i;
              i = *((_QWORD **)&v52 + 1);
              if ( *((_QWORD *)&v52 + 1) == 0 )
              {
                v27 = v53;
                if ( v53 != 0 )
                {
                  if ( 0xFFFFFFFFFFFFFFFFuLL / v53 < 0x18 )
                    goto LABEL_54;
                  v27 = 24LL * v53;
                }
                v28 = j__malloc_base(v27 + 8);
                if ( v28 == nullptr )
                  goto LABEL_54;
                *v28 = v52;
                *(_QWORD *)&v52 = v28;
                v29 = &v28[3 * v53 - 2];
                v30 = v53 - 1;
                for ( i = *((_QWORD **)&v52 + 1); v30 >= 0; --v30 )
                {
                  *v29 = i;
                  i = v29;
                  *((_QWORD *)&v52 + 1) = v29;
                  v29 -= 3;
                }
              }
              v22 = v24;
              v31 = *i;
              i[2] = v25;
              *((_QWORD *)&v52 + 1) = v31;
              i[1] = v26;
              *i = 0;
              ++v51;
              if ( *((_QWORD *)&v50 + 1) != 0 )
                **((_QWORD **)&v50 + 1) = i;
              else
                *(_QWORD *)&v50 = i;
              *((_QWORD *)&v50 + 1) = i;
            }
            while ( v24 != nullptr );
          }
          v32 = sub_1404A362C(
                  (_DWORD)v17,
                  0,
                  (unsigned int)&AControlBase `RTTI Type Descriptor',
                  (unsigned int)&XWindow `RTTI Type Descriptor',
                  0);
          if ( v32 == 0 )
            goto LABEL_36;
          v33 = *(_QWORD *)(v32 + 544);
          if ( v33 == 0 )
            goto LABEL_36;
          if ( v49 == 0xAAAAAAAAAAAAAAALL )
LABEL_53:
            sub_1404962E4("list too long");
          v20 = v48;
          *(_QWORD *)&v55 = &v48;
          *((_QWORD *)&v55 + 1) = 0;
          v21 = operator new(0x18u);
          v21[2] = v33;
          ++v49;
          *((_QWORD *)&v55 + 1) = 0;
        }
        v34 = (_QWORD *)v20[1];
        *v21 = v20;
        v21[1] = v34;
        v20[1] = v21;
        *v34 = v21;
LABEL_36:
        v16 = (_QWORD *)*v16;
        if ( v16 == nullptr )
        {
          v2 = v54;
          v7 = a1 + 888;
          break;
        }
      }
    }
    v35 = Block;
    v36 = *(_QWORD **)Block;
    if ( *(void **)Block != Block )
    {
      do
      {
        sub_1401DBEE0(v36[2], v2);
        v36 = (_QWORD *)*v36;
      }
      while ( v36 != v35 );
    }
    if ( *(_BYTE *)(a1 + 384) != 0 )
    {
      *(_QWORD *)(a1 + 1296) = 0;
      v37 = *(volatile signed __int32 **)(a1 + 1304);
      *(_QWORD *)(a1 + 1304) = 0;
      if ( v37 != nullptr && _InterlockedExchangeAdd(v37 + 2, 0xFFFFFFFF) == 1 )
      {
        (**(void (__fastcall ***)(volatile signed __int32 *, _QWORD *, __int64))v37)(v37, v14, v13);
        if ( _InterlockedExchangeAdd(v37 + 3, 0xFFFFFFFF) == 1 )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v37 + 8LL))(v37);
      }
    }
    else
    {
      v55 = *(_OWORD *)(a1 + 264);
      sub_140214400(v7, &v55, v13);
      sub_1401C3E50(a1);
      sub_1401BDEF0(a1);
      v38 = (HWND)v48;
      v39 = *(HWND *)v48;
      if ( *(void **)v48 != v48 )
      {
        do
        {
          RedrawWindow(*((HWND *)v39 + 2), nullptr, nullptr, 0x505u);
          v39 = *(HWND *)v39;
        }
        while ( v39 != v38 );
      }
    }
    sub_14006D9B0(&v50);
    v40 = (_QWORD **)Block;
    **((_QWORD **)Block + 1) = 0;
    v41 = *v40;
    if ( v41 != nullptr )
    {
      do
      {
        v42 = (_QWORD *)*v41;
        j_j_j__free_base(v41);
        v41 = v42;
      }
      while ( v42 != nullptr );
    }
    j_j_j__free_base(Block);
    v43 = (_QWORD **)v48;
    **((_QWORD **)v48 + 1) = 0;
    v44 = *v43;
    if ( v44 != nullptr )
    {
      do
      {
        v45 = (_QWORD *)*v44;
        j_j_j__free_base(v44);
        v44 = v45;
      }
      while ( v45 != nullptr );
    }
    j_j_j__free_base(v48);
  }
}
