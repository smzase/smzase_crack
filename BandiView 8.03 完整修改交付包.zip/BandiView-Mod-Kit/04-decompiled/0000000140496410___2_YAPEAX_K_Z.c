// EA 0x140496410  name ??2@YAPEAX_K@Z  size 60
void *__fastcall operator new(size_t Size)
{
  size_t i; // rbx
  void *result; // rax

  for ( i = Size; ; Size = i )
  {
    result = j__malloc_base(Size);
    if ( result != nullptr )
      break;
    if ( (unsigned int)sub_1404AE7F0(i) == 0 )
    {
      if ( i != -1 )
      {
        sub_140496280();
        __debugbreak();
      }
      sub_14005D3C0();
      __debugbreak();
    }
  }
  return result;
}
