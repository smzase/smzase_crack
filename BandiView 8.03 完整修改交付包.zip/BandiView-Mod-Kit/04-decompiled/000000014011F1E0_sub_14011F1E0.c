// EA 0x14011f1e0  name sub_14011F1E0  size 218
__int64 __fastcall sub_14011F1E0(_QWORD *a1)
{
  __int64 v1; // rdx
  volatile signed __int32 *v3; // rdx
  __int64 result; // rax
  __int64 v5; // rcx
  __int64 v6; // rax
  void *v7; // rcx
  volatile signed __int32 *v8; // rdx
  void *v9; // rcx

  v1 = a1[36];
  *a1 = &SettingKeyDlg::`vftable';
  v3 = (volatile signed __int32 *)(v1 - 24);
  if ( _InterlockedExchangeAdd(v3 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v3 + 8LL))(*(_QWORD *)v3);
  result = sub_140094790(a1 + 16);
  v5 = a1[11];
  if ( v5 != 0 )
  {
    sub_140091870(v5, a1[12]);
    v6 = a1[11];
    if ( ((a1[13] - v6) & 0xFFFFFFFFFFFFFFF0uLL) < 0x1000 )
    {
      v7 = (void *)a1[11];
    }
    else
    {
      v7 = *(void **)(v6 - 8);
      if ( (unsigned __int64)(v6 - (_QWORD)v7 - 8) > 0x1F )
        __fastfail(5u);
    }
    j_j_j__free_base(v7);
    result = 0;
    a1[11] = 0;
    a1[12] = 0;
    a1[13] = 0;
  }
  v8 = (volatile signed __int32 *)(a1[9] - 24LL);
  if ( _InterlockedExchangeAdd(v8 + 4, 0xFFFFFFFF) <= 1 )
    result = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v8 + 8LL))(*(_QWORD *)v8);
  v9 = (void *)a1[5];
  if ( v9 != nullptr )
    return sub_140495E60(v9);
  return result;
}
