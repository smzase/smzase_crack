// EA 0x14019bb00  name sub_14019BB00  size 202
__int128 *sub_14019BB00()
{
  if ( dword_14071EB40 > *(_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL) )
  {
    sub_140496500(&dword_14071EB40);
    if ( dword_14071EB40 == -1 )
    {
      xmmword_14071EB50 = 0;
      sub_14019B920(&unk_14071EB60);
      dword_14071EC00 = 0;
      xmmword_14071EC04 = 0;
      xmmword_14071EC14 = 0;
      xmmword_14071EC24 = 0;
      xmmword_14071EC34 = 0;
      xmmword_14071EC44 = 0;
      xmmword_14071EC54 = 0;
      xmmword_14071EC64 = 0;
      xmmword_14071EC74 = 0;
      dword_14071EC84 = 0;
      byte_14071EC88 = 0;
      atexit(sub_140592E40);
      Init_thread_footer(&dword_14071EB40);
    }
  }
  return &xmmword_14071EB50;
}
