// EA 0x1401c56d0  name sub_1401C56D0  size 177
int **__fastcall sub_1401C56D0(int **a1, __int64 a2, const void *a3, __int64 a4)
{
  __int64 *v8; // rax
  _BYTE *v9; // rbx
  __int64 *v10; // rax
  int v11; // eax

  v8 = sub_1401C5640();
  v9 = (_BYTE *)sub_1401C81E0(v8, a2, a4);
  v10 = sub_1400601C0();
  if ( v10 == nullptr )
    sub_14005FF30(0x80004005);
  *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24);
  if ( (unsigned __int8)sub_14005F980(a1, (__int64)v9) == 0 )
  {
    if ( v9 != nullptr )
      v11 = sub_1404ADC20(v9);
    else
      v11 = 0;
    sub_14005FCF0(a1, v9, v11);
  }
  sub_140060D20((unsigned __int64 *)a1, (__int64)L"${str1}", a3);
  return a1;
}
