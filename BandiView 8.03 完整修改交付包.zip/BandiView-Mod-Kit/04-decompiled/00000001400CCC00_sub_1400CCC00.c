// EA 0x1400ccc00  name sub_1400CCC00  size 1114
__int64 sub_1400CCC00()
{
  __int64 *v0; // rax
  __int64 v1; // rax
  WCHAR *v2; // r13
  int v3; // eax
  __int64 *v4; // rax
  __int64 v5; // rsi
  HANDLE FileW; // r14
  char *v7; // rbx
  int v8; // ecx
  char *v9; // rdi
  size_t v10; // rax
  __int64 *v11; // rax
  const WCHAR *v12; // r14
  DWORD v13; // r15d
  LPSTR v14; // rdi
  __int64 v15; // rbx
  LPCWSTR v16; // rdx
  volatile signed __int32 *v17; // rdx
  DWORD VolumeSerialNumber; // [rsp+40h] [rbp-C0h] BYREF
  LPSTR OutBuffer; // [rsp+48h] [rbp-B8h] BYREF
  DWORD BytesReturned[2]; // [rsp+50h] [rbp-B0h] BYREF
  WCHAR *v22; // [rsp+58h] [rbp-A8h] BYREF
  __int64 v23; // [rsp+60h] [rbp-A0h] BYREF
  LPCWSTR lpFileName; // [rsp+68h] [rbp-98h] BYREF
  volatile signed __int32 *v25; // [rsp+70h] [rbp-90h] BYREF
  LPCWSTR lpRootPathName; // [rsp+78h] [rbp-88h] BYREF
  int InBuffer; // [rsp+80h] [rbp-80h] BYREF
  __int64 v28; // [rsp+84h] [rbp-7Ch]
  WCHAR VolumeNameBuffer[264]; // [rsp+90h] [rbp-70h] BYREF

  v0 = sub_1400601C0();
  if ( v0 == nullptr )
    sub_14005FF30(0x80004005);
  v1 = (*(__int64 (__fastcall **)(__int64 *))(*v0 + 24))(v0);
  v2 = (WCHAR *)(v1 + 24);
  v22 = (WCHAR *)(v1 + 24);
  if ( ((*(_DWORD *)(v1 + 12) - 260) | (1 - *(_DWORD *)(v1 + 16))) < 0 )
  {
    sub_14005FC80(&v22, 260);
    v2 = v22;
  }
  GetSystemDirectoryW(v2, 0x104u);
  if ( v2 != nullptr )
  {
    v3 = sub_1404ADD70(v2, *((int *)v2 - 3));
    if ( v3 < 0 )
      goto LABEL_46;
  }
  else
  {
    v3 = 0;
  }
  if ( v3 > *((_DWORD *)v2 - 3) )
LABEL_46:
    sub_14005FF30(0x80070057);
  *((_DWORD *)v2 - 4) = v3;
  v2[v3] = 0;
  sub_14006B130(&v22, &v25, 2);
  sub_14006B130(&v22, &lpRootPathName, 3);
  sub_1400609A0((__int64 *)&lpFileName, L"\\\\.\\", (const void **)&v25);
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v5 = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24;
  v23 = v5;
  FileW = CreateFileW(lpFileName, 0, 3u, nullptr, 3u, 0, nullptr);
  if ( FileW != (HANDLE)-1LL )
  {
    BytesReturned[0] = 0;
    v28 = 0;
    InBuffer = 0;
    OutBuffer = nullptr;
    if ( DeviceIoControl(FileW, 0x2D1400u, &InBuffer, 0xCu, &OutBuffer, 8u, BytesReturned, nullptr) )
    {
      v7 = (char *)j__malloc_base(HIDWORD(OutBuffer));
      if ( v7 != nullptr )
      {
        if ( DeviceIoControl(FileW, 0x2D1400u, &InBuffer, 0xCu, v7, HIDWORD(OutBuffer), BytesReturned, nullptr) )
        {
          v8 = *((_DWORD *)v7 + 6);
          if ( (unsigned int)(v8 - 1) <= 0xFFFFFFFD )
          {
            v9 = &v7[v8];
            if ( v9 != nullptr )
            {
              v10 = strlen(&v7[v8]);
              if ( v10 != 0 )
              {
                sub_140073B10(&v23, v9, (unsigned int)v10);
                v5 = v23;
              }
            }
          }
        }
        j__free_base(v7);
      }
    }
    CloseHandle(FileW);
  }
  v11 = sub_1400601C0();
  if ( v11 == nullptr )
    sub_14005FF30(0x80004005);
  OutBuffer = (LPSTR)((*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24);
  if ( (unsigned __int8)sub_140073860(&OutBuffer, (__int64)"Hello") == 0 )
    sub_140073B10(&OutBuffer, "Hello", 5);
  VolumeSerialNumber = 0;
  v12 = lpRootPathName;
  if ( *(_DWORD *)(v5 - 16) == 0 || (v13 = sub_14009A4C0(0, v5), VolumeSerialNumber = v13, v13 == 0) )
  {
    GetVolumeInformationW(v12, VolumeNameBuffer, 0x105u, &VolumeSerialNumber, nullptr, nullptr, nullptr, 0);
    v13 = VolumeSerialNumber;
  }
  v14 = OutBuffer;
  if ( v13 == 0 )
  {
    v13 = sub_1400CC9C0();
    VolumeSerialNumber = v13;
    if ( v13 == 0 )
    {
      sub_1400CC900(BytesReturned);
      v15 = *(_QWORD *)BytesReturned;
      v13 = sub_14009A4C0(0, *(_QWORD *)BytesReturned);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v15 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v15 - 24) + 8LL))(*(_QWORD *)(v15 - 24));
      VolumeSerialNumber = v13;
      if ( v13 == 0 && *((_DWORD *)v14 - 4) != 0 )
      {
        v13 = sub_14009A4C0(0, v14);
        VolumeSerialNumber = v13;
      }
    }
  }
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v14 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v14 - 3) + 8LL))(*((_QWORD *)v14 - 3));
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v5 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v5 - 24) + 8LL))(*(_QWORD *)(v5 - 24));
  v16 = lpFileName - 12;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)lpFileName - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v16 + 8LL))(*(_QWORD *)v16);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v12 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v12 - 3) + 8LL))(*((_QWORD *)v12 - 3));
  v17 = v25 - 6;
  if ( _InterlockedExchangeAdd(v25 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v17 + 8LL))(*(_QWORD *)v17);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v2 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v2 - 3) + 8LL))(*((_QWORD *)v2 - 3));
  return v13;
}
