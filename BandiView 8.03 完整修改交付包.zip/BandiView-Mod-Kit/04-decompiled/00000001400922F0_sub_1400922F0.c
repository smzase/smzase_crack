// EA 0x1400922f0  name sub_1400922F0  size 291
__int64 __fastcall sub_1400922F0(unsigned int a1, unsigned int a2, char a3, unsigned int a4)
{
  int v8; // r10d
  int v9; // eax
  unsigned __int64 v10; // rbx
  __int64 v11; // rbx
  char *v12; // rdi
  signed __int64 v13; // rbx
  int v15; // [rsp+20h] [rbp-68h] BYREF
  __int128 v16; // [rsp+28h] [rbp-60h] BYREF
  char *v17; // [rsp+38h] [rbp-50h]
  void *Src[2]; // [rsp+40h] [rbp-48h] BYREF
  __int64 v19; // [rsp+50h] [rbp-38h]

  *(_OWORD *)Src = 0;
  v19 = 0;
  v8 = 0;
  v15 = 0;
  v9 = 0;
  do
  {
    if ( a3 == 0 || *((_DWORD *)&unk_1406DCBB4 + 8 * v9) != 0 )
    {
      sub_140093E70(Src, &v15);
      v8 = v15;
    }
    v15 = ++v8;
    v9 = v8;
  }
  while ( v8 < 68 );
  v16 = 0;
  v17 = nullptr;
  v10 = ((char *)Src[1] - (char *)Src[0]) >> 2;
  if ( v10 != 0 )
  {
    if ( v10 > 0x3FFFFFFFFFFFFFFFLL )
      unknown_libname_4();
    v11 = 4 * v10;
    v12 = (char *)sub_14005D1E0(v11);
    *(_QWORD *)&v16 = v12;
    *((_QWORD *)&v16 + 1) = v12;
    v17 = &v12[v11];
    v13 = (char *)Src[1] - (char *)Src[0];
    memcpy(v12, Src[0], (char *)Src[1] - (char *)Src[0]);
    *((_QWORD *)&v16 + 1) = &v12[4 * (v13 >> 2)];
  }
  sub_140092420(&v16, a1, a2, a4);
  return sub_1400941F0(Src);
}
