// EA 0x1404add70  name sub_1404ADD70  size 518
__int64 __fastcall sub_1404ADD70(_WORD *a1, unsigned __int64 a2)
{
  _WORD *v6; // rax
  _WORD *v7; // rdx
  __int64 result; // rax
  unsigned __int64 v9; // r10
  __int64 v10; // rcx
  _WORD *v11; // rdx
  unsigned __int64 v12; // r10
  _WORD *v13; // rax
  __int64 v14; // rdx
  _WORD *v15; // r8
  _WORD *i; // rdx
  _WORD *j; // rax
  _WORD *v19; // rcx
  _WORD *k; // rax
  unsigned __int64 v21; // r10
  __int64 v22; // rcx
  _WORD *v23; // rax
  unsigned __int64 v24; // r10
  _WORD *v25; // rcx
  __m128i *v26; // r8
  __m128i *m; // rcx
  __m128i *n; // rax
  _WORD *v29; // rcx

  if ( dword_1406DA088 >= 5 )
  {
    if ( ((unsigned __int8)a1 & 1) != 0 )
    {
      v6 = &a1[a2];
      v7 = a1;
      if ( a1 != v6 )
      {
        while ( *v7 != 0 )
        {
          if ( ++v7 == v6 )
            return v7 - a1;
        }
      }
    }
    else
    {
      v9 = 0;
      v10 = (unsigned __int8)a1 & 0x1F;
      v11 = a1;
      if ( v10 != 0 )
        v9 = 32 - v10;
      v12 = v9 >> 1;
      if ( a2 < v12 )
        v12 = a2;
      v13 = &a1[v12];
      if ( a1 != v13 )
      {
        do
        {
          if ( *v11 == 0 )
            break;
          ++v11;
        }
        while ( v11 != v13 );
      }
      v14 = v11 - a1;
      if ( v14 != v12 )
        return v14;
      v15 = &a1[v14];
      for ( i = &a1[v14 + a2 - v12 - (((_BYTE)a2 - (_BYTE)v12) & 0x1F)]; v15 != i; v15 += 16 )
      {
        __asm
        {
          vpxor   xmm1, xmm1, xmm1
          vpcmpeqw ymm1, ymm1, ymmword ptr [r8]
          vpmovmskb eax, ymm1
        }
        __asm { vzeroupper }
        if ( _EAX != 0 )
          break;
      }
      for ( j = &a1[a2]; v15 != j; ++v15 )
      {
        if ( *v15 == 0 )
          break;
      }
      v7 = v15;
    }
    return v7 - a1;
  }
  if ( dword_1406DA088 < 1 )
  {
    v29 = &a1[a2];
    for ( k = a1; k != v29; ++k )
    {
      if ( *k == 0 )
        break;
    }
    return k - a1;
  }
  if ( ((unsigned __int8)a1 & 1) != 0 )
  {
    v19 = &a1[a2];
    k = a1;
    if ( a1 != v19 )
    {
      while ( *k != 0 )
      {
        if ( ++k == v19 )
          return k - a1;
      }
    }
    return k - a1;
  }
  v21 = 0;
  v22 = (unsigned __int8)a1 & 0xF;
  if ( v22 != 0 )
    v21 = 16 - v22;
  v23 = a1;
  v24 = v21 >> 1;
  if ( a2 < v24 )
    v24 = a2;
  v25 = &a1[v24];
  if ( a1 != v25 )
  {
    do
    {
      if ( *v23 == 0 )
        break;
      ++v23;
    }
    while ( v23 != v25 );
  }
  result = v23 - a1;
  if ( result == v24 )
  {
    v26 = (__m128i *)&a1[result];
    for ( m = (__m128i *)&a1[result + a2 - v24 - (((_BYTE)a2 - (_BYTE)v24) & 0xF)]; v26 != m; ++v26 )
    {
      if ( _mm_movemask_epi8(_mm_cmpeq_epi16((__m128i)0LL, *v26)) != 0 )
        break;
    }
    for ( n = (__m128i *)&a1[a2]; v26 != n; v26 = (__m128i *)((char *)v26 + 2) )
    {
      if ( v26->m128i_i16[0] == 0 )
        break;
    }
    return ((char *)v26 - (char *)a1) >> 1;
  }
  return result;
}
