// EA 0x14009e480  name sub_14009E480  size 1333
__int64 __fastcall sub_14009E480(__int64 a1, unsigned __int64 *a2, char *a3, __int64 a4)
{
  __int64 v7; // rcx
  __m128i si128; // xmm6
  const WCHAR *v9; // rbx
  unsigned __int64 v10; // rax
  volatile signed __int32 *v11; // rdx
  __int64 v12; // r8
  unsigned __int64 v13; // rdx
  __int128 *v14; // r9
  void *v15; // rax
  char **v16; // rdx
  const void *v17; // rdx
  __int64 v18; // rdx
  __int64 v19; // r8
  char *v20; // rdi
  __int64 v21; // r15
  unsigned __int16 *v22; // rbx
  char **v23; // r9
  char **v24; // rdx
  _QWORD *v25; // rdi
  _QWORD *v26; // rbx
  _QWORD *v27; // rdi
  _QWORD *v28; // rbx
  __int128 *v29; // rdx
  __int128 *v30; // rdx
  char **v31; // rdx
  char **v32; // rdx
  volatile signed __int32 *v33; // rdx
  volatile signed __int32 *v36; // [rsp+48h] [rbp-B8h] BYREF
  volatile signed __int32 *v37; // [rsp+50h] [rbp-B0h] BYREF
  __int128 v38; // [rsp+58h] [rbp-A8h] BYREF
  __int64 v39; // [rsp+68h] [rbp-98h]
  __int64 v40; // [rsp+70h] [rbp-90h]
  unsigned __int64 *v41; // [rsp+78h] [rbp-88h]
  char *v42; // [rsp+80h] [rbp-80h]
  __int128 v43; // [rsp+88h] [rbp-78h] BYREF
  __m128i v44; // [rsp+98h] [rbp-68h]
  char *v45[2]; // [rsp+A8h] [rbp-58h] BYREF
  unsigned __int64 v46; // [rsp+B8h] [rbp-48h]
  unsigned __int64 v47; // [rsp+C0h] [rbp-40h]
  char *v48[2]; // [rsp+C8h] [rbp-38h] BYREF
  unsigned __int64 v49; // [rsp+D8h] [rbp-28h]
  unsigned __int64 v50; // [rsp+E0h] [rbp-20h]
  __int128 v51; // [rsp+E8h] [rbp-18h] BYREF
  __m128i v52; // [rsp+F8h] [rbp-8h]
  __int128 v53; // [rsp+108h] [rbp+8h] BYREF
  __m128i v54; // [rsp+118h] [rbp+18h]
  char *v55[4]; // [rsp+128h] [rbp+28h] BYREF

  v41 = a2;
  v42 = a3;
  sub_14009DB40(&v36);
  v7 = *sub_1400609A0((__int64 *)&v37, L"DOWNLOAD.", (const void **)&v36);
  v53 = 0;
  si128 = _mm_load_si128((const __m128i *)&xmmword_140662F90);
  v54 = si128;
  LOWORD(v53) = 0;
  v9 = &Data;
  if ( v7 != 0 )
    v9 = (const WCHAR *)v7;
  v10 = sub_1404ADC20(v9);
  sub_140069540((void **)&v53, v9, v10);
  v11 = v37 - 6;
  if ( _InterlockedExchangeAdd(v37 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v11 + 8LL))(*(_QWORD *)v11);
  v43 = 0;
  v44 = si128;
  LOWORD(v43) = 0;
  sub_140069540((void **)&v43, L"DOWNLOAD.", 9u);
  v13 = a2[2];
  if ( 0x7FFFFFFFFFFFFFFELL - v44.m128i_i64[0] < v13 )
    unknown_libname_3();
  v14 = &v43;
  if ( v44.m128i_i64[1] > 7uLL )
    v14 = (__int128 *)v43;
  v15 = a2;
  if ( a2[3] > 7 )
    v15 = (void *)*a2;
  sub_14005D0A0((char *)v45, v13, v12, v14, v44.m128i_i64[0], v15, a2[2]);
  v51 = 0;
  v52 = _mm_load_si128((const __m128i *)&xmmword_140662F90);
  LOWORD(v51) = 0;
  v16 = v45;
  if ( v47 > 7 )
    v16 = (char **)v45[0];
  sub_140069540((void **)&v51, v16, v46);
  sub_14005D410(v45);
  sub_14005D410((char **)&v43);
  v37 = (volatile signed __int32 *)&v38;
  v38 = 0;
  v39 = 0;
  v40 = 7;
  LOWORD(v38) = 0;
  if ( &v38 != (__int128 *)a2 )
  {
    if ( a2[3] <= 7 )
      v17 = a2;
    else
      v17 = (const void *)*a2;
    sub_140069540((void **)&v38, v17, a2[2]);
  }
  sub_14009DCF0(v48, &v38);
  if ( *((_QWORD *)a3 + 3) <= 7u )
  {
    v20 = a3;
    v21 = (__int64)&a3[2 * *((_QWORD *)a3 + 2)];
    v22 = (unsigned __int16 *)a3;
  }
  else
  {
    v20 = *(char **)a3;
    v21 = *(_QWORD *)a3 + 2LL * *((_QWORD *)a3 + 2);
    v22 = *(unsigned __int16 **)a3;
  }
  for ( ; v22 != (unsigned __int16 *)v21; ++v22 )
  {
    *(_WORD *)v20 = sub_1404C4540(*v22);
    v20 += 2;
  }
  if ( 0x7FFFFFFFFFFFFFFELL == v49 )
    unknown_libname_3();
  v23 = v48;
  if ( v50 > 7 )
    v23 = (char **)v48[0];
  sub_14005D0A0((char *)v45, v18, v19, v23, v49, (void *)L".", 1);
  v43 = 0;
  v44 = _mm_load_si128((const __m128i *)&xmmword_140662F90);
  LOWORD(v43) = 0;
  v24 = v45;
  if ( v47 > 7 )
    v24 = (char **)v45[0];
  sub_140069540((void **)&v43, v24, v46);
  sub_14005D410(v45);
  sub_1401CAEC0(v55, &v43, a3);
  sub_14005D410((char **)&v43);
  v25 = (_QWORD *)(a4 + 128);
  sub_140069540((void **)(a4 + 128), &Data, 0);
  v26 = (_QWORD *)(a4 + 96);
  if ( a4 + 96 != a4 + 128 )
  {
    if ( *(_QWORD *)(a4 + 152) > 7u )
      v25 = (_QWORD *)*v25;
    sub_140069540((void **)(a4 + 96), v25, *(_QWORD *)(a4 + 144));
  }
  v27 = (_QWORD *)(a4 + 64);
  if ( (_QWORD *)(a4 + 64) != v26 )
  {
    if ( *(_QWORD *)(a4 + 120) > 7u )
      v26 = (_QWORD *)*v26;
    sub_140069540((void **)(a4 + 64), v26, *(_QWORD *)(a4 + 112));
  }
  v28 = (_QWORD *)(a4 + 32);
  if ( (_QWORD *)(a4 + 32) != v27 )
  {
    if ( *(_QWORD *)(a4 + 88) > 7u )
      v27 = (_QWORD *)*v27;
    sub_140069540((void **)(a4 + 32), v27, *(_QWORD *)(a4 + 80));
  }
  if ( (_QWORD *)a4 != v28 )
  {
    if ( *(_QWORD *)(a4 + 56) > 7u )
      v28 = (_QWORD *)*v28;
    sub_140069540((void **)a4, v28, *(_QWORD *)(a4 + 48));
  }
  v37 = (volatile signed __int32 *)&v43;
  v43 = 0;
  v44.m128i_i64[0] = 0;
  v44.m128i_i64[1] = 7;
  LOWORD(v43) = 0;
  v29 = &v53;
  if ( v54.m128i_i64[1] > 7uLL )
    v29 = (__int128 *)v53;
  sub_140069540((void **)&v43, v29, v54.m128i_u64[0]);
  sub_14009E000(a1, &v43, a4);
  v43 = 0;
  v44.m128i_i64[0] = 0;
  v44.m128i_i64[1] = 7;
  LOWORD(v43) = 0;
  v30 = &v51;
  if ( v52.m128i_i64[1] > 7uLL )
    v30 = (__int128 *)v51;
  sub_140069540((void **)&v43, v30, v52.m128i_u64[0]);
  sub_14009E000(a1, &v43, a4);
  v43 = 0;
  v44.m128i_i64[0] = 0;
  v44.m128i_i64[1] = 7;
  LOWORD(v43) = 0;
  v31 = v48;
  if ( v50 > 7 )
    v31 = (char **)v48[0];
  sub_140069540((void **)&v43, v31, v49);
  sub_14009E000(a1, &v43, a4);
  if ( *((_QWORD *)a3 + 2) != 0 )
  {
    v43 = 0;
    v44.m128i_i64[0] = 0;
    v44.m128i_i64[1] = 7;
    LOWORD(v43) = 0;
    v32 = v55;
    if ( v55[3] > (char *)7 )
      v32 = (char **)v55[0];
    sub_140069540((void **)&v43, v32, (unsigned __int64)v55[2]);
    sub_14009E000(a1, &v43, a4);
  }
  sub_14005D410(v55);
  sub_14005D410(v48);
  sub_14005D410((char **)&v51);
  sub_14005D410((char **)&v53);
  v33 = v36 - 6;
  if ( _InterlockedExchangeAdd(v36 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v33 + 8LL))(*(_QWORD *)v33);
  sub_14005D410((char **)a2);
  return sub_14005D410((char **)a3);
}
