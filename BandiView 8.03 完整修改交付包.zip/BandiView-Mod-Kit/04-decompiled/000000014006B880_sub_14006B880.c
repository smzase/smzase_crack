// EA 0x14006b880  name sub_14006B880  size 136
_QWORD *__fastcall sub_14006B880(_QWORD *a1)
{
  int **v2; // rdi
  __int64 *v3; // rax

  *a1 = 0;
  a1[1] = 0;
  a1[2] = 0;
  a1[3] = 0;
  v2 = (int **)(a1 + 4);
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  *v2 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
  if ( (unsigned __int8)sub_14005F980(v2, (__int64)L"Error: WebView2 is not installed.") == 0 )
    sub_14005FCF0(v2, L"Error: WebView2 is not installed.", 33);
  return a1;
}
