// EA 0x1401d18c0  name sub_1401D18C0  size 356
__int64 __fastcall sub_1401D18C0(__int64 a1, __int64 a2, __int64 **a3, unsigned int a4)
{
  _QWORD *v6; // rax
  __int64 v8; // rdx
  __m128i si128; // xmm6
  __int64 v10; // rdx
  __int64 v11; // rax
  __int64 v12; // rcx
  __int128 *v13; // rcx
  __int128 v15; // [rsp+30h] [rbp-69h] BYREF
  __m128i v16; // [rsp+40h] [rbp-59h]
  __int128 v17; // [rsp+50h] [rbp-49h] BYREF
  __m128i v18; // [rsp+60h] [rbp-39h]
  int v19; // [rsp+70h] [rbp-29h]
  _QWORD v20[4]; // [rsp+80h] [rbp-19h] BYREF
  _QWORD v21[4]; // [rsp+A0h] [rbp+7h] BYREF

  v6 = (_QWORD *)a2;
  v8 = *(unsigned int *)(a2 + 16);
  if ( v6[3] > 7u )
    v6 = (_QWORD *)*v6;
  *(_OWORD *)v21 = 0;
  si128 = _mm_load_si128((const __m128i *)&xmmword_140662FA0);
  *(__m128i *)&v21[2] = si128;
  LOBYTE(v21[0]) = 0;
  sub_1401CB4C0(v6, v8, v21);
  v10 = *((unsigned int *)a3 + 4);
  if ( (unsigned __int64)a3[3] > 7 )
    a3 = (__int64 **)*a3;
  *(_OWORD *)v20 = 0;
  *(__m128i *)&v20[2] = si128;
  LOBYTE(v20[0]) = 0;
  sub_1401CB4C0(a3, v10, v20);
  v11 = sub_1401D2130(a1, v21);
  if ( v11 != 0 )
  {
    v15 = 0;
    v16 = _mm_load_si128((const __m128i *)&xmmword_140662FA0);
    LOBYTE(v15) = 0;
    v17 = 0;
    v18 = v16;
    LOBYTE(v17) = 0;
    v19 = 0;
    if ( (unsigned __int8)sub_1401D17A0(v12, v11, v20, &v15) != 0 )
    {
      v13 = &v17;
      if ( v18.m128i_i64[1] > 0xFuLL )
        v13 = (__int128 *)v17;
      a4 = sub_1404BF974(v13, 0, 10);
    }
    sub_14007F110(&v17);
    sub_14007F110(&v15);
  }
  sub_14007F110(v20);
  sub_14007F110(v21);
  return a4;
}
