// EA 0x140065d40  name sub_140065D40  size 106
void __fastcall sub_140065D40(__int64 a1, _QWORD **a2)
{
  _QWORD *v2; // rbx
  _QWORD *v3; // rdi
  volatile signed __int32 *v4; // rdx

  *a2[1] = 0;
  v2 = *a2;
  if ( *a2 != nullptr )
  {
    do
    {
      v3 = (_QWORD *)*v2;
      v4 = (volatile signed __int32 *)(v2[2] - 24LL);
      if ( _InterlockedExchangeAdd(v4 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v4 + 8LL))(*(_QWORD *)v4);
      j_j_j__free_base(v2);
      v2 = v3;
    }
    while ( v3 != nullptr );
  }
}
