// EA 0x140074840  name sub_140074840  size 1007
__int64 __fastcall sub_140074840(unsigned __int64 *a1, _QWORD *a2, char a3)
{
  int v6; // ebx
  __int64 v7; // rax
  __int64 v8; // rbx
  __int64 *v9; // rax
  __int64 *v10; // rax
  wchar_t *v11; // rbx
  __int64 *v12; // rax
  int v13; // eax
  __int64 v14; // rsi
  unsigned __int64 v15; // rbp
  unsigned int v16; // eax
  __int64 v17; // rdi
  __int64 v18; // rdx
  __int64 v19; // r8
  __int64 v20; // rbx
  _QWORD *v21; // rax
  int *v22; // rdi
  _QWORD *v23; // rdx
  int **v24; // rdx
  __int64 v25; // rax
  __int64 v26; // r13
  __int64 v27; // r12
  int **v28; // rsi
  int *v29; // rbx
  uintptr_t v30; // rax
  volatile signed __int32 *v31; // rdx
  signed __int32 v32; // eax
  bool v33; // cc
  __int64 result; // rax
  volatile signed __int32 *v35; // rdx
  unsigned int *ThrdAddr; // [rsp+28h] [rbp-70h]
  int *v37; // [rsp+40h] [rbp-58h] BYREF
  __int64 v38; // [rsp+48h] [rbp-50h] BYREF
  int **v39; // [rsp+50h] [rbp-48h] BYREF
  unsigned __int64 *v40; // [rsp+A0h] [rbp+8h]
  _QWORD *v41; // [rsp+A8h] [rbp+10h]
  int *v42; // [rsp+B8h] [rbp+20h] BYREF

  v41 = a2;
  v40 = a1;
  if ( *(_BYTE *)sub_140075FE0() != 0 && *(_BYTE *)(sub_14007D5E0() + 96) != 0 && byte_1406DC8F4 == 0 )
  {
    v6 = sub_140074720();
    if ( *(_DWORD *)(sub_140075FE0() + 24) == v6 )
    {
      if ( *(int *)(sub_140075FE0() + 28) > 3 )
        goto LABEL_29;
      v7 = sub_140075FE0();
      ++*(_DWORD *)(v7 + 28);
    }
    else
    {
      *(_DWORD *)(sub_140075FE0() + 24) = v6;
      *(_DWORD *)(sub_140075FE0() + 28) = 1;
    }
    v8 = sub_140075FE0();
    v39 = &v42;
    v9 = sub_1400601C0();
    if ( v9 == nullptr )
      sub_14005FF30(0x80004005);
    v42 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
    if ( (unsigned __int8)sub_14005F980(&v42, (__int64)&Data) == 0 )
      sub_14005FCF0(&v42, &Data, 0);
    sub_140076F50(v8, 1, &v42);
    sub_140060D20(a1, (__int64)L"\n", L"\\n");
    sub_140060D20(a1, (__int64)L"\r", L"\\r");
    v10 = sub_1400601C0();
    if ( v10 == nullptr )
      sub_14005FF30(0x80004005);
    v42 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24);
    v11 = L"http://log.bandi.so/dump/report.php?name=%s&buildDate=%s&version=%s&os=%s&param=%s&type=%s";
    if ( a3 != 0 )
      v11 = L"https://log.bandi.so/dump/report.php?name=%s&buildDate=%s&version=%s&os=%s&param=%s&type=%s";
    v12 = sub_1400601C0();
    if ( v12 == nullptr )
      sub_14005FF30(0x80004005);
    v37 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24);
    if ( (unsigned __int8)sub_14005F980(&v37, (__int64)v11) == 0 )
    {
      v13 = sub_1404ADC20(v11);
      sub_14005FCF0(&v37, v11, v13);
    }
    v14 = *a2;
    v15 = *a1;
    v16 = sub_14006E550();
    v17 = sub_14006E440(v16);
    v20 = *sub_140074440(&v39, v18, v19);
    v21 = (_QWORD *)sub_14006E1D0(&v38, L"%04d%02d%02d");
    ThrdAddr = (unsigned int *)v17;
    v22 = v37;
    sub_14005EB50((__int64)&v42, (__int64)v37, L"BandiView", *v21, v20, ThrdAddr, v15, v14);
    v23 = (_QWORD *)(v38 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v38 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v23 + 8LL))(*v23);
    v24 = v39 - 3;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v39 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(int *))(*(_QWORD *)*v24 + 8LL))(*v24);
    v25 = sub_14007D5E0();
    v26 = v25 + 120;
    v27 = *(_QWORD *)(v25 + 128);
    if ( v27 == *(_QWORD *)(v25 + 136) )
    {
      sub_140075A60(v25 + 120, *(_QWORD *)(v25 + 128), sub_140074780, &v42);
      v29 = v42;
    }
    else
    {
      v28 = (int **)operator new(0x10u);
      v39 = v28;
      v29 = v42;
      *v28 = (int *)(sub_14005F710(v42 - 6) + 24);
      v28[1] = (int *)sub_140074780;
      v39 = v28;
      v30 = beginthreadex(nullptr, 0, sub_140075D90, v28, 0, (unsigned int *)(v27 + 8));
      *(_QWORD *)v27 = v30;
      if ( v30 == 0 )
      {
        *(_DWORD *)(v27 + 8) = 0;
        std::_Throw_Cpp_error(6);
      }
      *(_QWORD *)(v26 + 8) += 16LL;
    }
    sub_14006DB60((__int64)L"BandiView Error report: %s", v29);
    if ( _InterlockedExchangeAdd(v22 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v22 - 3) + 8LL))(*((_QWORD *)v22 - 3));
    if ( _InterlockedExchangeAdd(v29 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v29 - 3) + 8LL))(*((_QWORD *)v29 - 3));
  }
LABEL_29:
  v31 = (volatile signed __int32 *)(*a1 - 24);
  v32 = _InterlockedExchangeAdd(v31 + 4, 0xFFFFFFFF);
  v33 = v32 <= 1;
  result = (unsigned int)(v32 - 1);
  if ( v33 )
    result = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v31 + 8LL))(*(_QWORD *)v31);
  v35 = (volatile signed __int32 *)(*a2 - 24LL);
  if ( _InterlockedExchangeAdd(v35 + 4, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v35 + 8LL))(*(_QWORD *)v35);
  return result;
}
