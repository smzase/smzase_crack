// EA 0x1401be5d0  name sub_1401BE5D0  size 325
__int64 __fastcall sub_1401BE5D0(__int64 a1, _QWORD *a2)
{
  __int64 v3; // r15
  volatile signed __int32 *v4; // rsi
  unsigned __int16 *v5; // r14
  unsigned int v6; // edi
  unsigned __int16 v7; // ax
  _WORD *v8; // rcx
  __int64 v9; // rbx
  __int64 v10; // r9
  unsigned int v11; // r8d
  __int64 v12; // rax
  __int64 v13; // rdi
  volatile signed __int32 *v14; // rdx

  v3 = *(_QWORD *)(a1 + 1240);
  v4 = (volatile signed __int32 *)sub_14005F710((volatile signed __int32 *)(*a2 - 24LL));
  v5 = (unsigned __int16 *)(v4 + 6);
  if ( v4 == (volatile signed __int32 *)-24LL )
    sub_14005FF30(0x80004005);
  v6 = 0;
  v7 = *v5;
  if ( *v5 != 0 )
  {
    v8 = v4 + 6;
    do
    {
      v6 = v7 + 33 * v6;
      v7 = *++v8;
    }
    while ( *v8 != 0 );
  }
  if ( *(_QWORD *)v3 != 0 && (v9 = *(_QWORD *)(*(_QWORD *)v3 + 8LL * (v6 % *(_DWORD *)(v3 + 16)))) != 0 )
  {
    while ( *(_DWORD *)(v9 + 24) != v6 || (unsigned int)sub_1404D8590(*(_QWORD *)v9, v5) != 0 )
    {
      v9 = *(_QWORD *)(v9 + 16);
      if ( v9 == 0 )
        goto LABEL_10;
    }
  }
  else
  {
LABEL_10:
    v9 = 0;
  }
  if ( v9 != 0
    && (v10 = *(_QWORD *)(v3 + 144)) != 0
    && (v11 = *(_DWORD *)(v9 + 8), (v12 = *(_QWORD *)(v10 + 8LL * (v11 % *(_DWORD *)(v3 + 160)))) != 0) )
  {
    while ( *(_DWORD *)(v12 + 24) != v11 || *(_DWORD *)v12 != v11 )
    {
      v12 = *(_QWORD *)(v12 + 16);
      if ( v12 == 0 )
        goto LABEL_17;
    }
    v13 = *(_QWORD *)(v12 + 8);
  }
  else
  {
LABEL_17:
    v13 = 0;
  }
  if ( _InterlockedExchangeAdd(v4 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v4 + 8LL))(*(_QWORD *)v4, v4);
  v14 = (volatile signed __int32 *)(*a2 - 24LL);
  if ( _InterlockedExchangeAdd(v14 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v14 + 8LL))(*(_QWORD *)v14);
  return v13;
}
