// EA 0x140098bf0  name sub_140098BF0  size 1381
__int64 __fastcall sub_140098BF0(__int64 a1)
{
  __int64 v2; // rdi
  __int64 v3; // rax
  _BYTE *v4; // rbx
  __int64 *v5; // rax
  int v6; // eax
  __int64 *v7; // rax
  __int64 v8; // rax
  _BYTE *v9; // rbx
  __int64 *v10; // rax
  int v11; // eax
  __int64 *v12; // rax
  __int64 v13; // rax
  _BYTE *v14; // rbx
  __int64 *v15; // rax
  int v16; // eax
  __int64 *v17; // rax
  __int64 v18; // rax
  _BYTE *v19; // rbx
  __int64 *v20; // rax
  int v21; // eax
  __int64 *v22; // rax
  __int64 *v23; // rax
  int v24; // eax
  __int64 v25; // rax
  __int64 v26; // rax
  _BYTE *v27; // rbx
  __int64 v28; // rax
  __int64 v29; // rax
  int *v30; // rbx
  __int64 *v31; // rax
  signed __int32 v32; // eax
  bool v33; // cc
  __int64 result; // rax
  int *v35; // [rsp+60h] [rbp+28h] BYREF
  int *v36; // [rsp+68h] [rbp+30h] BYREF
  int **v37; // [rsp+70h] [rbp+38h] BYREF
  int **v38; // [rsp+78h] [rbp+40h]

  v2 = *(_QWORD *)(a1 + 160);
  v37 = &v35;
  v3 = sub_1401C5640();
  v4 = (_BYTE *)sub_1401C81E0(v3, L"IDC_STATIC_COMPARISON", L"IDD_LICENSE_GUIDE");
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  v35 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
  if ( (unsigned __int8)sub_14005F980(&v35, (__int64)v4) == 0 )
  {
    if ( v4 != nullptr )
      v6 = sub_1404ADC20(v4);
    else
      v6 = 0;
    sub_14005FCF0(&v35, v4, v6);
  }
  v38 = &v36;
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  v36 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
  if ( (unsigned __int8)sub_14005F980(&v36, (__int64)L"BTN_COMPARISON") == 0 )
    sub_14005FCF0(&v36, L"BTN_COMPARISON", 14);
  sub_1401C5020(v2, &v36, &v35);
  v37 = &v35;
  v8 = sub_1401C5640();
  v9 = (_BYTE *)sub_1401C81E0(v8, L"IDC_STATIC_HOWTOREGISTER", L"IDD_LICENSE_GUIDE");
  v10 = sub_1400601C0();
  if ( v10 == nullptr )
    sub_14005FF30(0x80004005);
  v35 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24);
  if ( (unsigned __int8)sub_14005F980(&v35, (__int64)v9) == 0 )
  {
    if ( v9 != nullptr )
      v11 = sub_1404ADC20(v9);
    else
      v11 = 0;
    sub_14005FCF0(&v35, v9, v11);
  }
  v38 = &v36;
  v12 = sub_1400601C0();
  if ( v12 == nullptr )
    sub_14005FF30(0x80004005);
  v36 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24);
  if ( (unsigned __int8)sub_14005F980(&v36, (__int64)L"BTN_HOWTOREGISTER") == 0 )
    sub_14005FCF0(&v36, L"BTN_HOWTOREGISTER", 17);
  sub_1401C5020(v2, &v36, &v35);
  v37 = &v35;
  v13 = sub_1401C5640();
  v14 = (_BYTE *)sub_1401C81E0(v13, L"IDC_STATIC_BUYNOW", L"IDD_REGISTER");
  v15 = sub_1400601C0();
  if ( v15 == nullptr )
    sub_14005FF30(0x80004005);
  v35 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
  if ( (unsigned __int8)sub_14005F980(&v35, (__int64)v14) == 0 )
  {
    if ( v14 != nullptr )
      v16 = sub_1404ADC20(v14);
    else
      v16 = 0;
    sub_14005FCF0(&v35, v14, v16);
  }
  v38 = &v36;
  v17 = sub_1400601C0();
  if ( v17 == nullptr )
    sub_14005FF30(0x80004005);
  v36 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v17 + 24))(v17) + 24);
  if ( (unsigned __int8)sub_14005F980(&v36, (__int64)L"BTN_BUYNOW") == 0 )
    sub_14005FCF0(&v36, L"BTN_BUYNOW", 10);
  sub_1401C5020(v2, &v36, &v35);
  v37 = &v35;
  v18 = sub_1401C5640();
  v19 = (_BYTE *)sub_1401C81E0(v18, L"TEXT_MESSAGEBOX_OK", L"TEXT");
  v20 = sub_1400601C0();
  if ( v20 == nullptr )
    sub_14005FF30(0x80004005);
  v35 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v20 + 24))(v20) + 24);
  if ( (unsigned __int8)sub_14005F980(&v35, (__int64)v19) == 0 )
  {
    if ( v19 != nullptr )
      v21 = sub_1404ADC20(v19);
    else
      v21 = 0;
    sub_14005FCF0(&v35, v19, v21);
  }
  v38 = &v36;
  v22 = sub_1400601C0();
  if ( v22 == nullptr )
    sub_14005FF30(0x80004005);
  v36 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v22 + 24))(v22) + 24);
  if ( (unsigned __int8)sub_14005F980(&v36, (__int64)L"IDOK") == 0 )
    sub_14005FCF0(&v36, L"IDOK", 4);
  sub_1401C5020(v2, &v36, &v35);
  v23 = sub_1400601C0();
  if ( v23 == nullptr )
    sub_14005FF30(0x80004005);
  v35 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v23 + 24))(v23) + 24);
  if ( (unsigned __int8)sub_14005F980(&v35, (__int64)L"...") == 0 )
    sub_14005FCF0(&v35, L"...", 3);
  v24 = *(_DWORD *)(a1 + 72);
  switch ( v24 )
  {
    case 0:
      v25 = sub_1401C5640();
      v26 = sub_1401C81E0(v25, L"TEXT_SHOW_AD", L"IDD_LICENSE_GUIDE");
      v27 = (_BYTE *)v26;
      if ( v26 == 0 )
        goto LABEL_49;
      goto LABEL_48;
    case 1:
      v28 = sub_1401C5640();
      v26 = sub_1401C81E0(v28, L"TEXT_CANNOT_CHANGE", L"IDD_LICENSE_GUIDE");
      v27 = (_BYTE *)v26;
      if ( v26 == 0 )
        goto LABEL_49;
      goto LABEL_48;
    case 2:
      v29 = sub_1401C5640();
      v26 = sub_1401C81E0(v29, L"TEXT_CANNOT_USE", L"IDD_LICENSE_GUIDE");
      v27 = (_BYTE *)v26;
      if ( v26 != 0 )
LABEL_48:
        LODWORD(v26) = sub_1404ADC20(v27);
LABEL_49:
      sub_14005FCF0(&v35, v27, v26);
      break;
    default:
      break;
  }
  v38 = (int **)&v37;
  v30 = v35;
  v37 = (int **)(sub_14005F710(v35 - 6) + 24);
  v31 = sub_1400601C0();
  if ( v31 == nullptr )
    sub_14005FF30(0x80004005);
  v36 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v31 + 24))(v31) + 24);
  if ( (unsigned __int8)sub_14005F980(&v36, (__int64)L"STATIC_MESSAGE") == 0 )
    sub_14005FCF0(&v36, L"STATIC_MESSAGE", 14);
  sub_1401C5020(v2, &v36, &v37);
  v32 = _InterlockedExchangeAdd(v30 - 2, 0xFFFFFFFF);
  v33 = v32 <= 1;
  result = (unsigned int)(v32 - 1);
  if ( v33 )
    return (*(__int64 (__fastcall **)(_QWORD, int *))(**((_QWORD **)v30 - 3) + 8LL))(*((_QWORD *)v30 - 3), v30 - 6);
  return result;
}
