// EA 0x1401d47b0  name sub_1401D47B0  size 314
void __fastcall sub_1401D47B0(__int64 a1, HWND a2)
{
  __int64 v3; // rcx
  _OWORD *v4; // rdi
  void *v5; // rcx

  if ( *(_BYTE *)(a1 + 8) != 0 && a2 != nullptr )
  {
    if ( *(_DWORD *)(a1 + 4) == 3 )
    {
      byte_1406F8D4B = 0;
      sub_1402B75D0(a2);
      sub_1401D48F0(v3, a2);
    }
    else
    {
      byte_1406F8D4B = 1;
      sub_1402B75D0(a2);
      if ( !GetWindowSubclass(a2, sub_1402BE6D0, 0x3Au, nullptr) )
        SetWindowSubclass(a2, sub_1402BE6D0, 0x3Au, 0);
      if ( !GetWindowSubclass(a2, sub_1402C0150, 0x3Du, nullptr) )
      {
        v4 = operator new(0x48u);
        *v4 = 0;
        v4[1] = 0;
        v4[2] = 0;
        v4[3] = 0;
        *((_QWORD *)v4 + 8) = 0;
        *(_QWORD *)v4 = *(_QWORD *)L"MENU";
        if ( !SetWindowSubclass(a2, sub_1402C0150, 0x3Du, (DWORD_PTR)v4) )
        {
          v5 = *((void **)v4 + 8);
          if ( v5 != nullptr )
          {
            CloseThemeData(v5);
            *((_QWORD *)v4 + 8) = 0;
          }
          j_j_j__free_base(v4);
        }
      }
    }
    RedrawWindow(a2, nullptr, nullptr, 0x585u);
  }
}
