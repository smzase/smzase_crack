// EA 0x1400692c0  name sub_1400692C0  size 225
INT_PTR __fastcall sub_1400692C0(__int64 a1, HWND a2)
{
  __int64 v2; // rax

  v2 = *(_QWORD *)(a1 + 40);
  if ( v2 != 0 || (v2 = sub_140495D90(), *(_QWORD *)(a1 + 40) = v2, v2 != 0) )
  {
    sub_140495EC0(v2, 0, 0);
    if ( a1 == -16 || a1 == 0 )
    {
      sub_14005F240(3221225477LL, 1);
      JUMPOUT(0x1400693A0LL);
    }
    *(_QWORD *)(a1 + 16) = a1;
    *(_DWORD *)(a1 + 24) = GetCurrentThreadId();
    EnterCriticalSection(&CriticalSection);
    *(_QWORD *)(a1 + 32) = qword_1406FBC60;
    qword_1406FBC60 = a1 + 16;
    LeaveCriticalSection(&CriticalSection);
    return DialogBoxParamW(hInstance, (LPCWSTR)0x88, a2, DialogFunc, 0);
  }
  else
  {
    SetLastError(0xEu);
    return -1;
  }
}
