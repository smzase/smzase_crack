// EA 0x140097230  name sub_140097230  size 792
__int64 __fastcall sub_140097230(_QWORD *a1, _QWORD *a2, _QWORD *a3)
{
  __int64 v6; // r15
  __int64 v7; // rdx
  __int64 v8; // rcx
  unsigned __int16 *v9; // r8
  const WCHAR *v10; // rbx
  __int64 v11; // rax
  unsigned int v12; // eax
  __int64 v13; // rdx
  int v14; // r8d
  int v15; // r8d
  __int64 v16; // rdx
  int v17; // r8d
  int v18; // r8d
  __int64 v19; // rdx
  int v20; // r8d
  int v21; // r8d
  _QWORD *v22; // rdx
  _QWORD *v23; // rdx
  volatile signed __int32 *v24; // rdx
  volatile signed __int32 *v25; // rdx
  volatile signed __int32 *v26; // rdx
  volatile signed __int32 *v28; // rdx
  volatile signed __int32 *v29; // rdx
  volatile signed __int32 *v30; // rdx
  __int64 v31; // [rsp+20h] [rbp-38h] BYREF
  __int64 v32; // [rsp+28h] [rbp-30h] BYREF
  _QWORD v33[5]; // [rsp+30h] [rbp-28h] BYREF
  __int64 v34; // [rsp+A8h] [rbp+50h] BYREF

  v31 = 0;
  v6 = sub_1400A1680();
  sub_1400A2270(v6);
  v9 = *(unsigned __int16 **)(v6 + 96);
  if ( *((_DWORD *)v9 - 4) == 0 )
    goto LABEL_6;
  v7 = (unsigned int)*v9 - 111;
  if ( *v9 == 111 )
  {
    v7 = (unsigned int)v9[1] - 107;
    if ( v9[1] == 107 )
    {
      v8 = 0;
      v7 = v9[2];
    }
  }
  v10 = &Data;
  if ( (_DWORD)v7 == 0 )
LABEL_6:
    v10 = *(const WCHAR **)(v6 + 40);
  v11 = sub_1400601C0(v8, v7, v9);
  if ( v11 == 0 )
    sub_14005FF30(2147500037LL);
  v34 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v11 + 24LL))(v11) + 24;
  if ( (unsigned __int8)sub_14005F980(&v34, v10) == 0 )
  {
    if ( v10 != nullptr )
      v12 = sub_1404ADC20(v10);
    else
      v12 = 0;
    sub_14005FCF0(&v34, v10, v12);
  }
  v13 = 0;
  do
  {
    v14 = *(unsigned __int16 *)(v34 + 2 * v13++);
    v15 = v14 - aEnt[v13 - 1];
  }
  while ( v15 == 0 && v13 != 4 );
  if ( v15 == 0 )
    goto LABEL_27;
  v16 = 0;
  do
  {
    v17 = *(unsigned __int16 *)(v34 + 2 * v16++);
    v18 = v17 - aPrv[v16 - 1];
  }
  while ( v18 == 0 && v16 != 4 );
  if ( v18 == 0 )
    goto LABEL_27;
  v19 = 0;
  do
  {
    v20 = *(unsigned __int16 *)(v34 + 2 * v19++);
    v21 = v20 - aPro[v19 - 1];
  }
  while ( v21 == 0 && v19 != 4 );
  if ( v21 != 0 )
  {
    v22 = (_QWORD *)(v34 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v34 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v22 + 8LL))(*v22);
  }
  else
  {
LABEL_27:
    v23 = (_QWORD *)(v34 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v34 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v23 + 8LL))(*v23);
    v33[0] = &v34;
    v34 = sub_14005F710(*a2 - 24LL) + 24;
    v32 = sub_14005F710(*a1 - 24LL) + 24;
    if ( (unsigned __int8)sub_1400A23E0(v6, &v32, &v34) != 0 )
      goto LABEL_31;
  }
  v33[1] = &v34;
  v34 = sub_14005F710(*a3 - 24LL) + 24;
  v33[2] = &v32;
  v32 = sub_14005F710(*a2 - 24LL) + 24;
  v33[0] = sub_14005F710(*a1 - 24LL) + 24;
  if ( (unsigned __int8)sub_1400969B0(v33, &v32, &v34, &v31) != 0 )
  {
LABEL_31:
    v24 = (volatile signed __int32 *)(*a1 - 24LL);
    if ( _InterlockedExchangeAdd(v24 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v24 + 8LL))(*(_QWORD *)v24);
    v25 = (volatile signed __int32 *)(*a2 - 24LL);
    if ( _InterlockedExchangeAdd(v25 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v25 + 8LL))(*(_QWORD *)v25);
    v26 = (volatile signed __int32 *)(*a3 - 24LL);
    if ( _InterlockedExchangeAdd(v26 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v26 + 8LL))(*(_QWORD *)v26);
    return 0;
  }
  v28 = (volatile signed __int32 *)(*a1 - 24LL);
  if ( _InterlockedExchangeAdd(v28 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v28 + 8LL))(*(_QWORD *)v28);
  v29 = (volatile signed __int32 *)(*a2 - 24LL);
  if ( _InterlockedExchangeAdd(v29 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v29 + 8LL))(*(_QWORD *)v29);
  v30 = (volatile signed __int32 *)(*a3 - 24LL);
  if ( _InterlockedExchangeAdd(v30 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v30 + 8LL))(*(_QWORD *)v30);
  return (unsigned int)v31;
}
