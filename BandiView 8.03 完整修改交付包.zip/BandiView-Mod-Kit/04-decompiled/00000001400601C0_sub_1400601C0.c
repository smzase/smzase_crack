// EA 0x1400601c0  name sub_1400601C0  size 277
__int64 *sub_1400601C0()
{
  _DWORD *v0; // rbx
  HANDLE ProcessHeap; // rax

  v0 = (_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL);
  if ( dword_1407091C8 > *v0 )
  {
    sub_140496500(&dword_1407091C8);
    if ( dword_1407091C8 == -1 )
    {
      xmmword_140709200 = 0;
      qword_140709210 = 0;
      ProcessHeap = GetProcessHeap();
      LOBYTE(qword_140709210) = 0;
      *(_QWORD *)&xmmword_140709200 = &ATL::CWin32Heap::`vftable';
      *((_QWORD *)&xmmword_140709200 + 1) = ProcessHeap;
      atexit(sub_1405926A0);
      Init_thread_footer(&dword_1407091C8);
    }
  }
  if ( dword_1407091CC <= *v0 )
    return &qword_1407091D0;
  sub_140496500(&dword_1407091CC);
  if ( dword_1407091CC != -1 )
    return &qword_1407091D0;
  qword_1407091F0 = 2;
  qword_1407091F8 = 0;
  qword_1407091D0 = (__int64)&ATL::CAtlStringMgr::`vftable';
  qword_1407091E8 = 0;
  qword_1407091D8 = (__int64)&xmmword_140709200;
  qword_1407091E0 = (__int64)&qword_1407091D0;
  atexit(sub_1405926D0);
  Init_thread_footer(&dword_1407091CC);
  return &qword_1407091D0;
}
