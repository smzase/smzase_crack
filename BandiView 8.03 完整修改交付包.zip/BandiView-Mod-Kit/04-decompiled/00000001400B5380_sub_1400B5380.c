// EA 0x1400b5380  name sub_1400B5380  size 546
__int64 __fastcall sub_1400B5380(__int64 a1, __int64 a2)
{
  __int64 v4; // rdi
  HWND v5; // rbx
  int v6; // eax
  WPARAM v7; // rdi
  __int64 v8; // rbx
  __int64 v9; // rcx
  __int64 v10; // rax
  _BYTE *v11; // rbx
  __int64 *v12; // rax
  int v13; // eax
  int *v14; // rbx
  signed __int32 v15; // eax
  bool v16; // cc
  __int64 result; // rax
  const WCHAR *v18; // rdx
  LPARAM lParam; // [rsp+20h] [rbp-60h] BYREF
  __int64 v20; // [rsp+28h] [rbp-58h]
  int v21; // [rsp+30h] [rbp-50h]
  const WCHAR *v22; // [rsp+38h] [rbp-48h]
  int v23; // [rsp+44h] [rbp-3Ch]
  __int64 v24; // [rsp+48h] [rbp-38h]
  int *v25; // [rsp+B0h] [rbp+30h] BYREF
  const WCHAR *v26; // [rsp+B8h] [rbp+38h] BYREF

  v4 = *(_QWORD *)(a1 + 464);
  if ( v4 == *(_QWORD *)(a1 + 472) )
  {
    sub_14007A3B0(a1 + 456, *(_QWORD *)(a1 + 464), a2);
  }
  else
  {
    *(_DWORD *)v4 = *(_DWORD *)a2;
    *(_QWORD *)(v4 + 8) = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a2 + 8) - 24LL)) + 24;
    *(_DWORD *)(v4 + 16) = *(_DWORD *)(a2 + 16);
    *(_QWORD *)(a1 + 464) += 24LL;
  }
  sub_14009D4A0(&v26, (unsigned __int8)BYTE1(*(_DWORD *)(a2 + 16)), (unsigned __int8)*(_DWORD *)(a2 + 16));
  v5 = *(HWND *)(a1 + 448);
  LODWORD(lParam) = 7;
  HIDWORD(lParam) = SendMessageW(v5, 0x1004u, 0, 0);
  v20 = 0;
  v22 = &Data;
  v21 = 0;
  v23 = 0;
  v24 = 0;
  v6 = SendMessageW(v5, 0x104Du, 0, (LPARAM)&lParam);
  LODWORD(v20) = 1;
  v22 = v26;
  v7 = v6;
  SendMessageW(*(HWND *)(a1 + 448), 0x1074u, v6, (LPARAM)&lParam);
  LODWORD(v20) = 2;
  v22 = *(const WCHAR **)(a2 + 8);
  SendMessageW(*(HWND *)(a1 + 448), 0x1074u, v7, (LPARAM)&lParam);
  v8 = *(_QWORD *)(a2 + 8);
  v10 = sub_1401C5640(v9);
  v11 = (_BYTE *)sub_1401C81E0(v10, v8, L"CMD");
  v12 = sub_1400601C0();
  if ( v12 == nullptr )
    sub_14005FF30(0x80004005);
  v25 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24);
  if ( (unsigned __int8)sub_14005F980(&v25, (__int64)v11) == 0 )
  {
    if ( v11 != nullptr )
      v13 = sub_1404ADC20(v11);
    else
      v13 = 0;
    sub_14005FCF0(&v25, v11, v13);
  }
  v14 = v25;
  if ( *(v25 - 4) != 0 )
  {
    LODWORD(v20) = 3;
    v22 = (const WCHAR *)v25;
    SendMessageW(*(HWND *)(a1 + 448), 0x1074u, v7, (LPARAM)&lParam);
  }
  v15 = _InterlockedExchangeAdd(v14 - 2, 0xFFFFFFFF);
  v16 = v15 <= 1;
  result = (unsigned int)(v15 - 1);
  if ( v16 )
    result = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v14 - 3) + 8LL))(*((_QWORD *)v14 - 3));
  v18 = v26 - 12;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v26 - 2, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v18 + 8LL))(*(_QWORD *)v18);
  return result;
}
