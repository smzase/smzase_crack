// EA 0x1401c5020  name sub_1401C5020  size 187
__int64 __fastcall sub_1401C5020(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  __int64 v6; // rax
  __int64 v7; // r14
  void (__fastcall *v8)(__int64, __int64 *); // rbx
  volatile signed __int32 *v9; // rdx
  signed __int32 v10; // eax
  bool v11; // cc
  __int64 result; // rax
  volatile signed __int32 *v13; // rdx
  __int64 v14[5]; // [rsp+20h] [rbp-28h] BYREF
  __int64 v15; // [rsp+68h] [rbp+20h] BYREF

  v15 = sub_14005F710((volatile signed __int32 *)(*a2 - 24LL)) + 24;
  v6 = sub_1401BE5D0(a1, &v15);
  v7 = v6;
  if ( v6 != 0 )
  {
    v8 = *(void (__fastcall **)(__int64, __int64 *))(*(_QWORD *)v6 + 40LL);
    v14[0] = sub_14005F710((volatile signed __int32 *)(*a3 - 24LL)) + 24;
    v8(v7, v14);
  }
  v9 = (volatile signed __int32 *)(*a2 - 24LL);
  v10 = _InterlockedExchangeAdd(v9 + 4, 0xFFFFFFFF);
  v11 = v10 <= 1;
  result = (unsigned int)(v10 - 1);
  if ( v11 )
    result = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v9 + 8LL))(*(_QWORD *)v9);
  v13 = (volatile signed __int32 *)(*a3 - 24LL);
  if ( _InterlockedExchangeAdd(v13 + 4, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v13 + 8LL))(*(_QWORD *)v13);
  return result;
}
