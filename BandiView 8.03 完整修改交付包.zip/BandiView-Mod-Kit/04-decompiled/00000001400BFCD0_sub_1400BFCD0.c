// EA 0x1400bfcd0  name sub_1400BFCD0  size 12320
void __fastcall sub_1400BFCD0(unsigned __int64 a1, __int64 a2, _BYTE *a3)
{
  unsigned __int64 v4; // r15
  int v5; // r13d
  unsigned __int64 v6; // rdx
  unsigned int v7; // edi
  int v8; // esi
  int v9; // r14d
  unsigned __int16 v10; // ax
  __int64 v11; // rbx
  __int64 v12; // rbx
  __int64 *v13; // rax
  int v14; // eax
  unsigned __int64 v15; // rax
  __int64 *v16; // rax
  int v17; // eax
  __int64 *v18; // rax
  int v19; // eax
  __int64 *v20; // rax
  bool v21; // bl
  WPARAM v22; // r8
  __int64 *v23; // rax
  bool v24; // bl
  __int64 *v25; // rax
  bool v26; // bl
  __int64 *v27; // rax
  bool v28; // bl
  __int64 *v29; // rax
  bool v30; // bl
  HWND v31; // rbx
  _QWORD *v32; // rax
  __int64 v33; // rcx
  __int64 v34; // rdi
  __int64 *v35; // rax
  __int64 *v36; // rax
  __int64 v37; // rax
  _BYTE *v38; // rbx
  __int64 *v39; // rax
  int v40; // eax
  int *v41; // rdi
  int v42; // ebx
  int *v43; // rdx
  signed __int32 v44; // ecx
  bool v45; // cc
  __int64 *v46; // rax
  int v47; // eax
  const WCHAR *v48; // r8
  __int16 *v49; // rax
  int v50; // edx
  unsigned __int64 v51; // rcx
  __int64 v52; // r8
  __int16 *v53; // rax
  int v54; // edx
  unsigned __int64 v55; // rcx
  __int64 v56; // r8
  __int16 *v57; // rax
  int v58; // edx
  unsigned __int64 v59; // rcx
  __int64 v60; // r8
  __int16 *v61; // rax
  int v62; // edx
  unsigned __int64 v63; // rcx
  __int64 v64; // r8
  __int16 *v65; // rax
  int v66; // edx
  unsigned __int64 v67; // rcx
  __int64 v68; // r8
  __int16 *v69; // rax
  int v70; // edx
  unsigned __int64 v71; // rcx
  __int64 v72; // r8
  __int16 *v73; // rax
  int v74; // edx
  unsigned __int64 v75; // rcx
  __int64 v76; // r8
  __int64 *v77; // rax
  bool v78; // bl
  unsigned __int64 v79; // rax
  const __m128i *v80; // rcx
  int v81; // ebx
  int v82; // esi
  int *v83; // rdx
  int v84; // r8d
  int **v85; // rbx
  __int64 v86; // rbx
  HWND v87; // rax
  int v88; // eax
  WPARAM v89; // r14
  __int64 v90; // rdi
  __int64 v91; // rsi
  __int64 i; // rbx
  volatile signed __int32 *v93; // rdx
  __int64 *v94; // rax
  int v95; // eax
  __int64 *v96; // rax
  bool v97; // bl
  __int16 *v98; // rbx
  __int64 *v99; // rax
  __int64 *v100; // rax
  int v101; // eax
  __int64 *v102; // rax
  int v103; // eax
  __int64 *v104; // rax
  int v105; // eax
  __int64 *v106; // rax
  int v107; // eax
  unsigned __int64 v108; // rax
  int **v109; // [rsp+30h] [rbp-D0h] BYREF
  int **v110; // [rsp+38h] [rbp-C8h]
  __m128i v111; // [rsp+40h] [rbp-C0h] BYREF
  const wchar_t *v112; // [rsp+50h] [rbp-B0h]
  const wchar_t *v113; // [rsp+58h] [rbp-A8h]
  int *v114; // [rsp+60h] [rbp-A0h] BYREF
  int *v115; // [rsp+68h] [rbp-98h] BYREF
  int *v116; // [rsp+70h] [rbp-90h] BYREF
  int *v117; // [rsp+78h] [rbp-88h] BYREF
  int *v118; // [rsp+80h] [rbp-80h] BYREF
  int *v119; // [rsp+88h] [rbp-78h] BYREF
  int *v120; // [rsp+90h] [rbp-70h] BYREF
  int *v121; // [rsp+98h] [rbp-68h] BYREF
  int *v122; // [rsp+A0h] [rbp-60h] BYREF
  int *v123; // [rsp+A8h] [rbp-58h] BYREF
  int *v124; // [rsp+B0h] [rbp-50h] BYREF
  int *v125; // [rsp+B8h] [rbp-48h] BYREF
  int *v126; // [rsp+C0h] [rbp-40h] BYREF
  int *v127; // [rsp+C8h] [rbp-38h] BYREF
  int *v128; // [rsp+D0h] [rbp-30h] BYREF
  int *v129; // [rsp+D8h] [rbp-28h] BYREF
  int *v130; // [rsp+E0h] [rbp-20h] BYREF
  int *v131; // [rsp+E8h] [rbp-18h] BYREF
  int *v132[2]; // [rsp+F0h] [rbp-10h] BYREF
  _BYTE v133[80]; // [rsp+100h] [rbp+0h] BYREF
  const wchar_t *v134; // [rsp+150h] [rbp+50h]
  _BYTE *v135; // [rsp+160h] [rbp+60h] BYREF
  int *v136; // [rsp+168h] [rbp+68h] BYREF
  _BYTE v137[8]; // [rsp+170h] [rbp+70h] BYREF
  int *v138; // [rsp+178h] [rbp+78h] BYREF
  _BYTE v139[64]; // [rsp+180h] [rbp+80h] BYREF
  _QWORD v140[30]; // [rsp+1C0h] [rbp+C0h] BYREF
  _QWORD v141[10]; // [rsp+2B0h] [rbp+1B0h] BYREF
  const wchar_t *v142; // [rsp+300h] [rbp+200h]
  HWND ActiveWindow; // [rsp+308h] [rbp+208h]
  int v144; // [rsp+310h] [rbp+210h]
  void *Block; // [rsp+318h] [rbp+218h]
  __int64 v146; // [rsp+320h] [rbp+220h]
  int v147; // [rsp+328h] [rbp+228h]

  if ( a3 != nullptr )
  {
    v4 = a1;
    v5 = 1;
    while ( 1 )
    {
      v6 = 0x140000000uLL;
      v7 = 0;
      v8 = -2;
      v9 = *(_DWORD *)(v4 + 2584);
      if ( v9 != 0 )
        break;
LABEL_15:
      switch ( v8 )
      {
        case -2:
        case 0:
          if ( v9 == 0 )
            sub_1400C2FE0(v4 + 2592, L"IDOK", 0);
          goto LABEL_19;
        case 1:
LABEL_19:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
            goto LABEL_554;
          sub_1400C2FE0(v4 + 2592, L"IDCANCEL", 1);
LABEL_21:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
          {
            sub_1400914B0(v4 - 64, 0);
            goto LABEL_554;
          }
          sub_1400C2FE0(v4 + 2592, L"BTN_TAB_0", 2);
LABEL_23:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
          {
            sub_1400914B0(v4 - 64, 1);
            goto LABEL_554;
          }
          sub_1400C2FE0(v4 + 2592, L"BTN_TAB_1", 3);
LABEL_25:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
          {
            sub_1400914B0(v4 - 64, 2);
            goto LABEL_554;
          }
          sub_1400C2FE0(v4 + 2592, L"BTN_TAB_2", 4);
LABEL_27:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
          {
            sub_1400914B0(v4 - 64, 3);
            goto LABEL_554;
          }
          sub_1400C2FE0(v4 + 2592, L"BTN_TAB_3", 5);
LABEL_29:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
          {
            sub_1400914B0(v4 - 64, 4);
            goto LABEL_554;
          }
          sub_1400C2FE0(v4 + 2592, L"BTN_TAB_4", 6);
LABEL_31:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
          {
            sub_1400914B0(v4 - 64, 5);
            goto LABEL_554;
          }
          sub_1400C2FE0(v4 + 2592, L"BTN_TAB_5", 7);
LABEL_33:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
          {
            sub_1400914B0(v4 - 64, 6);
            goto LABEL_554;
          }
          sub_1400C2FE0(v4 + 2592, L"BTN_TAB_6", 8);
LABEL_35:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
          {
            sub_1400914B0(v4 - 64, 7);
            goto LABEL_554;
          }
          sub_1400C2FE0(v4 + 2592, L"BTN_TAB_7", 9);
LABEL_37:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
          {
            sub_1400914B0(v4 - 64, 8);
            goto LABEL_554;
          }
          sub_1400C2FE0(v4 + 2592, L"BTN_TAB_8", 10);
LABEL_39:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
          {
            sub_1400914B0(v4 - 64, 9);
            goto LABEL_554;
          }
          sub_1400C2FE0(v4 + 2592, L"BTN_TAB_9", 11);
LABEL_41:
          if ( *(_DWORD *)(v4 + 2584) != 0 )
          {
            sub_1400914B0(v4 - 64, 10);
            goto LABEL_554;
          }
          sub_1400C2FE0(v4 + 2592, L"BTN_TAB_10", 12);
LABEL_43:
          if ( *(_DWORD *)(v4 + 2584) == 0 )
          {
            sub_1400C2FE0(v4 + 2592, L"CHK_UPDATE_0", 13);
LABEL_45:
            if ( *(_DWORD *)(v4 + 2584) == 0 )
            {
              sub_1400C2FE0(v4 + 2592, L"CHK_UPDATE_1", 14);
LABEL_47:
              if ( *(_DWORD *)(v4 + 2584) == 0 )
              {
                sub_1400C2FE0(v4 + 2592, L"CHK_BG_CLR_BLUR", 15);
LABEL_49:
                if ( *(_DWORD *)(v4 + 2584) == 0 )
                {
                  sub_1400C2FE0(v4 + 2592, L"CHK_BG_CLR_AUTO", 16);
LABEL_51:
                  if ( *(_DWORD *)(v4 + 2584) == 0 )
                  {
                    sub_1400C2FE0(v4 + 2592, L"CHK_BG_CLR_CUSTOM", 17);
LABEL_53:
                    if ( *(_DWORD *)(v4 + 2584) != 0 )
                    {
                      sub_1400B1C90(v4 - 64);
                      goto LABEL_554;
                    }
                    sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR", 18);
LABEL_55:
                    if ( *(_DWORD *)(v4 + 2584) == 0 )
                    {
                      sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR_DEFAULT", 19);
LABEL_57:
                      if ( *(_DWORD *)(v4 + 2584) == 0 )
                      {
                        sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR1", 20);
LABEL_59:
                        if ( *(_DWORD *)(v4 + 2584) == 0 )
                        {
                          sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR2", 21);
LABEL_61:
                          if ( *(_DWORD *)(v4 + 2584) == 0 )
                          {
                            sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR3", 22);
LABEL_63:
                            if ( *(_DWORD *)(v4 + 2584) == 0 )
                            {
                              sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR4", 23);
LABEL_65:
                              if ( *(_DWORD *)(v4 + 2584) == 0 )
                              {
                                sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR5", 24);
LABEL_67:
                                if ( *(_DWORD *)(v4 + 2584) == 0 )
                                {
                                  sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR6", 25);
LABEL_69:
                                  if ( *(_DWORD *)(v4 + 2584) == 0 )
                                  {
                                    sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR7", 26);
LABEL_71:
                                    if ( *(_DWORD *)(v4 + 2584) == 0 )
                                    {
                                      sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR8", 27);
LABEL_73:
                                      if ( *(_DWORD *)(v4 + 2584) == 0 )
                                      {
                                        sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR9", 28);
LABEL_75:
                                        if ( *(_DWORD *)(v4 + 2584) == 0 )
                                        {
                                          sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR10", 29);
LABEL_77:
                                          if ( *(_DWORD *)(v4 + 2584) == 0 )
                                          {
                                            sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR11", 30);
LABEL_79:
                                            if ( *(_DWORD *)(v4 + 2584) == 0 )
                                            {
                                              sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR12", 31);
LABEL_81:
                                              if ( *(_DWORD *)(v4 + 2584) == 0 )
                                              {
                                                sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR13", 32);
LABEL_83:
                                                if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                {
                                                  sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR14", 33);
LABEL_85:
                                                  if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                  {
                                                    sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR15", 34);
LABEL_87:
                                                    if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                    {
                                                      sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR16", 35);
LABEL_89:
                                                      if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                      {
                                                        sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR17", 36);
LABEL_91:
                                                        if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                        {
                                                          sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR18", 37);
LABEL_93:
                                                          if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                          {
                                                            sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR19", 38);
LABEL_95:
                                                            if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                            {
                                                              sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_CLR20", 39);
LABEL_97:
                                                              if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                              {
                                                                sub_1400B2070(v4 - 64);
                                                                goto LABEL_554;
                                                              }
                                                              sub_1400C2FE0(v4 + 2592, L"BTN_BORDER_CLR", 40);
LABEL_99:
                                                              if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                              {
                                                                sub_1400C2FE0(v4 + 2592, L"BTN_BORDER_CLR_DEFAULT", 41);
LABEL_101:
                                                                if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                {
                                                                  sub_1400C2FE0(v4 + 2592, L"BTN_BORDER_CLR1", 42);
LABEL_103:
                                                                  if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                  {
                                                                    sub_1400C2FE0(v4 + 2592, L"BTN_BORDER_CLR2", 43);
LABEL_105:
                                                                    if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                    {
                                                                      sub_1400C2FE0(v4 + 2592, L"BTN_BORDER_CLR3", 44);
LABEL_107:
                                                                      if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                      {
                                                                        sub_1400C2FE0(v4 + 2592, L"BTN_BORDER_CLR4", 45);
LABEL_109:
                                                                        if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                        {
                                                                          sub_1400C2FE0(
                                                                            v4 + 2592,
                                                                            L"BTN_BORDER_CLR5",
                                                                            46);
LABEL_111:
                                                                          if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                          {
                                                                            sub_1400C2FE0(
                                                                              v4 + 2592,
                                                                              L"BTN_BORDER_CLR6",
                                                                              47);
LABEL_113:
                                                                            if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                            {
                                                                              sub_1400C2FE0(
                                                                                v4 + 2592,
                                                                                L"BTN_BORDER_CLR7",
                                                                                48);
LABEL_115:
                                                                              if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                              {
                                                                                sub_1400C2FE0(
                                                                                  v4 + 2592,
                                                                                  L"BTN_BORDER_CLR8",
                                                                                  49);
LABEL_117:
                                                                                if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                {
                                                                                  sub_1400C2FE0(
                                                                                    v4 + 2592,
                                                                                    L"BTN_BORDER_CLR9",
                                                                                    50);
LABEL_119:
                                                                                  if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                  {
                                                                                    sub_1400C2FE0(
                                                                                      v4 + 2592,
                                                                                      L"BTN_BORDER_CLR10",
                                                                                      51);
LABEL_121:
                                                                                    if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                    {
                                                                                      sub_1400C2FE0(
                                                                                        v4 + 2592,
                                                                                        L"BTN_BORDER_CLR11",
                                                                                        52);
LABEL_123:
                                                                                      if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                      {
                                                                                        sub_1400C2FE0(
                                                                                          v4 + 2592,
                                                                                          L"BTN_BORDER_CLR12",
                                                                                          53);
LABEL_125:
                                                                                        if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                        {
                                                                                          sub_1400C2FE0(
                                                                                            v4 + 2592,
                                                                                            L"BTN_BORDER_CLR13",
                                                                                            54);
LABEL_127:
                                                                                          if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                          {
                                                                                            sub_1400C2FE0(
                                                                                              v4 + 2592,
                                                                                              L"BTN_BORDER_CLR14",
                                                                                              55);
LABEL_129:
                                                                                            if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                            {
                                                                                              sub_1400C2FE0(
                                                                                                v4 + 2592,
                                                                                                L"BTN_BORDER_CLR15",
                                                                                                56);
LABEL_131:
                                                                                              if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                              {
                                                                                                sub_1400C2FE0(
                                                                                                  v4 + 2592,
                                                                                                  L"BTN_BORDER_CLR16",
                                                                                                  57);
LABEL_133:
                                                                                                if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                {
                                                                                                  sub_1400C2FE0(
                                                                                                    v4 + 2592,
                                                                                                    L"BTN_BORDER_CLR17",
                                                                                                    58);
LABEL_135:
                                                                                                  if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                  {
                                                                                                    sub_1400C2FE0(v4 + 2592, L"BTN_BORDER_CLR18", 59);
LABEL_137:
                                                                                                    if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                    {
                                                                                                      sub_1400C2FE0(v4 + 2592, L"BTN_BORDER_CLR19", 60);
LABEL_139:
                                                                                                      if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                      {
                                                                                                        sub_1400C2FE0(v4 + 2592, L"BTN_BORDER_CLR20", 61);
LABEL_141:
                                                                                                        if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                        {
                                                                                                          v109 = &v117;
                                                                                                          v20 = sub_1400601C0();
                                                                                                          if ( v20 == nullptr )
                                                                                                            sub_14005FF30(0x80004005);
                                                                                                          v117 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v20 + 24))(v20) + 24);
                                                                                                          if ( (unsigned __int8)sub_14005F980(&v117, (__int64)L"CHK_SHOWBORDER") == 0 )
                                                                                                            sub_14005FCF0(&v117, L"CHK_SHOWBORDER", 14);
                                                                                                          v21 = sub_1400ACB10(v4 - 64, &v117);
                                                                                                          *((_BYTE *)sub_140075FE0() + 190) = v21;
LABEL_375:
                                                                                                          v22 = 32877;
LABEL_376:
                                                                                                          PostMessageW(*(HWND *)(v4 + 552), 0x111u, v22, 0);
                                                                                                          goto LABEL_554;
                                                                                                        }
                                                                                                        sub_1400C2FE0(v4 + 2592, L"CHK_SHOWBORDER", 62);
LABEL_143:
                                                                                                        if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                        {
                                                                                                          v109 = &v118;
                                                                                                          v23 = sub_1400601C0();
                                                                                                          if ( v23 == nullptr )
                                                                                                            sub_14005FF30(0x80004005);
                                                                                                          v118 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v23 + 24))(v23) + 24);
                                                                                                          if ( (unsigned __int8)sub_14005F980(&v118, (__int64)L"CHK_SHOW_MINITITLE") == 0 )
                                                                                                            sub_14005FCF0(&v118, L"CHK_SHOW_MINITITLE", 18);
                                                                                                          v24 = sub_1400ACB10(v4 - 64, &v118);
                                                                                                          *((_BYTE *)sub_140075FE0() + 191) = v24;
                                                                                                          goto LABEL_375;
                                                                                                        }
                                                                                                        sub_1400C2FE0(v4 + 2592, L"CHK_SHOW_MINITITLE", 63);
LABEL_145:
                                                                                                        if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                        {
                                                                                                          v109 = &v119;
                                                                                                          v25 = sub_1400601C0();
                                                                                                          if ( v25 == nullptr )
                                                                                                            sub_14005FF30(0x80004005);
                                                                                                          v119 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v25 + 24))(v25) + 24);
                                                                                                          if ( (unsigned __int8)sub_14005F980(&v119, (__int64)L"CHK_SHOW_TITLE_BAR") == 0 )
                                                                                                            sub_14005FCF0(&v119, L"CHK_SHOW_TITLE_BAR", 18);
                                                                                                          v26 = sub_1400ACB10(v4 - 64, &v119);
                                                                                                          *((_BYTE *)sub_140075FE0() + 185) = v26;
                                                                                                          goto LABEL_375;
                                                                                                        }
                                                                                                        sub_1400C2FE0(v4 + 2592, L"CHK_SHOW_TITLE_BAR", 64);
LABEL_147:
                                                                                                        if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                        {
                                                                                                          v109 = &v120;
                                                                                                          v27 = sub_1400601C0();
                                                                                                          if ( v27 == nullptr )
                                                                                                            sub_14005FF30(0x80004005);
                                                                                                          v120 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v27 + 24))(v27) + 24);
                                                                                                          if ( (unsigned __int8)sub_14005F980(&v120, (__int64)L"CHK_SHOW_CONTROL_BAR") == 0 )
                                                                                                            sub_14005FCF0(&v120, L"CHK_SHOW_CONTROL_BAR", 20);
                                                                                                          v28 = sub_1400ACB10(v4 - 64, &v120);
                                                                                                          *((_BYTE *)sub_140075FE0() + 186) = v28;
                                                                                                          goto LABEL_375;
                                                                                                        }
                                                                                                        sub_1400C2FE0(v4 + 2592, L"CHK_SHOW_CONTROL_BAR", 65);
LABEL_149:
                                                                                                        if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                        {
                                                                                                          v109 = &v121;
                                                                                                          v29 = sub_1400601C0();
                                                                                                          if ( v29 == nullptr )
                                                                                                            sub_14005FF30(0x80004005);
                                                                                                          v121 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v29 + 24))(v29) + 24);
                                                                                                          if ( (unsigned __int8)sub_14005F980(&v121, (__int64)L"CHK_SHOW_LOGO") == 0 )
                                                                                                            sub_14005FCF0(&v121, L"CHK_SHOW_LOGO", 13);
                                                                                                          v30 = sub_1400ACB10(v4 - 64, &v121);
                                                                                                          *((_BYTE *)sub_140075FE0() + 195) = v30;
                                                                                                          goto LABEL_375;
                                                                                                        }
                                                                                                        sub_1400C2FE0(v4 + 2592, L"CHK_SHOW_LOGO", 66);
LABEL_151:
                                                                                                        if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                        {
                                                                                                          sub_1400BE620(v4 - 64);
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_SET_TEMP_FOLDER", 67);
LABEL_153:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            v111.m128i_i64[0] = (__int64)L"Executable File(*.exe)";
                                                                                                            v111.m128i_i64[1] = (__int64)L"*.exe";
                                                                                                            v112 = L"All Files";
                                                                                                            v113 = L"*.*";
                                                                                                            *(_QWORD *)&v133[72] = L"All Files(*.*)";
                                                                                                            v134 = L"*.*";
                                                                                                            v133[0] = 1;
                                                                                                            *(_QWORD *)&v133[24] = &Data;
                                                                                                            memset(&v133[32], 0, 24);
                                                                                                            *(_QWORD *)&v133[64] = 0;
                                                                                                            v133[56] = 1;
                                                                                                            *(_DWORD *)&v133[60] = 6728;
                                                                                                            *(_QWORD *)&v133[8] = &v111;
                                                                                                            *(_QWORD *)&v133[16] = 0x100000002LL;
                                                                                                            v31 = *(HWND *)(v4 - 56);
                                                                                                            qmemcpy(v141, v133, 32);
                                                                                                            *(_OWORD *)&v141[4] = 0;
                                                                                                            *(_OWORD *)&v141[6] = *(_OWORD *)&v133[48];
                                                                                                            *(_OWORD *)&v141[8] = *(_OWORD *)&v133[64];
                                                                                                            v142 = L"*.*";
                                                                                                            Block = nullptr;
                                                                                                            v146 = 0;
                                                                                                            v32 = operator new(0x18u);
                                                                                                            *v32 = v32;
                                                                                                            v32[1] = v32;
                                                                                                            Block = v32;
                                                                                                            v147 = 0;
                                                                                                            if ( v31 != nullptr )
                                                                                                              ActiveWindow = v31;
                                                                                                            else
                                                                                                              ActiveWindow = GetActiveWindow();
                                                                                                            v144 = 0;
                                                                                                            if ( (unsigned int)sub_140121B00(v141) != 0 )
                                                                                                            {
                                                                                                              v109 = (int **)v137;
                                                                                                              v34 = sub_140121BD0(v141, v137);
                                                                                                              v110 = &v122;
                                                                                                              v35 = sub_1400601C0();
                                                                                                              if ( v35 == nullptr )
                                                                                                                sub_14005FF30(0x80004005);
                                                                                                              v122 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v35 + 24))(v35) + 24);
                                                                                                              if ( (unsigned __int8)sub_14005F980(&v122, (__int64)L"IDC_EDIT_EXTPROG0") == 0 )
                                                                                                                sub_14005FCF0(&v122, L"IDC_EDIT_EXTPROG0", 17);
                                                                                                              sub_1401C5020(v4 + 664, &v122, v34);
                                                                                                            }
                                                                                                            sub_140065D40(v33, (_QWORD **)Block);
                                                                                                            j_j_j__free_base(Block);
                                                                                                            goto LABEL_554;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_SET_EXT_PROG0", 68);
LABEL_155:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            v110 = &v123;
                                                                                                            v36 = sub_1400601C0();
                                                                                                            if ( v36 == nullptr )
                                                                                                              sub_14005FF30(0x80004005);
                                                                                                            v123 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v36 + 24))(v36) + 24);
                                                                                                            if ( (unsigned __int8)sub_14005F980(&v123, (__int64)L"BTN_SET_EXT_FAST0") == 0 )
                                                                                                              sub_14005FCF0(&v123, L"BTN_SET_EXT_FAST0", 17);
                                                                                                            sub_140121C50(v4 - 64, &v123);
                                                                                                            goto LABEL_554;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_SET_EXT_FAST0", 69);
LABEL_157:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            v37 = sub_1401C5640(a1);
                                                                                                            v38 = (_BYTE *)sub_1401C81E0(v37, L"TEXT_ASK_INIT", L"TEXT");
                                                                                                            v39 = sub_1400601C0();
                                                                                                            if ( v39 == nullptr )
                                                                                                              sub_14005FF30(0x80004005);
                                                                                                            v109 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v39 + 24))(v39) + 24);
                                                                                                            if ( (unsigned __int8)sub_14005F980(&v109, (__int64)v38) == 0 )
                                                                                                            {
                                                                                                              if ( v38 != nullptr )
                                                                                                                v40 = sub_1404ADC20(v38);
                                                                                                              else
                                                                                                                v40 = 0;
                                                                                                              sub_14005FCF0((int **)&v109, v38, v40);
                                                                                                            }
                                                                                                            sub_14007D7F0(&v138);
                                                                                                            v41 = (int *)v109;
                                                                                                            v135 = (_BYTE *)(sub_14005F710((volatile signed __int32 *)v109 - 6) + 24);
                                                                                                            v42 = sub_14008B0F0(*(HWND *)(v4 - 56), &v135);
                                                                                                            v43 = v138 - 6;
                                                                                                            v44 = _InterlockedExchangeAdd(v138 - 2, 0xFFFFFFFF);
                                                                                                            v45 = v44 <= 1;
                                                                                                            a1 = (unsigned int)(v44 - 1);
                                                                                                            if ( v45 )
                                                                                                              (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v43 + 8LL))(*(_QWORD *)v43);
                                                                                                            if ( v42 == 6 )
                                                                                                            {
                                                                                                              *((_BYTE *)sub_14007D5E0() + 112) = 1;
                                                                                                              EndDialog(*(HWND *)(v4 - 56), 1);
                                                                                                            }
                                                                                                            if ( _InterlockedExchangeAdd(v41 - 2, 0xFFFFFFFF) <= 1 )
                                                                                                              (*(void (__fastcall **)(_QWORD, int *))(**((_QWORD **)v41 - 3) + 8LL))(*((_QWORD *)v41 - 3), v41 - 6);
                                                                                                            goto LABEL_554;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_INIT", 70);
LABEL_159:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                            goto LABEL_419;
                                                                                                          sub_1400C2FE0(v4 + 2592, L"CHK_COLORTHEME_SYSTEM", 71);
LABEL_161:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                            goto LABEL_419;
                                                                                                          sub_1400C2FE0(v4 + 2592, L"CHK_COLORTHEME_LIGHT", 72);
LABEL_163:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
LABEL_419:
                                                                                                            v110 = &v124;
                                                                                                            v46 = sub_1400601C0();
                                                                                                            if ( v46 == nullptr )
                                                                                                              sub_14005FF30(0x80004005);
                                                                                                            v124 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v46 + 24))(v46) + 24);
                                                                                                            if ( (unsigned __int8)sub_14005F980(&v124, (__int64)a3) == 0 )
                                                                                                            {
                                                                                                              v47 = sub_1404ADC20(a3);
                                                                                                              sub_14005FCF0(&v124, a3, v47);
                                                                                                            }
                                                                                                            sub_1400B2A70(v4 - 64, (__int64 *)&v124);
                                                                                                            goto LABEL_554;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"CHK_COLORTHEME_DARK", 73);
LABEL_165:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            v48 = L"https://translate.bandisoft.com/win/";
LABEL_424:
                                                                                                            ShellExecuteW(nullptr, L"open", v48, nullptr, nullptr, 1);
                                                                                                            goto LABEL_554;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_OPEN_TRANSLATIONWEB", 74);
LABEL_167:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            *((_DWORD *)sub_140075FE0() + 53) = 0;
                                                                                                            v49 = sub_140075FE0();
                                                                                                            v50 = *((_DWORD *)v49 + 53);
                                                                                                            if ( v50 != 0 )
                                                                                                            {
                                                                                                              v51 = (unsigned int)(v50 - 100);
                                                                                                              if ( (unsigned int)v51 > 0x32 || (v52 = 0x4000002000001LL, !_bittest64(&v52, v51)) )
                                                                                                              {
                                                                                                                if ( v50 != 175 && v50 != 200 && v50 != 250 )
                                                                                                                  *((_DWORD *)v49 + 53) = 0;
                                                                                                              }
                                                                                                            }
                                                                                                            goto LABEL_480;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_DPI_000", 75);
LABEL_169:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            *((_DWORD *)sub_140075FE0() + 53) = 100;
                                                                                                            v53 = sub_140075FE0();
                                                                                                            v54 = *((_DWORD *)v53 + 53);
                                                                                                            if ( v54 != 0 )
                                                                                                            {
                                                                                                              v55 = (unsigned int)(v54 - 100);
                                                                                                              if ( (unsigned int)v55 > 0x32 || (v56 = 0x4000002000001LL, !_bittest64(&v56, v55)) )
                                                                                                              {
                                                                                                                if ( v54 != 175 && v54 != 200 && v54 != 250 )
                                                                                                                  *((_DWORD *)v53 + 53) = 0;
                                                                                                              }
                                                                                                            }
                                                                                                            goto LABEL_480;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_DPI_100", 76);
LABEL_171:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            *((_DWORD *)sub_140075FE0() + 53) = 125;
                                                                                                            v57 = sub_140075FE0();
                                                                                                            v58 = *((_DWORD *)v57 + 53);
                                                                                                            if ( v58 != 0 )
                                                                                                            {
                                                                                                              v59 = (unsigned int)(v58 - 100);
                                                                                                              if ( (unsigned int)v59 > 0x32 || (v60 = 0x4000002000001LL, !_bittest64(&v60, v59)) )
                                                                                                              {
                                                                                                                if ( v58 != 175 && v58 != 200 && v58 != 250 )
                                                                                                                  *((_DWORD *)v57 + 53) = 0;
                                                                                                              }
                                                                                                            }
                                                                                                            goto LABEL_480;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_DPI_125", 77);
LABEL_173:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            *((_DWORD *)sub_140075FE0() + 53) = 150;
                                                                                                            v61 = sub_140075FE0();
                                                                                                            v62 = *((_DWORD *)v61 + 53);
                                                                                                            if ( v62 != 0 )
                                                                                                            {
                                                                                                              v63 = (unsigned int)(v62 - 100);
                                                                                                              if ( (unsigned int)v63 > 0x32 || (v64 = 0x4000002000001LL, !_bittest64(&v64, v63)) )
                                                                                                              {
                                                                                                                if ( v62 != 175 && v62 != 200 && v62 != 250 )
                                                                                                                  *((_DWORD *)v61 + 53) = 0;
                                                                                                              }
                                                                                                            }
                                                                                                            goto LABEL_480;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_DPI_150", 78);
LABEL_175:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            *((_DWORD *)sub_140075FE0() + 53) = 175;
                                                                                                            v65 = sub_140075FE0();
                                                                                                            v66 = *((_DWORD *)v65 + 53);
                                                                                                            if ( v66 != 0 )
                                                                                                            {
                                                                                                              v67 = (unsigned int)(v66 - 100);
                                                                                                              if ( (unsigned int)v67 > 0x32 || (v68 = 0x4000002000001LL, !_bittest64(&v68, v67)) )
                                                                                                              {
                                                                                                                if ( v66 != 175 && v66 != 200 && v66 != 250 )
                                                                                                                  *((_DWORD *)v65 + 53) = 0;
                                                                                                              }
                                                                                                            }
                                                                                                            goto LABEL_480;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_DPI_175", 79);
LABEL_177:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            *((_DWORD *)sub_140075FE0() + 53) = 200;
                                                                                                            v69 = sub_140075FE0();
                                                                                                            v70 = *((_DWORD *)v69 + 53);
                                                                                                            if ( v70 != 0 )
                                                                                                            {
                                                                                                              v71 = (unsigned int)(v70 - 100);
                                                                                                              if ( (unsigned int)v71 > 0x32 || (v72 = 0x4000002000001LL, !_bittest64(&v72, v71)) )
                                                                                                              {
                                                                                                                if ( v70 != 175 && v70 != 200 && v70 != 250 )
                                                                                                                  *((_DWORD *)v69 + 53) = 0;
                                                                                                              }
                                                                                                            }
                                                                                                            goto LABEL_480;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_DPI_200", 80);
LABEL_179:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            *((_DWORD *)sub_140075FE0() + 53) = 250;
                                                                                                            v73 = sub_140075FE0();
                                                                                                            v74 = *((_DWORD *)v73 + 53);
                                                                                                            if ( v74 != 0 )
                                                                                                            {
                                                                                                              v75 = (unsigned int)(v74 - 100);
                                                                                                              if ( (unsigned int)v75 > 0x32 || (v76 = 0x4000002000001LL, !_bittest64(&v76, v75)) )
                                                                                                              {
                                                                                                                if ( v74 != 175 && v74 != 200 && v74 != 250 )
                                                                                                                  *((_DWORD *)v73 + 53) = 0;
                                                                                                              }
                                                                                                            }
LABEL_480:
                                                                                                            sub_140091430(v4 - 64);
                                                                                                            goto LABEL_375;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_DPI_250", 81);
LABEL_181:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            v110 = &v125;
                                                                                                            v77 = sub_1400601C0();
                                                                                                            if ( v77 == nullptr )
                                                                                                              sub_14005FF30(0x80004005);
                                                                                                            v125 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v77 + 24))(v77) + 24);
                                                                                                            if ( (unsigned __int8)sub_14005F980(&v125, (__int64)L"CHK_APPLY_DPI_IMAGE") == 0 )
                                                                                                              sub_14005FCF0(&v125, L"CHK_APPLY_DPI_IMAGE", 19);
                                                                                                            v78 = sub_1400ACB10(v4 - 64, &v125);
                                                                                                            *((_BYTE *)sub_140075FE0() + 216) = v78;
                                                                                                            goto LABEL_375;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"CHK_APPLY_DPI_IMAGE", 82);
LABEL_183:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            sub_1400B41A0(v4 - 64);
                                                                                                            goto LABEL_554;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_ASSOC_CHANGE", 83);
LABEL_185:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            sub_1400922F0(0, 1u, 0, 0x64u);
                                                                                                            goto LABEL_554;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_ASSOC_CHANGETRY", 84);
LABEL_187:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                            goto LABEL_501;
                                                                                                          sub_1400C2FE0(v4 + 2592, L"CHK_CACHE_IMAGE", 85);
LABEL_189:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                            goto LABEL_487;
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_CACHESIZE_INCREASE", 86);
LABEL_191:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
LABEL_487:
                                                                                                            v111 = 0;
                                                                                                            v112 = nullptr;
                                                                                                            v113 = nullptr;
                                                                                                            v79 = sub_1404ADC20(a3);
                                                                                                            sub_140061270((char **)&v111, a3, v79);
                                                                                                            v110 = (int **)&v111;
                                                                                                            v80 = &v111;
                                                                                                            if ( (unsigned __int64)v113 > 7 )
                                                                                                              v80 = (const __m128i *)v111.m128i_i64[0];
                                                                                                            if ( v112 != (const wchar_t *)22 || (unsigned int)sub_140074220(v80, (const __m128i *)L"BTN_CACHESIZE_INCREASE", 0x16u) != 0 )
                                                                                                              v81 = -*(_DWORD *)(v4 + 216);
                                                                                                            else
                                                                                                              v81 = *(_DWORD *)(v4 + 216);
                                                                                                            sub_1400AED30(v4 + 48, &v136);
                                                                                                            v82 = sub_1404BF238(v136);
                                                                                                            v83 = v136 - 6;
                                                                                                            if ( _InterlockedExchangeAdd(v136 - 2, 0xFFFFFFFF) <= 1 )
                                                                                                              (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v83 + 8LL))(*(_QWORD *)v83);
                                                                                                            v84 = v82 + v81;
                                                                                                            LODWORD(v109) = v84;
                                                                                                            v85 = (int **)&v109;
                                                                                                            if ( v84 < *(_DWORD *)(v4 + 208) )
                                                                                                              v85 = (int **)(v4 + 208);
                                                                                                            if ( *(_DWORD *)(v4 + 212) < v84 )
                                                                                                              v85 = (int **)(v4 + 212);
                                                                                                            v86 = *(int *)v85;
                                                                                                            sub_1400AEC80(v4 + 48, v86);
                                                                                                            *((_DWORD *)sub_140075FE0() + 59) = v86;
                                                                                                            sub_14005D410((char **)&v111);
                                                                                                            goto LABEL_554;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"BTN_CACHESIZE_DECREASE", 87);
LABEL_193:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                            goto LABEL_500;
                                                                                                          sub_1400C2FE0(v4 + 2592, L"CHK_WEBTOON_SPACE", 88);
LABEL_195:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
LABEL_500:
                                                                                                            sub_1400BBEA0(v4 - 64);
                                                                                                            PostMessageW(*(HWND *)(v4 + 552), 0x111u, 0x806Au, 0);
LABEL_501:
                                                                                                            sub_1400BC650((HWND *)(v4 - 64));
                                                                                                            goto LABEL_554;
                                                                                                          }
                                                                                                          sub_1400C2FE0(v4 + 2592, L"CHK_2PAGE_SPACE", 89);
LABEL_197:
                                                                                                          if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                          {
                                                                                                            *(_QWORD *)v133 = 72;
                                                                                                            memset(&v133[16], 0, 56);
                                                                                                            *(_QWORD *)&v133[8] = *(_QWORD *)(v4 - 56);
                                                                                                            *(_QWORD *)&v133[32] = sub_140075FE0() + 422;
                                                                                                            *(_DWORD *)&v133[24] = *((_DWORD *)sub_140075FE0() + 62);
                                                                                                            *(_DWORD *)&v133[40] = 3;
                                                                                                            if ( ChooseColorW((LPCHOOSECOLORW)v133) )
                                                                                                            {
                                                                                                              *((_DWORD *)sub_140075FE0() + 62) = *(_DWORD *)&v133[24];
LABEL_504:
                                                                                                              sub_1400BBEA0(v4 - 64);
                                                                                                              sub_1400BCA00(v4 - 64);
                                                                                                              v22 = 32874;
                                                                                                              goto LABEL_376;
                                                                                                            }
                                                                                                          }
                                                                                                          else
                                                                                                          {
                                                                                                            sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_COLOR_GRID1", 90);
LABEL_199:
                                                                                                            if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                            {
                                                                                                              sub_1400C2FE0(v4 + 2592, L"BTN_BKGND_COLOR_GRID2", 91);
LABEL_201:
                                                                                                              if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                              {
                                                                                                                sub_1400B50C0(v4 - 64);
                                                                                                                goto LABEL_554;
                                                                                                              }
                                                                                                              sub_1400C2FE0(v4 + 2592, L"BTN_KEY_CHANGE", 92);
LABEL_203:
                                                                                                              if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                              {
                                                                                                                sub_14011F0F0(v139, v6);
                                                                                                                v87 = GetActiveWindow();
                                                                                                                if ( sub_1400B55B0((__int64)v139, v87) == 1 )
                                                                                                                  sub_1400B5380(v4 - 64, (__int64)v140);
                                                                                                                sub_14011F1E0(v139);
                                                                                                                goto LABEL_554;
                                                                                                              }
                                                                                                              sub_1400C2FE0(v4 + 2592, L"BTN_KEY_ADD", 93);
LABEL_205:
                                                                                                              if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                              {
                                                                                                                v88 = sub_1400B3720(*(HWND *)(v4 + 384));
                                                                                                                if ( v88 >= 0 )
                                                                                                                {
                                                                                                                  v89 = v88;
                                                                                                                  v90 = *(_QWORD *)(v4 + 392) + 24LL * v88;
                                                                                                                  v91 = *(_QWORD *)(v4 + 400);
                                                                                                                  for ( i = v90 + 24;
                                                                                                                        i != v91;
                                                                                                                        i += 24 )
                                                                                                                  {
                                                                                                                    *(_DWORD *)v90 = *(_DWORD *)i;
                                                                                                                    sub_14006B500((int **)(v90 + 8), (_BYTE **)(i + 8));
                                                                                                                    *(_DWORD *)(v90 + 16) = *(_DWORD *)(i + 16);
                                                                                                                    v90 += 24;
                                                                                                                  }
                                                                                                                  v93 = (volatile signed __int32 *)(*(_QWORD *)(*(_QWORD *)(v4 + 400) - 16LL) - 24LL);
                                                                                                                  if ( _InterlockedExchangeAdd(v93 + 4, 0xFFFFFFFF) <= 1 )
                                                                                                                    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v93 + 8LL))(*(_QWORD *)v93);
                                                                                                                  *(_QWORD *)(v4 + 400) -= 24LL;
                                                                                                                  SendMessageW(*(HWND *)(v4 + 384), 0x1008u, v89, 0);
                                                                                                                }
                                                                                                                goto LABEL_554;
                                                                                                              }
                                                                                                              sub_1400C2FE0(v4 + 2592, L"BTN_KEY_DEL", 94);
LABEL_207:
                                                                                                              if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                              {
                                                                                                                sub_1400C2FE0(v4 + 2592, L"CHK_CUSTOM_LBUTTON", 95);
LABEL_209:
                                                                                                                if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                {
                                                                                                                  sub_1400C2FE0(v4 + 2592, L"CHK_CUSTOM_LBTNDBL", 96);
LABEL_211:
                                                                                                                  if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                  {
                                                                                                                    sub_1400C2FE0(v4 + 2592, L"CHK_CLICK2PAGETURN", 97);
LABEL_213:
                                                                                                                    if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                    {
                                                                                                                      sub_1400C2FE0(v4 + 2592, L"CHK_CUSTOM_MBUTTON", 98);
LABEL_215:
                                                                                                                      if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                      {
                                                                                                                        sub_1400C2FE0(v4 + 2592, L"CHK_CUSTOM_RBUTTON", 99);
LABEL_217:
                                                                                                                        if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                        {
                                                                                                                          sub_1400C2FE0(v4 + 2592, L"CHK_CUSTOM_XBUTTON", 100);
LABEL_219:
                                                                                                                          if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                          {
                                                                                                                            sub_1400C2FE0(v4 + 2592, L"CHK_CUSTOM_YBUTTON", 101);
LABEL_221:
                                                                                                                            if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                            {
                                                                                                                              sub_1400C2FE0(v4 + 2592, L"CHK_CUSTOM_WHEELUP", 102);
LABEL_223:
                                                                                                                              if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                              {
                                                                                                                                sub_1400C2FE0(v4 + 2592, L"CHK_CUSTOM_WHEELDN", 103);
LABEL_225:
                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                {
                                                                                                                                  sub_14011D7E0(v4 - 64, v6);
                                                                                                                                  goto LABEL_554;
                                                                                                                                }
                                                                                                                                sub_1400C2FE0(v4 + 2592, L"BTN_CLEAR_FILE_POS_IN_ARCHIVE", 104);
LABEL_227:
                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                {
                                                                                                                                  sub_14011DBE0(a1, v6);
                                                                                                                                  goto LABEL_554;
                                                                                                                                }
                                                                                                                                sub_1400C2FE0(v4 + 2592, L"BTN_OPEN_BOOKMARKFOLDER", 105);
LABEL_229:
                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                {
                                                                                                                                  sub_14011DD40(v4 - 64, v6);
                                                                                                                                  goto LABEL_554;
                                                                                                                                }
                                                                                                                                sub_1400C2FE0(v4 + 2592, L"BTN_IMPORT_HONEYVIEWBOOKMARK", 106);
LABEL_231:
                                                                                                                                if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                {
                                                                                                                                  sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_MENU_ENABLE", 107);
LABEL_233:
                                                                                                                                  if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                  {
                                                                                                                                    sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_MENU_ENABLE_CONV", 108);
LABEL_235:
                                                                                                                                    if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                    {
                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_WEBP", 109);
LABEL_237:
                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                      {
                                                                                                                                        sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_AVIF", 110);
LABEL_239:
                                                                                                                                        if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                        {
                                                                                                                                          sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_APNG", 111);
LABEL_241:
                                                                                                                                          if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                          {
                                                                                                                                            sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_HEIF", 112);
LABEL_243:
                                                                                                                                            if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                            {
                                                                                                                                              sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_HIF", 113);
LABEL_245:
                                                                                                                                              if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                              {
                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_HEIC", 114);
LABEL_247:
                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                {
                                                                                                                                                  sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_JPG", 115);
LABEL_249:
                                                                                                                                                  if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                  {
                                                                                                                                                    sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_JXL", 116);
LABEL_251:
                                                                                                                                                    if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                    {
                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_PSD", 117);
LABEL_253:
                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                      {
                                                                                                                                                        sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_PSB", 118);
LABEL_255:
                                                                                                                                                        if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                        {
                                                                                                                                                          sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_PNG", 119);
LABEL_257:
                                                                                                                                                          if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                          {
                                                                                                                                                            sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_CLIP", 120);
LABEL_259:
                                                                                                                                                            if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                            {
                                                                                                                                                              sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_TIF", 121);
LABEL_261:
                                                                                                                                                              if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                              {
                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_EXR", 122);
LABEL_263:
                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                {
                                                                                                                                                                  sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_GIF", 123);
LABEL_265:
                                                                                                                                                                  if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                  {
                                                                                                                                                                    sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_DDS", 124);
LABEL_267:
                                                                                                                                                                    if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                    {
                                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_TGA", 125);
LABEL_269:
                                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                      {
                                                                                                                                                                        sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_SVG", 126);
LABEL_271:
                                                                                                                                                                        if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                        {
                                                                                                                                                                          sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_JP2", 127);
LABEL_273:
                                                                                                                                                                          if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                          {
                                                                                                                                                                            sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_HDR", 128);
LABEL_275:
                                                                                                                                                                            if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                            {
                                                                                                                                                                              sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_CBZ", 129);
LABEL_277:
                                                                                                                                                                              if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                              {
                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_CBR", 130);
LABEL_279:
                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                                {
                                                                                                                                                                                  sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_CB7", 131);
LABEL_281:
                                                                                                                                                                                  if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                                  {
                                                                                                                                                                                    sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_CBT", 132);
LABEL_283:
                                                                                                                                                                                    if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                                    {
                                                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"IDC_CHK_SHELL_THUMB_UGOIRA", 133);
LABEL_285:
                                                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                      {
                                                                                                                                                                                        v110 = &v127;
                                                                                                                                                                                        v96 = sub_1400601C0();
                                                                                                                                                                                        if ( v96 == nullptr )
                                                                                                                                                                                          sub_14005FF30(0x80004005);
                                                                                                                                                                                        v127 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v96 + 24))(v96) + 24);
                                                                                                                                                                                        if ( (unsigned __int8)sub_14005F980(&v127, (__int64)L"CHK_SHELL_PREVIEWICON") == 0 )
                                                                                                                                                                                          sub_14005FCF0(&v127, L"CHK_SHELL_PREVIEWICON", 21);
                                                                                                                                                                                        v97 = sub_1400ACB10(v4 - 64, &v127);
                                                                                                                                                                                        *((_BYTE *)sub_140075FE0() + 456) = v97;
                                                                                                                                                                                        v98 = sub_140075FE0();
                                                                                                                                                                                        v110 = &v128;
                                                                                                                                                                                        v99 = sub_1400601C0();
                                                                                                                                                                                        if ( v99 == nullptr )
                                                                                                                                                                                          sub_14005FF30(0x80004005);
                                                                                                                                                                                        v128 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v99 + 24))(v99) + 24);
                                                                                                                                                                                        if ( (unsigned __int8)sub_14005F980(&v128, (__int64)&Data) == 0 )
                                                                                                                                                                                          sub_14005FCF0(&v128, &Data, 0);
                                                                                                                                                                                        sub_140076F50((__int64)v98, 1, &v128);
                                                                                                                                                                                        goto LABEL_554;
                                                                                                                                                                                      }
                                                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"CHK_SHELL_PREVIEWICON", 134);
LABEL_287:
                                                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                        goto LABEL_500;
                                                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"CHK_SEPARATE_COVER", 135);
LABEL_289:
                                                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                        goto LABEL_500;
                                                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"CHK_USE_IMAGE_ICC", 136);
LABEL_291:
                                                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                        goto LABEL_500;
                                                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"CHK_USE_MONITOR_ICC", 137);
LABEL_293:
                                                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                      {
                                                                                                                                                                                        sub_1400BED70(v4 - 64);
                                                                                                                                                                                        goto LABEL_554;
                                                                                                                                                                                      }
                                                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"BTN_EXPORT_SETTINGS", 138);
LABEL_295:
                                                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                      {
                                                                                                                                                                                        v110 = &v129;
                                                                                                                                                                                        v100 = sub_1400601C0();
                                                                                                                                                                                        if ( v100 == nullptr )
                                                                                                                                                                                          sub_14005FF30(0x80004005);
                                                                                                                                                                                        v129 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v100 + 24))(v100) + 24);
                                                                                                                                                                                        if ( (unsigned __int8)sub_14005F980(&v129, (__int64)a3) == 0 )
                                                                                                                                                                                        {
                                                                                                                                                                                          v101 = sub_1404ADC20(a3);
                                                                                                                                                                                          sub_14005FCF0(&v129, a3, v101);
                                                                                                                                                                                        }
                                                                                                                                                                                        sub_14011E4A0(v4 - 64, &v129);
                                                                                                                                                                                        goto LABEL_554;
                                                                                                                                                                                      }
                                                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"BTN_SET_PHOTO_FOLDER1", 139);
LABEL_297:
                                                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                      {
                                                                                                                                                                                        v110 = &v130;
                                                                                                                                                                                        v102 = sub_1400601C0();
                                                                                                                                                                                        if ( v102 == nullptr )
                                                                                                                                                                                          sub_14005FF30(0x80004005);
                                                                                                                                                                                        v130 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v102 + 24))(v102) + 24);
                                                                                                                                                                                        if ( (unsigned __int8)sub_14005F980(&v130, (__int64)a3) == 0 )
                                                                                                                                                                                        {
                                                                                                                                                                                          v103 = sub_1404ADC20(a3);
                                                                                                                                                                                          sub_14005FCF0(&v130, a3, v103);
                                                                                                                                                                                        }
                                                                                                                                                                                        sub_14011E4A0(v4 - 64, &v130);
                                                                                                                                                                                        goto LABEL_554;
                                                                                                                                                                                      }
                                                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"BTN_SET_PHOTO_FOLDER2", 140);
LABEL_299:
                                                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                      {
                                                                                                                                                                                        v110 = &v131;
                                                                                                                                                                                        v104 = sub_1400601C0();
                                                                                                                                                                                        if ( v104 == nullptr )
                                                                                                                                                                                          sub_14005FF30(0x80004005);
                                                                                                                                                                                        v131 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v104 + 24))(v104) + 24);
                                                                                                                                                                                        if ( (unsigned __int8)sub_14005F980(&v131, (__int64)a3) == 0 )
                                                                                                                                                                                        {
                                                                                                                                                                                          v105 = sub_1404ADC20(a3);
                                                                                                                                                                                          sub_14005FCF0(&v131, a3, v105);
                                                                                                                                                                                        }
                                                                                                                                                                                        sub_14011E990(v4 - 64, &v131);
                                                                                                                                                                                        goto LABEL_554;
                                                                                                                                                                                      }
                                                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"BTN_OPEN_PHOTO_FOLDER1", 141);
LABEL_301:
                                                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                      {
                                                                                                                                                                                        v110 = v132;
                                                                                                                                                                                        v106 = sub_1400601C0();
                                                                                                                                                                                        if ( v106 == nullptr )
                                                                                                                                                                                          sub_14005FF30(0x80004005);
                                                                                                                                                                                        v132[0] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v106 + 24))(v106) + 24);
                                                                                                                                                                                        if ( (unsigned __int8)sub_14005F980(v132, (__int64)a3) == 0 )
                                                                                                                                                                                        {
                                                                                                                                                                                          v107 = sub_1404ADC20(a3);
                                                                                                                                                                                          sub_14005FCF0(v132, a3, v107);
                                                                                                                                                                                        }
                                                                                                                                                                                        sub_14011E990(v4 - 64, v132);
                                                                                                                                                                                        goto LABEL_554;
                                                                                                                                                                                      }
                                                                                                                                                                                      sub_1400C2FE0(v4 + 2592, L"BTN_OPEN_PHOTO_FOLDER2", 142);
LABEL_303:
                                                                                                                                                                                      if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                                      {
                                                                                                                                                                                        sub_1400C2FE0(v4 + 2592, L"CHK_SET_TEMP_FOLDER", 143);
LABEL_305:
                                                                                                                                                                                        if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                                        {
                                                                                                                                                                                          sub_1400C2FE0(v4 + 2592, L"CHK_USER_DEFINE_IMAGE_EXT", 144);
LABEL_307:
                                                                                                                                                                                          if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                                          {
                                                                                                                                                                                            sub_1400C2FE0(v4 + 2592, L"CHK_USER_DEFINE_IGNORE_IMAGE_EXT", 145);
LABEL_309:
                                                                                                                                                                                            if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                            {
                                                                                                                                                                                              v48 = L"https://www.bandisoft.com/bandiview/help/setting-video-output/";
                                                                                                                                                                                            }
                                                                                                                                                                                            else
                                                                                                                                                                                            {
                                                                                                                                                                                              sub_1400C2FE0(v4 + 2592, L"_CMD_HELP_VIDEO_OUTPUT", 146);
LABEL_311:
                                                                                                                                                                                              if ( *(_DWORD *)(v4 + 2584) == 0 )
                                                                                                                                                                                              {
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"_CMD_HELP_EXPORT_SETTINGS", 147);
LABEL_313:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_LASTACTION_IMAGE", 148);
LABEL_315:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_LASTACTION_ARCHIVE", 149);
LABEL_317:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_TITLEFORMAT", 150);
LABEL_319:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_32BPP_BKGND", 151);
LABEL_321:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_CUSTOM_LBUTTON", 152);
LABEL_323:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_CUSTOM_LBTNDBL", 153);
LABEL_325:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_CUSTOM_MBUTTON", 154);
LABEL_327:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_CUSTOM_RBUTTON", 155);
LABEL_329:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_CUSTOM_XBUTTON", 156);
LABEL_331:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_CUSTOM_YBUTTON", 157);
LABEL_333:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_CUSTOM_WHEELUP", 158);
LABEL_335:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_CUSTOM_WHEELDN", 159);
LABEL_337:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_CUSTOM_WHEELSPEED", 160);
LABEL_339:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_VIDEO_OUTPUT", 161);
LABEL_341:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                  goto LABEL_553;
                                                                                                                                                                                                sub_1400C2FE0(v4 + 2592, L"IDC_CB_USER_DEFINE_IGNORE_IMAGE_EXT", 162);
LABEL_343:
                                                                                                                                                                                                if ( *(_DWORD *)(v4 + 2584) != 0 )
                                                                                                                                                                                                {
LABEL_553:
                                                                                                                                                                                                  v111 = 0;
                                                                                                                                                                                                  v112 = nullptr;
                                                                                                                                                                                                  v113 = nullptr;
                                                                                                                                                                                                  v108 = sub_1404ADC20(a3);
                                                                                                                                                                                                  sub_140061270((char **)&v111, a3, v108);
                                                                                                                                                                                                  sub_1400C2CF0(v4 - 64, &v111);
                                                                                                                                                                                                }
                                                                                                                                                                                                else
                                                                                                                                                                                                {
                                                                                                                                                                                                  sub_1400C2FE0(v4 + 2592, L"IDC_CB_LANG", 163);
                                                                                                                                                                                                }
                                                                                                                                                                                                goto LABEL_554;
                                                                                                                                                                                              }
                                                                                                                                                                                              v48 = L"https://www.bandisoft.com/bandiview/help/how-to-export-settings/";
                                                                                                                                                                                            }
                                                                                                                                                                                            goto LABEL_424;
                                                                                                                                                                                          }
                                                                                                                                                                                        }
                                                                                                                                                                                      }
                                                                                                                                                                                      sub_1400BE880(v4 - 64);
                                                                                                                                                                                      goto LABEL_554;
                                                                                                                                                                                    }
                                                                                                                                                                                  }
                                                                                                                                                                                }
                                                                                                                                                                              }
                                                                                                                                                                            }
                                                                                                                                                                          }
                                                                                                                                                                        }
                                                                                                                                                                      }
                                                                                                                                                                    }
                                                                                                                                                                  }
                                                                                                                                                                }
                                                                                                                                                              }
                                                                                                                                                            }
                                                                                                                                                          }
                                                                                                                                                        }
                                                                                                                                                      }
                                                                                                                                                    }
                                                                                                                                                  }
                                                                                                                                                }
                                                                                                                                              }
                                                                                                                                            }
                                                                                                                                          }
                                                                                                                                        }
                                                                                                                                      }
                                                                                                                                    }
                                                                                                                                    v110 = &v126;
                                                                                                                                    v94 = sub_1400601C0();
                                                                                                                                    if ( v94 == nullptr )
                                                                                                                                      sub_14005FF30(0x80004005);
                                                                                                                                    v126 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v94 + 24))(v94) + 24);
                                                                                                                                    if ( (unsigned __int8)sub_14005F980(&v126, (__int64)a3) == 0 )
                                                                                                                                    {
                                                                                                                                      v95 = sub_1404ADC20(a3);
                                                                                                                                      sub_14005FCF0(&v126, a3, v95);
                                                                                                                                    }
                                                                                                                                    sub_14008E580(v4 - 64, (int *)&v126);
                                                                                                                                    goto LABEL_554;
                                                                                                                                  }
                                                                                                                                }
                                                                                                                                sub_14008E350(v4 - 64);
                                                                                                                                goto LABEL_554;
                                                                                                                              }
                                                                                                                            }
                                                                                                                          }
                                                                                                                        }
                                                                                                                      }
                                                                                                                    }
                                                                                                                  }
                                                                                                                }
                                                                                                              }
                                                                                                              sub_1400B9A30(v4 - 64);
                                                                                                              goto LABEL_554;
                                                                                                            }
                                                                                                            *(_QWORD *)v133 = 72;
                                                                                                            memset(&v133[16], 0, 56);
                                                                                                            *(_QWORD *)&v133[8] = *(_QWORD *)(v4 - 56);
                                                                                                            *(_QWORD *)&v133[32] = sub_140075FE0() + 422;
                                                                                                            *(_DWORD *)&v133[24] = *((_DWORD *)sub_140075FE0() + 63);
                                                                                                            *(_DWORD *)&v133[40] = 3;
                                                                                                            if ( ChooseColorW((LPCHOOSECOLORW)v133) )
                                                                                                            {
                                                                                                              *((_DWORD *)sub_140075FE0() + 63) = *(_DWORD *)&v133[24];
                                                                                                              goto LABEL_504;
                                                                                                            }
                                                                                                          }
                                                                                                        }
LABEL_554:
                                                                                                        *(_DWORD *)(v4 + 2584) = 1;
                                                                                                        if ( v5 == 0 )
                                                                                                          return;
                                                                                                        break;
                                                                                                      }
                                                                                                    }
                                                                                                  }
                                                                                                }
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                              v109 = &v116;
                                                              v18 = sub_1400601C0();
                                                              if ( v18 == nullptr )
                                                                sub_14005FF30(0x80004005);
                                                              v116 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v18 + 24))(v18)
                                                                           + 24);
                                                              if ( (unsigned __int8)sub_14005F980(&v116, (__int64)a3) == 0 )
                                                              {
                                                                v19 = sub_1404ADC20(a3);
                                                                sub_14005FCF0(&v116, a3, v19);
                                                              }
                                                              sub_1400B2890(v4 - 64, &v116);
                                                              goto LABEL_554;
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                    v109 = &v115;
                    v16 = sub_1400601C0();
                    if ( v16 == nullptr )
                      sub_14005FF30(0x80004005);
                    v115 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v16 + 24))(v16) + 24);
                    if ( (unsigned __int8)sub_14005F980(&v115, (__int64)a3) == 0 )
                    {
                      v17 = sub_1404ADC20(a3);
                      sub_14005FCF0(&v115, a3, v17);
                    }
                    sub_1400B25F0(v4 - 64, &v115);
                    goto LABEL_554;
                  }
                }
              }
              v111 = 0;
              v112 = nullptr;
              v113 = nullptr;
              v15 = sub_1404ADC20(a3);
              sub_140061270((char **)&v111, a3, v15);
              sub_1400B30A0(v4 - 64, &v111);
              goto LABEL_554;
            }
          }
          v109 = &v114;
          v13 = sub_1400601C0();
          if ( v13 == nullptr )
            sub_14005FF30(0x80004005);
          v114 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24);
          if ( (unsigned __int8)sub_14005F980(&v114, (__int64)a3) == 0 )
          {
            v14 = sub_1404ADC20(a3);
            sub_14005FCF0(&v114, a3, v14);
          }
          sub_14011D3F0(v4 - 64, &v114);
          goto LABEL_554;
        case 2:
          goto LABEL_21;
        case 3:
          goto LABEL_23;
        case 4:
          goto LABEL_25;
        case 5:
          goto LABEL_27;
        case 6:
          goto LABEL_29;
        case 7:
          goto LABEL_31;
        case 8:
          goto LABEL_33;
        case 9:
          goto LABEL_35;
        case 10:
          goto LABEL_37;
        case 11:
          goto LABEL_39;
        case 12:
          goto LABEL_41;
        case 13:
          goto LABEL_43;
        case 14:
          goto LABEL_45;
        case 15:
          goto LABEL_47;
        case 16:
          goto LABEL_49;
        case 17:
          goto LABEL_51;
        case 18:
          goto LABEL_53;
        case 19:
          goto LABEL_55;
        case 20:
          goto LABEL_57;
        case 21:
          goto LABEL_59;
        case 22:
          goto LABEL_61;
        case 23:
          goto LABEL_63;
        case 24:
          goto LABEL_65;
        case 25:
          goto LABEL_67;
        case 26:
          goto LABEL_69;
        case 27:
          goto LABEL_71;
        case 28:
          goto LABEL_73;
        case 29:
          goto LABEL_75;
        case 30:
          goto LABEL_77;
        case 31:
          goto LABEL_79;
        case 32:
          goto LABEL_81;
        case 33:
          goto LABEL_83;
        case 34:
          goto LABEL_85;
        case 35:
          goto LABEL_87;
        case 36:
          goto LABEL_89;
        case 37:
          goto LABEL_91;
        case 38:
          goto LABEL_93;
        case 39:
          goto LABEL_95;
        case 40:
          goto LABEL_97;
        case 41:
          goto LABEL_99;
        case 42:
          goto LABEL_101;
        case 43:
          goto LABEL_103;
        case 44:
          goto LABEL_105;
        case 45:
          goto LABEL_107;
        case 46:
          goto LABEL_109;
        case 47:
          goto LABEL_111;
        case 48:
          goto LABEL_113;
        case 49:
          goto LABEL_115;
        case 50:
          goto LABEL_117;
        case 51:
          goto LABEL_119;
        case 52:
          goto LABEL_121;
        case 53:
          goto LABEL_123;
        case 54:
          goto LABEL_125;
        case 55:
          goto LABEL_127;
        case 56:
          goto LABEL_129;
        case 57:
          goto LABEL_131;
        case 58:
          goto LABEL_133;
        case 59:
          goto LABEL_135;
        case 60:
          goto LABEL_137;
        case 61:
          goto LABEL_139;
        case 62:
          goto LABEL_141;
        case 63:
          goto LABEL_143;
        case 64:
          goto LABEL_145;
        case 65:
          goto LABEL_147;
        case 66:
          goto LABEL_149;
        case 67:
          goto LABEL_151;
        case 68:
          goto LABEL_153;
        case 69:
          goto LABEL_155;
        case 70:
          goto LABEL_157;
        case 71:
          goto LABEL_159;
        case 72:
          goto LABEL_161;
        case 73:
          goto LABEL_163;
        case 74:
          goto LABEL_165;
        case 75:
          goto LABEL_167;
        case 76:
          goto LABEL_169;
        case 77:
          goto LABEL_171;
        case 78:
          goto LABEL_173;
        case 79:
          goto LABEL_175;
        case 80:
          goto LABEL_177;
        case 81:
          goto LABEL_179;
        case 82:
          goto LABEL_181;
        case 83:
          goto LABEL_183;
        case 84:
          goto LABEL_185;
        case 85:
          goto LABEL_187;
        case 86:
          goto LABEL_189;
        case 87:
          goto LABEL_191;
        case 88:
          goto LABEL_193;
        case 89:
          goto LABEL_195;
        case 90:
          goto LABEL_197;
        case 91:
          goto LABEL_199;
        case 92:
          goto LABEL_201;
        case 93:
          goto LABEL_203;
        case 94:
          goto LABEL_205;
        case 95:
          goto LABEL_207;
        case 96:
          goto LABEL_209;
        case 97:
          goto LABEL_211;
        case 98:
          goto LABEL_213;
        case 99:
          goto LABEL_215;
        case 100:
          goto LABEL_217;
        case 101:
          goto LABEL_219;
        case 102:
          goto LABEL_221;
        case 103:
          goto LABEL_223;
        case 104:
          goto LABEL_225;
        case 105:
          goto LABEL_227;
        case 106:
          goto LABEL_229;
        case 107:
          goto LABEL_231;
        case 108:
          goto LABEL_233;
        case 109:
          goto LABEL_235;
        case 110:
          goto LABEL_237;
        case 111:
          goto LABEL_239;
        case 112:
          goto LABEL_241;
        case 113:
          goto LABEL_243;
        case 114:
          goto LABEL_245;
        case 115:
          goto LABEL_247;
        case 116:
          goto LABEL_249;
        case 117:
          goto LABEL_251;
        case 118:
          goto LABEL_253;
        case 119:
          goto LABEL_255;
        case 120:
          goto LABEL_257;
        case 121:
          goto LABEL_259;
        case 122:
          goto LABEL_261;
        case 123:
          goto LABEL_263;
        case 124:
          goto LABEL_265;
        case 125:
          goto LABEL_267;
        case 126:
          goto LABEL_269;
        case 127:
          goto LABEL_271;
        case 128:
          goto LABEL_273;
        case 129:
          goto LABEL_275;
        case 130:
          goto LABEL_277;
        case 131:
          goto LABEL_279;
        case 132:
          goto LABEL_281;
        case 133:
          goto LABEL_283;
        case 134:
          goto LABEL_285;
        case 135:
          goto LABEL_287;
        case 136:
          goto LABEL_289;
        case 137:
          goto LABEL_291;
        case 138:
          goto LABEL_293;
        case 139:
          goto LABEL_295;
        case 140:
          goto LABEL_297;
        case 141:
          goto LABEL_299;
        case 142:
          goto LABEL_301;
        case 143:
          goto LABEL_303;
        case 144:
          goto LABEL_305;
        case 145:
          goto LABEL_307;
        case 146:
          goto LABEL_309;
        case 147:
          goto LABEL_311;
        case 148:
          goto LABEL_313;
        case 149:
          goto LABEL_315;
        case 150:
          goto LABEL_317;
        case 151:
          goto LABEL_319;
        case 152:
          goto LABEL_321;
        case 153:
          goto LABEL_323;
        case 154:
          goto LABEL_325;
        case 155:
          goto LABEL_327;
        case 156:
          goto LABEL_329;
        case 157:
          goto LABEL_331;
        case 158:
          goto LABEL_333;
        case 159:
          goto LABEL_335;
        case 160:
          goto LABEL_337;
        case 161:
          goto LABEL_339;
        case 162:
          goto LABEL_341;
        case 163:
          goto LABEL_343;
        default:
          goto LABEL_554;
      }
    }
    v5 = 0;
    v8 = -1;
    a1 = (unsigned __int64)a3;
    v10 = *(_WORD *)a3;
    if ( *(_WORD *)a3 != 0 )
    {
      do
      {
        v7 = v10 + 33 * v7;
        a1 += 2LL;
        v10 = *(_WORD *)a1;
      }
      while ( *(_WORD *)a1 != 0 );
    }
    v11 = *(_QWORD *)(v4 + 2592);
    if ( v11 != 0 )
    {
      v12 = *(_QWORD *)(v11 + 8LL * (v7 % *(_DWORD *)(v4 + 2608)));
      if ( v12 != 0 )
      {
        while ( *(_DWORD *)(v12 + 24) != v7 || (unsigned int)sub_1404D8590(*(_QWORD *)v12, a3) != 0 )
        {
          v12 = *(_QWORD *)(v12 + 16);
          if ( v12 == 0 )
            goto LABEL_11;
        }
        v6 = 0x140000000uLL;
        goto LABEL_13;
      }
LABEL_11:
      v6 = 0x140000000uLL;
    }
    v12 = 0;
LABEL_13:
    if ( v12 != 0 )
      v8 = *(_DWORD *)(v12 + 8);
    goto LABEL_15;
  }
}
