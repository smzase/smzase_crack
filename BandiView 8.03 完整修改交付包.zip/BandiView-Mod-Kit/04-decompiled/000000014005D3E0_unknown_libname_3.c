// EA 0x14005d3e0  name unknown_libname_3  size 17
// Microsoft VisualC v14 64bit runtime
void __noreturn unknown_libname_3()
{
  sub_1404962E4("string too long");
}
