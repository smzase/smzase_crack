// EA 0x140121c50  name sub_140121C50  size 11985
void __fastcall sub_140121C50(__int64 a1, __int64 *a2)
{
  __int64 *v4; // rax
  __int64 *v5; // rax
  __int64 *v6; // rax
  __int64 *v7; // rax
  __int64 *v8; // rax
  __int64 *v9; // rax
  __int64 *v10; // rax
  __int64 *v11; // rax
  __int64 *v12; // rax
  __int64 *v13; // rax
  __int64 *v14; // rax
  __int64 *v15; // rax
  __int64 *v16; // rax
  __int64 *v17; // rax
  __int64 *v18; // rax
  __int64 *v19; // rax
  __int64 *v20; // rax
  __int64 *v21; // rax
  __int64 *v22; // rax
  __int64 *v23; // rax
  __int64 *v24; // rax
  __int64 *v25; // rax
  __int64 *v26; // rax
  __int64 *v27; // rax
  __int64 *v28; // rax
  __int64 *v29; // rax
  __int64 *v30; // rax
  __int64 *v31; // rax
  __int64 *v32; // rax
  __int64 *v33; // rax
  __int64 *v34; // rax
  __int64 *v35; // rax
  __int64 *v36; // rax
  __int64 *v37; // rax
  __int64 *v38; // rax
  __int64 *v39; // rax
  __int64 *v40; // rax
  __int64 *v41; // rax
  __int64 *v42; // rax
  __int64 *v43; // rax
  __int64 *v44; // rax
  __int64 *v45; // rax
  __int64 *v46; // rax
  __int64 *v47; // rax
  __int64 *v48; // rax
  __int64 *v49; // rax
  __int64 *v50; // rax
  __int64 *v51; // rax
  __int64 *v52; // rax
  __int64 *v53; // rax
  __int64 *v54; // rax
  __int64 *v55; // rax
  __int64 *v56; // rax
  __int64 *v57; // rax
  __int64 *v58; // rax
  __int64 *v59; // rax
  __int64 v60; // rax
  __int64 v61; // rdx
  volatile signed __int32 *v62; // rdx
  __int64 *v63; // rax
  __int64 *v64; // rax
  __int64 *v65; // rax
  __int64 v66; // rdx
  const wchar_t *v67; // r8
  __int64 v68; // rax
  BYTE *v69; // rcx
  wchar_t v70; // r9
  int v71; // eax
  int v72; // eax
  int v73; // edi
  int *v74; // r13
  int *v75; // rbx
  int *v76; // rsi
  __int64 i; // rax
  int v78; // eax
  __int64 v79; // r14
  int v80; // r15d
  int v81; // edx
  int *v82; // rdi
  int *v83; // r12
  __int64 v84; // rcx
  __int64 j; // rbx
  int v86; // esi
  int v87; // eax
  int v88; // eax
  __int64 *v89; // rax
  __int64 *v90; // rax
  __int64 v91; // rcx
  __int64 v92; // rax
  __int64 v93; // rax
  _BYTE *v94; // rbx
  int v95; // eax
  _QWORD *v96; // rax
  _QWORD *v97; // r12
  size_t v98; // r15
  int *v99; // rbx
  int *v100; // rdi
  unsigned __int64 v101; // r13
  DWORD v102; // eax
  int *v103; // rbx
  int *v104; // rdi
  int **v105; // rsi
  int *v106; // rsi
  __int64 *v107; // rax
  volatile signed __int32 *v108; // rsi
  LPCWSTR *v109; // rax
  DWORD v110; // eax
  _QWORD *v111; // rdx
  __int64 *v112; // rax
  _BYTE *v113; // rdx
  volatile signed __int32 *v114; // rcx
  __int64 v115; // r15
  __int64 v116; // rdx
  __int64 *v117; // rax
  LPCWSTR *v118; // rax
  DWORD v119; // eax
  _QWORD *v120; // rdx
  __int64 *v121; // rax
  _BYTE *v122; // rdx
  volatile signed __int32 *v123; // rcx
  __int64 v124; // r15
  volatile signed __int32 *v125; // rdx
  __int64 *v126; // rax
  LPCWSTR *v127; // rax
  DWORD v128; // eax
  _QWORD *v129; // rdx
  __int64 *v130; // rax
  _BYTE *v131; // rdx
  volatile signed __int32 *v132; // rcx
  __int64 v133; // rax
  _QWORD *v134; // rdx
  unsigned __int64 v135; // rdx
  size_t v136; // rcx
  size_t v137; // rax
  _QWORD *v138; // rax
  _QWORD *v139; // rsi
  __int64 *v140; // rax
  LPCWSTR *v141; // rax
  DWORD v142; // eax
  volatile signed __int32 *v143; // rdx
  __int64 *v144; // rax
  _BYTE *v145; // rdx
  volatile signed __int32 *v146; // rcx
  __int64 v147; // rax
  volatile signed __int32 *v148; // rdx
  unsigned __int64 v149; // rdx
  size_t v150; // rcx
  size_t v151; // rax
  _QWORD *v152; // rax
  _QWORD *v153; // rsi
  int **v154; // rsi
  int *v155; // rdx
  int *v156; // rdx
  char v157; // al
  volatile signed __int32 *v158; // r15
  int **v159; // rbx
  __int64 v160; // r12
  __int64 v161; // rsi
  __int64 v162; // rdx
  __int64 v163; // rax
  __int64 *v164; // rax
  int *v165; // rsi
  __int64 *v166; // rax
  volatile signed __int32 *v167; // rcx
  volatile signed __int32 *v168; // rsi
  __int64 v169; // r13
  __int64 v170; // rax
  volatile signed __int32 *v171; // rdx
  HKEY v172; // rax
  HKEY v173; // rcx
  int *v174; // rsi
  __int64 v175; // r13
  __int64 k; // rcx
  int v177; // edx
  __int64 v178; // rax
  __int64 v179; // rax
  _BYTE *v180; // rsi
  int *v181; // rdx
  int *v182; // rdx
  volatile signed __int32 *v183; // rbx
  volatile signed __int32 *v184; // rdx
  volatile signed __int32 *v185; // rdx
  _QWORD *v186; // rdx
  int *v187; // rdx
  _QWORD *v188; // rdx
  signed int v189; // ebx
  HMENU v190; // r15
  __int64 v191; // rbx
  BOOL v192; // eax
  _QWORD *v193; // rbx
  _QWORD *v194; // rsi
  volatile signed __int32 *v195; // rdx
  volatile signed __int32 *v196; // rdx
  _QWORD *v197; // rdx
  int *v198; // rdx
  _QWORD *v199; // rdx
  unsigned __int64 m; // rbx
  volatile signed __int32 *v201; // rdx
  volatile signed __int32 *v202; // rdx
  unsigned __int64 v203; // rcx
  __int64 *v204; // rax
  void *v205; // rcx
  _QWORD *v206; // rdx
  int *v207; // rdx
  _QWORD *v208; // rdx
  unsigned __int64 n; // rbx
  volatile signed __int32 *v210; // rdx
  volatile signed __int32 *v211; // rdx
  PHKEY phkResult; // [rsp+20h] [rbp-E0h]
  PHKEY phkResulta; // [rsp+20h] [rbp-E0h]
  PHKEY phkResultb; // [rsp+20h] [rbp-E0h]
  PHKEY phkResultc; // [rsp+20h] [rbp-E0h]
  LPDWORD lpcbData; // [rsp+28h] [rbp-D8h]
  LPDWORD lpcbDataa; // [rsp+28h] [rbp-D8h]
  LPDWORD lpcbDatab; // [rsp+28h] [rbp-D8h]
  LPDWORD lpcbDatac; // [rsp+28h] [rbp-D8h]
  DWORD Type[2]; // [rsp+40h] [rbp-C0h] BYREF
  int *v221; // [rsp+48h] [rbp-B8h] BYREF
  int *v222; // [rsp+50h] [rbp-B0h] BYREF
  HKEY hKey; // [rsp+58h] [rbp-A8h] BYREF
  DWORD cbData; // [rsp+60h] [rbp-A0h] BYREF
  int *v225; // [rsp+68h] [rbp-98h] BYREF
  __int64 *v226; // [rsp+70h] [rbp-90h]
  __int64 v227; // [rsp+78h] [rbp-88h] BYREF
  void *Block[2]; // [rsp+80h] [rbp-80h] BYREF
  __int64 v229; // [rsp+90h] [rbp-70h]
  int **p_hKey; // [rsp+98h] [rbp-68h] BYREF
  __int64 v231; // [rsp+A0h] [rbp-60h] BYREF
  void *v232; // [rsp+A8h] [rbp-58h] BYREF
  __int64 v233; // [rsp+B0h] [rbp-50h]
  __int64 v234; // [rsp+B8h] [rbp-48h]
  int v235; // [rsp+C0h] [rbp-40h]
  __int64 v236; // [rsp+C8h] [rbp-38h] BYREF
  HMENU hMenu; // [rsp+D0h] [rbp-30h] BYREF
  volatile signed __int32 *v238; // [rsp+D8h] [rbp-28h] BYREF
  int *v239; // [rsp+E0h] [rbp-20h] BYREF
  int *v240; // [rsp+E8h] [rbp-18h] BYREF
  int *v241; // [rsp+F0h] [rbp-10h] BYREF
  int *v242; // [rsp+F8h] [rbp-8h] BYREF
  int *v243; // [rsp+100h] [rbp+0h] BYREF
  int *v244; // [rsp+108h] [rbp+8h] BYREF
  int *v245; // [rsp+110h] [rbp+10h] BYREF
  __int64 *v246; // [rsp+118h] [rbp+18h]
  volatile signed __int32 *v247; // [rsp+120h] [rbp+20h] BYREF
  int *v248; // [rsp+128h] [rbp+28h] BYREF
  int *v249; // [rsp+130h] [rbp+30h] BYREF
  __int64 v250; // [rsp+138h] [rbp+38h] BYREF
  __int64 v251; // [rsp+140h] [rbp+40h] BYREF
  __int64 v252; // [rsp+148h] [rbp+48h] BYREF
  __int64 v253; // [rsp+150h] [rbp+50h] BYREF
  __int64 v254; // [rsp+158h] [rbp+58h] BYREF
  __int64 v255; // [rsp+160h] [rbp+60h] BYREF
  __int64 v256; // [rsp+168h] [rbp+68h] BYREF
  __int64 v257; // [rsp+170h] [rbp+70h] BYREF
  __int64 v258; // [rsp+178h] [rbp+78h] BYREF
  __int64 v259; // [rsp+180h] [rbp+80h] BYREF
  __int64 v260; // [rsp+188h] [rbp+88h] BYREF
  __int64 v261; // [rsp+190h] [rbp+90h] BYREF
  __int64 v262; // [rsp+198h] [rbp+98h] BYREF
  __int64 v263; // [rsp+1A0h] [rbp+A0h] BYREF
  __int64 v264; // [rsp+1A8h] [rbp+A8h] BYREF
  __int64 v265; // [rsp+1B0h] [rbp+B0h] BYREF
  __int64 v266; // [rsp+1B8h] [rbp+B8h] BYREF
  __int64 v267; // [rsp+1C0h] [rbp+C0h] BYREF
  __int64 v268; // [rsp+1C8h] [rbp+C8h] BYREF
  __int64 v269; // [rsp+1D0h] [rbp+D0h] BYREF
  __int64 v270; // [rsp+1D8h] [rbp+D8h] BYREF
  __int64 v271; // [rsp+1E0h] [rbp+E0h] BYREF
  __int64 v272; // [rsp+1E8h] [rbp+E8h]
  _QWORD v273[4]; // [rsp+1F0h] [rbp+F0h]
  struct tagPOINT Point[2]; // [rsp+210h] [rbp+110h] BYREF
  int *v275; // [rsp+220h] [rbp+120h] BYREF
  int *v276; // [rsp+228h] [rbp+128h] BYREF
  int *v277; // [rsp+230h] [rbp+130h] BYREF
  int *v278; // [rsp+238h] [rbp+138h] BYREF
  int *v279; // [rsp+240h] [rbp+140h] BYREF
  int *v280; // [rsp+248h] [rbp+148h] BYREF
  int *v281; // [rsp+250h] [rbp+150h] BYREF
  int *v282; // [rsp+258h] [rbp+158h] BYREF
  int *v283; // [rsp+260h] [rbp+160h] BYREF
  int *v284; // [rsp+268h] [rbp+168h] BYREF
  int *v285; // [rsp+270h] [rbp+170h] BYREF
  int *v286; // [rsp+278h] [rbp+178h] BYREF
  int *v287; // [rsp+280h] [rbp+180h] BYREF
  int *v288; // [rsp+288h] [rbp+188h] BYREF
  int *v289; // [rsp+290h] [rbp+190h] BYREF
  int *v290; // [rsp+298h] [rbp+198h] BYREF
  int *v291; // [rsp+2A0h] [rbp+1A0h] BYREF
  int *v292; // [rsp+2A8h] [rbp+1A8h] BYREF
  int *v293; // [rsp+2B0h] [rbp+1B0h] BYREF
  int *v294; // [rsp+2B8h] [rbp+1B8h] BYREF
  int *v295; // [rsp+2C0h] [rbp+1C0h] BYREF
  int *v296; // [rsp+2C8h] [rbp+1C8h] BYREF
  int *v297; // [rsp+2D0h] [rbp+1D0h] BYREF
  int *v298; // [rsp+2D8h] [rbp+1D8h] BYREF
  int *v299; // [rsp+2E0h] [rbp+1E0h] BYREF
  int *v300; // [rsp+2E8h] [rbp+1E8h] BYREF
  int *v301; // [rsp+2F0h] [rbp+1F0h] BYREF
  int *v302; // [rsp+2F8h] [rbp+1F8h] BYREF
  int *v303; // [rsp+300h] [rbp+200h] BYREF
  int *v304; // [rsp+308h] [rbp+208h] BYREF
  int *v305; // [rsp+310h] [rbp+210h] BYREF
  int *v306; // [rsp+318h] [rbp+218h] BYREF
  int *v307; // [rsp+320h] [rbp+220h] BYREF
  int *v308; // [rsp+328h] [rbp+228h] BYREF
  int *v309; // [rsp+330h] [rbp+230h] BYREF
  int *v310; // [rsp+338h] [rbp+238h] BYREF
  int *v311; // [rsp+340h] [rbp+240h] BYREF
  int *v312; // [rsp+348h] [rbp+248h] BYREF
  int *v313; // [rsp+350h] [rbp+250h] BYREF
  int *v314; // [rsp+358h] [rbp+258h] BYREF
  int *v315; // [rsp+360h] [rbp+260h] BYREF
  int *v316; // [rsp+368h] [rbp+268h] BYREF
  int *v317; // [rsp+370h] [rbp+270h] BYREF
  int *v318; // [rsp+378h] [rbp+278h] BYREF
  int *v319; // [rsp+380h] [rbp+280h] BYREF
  int *v320; // [rsp+388h] [rbp+288h] BYREF
  int *v321; // [rsp+390h] [rbp+290h] BYREF
  int *v322; // [rsp+398h] [rbp+298h] BYREF
  int *v323; // [rsp+3A0h] [rbp+2A0h] BYREF
  int *v324; // [rsp+3A8h] [rbp+2A8h] BYREF
  int *v325; // [rsp+3B0h] [rbp+2B0h] BYREF
  int *v326; // [rsp+3B8h] [rbp+2B8h] BYREF
  int *v327; // [rsp+3C0h] [rbp+2C0h] BYREF
  int *v328; // [rsp+3C8h] [rbp+2C8h] BYREF
  int *v329; // [rsp+3D0h] [rbp+2D0h] BYREF
  int *v330; // [rsp+3D8h] [rbp+2D8h] BYREF
  WCHAR Data[264]; // [rsp+3E0h] [rbp+2E0h] BYREF

  v246 = a2;
  v272 = a1;
  v273[3] = a2;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v275 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( (unsigned __int8)sub_14005F980(&v275, (__int64)L"Paint.Net") == 0 )
    sub_14005FCF0(&v275, L"Paint.Net", 9);
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  v276 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
  if ( (unsigned __int8)sub_14005F980(&v276, (__int64)L"Paint.NET\\PaintDotNet.exe") == 0 )
    sub_14005FCF0(&v276, L"Paint.NET\\PaintDotNet.exe", 25);
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  v277 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  if ( (unsigned __int8)sub_14005F980(&v277, (__int64)L"Paint Shop Pro 6") == 0 )
    sub_14005FCF0(&v277, L"Paint Shop Pro 6", 16);
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  v278 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
  if ( (unsigned __int8)sub_14005F980(&v278, (__int64)L"Paint Shop Pro 6\\psp.exe") == 0 )
    sub_14005FCF0(&v278, L"Paint Shop Pro 6\\psp.exe", 24);
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  v279 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24);
  if ( (unsigned __int8)sub_14005F980(&v279, (__int64)L"Paint Shop Pro 8") == 0 )
    sub_14005FCF0(&v279, L"Paint Shop Pro 8", 16);
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    sub_14005FF30(0x80004005);
  v280 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
  if ( (unsigned __int8)sub_14005F980(&v280, (__int64)L"Jasc Software Inc\\Paint Shop Pro 8\\Paint Shop Pro.exe") == 0 )
    sub_14005FCF0(&v280, L"Jasc Software Inc\\Paint Shop Pro 8\\Paint Shop Pro.exe", 53);
  v10 = sub_1400601C0();
  if ( v10 == nullptr )
    sub_14005FF30(0x80004005);
  v281 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24);
  if ( (unsigned __int8)sub_14005F980(&v281, (__int64)L"Paint Shop Pro X") == 0 )
    sub_14005FCF0(&v281, L"Paint Shop Pro X", 16);
  v11 = sub_1400601C0();
  if ( v11 == nullptr )
    sub_14005FF30(0x80004005);
  v282 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24);
  if ( (unsigned __int8)sub_14005F980(&v282, (__int64)L"Corel\\Corel Paint Shop Pro X\\Paint Shop Pro X.exe") == 0 )
    sub_14005FCF0(&v282, L"Corel\\Corel Paint Shop Pro X\\Paint Shop Pro X.exe", 49);
  v12 = sub_1400601C0();
  if ( v12 == nullptr )
    sub_14005FF30(0x80004005);
  v283 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24);
  if ( (unsigned __int8)sub_14005F980(&v283, (__int64)L"Imagine") == 0 )
    sub_14005FCF0(&v283, L"Imagine", 7);
  v13 = sub_1400601C0();
  if ( v13 == nullptr )
    sub_14005FF30(0x80004005);
  v284 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24);
  if ( (unsigned __int8)sub_14005F980(&v284, (__int64)L"Imagine\\Imagine.exe") == 0 )
    sub_14005FCF0(&v284, L"Imagine\\Imagine.exe", 19);
  v14 = sub_1400601C0();
  if ( v14 == nullptr )
    sub_14005FF30(0x80004005);
  v285 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
  if ( (unsigned __int8)sub_14005F980(&v285, (__int64)L"Adobe Photoshop CS2") == 0 )
    sub_14005FCF0(&v285, L"Adobe Photoshop CS2", 19);
  v15 = sub_1400601C0();
  if ( v15 == nullptr )
    sub_14005FF30(0x80004005);
  v286 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
  if ( (unsigned __int8)sub_14005F980(&v286, (__int64)L"Adobe\\Adobe Photoshop CS2\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v286, L"Adobe\\Adobe Photoshop CS2\\Photoshop.exe", 39);
  v16 = sub_1400601C0();
  if ( v16 == nullptr )
    sub_14005FF30(0x80004005);
  v287 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v16 + 24))(v16) + 24);
  if ( (unsigned __int8)sub_14005F980(&v287, (__int64)L"Adobe Photoshop CS3") == 0 )
    sub_14005FCF0(&v287, L"Adobe Photoshop CS3", 19);
  v17 = sub_1400601C0();
  if ( v17 == nullptr )
    sub_14005FF30(0x80004005);
  v288 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v17 + 24))(v17) + 24);
  if ( (unsigned __int8)sub_14005F980(&v288, (__int64)L"Adobe\\Adobe Photoshop CS3\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v288, L"Adobe\\Adobe Photoshop CS3\\Photoshop.exe", 39);
  v18 = sub_1400601C0();
  if ( v18 == nullptr )
    sub_14005FF30(0x80004005);
  v289 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v18 + 24))(v18) + 24);
  if ( (unsigned __int8)sub_14005F980(&v289, (__int64)L"Adobe Photoshop CS4") == 0 )
    sub_14005FCF0(&v289, L"Adobe Photoshop CS4", 19);
  v19 = sub_1400601C0();
  if ( v19 == nullptr )
    sub_14005FF30(0x80004005);
  v290 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v19 + 24))(v19) + 24);
  if ( (unsigned __int8)sub_14005F980(&v290, (__int64)L"Adobe\\Adobe Photoshop CS4\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v290, L"Adobe\\Adobe Photoshop CS4\\Photoshop.exe", 39);
  v20 = sub_1400601C0();
  if ( v20 == nullptr )
    sub_14005FF30(0x80004005);
  v291 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v20 + 24))(v20) + 24);
  if ( (unsigned __int8)sub_14005F980(&v291, (__int64)L"Adobe Photoshop CS5") == 0 )
    sub_14005FCF0(&v291, L"Adobe Photoshop CS5", 19);
  v21 = sub_1400601C0();
  if ( v21 == nullptr )
    sub_14005FF30(0x80004005);
  v292 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v21 + 24))(v21) + 24);
  if ( (unsigned __int8)sub_14005F980(&v292, (__int64)L"Adobe\\Adobe Photoshop CS5\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v292, L"Adobe\\Adobe Photoshop CS5\\Photoshop.exe", 39);
  v22 = sub_1400601C0();
  if ( v22 == nullptr )
    sub_14005FF30(0x80004005);
  v293 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v22 + 24))(v22) + 24);
  if ( (unsigned __int8)sub_14005F980(&v293, (__int64)L"Adobe Photoshop CS6") == 0 )
    sub_14005FCF0(&v293, L"Adobe Photoshop CS6", 19);
  v23 = sub_1400601C0();
  if ( v23 == nullptr )
    sub_14005FF30(0x80004005);
  v294 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v23 + 24))(v23) + 24);
  if ( (unsigned __int8)sub_14005F980(&v294, (__int64)L"Adobe\\Adobe Photoshop CS6\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v294, L"Adobe\\Adobe Photoshop CS6\\Photoshop.exe", 39);
  v24 = sub_1400601C0();
  if ( v24 == nullptr )
    sub_14005FF30(0x80004005);
  v295 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v24 + 24))(v24) + 24);
  if ( (unsigned __int8)sub_14005F980(&v295, (__int64)L"Adobe Photoshop CS6(64Bit)") == 0 )
    sub_14005FCF0(&v295, L"Adobe Photoshop CS6(64Bit)", 26);
  v25 = sub_1400601C0();
  if ( v25 == nullptr )
    sub_14005FF30(0x80004005);
  v296 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v25 + 24))(v25) + 24);
  if ( (unsigned __int8)sub_14005F980(&v296, (__int64)L"Adobe\\Adobe Photoshop CS6 (64 Bit)\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v296, L"Adobe\\Adobe Photoshop CS6 (64 Bit)\\Photoshop.exe", 48);
  v26 = sub_1400601C0();
  if ( v26 == nullptr )
    sub_14005FF30(0x80004005);
  v297 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v26 + 24))(v26) + 24);
  if ( (unsigned __int8)sub_14005F980(&v297, (__int64)L"Adobe Photoshop CC") == 0 )
    sub_14005FCF0(&v297, L"Adobe Photoshop CC", 18);
  v27 = sub_1400601C0();
  if ( v27 == nullptr )
    sub_14005FF30(0x80004005);
  v298 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v27 + 24))(v27) + 24);
  if ( (unsigned __int8)sub_14005F980(&v298, (__int64)L"Adobe\\Adobe Photoshop CC\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v298, L"Adobe\\Adobe Photoshop CC\\Photoshop.exe", 38);
  v28 = sub_1400601C0();
  if ( v28 == nullptr )
    sub_14005FF30(0x80004005);
  v299 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24);
  if ( (unsigned __int8)sub_14005F980(&v299, (__int64)L"Adobe Photoshop CC(64Bit)") == 0 )
    sub_14005FCF0(&v299, L"Adobe Photoshop CC(64Bit)", 25);
  v29 = sub_1400601C0();
  if ( v29 == nullptr )
    sub_14005FF30(0x80004005);
  v300 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v29 + 24))(v29) + 24);
  if ( (unsigned __int8)sub_14005F980(&v300, (__int64)L"Adobe\\Adobe Photoshop CC (64 Bit)\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v300, L"Adobe\\Adobe Photoshop CC (64 Bit)\\Photoshop.exe", 47);
  v30 = sub_1400601C0();
  if ( v30 == nullptr )
    sub_14005FF30(0x80004005);
  v301 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v30 + 24))(v30) + 24);
  if ( (unsigned __int8)sub_14005F980(&v301, (__int64)L"Adobe Photoshop CC(2015)") == 0 )
    sub_14005FCF0(&v301, L"Adobe Photoshop CC(2015)", 24);
  v31 = sub_1400601C0();
  if ( v31 == nullptr )
    sub_14005FF30(0x80004005);
  v302 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v31 + 24))(v31) + 24);
  if ( (unsigned __int8)sub_14005F980(&v302, (__int64)L"Adobe\\Adobe Photoshop CC 2015\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v302, L"Adobe\\Adobe Photoshop CC 2015\\Photoshop.exe", 43);
  v32 = sub_1400601C0();
  if ( v32 == nullptr )
    sub_14005FF30(0x80004005);
  v303 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v32 + 24))(v32) + 24);
  if ( (unsigned __int8)sub_14005F980(&v303, (__int64)L"Adobe Photoshop 2021") == 0 )
    sub_14005FCF0(&v303, L"Adobe Photoshop 2021", 20);
  v33 = sub_1400601C0();
  if ( v33 == nullptr )
    sub_14005FF30(0x80004005);
  v304 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v33 + 24))(v33) + 24);
  if ( (unsigned __int8)sub_14005F980(&v304, (__int64)L"Adobe\\Adobe Photoshop 2021\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v304, L"Adobe\\Adobe Photoshop 2021\\Photoshop.exe", 40);
  v34 = sub_1400601C0();
  if ( v34 == nullptr )
    sub_14005FF30(0x80004005);
  v305 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v34 + 24))(v34) + 24);
  if ( (unsigned __int8)sub_14005F980(&v305, (__int64)L"Adobe Photoshop 2022") == 0 )
    sub_14005FCF0(&v305, L"Adobe Photoshop 2022", 20);
  v35 = sub_1400601C0();
  if ( v35 == nullptr )
    sub_14005FF30(0x80004005);
  v306 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v35 + 24))(v35) + 24);
  if ( (unsigned __int8)sub_14005F980(&v306, (__int64)L"Adobe\\Adobe Photoshop 2022\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v306, L"Adobe\\Adobe Photoshop 2022\\Photoshop.exe", 40);
  v36 = sub_1400601C0();
  if ( v36 == nullptr )
    sub_14005FF30(0x80004005);
  v307 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v36 + 24))(v36) + 24);
  if ( (unsigned __int8)sub_14005F980(&v307, (__int64)L"Adobe Photoshop 2023") == 0 )
    sub_14005FCF0(&v307, L"Adobe Photoshop 2023", 20);
  v37 = sub_1400601C0();
  if ( v37 == nullptr )
    sub_14005FF30(0x80004005);
  v308 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v37 + 24))(v37) + 24);
  if ( (unsigned __int8)sub_14005F980(&v308, (__int64)L"Adobe\\Adobe Photoshop 2023\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v308, L"Adobe\\Adobe Photoshop 2023\\Photoshop.exe", 40);
  v38 = sub_1400601C0();
  if ( v38 == nullptr )
    sub_14005FF30(0x80004005);
  v309 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v38 + 24))(v38) + 24);
  if ( (unsigned __int8)sub_14005F980(&v309, (__int64)L"Adobe Photoshop 2024") == 0 )
    sub_14005FCF0(&v309, L"Adobe Photoshop 2024", 20);
  v39 = sub_1400601C0();
  if ( v39 == nullptr )
    sub_14005FF30(0x80004005);
  v310 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v39 + 24))(v39) + 24);
  if ( (unsigned __int8)sub_14005F980(&v310, (__int64)L"Adobe\\Adobe Photoshop 2024\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v310, L"Adobe\\Adobe Photoshop 2024\\Photoshop.exe", 40);
  v40 = sub_1400601C0();
  if ( v40 == nullptr )
    sub_14005FF30(0x80004005);
  v311 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v40 + 24))(v40) + 24);
  if ( (unsigned __int8)sub_14005F980(&v311, (__int64)L"Adobe Photoshop 2025") == 0 )
    sub_14005FCF0(&v311, L"Adobe Photoshop 2025", 20);
  v41 = sub_1400601C0();
  if ( v41 == nullptr )
    sub_14005FF30(0x80004005);
  v312 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v41 + 24))(v41) + 24);
  if ( (unsigned __int8)sub_14005F980(&v312, (__int64)L"Adobe\\Adobe Photoshop 2025\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v312, L"Adobe\\Adobe Photoshop 2025\\Photoshop.exe", 40);
  v42 = sub_1400601C0();
  if ( v42 == nullptr )
    sub_14005FF30(0x80004005);
  v313 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v42 + 24))(v42) + 24);
  if ( (unsigned __int8)sub_14005F980(&v313, (__int64)L"Adobe Photoshop 2026") == 0 )
    sub_14005FCF0(&v313, L"Adobe Photoshop 2026", 20);
  v43 = sub_1400601C0();
  if ( v43 == nullptr )
    sub_14005FF30(0x80004005);
  v314 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v43 + 24))(v43) + 24);
  if ( (unsigned __int8)sub_14005F980(&v314, (__int64)L"Adobe\\Adobe Photoshop 2026\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v314, L"Adobe\\Adobe Photoshop 2026\\Photoshop.exe", 40);
  v44 = sub_1400601C0();
  if ( v44 == nullptr )
    sub_14005FF30(0x80004005);
  v315 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v44 + 24))(v44) + 24);
  if ( (unsigned __int8)sub_14005F980(&v315, (__int64)L"Adobe Photoshop 2027") == 0 )
    sub_14005FCF0(&v315, L"Adobe Photoshop 2027", 20);
  v45 = sub_1400601C0();
  if ( v45 == nullptr )
    sub_14005FF30(0x80004005);
  v316 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v45 + 24))(v45) + 24);
  if ( (unsigned __int8)sub_14005F980(&v316, (__int64)L"Adobe\\Adobe Photoshop 2027\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v316, L"Adobe\\Adobe Photoshop 2027\\Photoshop.exe", 40);
  v46 = sub_1400601C0();
  if ( v46 == nullptr )
    sub_14005FF30(0x80004005);
  v317 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v46 + 24))(v46) + 24);
  if ( (unsigned __int8)sub_14005F980(&v317, (__int64)L"Adobe Photoshop 2028") == 0 )
    sub_14005FCF0(&v317, L"Adobe Photoshop 2028", 20);
  v47 = sub_1400601C0();
  if ( v47 == nullptr )
    sub_14005FF30(0x80004005);
  v318 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v47 + 24))(v47) + 24);
  if ( (unsigned __int8)sub_14005F980(&v318, (__int64)L"Adobe\\Adobe Photoshop 2028\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v318, L"Adobe\\Adobe Photoshop 2028\\Photoshop.exe", 40);
  v48 = sub_1400601C0();
  if ( v48 == nullptr )
    sub_14005FF30(0x80004005);
  v319 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v48 + 24))(v48) + 24);
  if ( (unsigned __int8)sub_14005F980(&v319, (__int64)L"Adobe Photoshop (Beta)") == 0 )
    sub_14005FCF0(&v319, L"Adobe Photoshop (Beta)", 22);
  v49 = sub_1400601C0();
  if ( v49 == nullptr )
    sub_14005FF30(0x80004005);
  v320 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v49 + 24))(v49) + 24);
  if ( (unsigned __int8)sub_14005F980(&v320, (__int64)L"Adobe\\Adobe Photoshop (Beta)\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v320, L"Adobe\\Adobe Photoshop (Beta)\\Photoshop.exe", 42);
  v50 = sub_1400601C0();
  if ( v50 == nullptr )
    sub_14005FF30(0x80004005);
  v321 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v50 + 24))(v50) + 24);
  if ( (unsigned __int8)sub_14005F980(&v321, (__int64)L"Adobe Photoshop 2028") == 0 )
    sub_14005FCF0(&v321, L"Adobe Photoshop 2028", 20);
  v51 = sub_1400601C0();
  if ( v51 == nullptr )
    sub_14005FF30(0x80004005);
  v322 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v51 + 24))(v51) + 24);
  if ( (unsigned __int8)sub_14005F980(&v322, (__int64)L"Adobe\\Adobe Photoshop 2028\\Photoshop.exe") == 0 )
    sub_14005FCF0(&v322, L"Adobe\\Adobe Photoshop 2028\\Photoshop.exe", 40);
  v52 = sub_1400601C0();
  if ( v52 == nullptr )
    sub_14005FF30(0x80004005);
  v323 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v52 + 24))(v52) + 24);
  if ( (unsigned __int8)sub_14005F980(&v323, (__int64)L"Clip Studio Paint") == 0 )
    sub_14005FCF0(&v323, L"Clip Studio Paint", 17);
  v53 = sub_1400601C0();
  if ( v53 == nullptr )
    sub_14005FF30(0x80004005);
  v324 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v53 + 24))(v53) + 24);
  if ( (unsigned __int8)sub_14005F980(
                          &v324,
                          (__int64)L"CELSYS\\CLIP STUDIO 1.5\\CLIP STUDIO PAINT\\CLIPStudioPaint.exe") == 0 )
    sub_14005FCF0(&v324, L"CELSYS\\CLIP STUDIO 1.5\\CLIP STUDIO PAINT\\CLIPStudioPaint.exe", 60);
  v54 = sub_1400601C0();
  if ( v54 == nullptr )
    sub_14005FF30(0x80004005);
  v325 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v54 + 24))(v54) + 24);
  if ( (unsigned __int8)sub_14005F980(&v325, (__int64)L"Clip Studio Paint En") == 0 )
    sub_14005FCF0(&v325, L"Clip Studio Paint En", 20);
  v55 = sub_1400601C0();
  if ( v55 == nullptr )
    sub_14005FF30(0x80004005);
  v326 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v55 + 24))(v55) + 24);
  if ( (unsigned __int8)sub_14005F980(
                          &v326,
                          (__int64)L"CELSYS\\CLIP STUDIO 1.5 EN\\CLIP STUDIO PAINT\\CLIPStudioPaint.exe") == 0 )
    sub_14005FCF0(&v326, L"CELSYS\\CLIP STUDIO 1.5 EN\\CLIP STUDIO PAINT\\CLIPStudioPaint.exe", 63);
  v56 = sub_1400601C0();
  if ( v56 == nullptr )
    sub_14005FF30(0x80004005);
  v327 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v56 + 24))(v56) + 24);
  if ( (unsigned __int8)sub_14005F980(&v327, (__int64)L"GIMP 2.1") == 0 )
    sub_14005FCF0(&v327, L"GIMP 2.1", 8);
  v57 = sub_1400601C0();
  if ( v57 == nullptr )
    sub_14005FF30(0x80004005);
  v328 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v57 + 24))(v57) + 24);
  if ( (unsigned __int8)sub_14005F980(&v328, (__int64)L"GIMP 2\\bin\\gimp-2.10.exe") == 0 )
    sub_14005FCF0(&v328, L"GIMP 2\\bin\\gimp-2.10.exe", 24);
  v58 = sub_1400601C0();
  if ( v58 == nullptr )
    sub_14005FF30(0x80004005);
  v329 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v58 + 24))(v58) + 24);
  if ( (unsigned __int8)sub_14005F980(&v329, (__int64)L"GIMP 3") == 0 )
    sub_14005FCF0(&v329, L"GIMP 3", 6);
  v59 = sub_1400601C0();
  if ( v59 == nullptr )
    sub_14005FF30(0x80004005);
  v330 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v59 + 24))(v59) + 24);
  if ( (unsigned __int8)sub_14005F980(&v330, (__int64)L"GIMP 3\\bin\\gimp.exe") == 0 )
    sub_14005FCF0(&v330, L"GIMP 3\\bin\\gimp.exe", 19);
  v227 = sub_14005F710((volatile signed __int32 *)(*a2 - 24)) + 24;
  v60 = sub_1401BE5D0(a1 + 728, &v227);
  if ( v60 == 0 )
  {
    `eh vector destructor iterator'(&v275, 0x10u, 0x1Cu, sub_140093C80);
    v61 = *a2;
    goto LABEL_171;
  }
  *(_OWORD *)&Point[0].x = *(_OWORD *)(v60 + 264);
  if ( ClientToScreen(*(HWND *)(a1 + 8), Point) )
    ClientToScreen(*(HWND *)(a1 + 8), &Point[1]);
  hMenu = CreatePopupMenu();
  v232 = nullptr;
  v233 = 0;
  v234 = 0;
  v235 = 0;
  v63 = sub_1400601C0();
  if ( v63 == nullptr )
    sub_14005FF30(0x80004005);
  v248 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v63 + 24))(v63) + 24);
  v64 = sub_1400601C0();
  if ( v64 == nullptr )
    sub_14005FF30(0x80004005);
  v225 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v64 + 24))(v64) + 24);
  sub_140072510(&v236, 28, L"Programs");
  v65 = sub_1400601C0();
  if ( v65 == nullptr )
    sub_14005FF30(0x80004005);
  v249 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v65 + 24))(v65) + 24);
  hKey = nullptr;
  v66 = 2147483646;
  v67 = L"C:\\Program Files";
  v68 = 260;
  v69 = (BYTE *)Data;
  while ( v66 != 0 )
  {
    v70 = *v67;
    if ( *v67 == 0 )
      break;
    ++v67;
    *(_WORD *)v69 = v70;
    v69 += 2;
    --v66;
    if ( --v68 == 0 )
    {
      v69 -= 2;
      break;
    }
  }
  *(_WORD *)v69 = 0;
  if ( RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"Software\\Microsoft\\Windows\\CurrentVersion", 0, 0x20019u, &hKey) == 0 )
  {
    cbData = 1024;
    Type[0] = 1;
    RegQueryValueExW(hKey, L"ProgramFilesDir", nullptr, Type, (LPBYTE)Data, &cbData);
    RegCloseKey(hKey);
  }
  v71 = sub_1404ADC20(Data);
  sub_14005FCF0(&v248, Data, v71);
  v72 = sub_1404ADC20(Data);
  sub_14005FCF0(&v225, Data, v72);
  v73 = 0;
  v74 = v225;
  v75 = v225;
  v76 = (int *)((char *)v225 + 2 * *(v225 - 4));
  if ( v225 < v76 )
  {
    do
    {
      for ( i = sub_1404A27AC(v75, L" Files"); i != 0; i = sub_1404A27AC(i + 12, L" Files") )
      {
        ++v73;
        v75 = (int *)(i + 12);
      }
      if ( v75 != nullptr )
        v78 = sub_1404ADC20(v75);
      else
        v78 = 0;
      v75 = (int *)((char *)v75 + 2 * v78 + 2);
    }
    while ( v75 < v76 );
    if ( v73 > 0 )
    {
      v79 = *(v74 - 4);
      v80 = v79 + 6 * v73;
      v81 = *(v74 - 4);
      if ( v80 > (int)v79 )
        v81 = v79 + 6 * v73;
      if ( v81 < 0 )
        goto LABEL_536;
      if ( ((*(v74 - 3) - v81) | (1 - *(v74 - 2))) < 0 )
      {
        sub_14005FC80(&v225, v81);
        v74 = v225;
      }
      v82 = v74;
      v83 = (int *)((char *)v74 + 2 * v79);
      if ( v74 < v83 )
      {
        do
        {
          for ( j = sub_1404A27AC(v82, L" Files"); j != 0; j = sub_1404A27AC(j + 24, L" Files") )
          {
            v86 = v79 - ((j - (__int64)v74) >> 1) - 6;
            v82 = (int *)(j + 24);
            if ( 2LL * v86 != 0 )
            {
              if ( j == -24 || j == -12 )
              {
                *(_DWORD *)sub_1404A7740(v84) = 22;
                invalid_parameter_noinfo();
                sub_14005FF30(0x80070057);
              }
              memcpy((void *)(j + 24), (const void *)(j + 12), 2LL * v86);
            }
            *(_OWORD *)j = xmmword_140637C98;
            *(_QWORD *)(j + 16) = 0x29003600380078LL;
            *(_WORD *)(j + 2LL * v86 + 24) = 0;
            LODWORD(v79) = v79 + 6;
          }
          if ( v82 != nullptr )
            v87 = sub_1404ADC20(v82);
          else
            v87 = 0;
          v82 = (int *)((char *)v82 + 2 * v87 + 2);
        }
        while ( v82 < v83 );
      }
      if ( v80 < 0 || v80 > *(v74 - 3) )
LABEL_536:
        sub_14005FF30(0x80070057);
      *(v74 - 4) = v80;
      *((_WORD *)v74 + v80) = 0;
    }
  }
  GetSystemDirectoryW(Data, 0x104u);
  v88 = sub_1404ADC20(Data);
  sub_14005FCF0(&v249, Data, v88);
  v89 = sub_1400601C0();
  if ( v89 == nullptr )
    sub_14005FF30(0x80004005);
  v221 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v89 + 24))(v89) + 24);
  if ( (unsigned __int8)sub_14005F980(&v221, (__int64)L"PaintBrush") == 0 )
    sub_14005FCF0(&v221, L"PaintBrush", 10);
  v90 = sub_1400601C0();
  if ( v90 == nullptr )
    sub_14005FF30(0x80004005);
  v222 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v90 + 24))(v90) + 24);
  if ( (unsigned __int8)sub_14005F980(&v222, (__int64)L"mspaint.exe") == 0 )
    sub_14005FCF0(&v222, L"mspaint.exe", 11);
  v92 = sub_1401C5640(v91);
  v93 = sub_1401C81E0(v92, L"MENU_MSPAINT_NAME", L"IDD_SETTING_ETC");
  v94 = (_BYTE *)v93;
  if ( v93 != 0 )
    v95 = sub_1404ADC20(v93);
  else
    v95 = 0;
  sub_14005FCF0(&v221, v94, v95);
  v96 = j__calloc_base(1u, 0x10u);
  v97 = v96;
  v232 = v96;
  if ( v96 == nullptr )
    sub_14005FF30(0x8007000E);
  v98 = 1;
  v234 = 1;
  v238 = (volatile signed __int32 *)v96;
  v99 = v221;
  *v96 = sub_14005F710(v221 - 6) + 24;
  v100 = v222;
  v97[1] = sub_14005F710(v222 - 6) + 24;
  v101 = 1;
  v233 = 1;
  if ( _InterlockedExchangeAdd(v100 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, int *))(**((_QWORD **)v100 - 3) + 8LL))(*((_QWORD *)v100 - 3), v100 - 6);
  if ( _InterlockedExchangeAdd(v99 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, int *))(**((_QWORD **)v99 - 3) + 8LL))(*((_QWORD *)v99 - 3), v99 - 6);
  v102 = 0;
  cbData = 0;
  v103 = v248;
  v104 = v249;
  do
  {
    v105 = &(&v275)[2 * (int)v102];
    v221 = (int *)(sub_14005F710(*v105 - 6) + 24);
    v106 = (int *)(sub_14005F710(v105[1] - 6) + 24);
    v222 = v106;
    *(_QWORD *)Type = &v239;
    v107 = sub_1400601C0();
    if ( v107 == nullptr )
      sub_14005FF30(0x80004005);
    v239 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v107 + 24))(v107) + 24);
    if ( (unsigned __int8)sub_14005F980(&v239, (__int64)L"\\") == 0 )
      sub_14005FCF0(&v239, L"\\", 1);
    v226 = &v250;
    v108 = v106 - 6;
    v250 = sub_14005F710(v108) + 24;
    v227 = (__int64)(v103 - 6);
    v251 = sub_14005F710(v103 - 6) + 24;
    v109 = (LPCWSTR *)sub_1400705B0(&v266, &v251, &v250, &v239, phkResult, lpcbData);
    v110 = sub_14006FEE0(*v109);
    Type[0] = v110;
    v111 = (_QWORD *)(v266 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v266 - 24 + 16), 0xFFFFFFFF) <= 1 )
    {
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v111 + 8LL))(*v111);
      v110 = Type[0];
    }
    if ( v110 != 0 )
    {
      v226 = (__int64 *)&v240;
      v112 = sub_1400601C0();
      if ( v112 == nullptr )
        sub_14005FF30(0x80004005);
      v240 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v112 + 24))(v112) + 24);
      if ( (unsigned __int8)sub_14005F980(&v240, (__int64)L"\\") == 0 )
        sub_14005FCF0(&v240, L"\\", 1);
      *(_QWORD *)Type = &v252;
      v252 = sub_14005F710(v108) + 24;
      v265 = sub_14005F710(v103 - 6) + 24;
      v113 = *(_BYTE **)sub_1400705B0(&v267, &v265, &v252, &v240, phkResulta, lpcbDataa);
      v114 = (volatile signed __int32 *)(v113 - 24);
      if ( v113 - 24 != (_BYTE *)v108 )
      {
        if ( *((int *)v108 + 4) >= 0 && *(_QWORD *)v114 == *(_QWORD *)v108 )
        {
          v115 = sub_14005F710(v114);
          if ( _InterlockedExchangeAdd(v108 + 4, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v108 + 8LL))(*(_QWORD *)v108, v108);
          v222 = (int *)(v115 + 24);
        }
        else
        {
          sub_14005FCF0(&v222, v113, *((_DWORD *)v113 - 4));
        }
      }
      v116 = v267;
LABEL_262:
      v125 = (volatile signed __int32 *)(v116 - 24);
      if ( _InterlockedExchangeAdd(v125 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v125 + 8LL))(*(_QWORD *)v125);
      sub_140124B30(&v232, &v221);
      v98 = v234;
      v101 = v233;
      v97 = v232;
      goto LABEL_337;
    }
    p_hKey = &v245;
    v117 = sub_1400601C0();
    if ( v117 == nullptr )
      sub_14005FF30(0x80004005);
    v245 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v117 + 24))(v117) + 24);
    if ( (unsigned __int8)sub_14005F980(&v245, (__int64)L"\\") == 0 )
      sub_14005FCF0(&v245, L"\\", 1);
    v226 = &v263;
    v263 = sub_14005F710(v108) + 24;
    v264 = sub_14005F710(v225 - 6) + 24;
    v118 = (LPCWSTR *)sub_1400705B0(&v268, &v264, &v263, &v245, phkResulta, lpcbDataa);
    v119 = sub_14006FEE0(*v118);
    Type[0] = v119;
    v120 = (_QWORD *)(v268 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v268 - 24 + 16), 0xFFFFFFFF) <= 1 )
    {
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v120 + 8LL))(*v120);
      v119 = Type[0];
    }
    if ( v119 != 0 )
    {
      p_hKey = &v241;
      v121 = sub_1400601C0();
      if ( v121 == nullptr )
        sub_14005FF30(0x80004005);
      v241 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v121 + 24))(v121) + 24);
      if ( (unsigned __int8)sub_14005F980(&v241, (__int64)L"\\") == 0 )
        sub_14005FCF0(&v241, L"\\", 1);
      v226 = &v262;
      v262 = sub_14005F710(v108) + 24;
      v261 = sub_14005F710(v225 - 6) + 24;
      v122 = *(_BYTE **)sub_1400705B0(&v269, &v261, &v262, &v241, phkResultb, lpcbDatab);
      v123 = (volatile signed __int32 *)(v122 - 24);
      if ( v122 - 24 != (_BYTE *)v108 )
      {
        if ( *((int *)v108 + 4) >= 0 && *(_QWORD *)v123 == *(_QWORD *)v108 )
        {
          v124 = sub_14005F710(v123);
          if ( _InterlockedExchangeAdd(v108 + 4, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v108 + 8LL))(*(_QWORD *)v108, v108);
          v222 = (int *)(v124 + 24);
        }
        else
        {
          sub_14005FCF0(&v222, v122, *((_DWORD *)v122 - 4));
        }
      }
      v116 = v269;
      goto LABEL_262;
    }
    p_hKey = &v242;
    v126 = sub_1400601C0();
    if ( v126 == nullptr )
      sub_14005FF30(0x80004005);
    v242 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v126 + 24))(v126) + 24);
    if ( (unsigned __int8)sub_14005F980(&v242, (__int64)L"\\") == 0 )
      sub_14005FCF0(&v242, L"\\", 1);
    v226 = &v260;
    v260 = sub_14005F710(v108) + 24;
    v259 = sub_14005F710(v104 - 6) + 24;
    v127 = (LPCWSTR *)sub_1400705B0(&v270, &v259, &v260, &v242, phkResultb, lpcbDatab);
    v128 = sub_14006FEE0(*v127);
    Type[0] = v128;
    v129 = (_QWORD *)(v270 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v270 - 24 + 16), 0xFFFFFFFF) <= 1 )
    {
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v129 + 8LL))(*v129);
      v128 = Type[0];
    }
    if ( v128 != 0 )
    {
      p_hKey = &v243;
      v130 = sub_1400601C0();
      if ( v130 == nullptr )
        sub_14005FF30(0x80004005);
      v243 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v130 + 24))(v130) + 24);
      if ( (unsigned __int8)sub_14005F980(&v243, (__int64)L"\\") == 0 )
        sub_14005FCF0(&v243, L"\\", 1);
      v226 = &v258;
      v258 = sub_14005F710(v108) + 24;
      v253 = sub_14005F710(v104 - 6) + 24;
      v131 = *(_BYTE **)sub_1400705B0(&v271, &v253, &v258, &v243, phkResultc, lpcbDatac);
      v132 = (volatile signed __int32 *)(v131 - 24);
      if ( v131 - 24 != (_BYTE *)v108 )
      {
        if ( *((int *)v108 + 4) >= 0 && *(_QWORD *)v132 == *(_QWORD *)v108 )
        {
          v133 = sub_14005F710(v132);
          *(_QWORD *)Type = v133;
          if ( _InterlockedExchangeAdd(v108 + 4, 0xFFFFFFFF) <= 1 )
          {
            (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v108 + 8LL))(*(_QWORD *)v108, v108);
            v133 = *(_QWORD *)Type;
          }
          v222 = (int *)(v133 + 24);
        }
        else
        {
          sub_14005FCF0(&v222, v131, *((_DWORD *)v131 - 4));
        }
      }
      v134 = (_QWORD *)(v271 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v271 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v134 + 8LL))(*v134);
      if ( v101 >= v98 )
      {
        v135 = v101 + 1;
        if ( v101 + 1 > v98 )
        {
          if ( v97 != nullptr )
          {
            v136 = v235;
            if ( v235 == 0 )
            {
              v136 = v98 >> 1;
              if ( v135 - v98 > v98 >> 1 )
                v136 = v135 - v98;
            }
            v137 = v136 + v98;
            v98 = v101 + 1;
            if ( v135 < v137 )
              v98 = v137;
            v138 = j__calloc_base(v98, 0x10u);
            v139 = v138;
            if ( v138 == nullptr )
              goto LABEL_473;
            if ( 16 * v101 != 0 )
              memcpy(v138, v97, 16 * v101);
            j__free_base(v97);
            v97 = v139;
            v232 = v139;
          }
          else
          {
            v98 = v101 + 1;
            if ( v235 > v135 )
              v98 = v235;
            v97 = j__calloc_base(v98, 0x10u);
            v232 = v97;
            if ( v97 == nullptr )
              goto LABEL_473;
          }
          v234 = v98;
        }
      }
LABEL_336:
      v154 = (int **)&v97[2 * v101];
      p_hKey = v154;
      *v154 = (int *)(sub_14005F710(v221 - 6) + 24);
      v154[1] = (int *)(sub_14005F710(v222 - 6) + 24);
      v233 = ++v101;
      goto LABEL_337;
    }
    p_hKey = &v244;
    v140 = sub_1400601C0();
    if ( v140 == nullptr )
      sub_14005FF30(0x80004005);
    v244 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v140 + 24))(v140) + 24);
    if ( (unsigned __int8)sub_14005F980(&v244, (__int64)L"\\") == 0 )
      sub_14005FCF0(&v244, L"\\", 1);
    v226 = &v254;
    v254 = sub_14005F710(v108) + 24;
    v255 = sub_14005F710((volatile signed __int32 *)(v236 - 24)) + 24;
    v141 = (LPCWSTR *)sub_1400705B0(&v247, &v255, &v254, &v244, phkResultc, lpcbDatac);
    v142 = sub_14006FEE0(*v141);
    Type[0] = v142;
    v143 = v247 - 6;
    if ( _InterlockedExchangeAdd(v247 - 2, 0xFFFFFFFF) <= 1 )
    {
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v143 + 8LL))(*(_QWORD *)v143);
      v142 = Type[0];
    }
    if ( v142 != 0 )
    {
      p_hKey = (int **)&hKey;
      v144 = sub_1400601C0();
      if ( v144 == nullptr )
        sub_14005FF30(0x80004005);
      hKey = (HKEY)((*(__int64 (__fastcall **)(__int64 *))(*v144 + 24))(v144) + 24);
      if ( (unsigned __int8)sub_14005F980(&hKey, (__int64)L"\\") == 0 )
        sub_14005FCF0((int **)&hKey, L"\\", 1);
      v226 = &v256;
      v256 = sub_14005F710(v108) + 24;
      v257 = sub_14005F710((volatile signed __int32 *)(v236 - 24)) + 24;
      v145 = *(_BYTE **)sub_1400705B0(&v238, &v257, &v256, &hKey, phkResult, lpcbData);
      v146 = (volatile signed __int32 *)(v145 - 24);
      if ( v145 - 24 != (_BYTE *)v108 )
      {
        if ( *((int *)v108 + 4) >= 0 && *(_QWORD *)v146 == *(_QWORD *)v108 )
        {
          v147 = sub_14005F710(v146);
          *(_QWORD *)Type = v147;
          if ( _InterlockedExchangeAdd(v108 + 4, 0xFFFFFFFF) <= 1 )
          {
            (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v108 + 8LL))(*(_QWORD *)v108, v108);
            v147 = *(_QWORD *)Type;
          }
          v222 = (int *)(v147 + 24);
        }
        else
        {
          sub_14005FCF0(&v222, v145, *((_DWORD *)v145 - 4));
        }
      }
      v148 = v238 - 6;
      if ( _InterlockedExchangeAdd(v238 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v148 + 8LL))(*(_QWORD *)v148);
      if ( v101 >= v98 )
      {
        v149 = v101 + 1;
        if ( v101 + 1 > v98 )
        {
          if ( v97 != nullptr )
          {
            v150 = v235;
            if ( v235 == 0 )
            {
              v150 = v98 >> 1;
              if ( v149 - v98 > v98 >> 1 )
                v150 = v149 - v98;
            }
            v151 = v150 + v98;
            v98 = v101 + 1;
            if ( v149 < v151 )
              v98 = v151;
            v152 = j__calloc_base(v98, 0x10u);
            v153 = v152;
            if ( v152 == nullptr )
LABEL_473:
              sub_14005FF30(0x8007000E);
            if ( 16 * v101 != 0 )
              memcpy(v152, v97, 16 * v101);
            j__free_base(v97);
            v97 = v153;
            v232 = v153;
          }
          else
          {
            v98 = v101 + 1;
            if ( v235 > v149 )
              v98 = v235;
            v97 = j__calloc_base(v98, 0x10u);
            v232 = v97;
            if ( v97 == nullptr )
              goto LABEL_473;
          }
          v234 = v98;
        }
      }
      goto LABEL_336;
    }
LABEL_337:
    v155 = v222 - 6;
    if ( _InterlockedExchangeAdd(v222 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v155 + 8LL))(*(_QWORD *)v155);
    v156 = v221 - 6;
    if ( _InterlockedExchangeAdd(v221 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v156 + 8LL))(*(_QWORD *)v156);
    v102 = cbData + 1;
    cbData = v102;
  }
  while ( v102 < 0x1C );
  *(_OWORD *)Block = 0;
  v229 = 0;
  v157 = sub_140161ED0(Block);
  v158 = (volatile signed __int32 *)Block[0];
  if ( v157 != 0 )
  {
    v247 = (volatile signed __int32 *)Block[1];
    if ( Block[0] != Block[1] )
    {
      do
      {
        v159 = (int **)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)v158 - 24LL)) + 24);
        p_hKey = v159;
        v160 = sub_14005F710((volatile signed __int32 *)(*((_QWORD *)v158 + 1) - 24LL)) + 24;
        v231 = v160;
        v273[0] = L"dotPDNLLC.paint.net";
        v273[1] = L"MooiiTech.PhotoScapeX";
        v273[2] = L"Microsoft.MSPaint";
        v161 = 0;
        while ( 1 )
        {
          v162 = v273[v161];
          if ( v162 != 0 && *((int *)v159 - 4) >= 0 )
          {
            v163 = sub_1404A27AC(v159, v162);
            if ( v163 != 0 && (int)((v163 - (__int64)v159) >> 1) >= 0 )
              break;
          }
          if ( (unsigned __int64)++v161 >= 3 )
            goto LABEL_384;
        }
        v164 = sub_1400601C0();
        if ( v164 == nullptr )
          sub_14005FF30(0x80004005);
        v165 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v164 + 24))(v164) + 24);
        v221 = v165;
        v166 = sub_1400601C0();
        if ( v166 == nullptr )
          sub_14005FF30(0x80004005);
        v222 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v166 + 24))(v166) + 24);
        v167 = (volatile signed __int32 *)(v159 - 3);
        v168 = v165 - 6;
        if ( v159 - 3 != (int **)v168 )
        {
          if ( *((int *)v168 + 4) >= 0 && *(_QWORD *)v167 == *(_QWORD *)v168 )
          {
            v169 = sub_14005F710(v167);
            if ( _InterlockedExchangeAdd(v168 + 4, 0xFFFFFFFF) <= 1 )
              (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v168 + 8LL))(
                *(_QWORD *)v168,
                v168);
            v221 = (int *)(v169 + 24);
          }
          else
          {
            sub_14005FCF0(&v221, v159, *((_DWORD *)v159 - 4));
          }
        }
        v170 = sub_140060B30(&v238, &v231, &unk_140636E00);
        sub_14006AFD0(&hKey, v170, &p_hKey);
        v171 = v238 - 6;
        if ( _InterlockedExchangeAdd(v238 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v171 + 8LL))(*(_QWORD *)v171);
        v172 = hKey;
        v173 = hKey - 6;
        v174 = v222 - 6;
        if ( hKey - 6 != (HKEY)(v222 - 6) )
        {
          if ( v174[4] >= 0 && *(_QWORD *)v173 == *(_QWORD *)v174 )
          {
            v175 = sub_14005F710((volatile signed __int32 *)v173);
            if ( _InterlockedExchangeAdd(v174 + 4, 0xFFFFFFFF) <= 1 )
              (*(void (__fastcall **)(_QWORD, int *))(**(_QWORD **)v174 + 8LL))(*(_QWORD *)v174, v174);
            v222 = (int *)(v175 + 24);
          }
          else
          {
            sub_14005FCF0(&v222, hKey, *((_DWORD *)hKey - 4));
          }
          v172 = hKey;
        }
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)v172 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v172 - 3) + 8LL))(*((_QWORD *)v172 - 3));
        for ( k = 0; k != 16; k += 2 )
        {
          v177 = *((unsigned __int16 *)v159 + k) - aMicrosoftPaint[k];
          if ( v177 != 0 )
            break;
          v177 = *((unsigned __int16 *)v159 + k + 1) - aMicrosoftPaint[k + 1];
          if ( v177 != 0 )
            break;
        }
        if ( v177 == 0 )
        {
          v178 = sub_1401C5640(k);
          v179 = sub_1401C81E0(v178, L"MENU_MSPAINT_NAME", L"IDD_SETTING_ETC");
          v180 = (_BYTE *)v179;
          if ( v179 != 0 )
            LODWORD(v179) = sub_1404ADC20(v179);
          sub_14005FCF0(&v221, v180, v179);
        }
        sub_140124B30(&v232, &v221);
        v181 = v222 - 6;
        if ( _InterlockedExchangeAdd(v222 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v181 + 8LL))(*(_QWORD *)v181);
        v182 = v221 - 6;
        if ( _InterlockedExchangeAdd(v221 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v182 + 8LL))(*(_QWORD *)v182);
LABEL_384:
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v160 - 24 + 16), 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v160 - 24) + 8LL))(*(_QWORD *)(v160 - 24));
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)v159 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*(v159 - 3) + 8LL))(*(v159 - 3));
        v158 += 4;
      }
      while ( v158 != v247 );
      v101 = v233;
      v97 = v232;
      v158 = (volatile signed __int32 *)Block[0];
    }
  }
  if ( v101 == 0 )
  {
    if ( v158 != nullptr )
    {
      v183 = (volatile signed __int32 *)Block[1];
      if ( v158 != Block[1] )
      {
        do
        {
          v184 = (volatile signed __int32 *)(*((_QWORD *)v158 + 1) - 24LL);
          if ( _InterlockedExchangeAdd(v184 + 4, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v184 + 8LL))(*(_QWORD *)v184);
          v185 = (volatile signed __int32 *)(*(_QWORD *)v158 - 24LL);
          if ( _InterlockedExchangeAdd(v185 + 4, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v185 + 8LL))(*(_QWORD *)v185);
          v158 += 4;
        }
        while ( v158 != v183 );
        v158 = (volatile signed __int32 *)Block[0];
      }
      if ( ((v229 - (_QWORD)v158) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 )
      {
        if ( (unsigned __int64)v158 - *((_QWORD *)v158 - 1) - 8 <= 0x1F )
        {
          v158 = *((volatile signed __int32 **)v158 - 1);
          goto LABEL_402;
        }
LABEL_471:
        __fastfail(5u);
      }
LABEL_402:
      j_j_j__free_base((void *)v158);
      *(_OWORD *)Block = 0;
      v229 = 0;
    }
    if ( _InterlockedExchangeAdd(v104 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v104 - 3) + 8LL))(*((_QWORD *)v104 - 3));
    v186 = (_QWORD *)(v236 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v236 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v186 + 8LL))(*v186);
    v187 = v225 - 6;
    if ( _InterlockedExchangeAdd(v225 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v187 + 8LL))(*(_QWORD *)v187);
    v188 = (_QWORD *)v227;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v227 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v188 + 8LL))(*v188);
    if ( v97 != nullptr )
LABEL_412:
      j__free_base(v97);
    goto LABEL_413;
  }
  v189 = 0;
  v190 = hMenu;
  if ( (int)v101 > 0 )
  {
    while ( v189 < v101 )
    {
      InsertMenuW(v190, v189, 0, v189 + 100LL, (LPCWSTR)v97[2 * v189]);
      if ( ++v189 >= (int)v101 )
        goto LABEL_417;
    }
    goto LABEL_544;
  }
LABEL_417:
  v191 = v272;
  v192 = TrackPopupMenu(v190, 0x108u, Point[1].x, Point[1].y, 0, *(HWND *)(v272 + 8), nullptr);
  if ( v192 <= 0 )
  {
    v193 = Block[0];
    if ( Block[0] != nullptr )
    {
      v194 = Block[1];
      if ( Block[0] != Block[1] )
      {
        do
        {
          v195 = (volatile signed __int32 *)(v193[1] - 24LL);
          if ( _InterlockedExchangeAdd(v195 + 4, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v195 + 8LL))(*(_QWORD *)v195);
          v196 = (volatile signed __int32 *)(*v193 - 24LL);
          if ( _InterlockedExchangeAdd(v196 + 4, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v196 + 8LL))(*(_QWORD *)v196);
          v193 += 2;
        }
        while ( v193 != v194 );
        v193 = Block[0];
      }
      if ( ((v229 - (_QWORD)v193) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 )
      {
        if ( (unsigned __int64)v193 - *(v193 - 1) - 8 > 0x1F )
          goto LABEL_471;
        v193 = (_QWORD *)*(v193 - 1);
      }
      j_j_j__free_base(v193);
      *(_OWORD *)Block = 0;
      v229 = 0;
    }
    if ( _InterlockedExchangeAdd(v104 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v104 - 3) + 8LL))(*((_QWORD *)v104 - 3));
    v197 = (_QWORD *)(v236 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v236 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v197 + 8LL))(*v197);
    v198 = v225 - 6;
    if ( _InterlockedExchangeAdd(v225 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v198 + 8LL))(*(_QWORD *)v198);
    v199 = (_QWORD *)v227;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v227 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v199 + 8LL))(*v199);
    if ( v97 != nullptr )
    {
      for ( m = 0; m < v101; ++m )
      {
        v201 = (volatile signed __int32 *)(v97[2 * m + 1] - 24LL);
        if ( _InterlockedExchangeAdd(v201 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v201 + 8LL))(*(_QWORD *)v201);
        v202 = (volatile signed __int32 *)(v97[2 * m] - 24LL);
        if ( _InterlockedExchangeAdd(v202 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v202 + 8LL))(*(_QWORD *)v202);
      }
      goto LABEL_412;
    }
    goto LABEL_413;
  }
  v203 = v192 - 100LL;
  if ( v203 >= v101 )
LABEL_544:
    sub_14005FF30(0x80070057);
  p_hKey = (int **)&hMenu;
  hMenu = (HMENU)(sub_14005F710((volatile signed __int32 *)(v97[2 * v203 + 1] - 24LL)) + 24);
  v226 = (__int64 *)&hKey;
  v204 = sub_1400601C0();
  if ( v204 == nullptr )
    sub_14005FF30(0x80004005);
  hKey = (HKEY)((*(__int64 (__fastcall **)(__int64 *))(*v204 + 24))(v204) + 24);
  if ( (unsigned __int8)sub_14005F980(&hKey, (__int64)L"IDC_EDIT_EXTPROG0") == 0 )
    sub_14005FCF0((int **)&hKey, L"IDC_EDIT_EXTPROG0", 17);
  sub_1401C5020(v191 + 728, &hKey, &hMenu);
  if ( Block[0] != nullptr )
  {
    sub_140124DA0(Block[0], Block[1]);
    v205 = Block[0];
    if ( ((v229 - (unsigned __int64)Block[0]) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 )
    {
      if ( (unsigned __int64)Block[0] - *((_QWORD *)Block[0] - 1) - 8 > 0x1F )
        goto LABEL_471;
      v205 = *((void **)Block[0] - 1);
    }
    j_j_j__free_base(v205);
    *(_OWORD *)Block = 0;
    v229 = 0;
  }
  if ( _InterlockedExchangeAdd(v104 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v104 - 3) + 8LL))(*((_QWORD *)v104 - 3));
  v206 = (_QWORD *)(v236 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v236 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v206 + 8LL))(*v206);
  v207 = v225 - 6;
  if ( _InterlockedExchangeAdd(v225 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v207 + 8LL))(*(_QWORD *)v207);
  v208 = (_QWORD *)v227;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v227 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v208 + 8LL))(*v208);
  if ( v97 != nullptr )
  {
    for ( n = 0; n < v101; ++n )
    {
      v210 = (volatile signed __int32 *)(v97[2 * n + 1] - 24LL);
      if ( _InterlockedExchangeAdd(v210 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v210 + 8LL))(*(_QWORD *)v210);
      v211 = (volatile signed __int32 *)(v97[2 * n] - 24LL);
      if ( _InterlockedExchangeAdd(v211 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v211 + 8LL))(*(_QWORD *)v211);
    }
    goto LABEL_412;
  }
LABEL_413:
  `eh vector destructor iterator'(&v275, 0x10u, 0x1Cu, sub_140093C80);
  v61 = *v246;
LABEL_171:
  v62 = (volatile signed __int32 *)(v61 - 24);
  if ( _InterlockedExchangeAdd(v62 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v62 + 8LL))(*(_QWORD *)v62);
}
