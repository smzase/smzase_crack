// EA 0x14005eb50  name sub_14005EB50  size 34
__int64 sub_14005EB50(__int64 a1, __int64 a2, ...)
{
  va_list va; // [rsp+40h] [rbp+18h] BYREF

  va_start(va, a2);
  return sub_14005EB80(a1, a2, (__int64 *)va);
}
