// EA 0x14006ac90  name sub_14006AC90  size 251
__int64 __fastcall sub_14006AC90(__int64 a1)
{
  __int64 result; // rax
  char v3; // di
  int v4; // edx
  int v5; // edx
  char v6; // si
  _QWORD *v7; // rdx
  signed __int32 v8; // eax
  bool v9; // cc
  _QWORD *v10; // rdx
  __int64 v11; // [rsp+50h] [rbp+18h] BYREF
  __int64 v12; // [rsp+58h] [rbp+20h] BYREF

  result = sub_14006B260(a1, &v12, 1);
  v3 = 1;
  v4 = **(unsigned __int16 **)result - 92;
  if ( **(_WORD **)result == 92 )
  {
    v4 = *(unsigned __int16 *)(*(_QWORD *)result + 2LL);
    result = 0;
  }
  if ( v4 == 0 )
    goto LABEL_8;
  result = sub_14006B260(a1, &v11, 1);
  v3 = 3;
  v5 = **(unsigned __int16 **)result - 47;
  if ( **(_WORD **)result == 47 )
  {
    v5 = *(unsigned __int16 *)(*(_QWORD *)result + 2LL);
    result = 0;
  }
  if ( v5 != 0 )
    v6 = 1;
  else
LABEL_8:
    v6 = 0;
  if ( (v3 & 2) != 0 )
  {
    v3 &= ~2u;
    v7 = (_QWORD *)(v11 - 24);
    v8 = _InterlockedExchangeAdd((volatile signed __int32 *)(v11 - 24 + 16), 0xFFFFFFFF);
    v9 = v8 <= 1;
    result = (unsigned int)(v8 - 1);
    if ( v9 )
      result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v7 + 8LL))(*v7);
  }
  if ( (v3 & 1) != 0 )
  {
    v10 = (_QWORD *)(v12 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v12 - 24 + 16), 0xFFFFFFFF) <= 1 )
      result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v10 + 8LL))(*v10);
  }
  if ( v6 != 0 )
    return sub_140069690(a1, L"\\", 1);
  return result;
}
