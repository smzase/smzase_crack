// EA 0x14006e550  name sub_14006E550  size 837
__int64 sub_14006E550()
{
  __int64 result; // rax
  HMODULE ModuleHandleW; // rax
  FARPROC ProcAddress; // rax
  _QWORD v3[36]; // [rsp+20h] [rbp-138h] BYREF

  result = (unsigned int)dword_140709A74;
  if ( dword_140709A74 == 0 )
  {
    dword_140709A74 = 19;
    v3[0] = 284;
    memset(&v3[1], 0, 0x114u);
    ModuleHandleW = GetModuleHandleW(L"ntdll.dll");
    if ( ModuleHandleW == nullptr )
      return (unsigned int)dword_140709A74;
    ProcAddress = GetProcAddress(ModuleHandleW, "RtlGetVersion");
    if ( ProcAddress == nullptr || ((unsigned int (__fastcall *)(_QWORD *))ProcAddress)(v3) != 0 || LODWORD(v3[2]) != 2 )
      return (unsigned int)dword_140709A74;
    switch ( HIDWORD(v3[0]) )
    {
      case 5:
        result = 1;
        dword_140709A74 = 1;
        if ( LODWORD(v3[1]) == 1 )
        {
          result = 2;
          dword_140709A74 = 2;
          switch ( WORD2(v3[34]) )
          {
            case 1:
              dword_140709A74 = 3;
              return 3;
            case 2:
              dword_140709A74 = 4;
              return 4;
            case 3:
              dword_140709A74 = 5;
              return 5;
            default:
              break;
          }
        }
        else if ( LODWORD(v3[1]) == 2 )
        {
          dword_140709A74 = 6;
          return 6;
        }
        break;
      case 6:
        if ( LODWORD(v3[1]) != 0 )
        {
          if ( LODWORD(v3[1]) != 1 )
          {
            if ( LODWORD(v3[1]) == 2 )
            {
              dword_140709A74 = 14;
              return 14;
            }
            if ( LODWORD(v3[1]) == 3 )
            {
              dword_140709A74 = (BYTE2(v3[35]) != 1) + 15;
              return (unsigned int)(BYTE2(v3[35]) != 1) + 15;
            }
            return (unsigned int)dword_140709A74;
          }
          if ( BYTE2(v3[35]) == 1 )
          {
            result = 11;
            dword_140709A74 = 11;
            if ( WORD2(v3[34]) == 1 )
            {
              dword_140709A74 = 12;
              return 12;
            }
          }
          else
          {
            dword_140709A74 = 13;
            return 13;
          }
        }
        else
        {
          result = 7;
          dword_140709A74 = 7;
          if ( BYTE2(v3[35]) == 1 )
          {
            if ( WORD2(v3[34]) == 1 )
            {
              dword_140709A74 = 8;
              return 8;
            }
            else if ( WORD2(v3[34]) == 2 )
            {
              dword_140709A74 = 9;
              return 9;
            }
          }
          else
          {
            dword_140709A74 = 10;
            return 10;
          }
        }
        break;
      case 0xA:
        result = 17;
        dword_140709A74 = 17;
        if ( HIDWORD(v3[1]) >= 0x55F0 )
        {
          dword_140709A74 = 18;
          return 18;
        }
        return result;
      default:
        return (unsigned int)dword_140709A74;
    }
  }
  return result;
}
