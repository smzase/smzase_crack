// EA 0x1404bd930  name j__calloc_base  size 5
// attributes: thunk
void *__cdecl j__calloc_base(size_t Count, size_t Size)
{
  return calloc_base(Count, Size);
}
