// EA 0x140134d40  name sub_140134D40  size 1323
__int64 __fastcall sub_140134D40(__int64 a1, __int64 a2, int a3, __int64 a4, int *nNumber, __int64 *a6, int a7)
{
  __int64 v10; // rbx
  __int64 v11; // rax
  __int64 v13; // rbx
  __int64 v14; // rax
  __int64 v15; // rbx
  __int64 v16; // rcx
  __int64 *v17; // rax
  __int64 *v18; // rax
  __int64 *v19; // rax
  __int64 v20; // rcx
  __int64 *v21; // rax
  unsigned int v22; // eax
  int *v23; // rbx
  __int64 *v24; // rax
  __int64 v25; // rcx
  int *v26; // [rsp+40h] [rbp-30h] BYREF
  int *v27; // [rsp+48h] [rbp-28h] BYREF
  int **v28; // [rsp+50h] [rbp-20h] BYREF
  int **v29; // [rsp+58h] [rbp-18h]
  int **v30; // [rsp+60h] [rbp-10h]

  if ( a7 != 0 )
    return 0;
  if ( a3 == 794 || a3 == 26 )
    sub_1401D4990(*(_QWORD *)(a1 + 8));
  switch ( a3 )
  {
    case 1:
      v10 = *(_QWORD *)(a1 + 8);
      v11 = sub_1401D4680();
      sub_1401D47B0(v11, v10);
      goto LABEL_7;
    case 272:
      v13 = *(_QWORD *)(a1 + 8);
      v14 = sub_1401D4680();
      sub_1401D47B0(v14, v13);
      *a6 = sub_140135390((_QWORD *)a1);
      return 1;
    case 16:
      v15 = *(_QWORD *)(a1 + 8);
      sub_1401D4680();
      sub_1401D48F0(v16, v15);
      goto LABEL_7;
    case 273:
      if ( (_WORD)a4 == 1 )
      {
        if ( WORD1(a4) == 0 )
        {
          v28 = &v26;
          v17 = sub_1400601C0();
          if ( v17 == nullptr )
            sub_14005FF30(0x80004005);
          v26 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v17 + 24))(v17) + 24);
          if ( (unsigned __int8)sub_14005F980(&v26, (__int64)L"IDOK") == 0 )
            sub_14005FCF0(&v26, L"IDOK", 4);
          sub_1401C4F90(a1 + 336, &v26, 0);
          v28 = &v26;
          v18 = sub_1400601C0();
          if ( v18 == nullptr )
            sub_14005FF30(0x80004005);
          v26 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v18 + 24))(v18) + 24);
          if ( (unsigned __int8)sub_14005F980(&v26, (__int64)L"0%") == 0 )
            sub_14005FCF0(&v26, L"0%", 2);
          v29 = &v27;
          v19 = sub_1400601C0();
          if ( v19 == nullptr )
            sub_14005FF30(0x80004005);
          v27 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v19 + 24))(v19) + 24);
          if ( (unsigned __int8)sub_14005F980(&v27, (__int64)L"IDOK") == 0 )
            sub_14005FCF0(&v27, L"IDOK", 4);
          sub_1401C5020(a1 + 336, &v27, &v26);
          sub_140135A20(a1);
          *a6 = 0;
          return 1;
        }
      }
      else
      {
        a2 = 2;
        if ( (_DWORD)a4 == 2 )
        {
          EndDialog(*(HWND *)(a1 + 8), 2);
          *a6 = 0;
          return 1;
        }
      }
LABEL_7:
      if ( a3 == dword_140709A8C )
      {
        if ( *(_BYTE *)(a1 + 328) != 0 )
        {
          *(_DWORD *)(a1 + 332) = (_DWORD)nNumber;
          *a6 = 0;
          return 1;
        }
        goto LABEL_52;
      }
      if ( a3 == dword_140709A90 )
      {
        if ( *(_BYTE *)(a1 + 328) != 0 && *(int *)(a1 + 332) >= 0 )
        {
          v21 = sub_1400601C0();
          if ( v21 == nullptr )
            sub_14005FF30(0x80004005);
          v26 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v21 + 24))(v21) + 24);
          v22 = MulDiv((int)nNumber, 100, *(_DWORD *)(a1 + 332));
          sub_14005EB50((__int64)&v26, (__int64)L"%d %%", v22);
          v29 = (int **)&v28;
          v23 = v26;
          v28 = (int **)(sub_14005F710(v26 - 6) + 24);
          v30 = &v27;
          v24 = sub_1400601C0();
          if ( v24 == nullptr )
            sub_14005FF30(0x80004005);
          v27 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v24 + 24))(v24) + 24);
          if ( (unsigned __int8)sub_14005F980(&v27, (__int64)L"IDOK") == 0 )
            sub_14005FCF0(&v27, L"IDOK", 4);
          sub_1401C5020(a1 + 336, &v27, &v28);
          if ( _InterlockedExchangeAdd(v23 - 2, 0xFFFFFFFF) <= 1 )
          {
            (*(void (__fastcall **)(_QWORD, int *))(**((_QWORD **)v23 - 3) + 8LL))(*((_QWORD *)v23 - 3), v23 - 6);
            *a6 = 0;
            return 1;
          }
        }
        goto LABEL_52;
      }
      if ( a3 == dword_140709A84 )
      {
        *a6 = sub_140136230(a1, a2, a4, nNumber);
        return 1;
      }
      if ( a3 == 3 )
      {
        v25 = *(_QWORD *)(a1 + 2352);
        if ( v25 != 0 )
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v25 + 56LL))(v25);
        goto LABEL_52;
      }
      return 0;
    case 2:
      if ( *(_QWORD *)(a1 + 2336) == 0 )
      {
LABEL_52:
        *a6 = 0;
        return 1;
      }
      v20 = *(_QWORD *)(a1 + 2352);
      if ( v20 != 0 )
      {
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v20 + 16LL))(v20);
        *(_QWORD *)(a1 + 2352) = 0;
      }
      FreeLibrary(*(HMODULE *)(a1 + 2336));
      *(_QWORD *)(a1 + 2336) = 0;
      *a6 = 0;
      return 1;
    case 736:
      if ( nNumber != nullptr )
        SetWindowPos(
          *(HWND *)(a1 + 8),
          nullptr,
          *nNumber,
          nNumber[1],
          nNumber[2] - *nNumber,
          nNumber[3] - nNumber[1],
          0x14u);
      sub_1401DBEF0(a1 + 336, WORD1(a4));
      *a6 = 0;
      return 1;
    default:
      goto LABEL_7;
  }
}
