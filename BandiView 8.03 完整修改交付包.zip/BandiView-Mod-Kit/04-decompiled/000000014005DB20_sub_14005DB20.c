// EA 0x14005db20  name sub_14005DB20  size 1093
__int64 __fastcall sub_14005DB20(__int64 a1)
{
  void *v2; // rax
  __int64 v3; // rax
  __int64 v4; // rax
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int128 *v8; // rbx
  __int64 v9; // rax
  unsigned int v10; // eax
  __int64 v11; // rdx
  __int64 v12; // rcx
  __int64 v13; // r8
  __int128 *v14; // rbx
  __int64 v15; // rax
  unsigned int v16; // eax
  __int64 v17; // rdx
  __int64 v18; // rcx
  __int64 v19; // r8
  __int64 v20; // rax
  _QWORD *v21; // rax
  __int64 v22; // rcx
  __int64 v23; // r8
  _QWORD *v24; // rdx
  __int64 v25; // rax
  const WCHAR *v26; // rbx
  __int64 v27; // r8
  __int64 v28; // rcx
  __int64 v30; // [rsp+20h] [rbp-89h] BYREF
  __int64 *v31; // [rsp+28h] [rbp-81h] BYREF
  LPCWSTR lpText; // [rsp+30h] [rbp-79h] BYREF
  __int128 v33; // [rsp+38h] [rbp-71h]
  __int128 Src; // [rsp+48h] [rbp-61h] BYREF
  __int128 v35; // [rsp+58h] [rbp-51h]
  __int64 *v36; // [rsp+68h] [rbp-41h]
  char *v37[4]; // [rsp+70h] [rbp-39h] BYREF
  __int64 v38; // [rsp+90h] [rbp-19h] BYREF
  __m128i si128; // [rsp+98h] [rbp-11h]
  char v40; // [rsp+A8h] [rbp-1h]
  __int16 v41; // [rsp+A9h] [rbp+0h]
  char v42; // [rsp+ABh] [rbp+2h]
  HGDIOBJ StockObject; // [rsp+B0h] [rbp+7h]
  int v44; // [rsp+B8h] [rbp+Fh]
  char v45; // [rsp+BCh] [rbp+13h]
  __int128 v46; // [rsp+C0h] [rbp+17h] BYREF
  __int128 v47; // [rsp+D0h] [rbp+27h]

  v2 = (void *)sub_140069AD0(v37);
  v3 = sub_14005ED20(v2);
  Src = 0;
  v35 = 0;
  Src = *(_OWORD *)v3;
  v35 = *(_OWORD *)(v3 + 16);
  *(_QWORD *)(v3 + 16) = 0;
  *(_QWORD *)(v3 + 24) = 7;
  *(_WORD *)v3 = 0;
  v4 = sub_14005ED20(&Src);
  v46 = 0;
  v47 = 0;
  v46 = *(_OWORD *)v4;
  v47 = *(_OWORD *)(v4 + 16);
  *(_QWORD *)(v4 + 16) = 0;
  *(_QWORD *)(v4 + 24) = 7;
  *(_WORD *)v4 = 0;
  sub_14005D410((char **)&Src);
  sub_14005D410(v37);
  v41 = 0;
  v42 = 0;
  StockObject = nullptr;
  v44 = 257;
  v45 = 0;
  v38 = *(_QWORD *)(a1 + 8);
  si128 = _mm_load_si128((const __m128i *)&xmmword_140663300);
  v40 = 1;
  StockObject = GetStockObject(0);
  *(_WORD *)((char *)&v44 + 1) = 257;
  if ( *(_BYTE *)(a1 + 2336) != 0 )
    goto LABEL_29;
  v31 = &v30;
  v8 = &v46;
  if ( *((_QWORD *)&v47 + 1) > 7u )
    v8 = (__int128 *)v46;
  v9 = sub_1400601C0(v6, v5, v7);
  if ( v9 == 0 )
    sub_14005FF30(2147500037LL);
  v30 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v9 + 24LL))(v9) + 24;
  if ( (unsigned __int8)sub_14005F980(&v30, v8) == 0 )
  {
    if ( v8 != nullptr )
      v10 = sub_1404ADC20(v8);
    else
      v10 = 0;
    sub_14005FCF0(&v30, v8, v10);
  }
  if ( (unsigned __int8)sub_14006B800(&v30) == 0 )
  {
LABEL_29:
    v33 = 0;
    sub_14006CBF0((HANDLE)(a1 + 2096));
    v28 = *(_QWORD *)(a1 + 2128);
    if ( v28 != 0 )
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v28 + 480LL))(v28, 1);
    *(_DWORD *)(a1 + 2304) = 1;
    *(_BYTE *)(a1 + 2308) = 1;
    *(_DWORD *)(a1 + 2276) = 0x40000000;
  }
  else
  {
    v31 = &v30;
    v14 = &v46;
    if ( *((_QWORD *)&v47 + 1) > 7u )
      v14 = (__int128 *)v46;
    v15 = sub_1400601C0(v12, v11, v13);
    if ( v15 == 0 )
      sub_14005FF30(2147500037LL);
    v30 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v15 + 24LL))(v15) + 24;
    if ( (unsigned __int8)sub_14005F980(&v30, v14) == 0 )
    {
      if ( v14 != nullptr )
        v16 = sub_1404ADC20(v14);
      else
        v16 = 0;
      sub_14005FCF0(&v30, v14, v16);
    }
    if ( (unsigned __int8)sub_14006B990(a1 + 2048, &v30, &v38, a1 + 72) != 0 )
    {
      *(_BYTE *)(a1 + 2088) = 1;
    }
    else
    {
      v31 = *(__int64 **)(a1 + 2056);
      v20 = sub_1400601C0(v18, v17, v19);
      if ( v20 == 0 )
        sub_14005FF30(2147500037LL);
      lpText = (LPCWSTR)((*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v20 + 24LL))(v20) + 24);
      v21 = (_QWORD *)sub_1401C0850(&v30, &v31);
      sub_14005EB50(&lpText, L"Error: Failed to initialize WebView2. [%s]", *v21);
      v24 = (_QWORD *)(v30 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v30 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v24 + 8LL))(*v24);
      v36 = &v30;
      v25 = sub_1400601C0(v22, v24, v23);
      if ( v25 == 0 )
        sub_14005FF30(2147500037LL);
      v30 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v25 + 24LL))(v25) + 24;
      if ( (unsigned __int8)sub_14005F980(&v30, L"error") == 0 )
        sub_14005FCF0(&v30, L"error", 5);
      v26 = lpText;
      v31 = (__int64 *)(sub_14005F710(lpText - 12) + 24);
      LOBYTE(v27) = 1;
      sub_140074840(&v31, &v30, v27);
      MessageBoxW(*(HWND *)(a1 + 8), v26, &Data, 0);
      PostMessageW(*(HWND *)(a1 + 8), 0x10u, 0, 0);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)v26 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD, const WCHAR *))(**((_QWORD **)v26 - 3) + 8LL))(*((_QWORD *)v26 - 3), v26 - 12);
    }
  }
  return sub_14005D410((char **)&v46);
}
