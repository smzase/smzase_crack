// EA 0x1400b2890  name sub_1400B2890  size 475
__int64 __fastcall sub_1400B2890(__int64 a1, _QWORD *a2)
{
  __int64 v4; // rbx
  __int64 v5; // rdi
  __int64 *v6; // rsi
  __int64 v7; // r14
  __int64 result; // rax
  volatile signed __int32 *v9; // rdx
  volatile signed __int32 *v10; // rbx
  volatile signed __int32 *v11; // rbp
  __int64 v12; // r15
  __int64 v13; // rbx
  int v14; // eax
  __int64 v15; // rcx
  __int64 v16; // rdx
  __int64 v17; // [rsp+90h] [rbp+18h] BYREF

  v4 = 0;
  v5 = *a2;
  v6 = qword_140709E40;
  while ( 1 )
  {
    if ( v5 == 0 )
      sub_14005FF30(0x80004005);
    v7 = 3 * v4;
    result = sub_1404D8590(qword_140709E40[3 * v4], v5);
    if ( (_DWORD)result == 0 )
      break;
    v4 = (unsigned int)(v4 + 1);
    if ( (int)v4 >= 21 )
    {
      v9 = (volatile signed __int32 *)(v5 - 24);
      goto LABEL_6;
    }
  }
  do
  {
    v10 = (volatile signed __int32 *)sub_14005F710((volatile signed __int32 *)(*v6 - 24));
    v11 = v10 + 6;
    v12 = sub_14005F710((volatile signed __int32 *)(v6[1] - 24)) + 24;
    v17 = sub_14005F710(v10) + 24;
    v13 = sub_1401BE5D0(a1 + 728, &v17);
    if ( *a2 == 0 )
      sub_14005FF30(0x80004005);
    v14 = sub_1404D8590(v11, *a2);
    v15 = *(_QWORD *)(v13 + 1048);
    if ( v14 != 0 )
    {
      if ( *(_DWORD *)(v15 - 16) != 0 )
        sub_1401F6750(v13);
      v16 = 0;
    }
    else
    {
      if ( *(_DWORD *)(v15 - 16) != 0 )
        sub_1401F6750(v13);
      v16 = 1;
    }
    sub_1401D8460(v13, v16);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v12 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v12 - 24) + 8LL))(*(_QWORD *)(v12 - 24));
    if ( _InterlockedExchangeAdd(v11 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v11 - 3) + 8LL))(*((_QWORD *)v11 - 3));
    v6 += 3;
  }
  while ( v6 != (__int64 *)&unk_14070A038 );
  *(_DWORD *)(a1 + 608) = qword_140709E40[v7 + 2];
  sub_1400B24E0(a1);
  result = sub_1400B2450(a1);
  v9 = (volatile signed __int32 *)(*a2 - 24LL);
LABEL_6:
  if ( _InterlockedExchangeAdd(v9 + 4, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v9 + 8LL))(*(_QWORD *)v9);
  return result;
}
