// EA 0x1401d0a80  name sub_1401D0A80  size 210
__int64 __fastcall sub_1401D0A80(__int64 a1, const WCHAR *a2)
{
  unsigned __int8 v4; // bl
  void **v6; // [rsp+20h] [rbp-48h] BYREF
  HANDLE hObject; // [rsp+28h] [rbp-40h]
  void *Block; // [rsp+30h] [rbp-38h]
  void *v9; // [rsp+38h] [rbp-30h]
  void *v10; // [rsp+40h] [rbp-28h]
  __int64 v11; // [rsp+48h] [rbp-20h]
  __int16 v12; // [rsp+50h] [rbp-18h]
  int v13; // [rsp+54h] [rbp-14h]

  sub_1401D0940(a1);
  v6 = &XFileReadStream::`vftable';
  v13 = 0;
  Block = j__malloc_base(0x2000u);
  v10 = Block;
  v9 = Block;
  v11 = 0;
  hObject = (HANDLE)-1LL;
  v12 = 0;
  if ( *((_QWORD *)a2 + 3) > 7u )
    a2 = *(const WCHAR **)a2;
  if ( sub_1401CC050((__int64)&v6, a2) != 0 )
    v4 = sub_1401D0B60(a1, &v6);
  else
    v4 = 0;
  v6 = &XFileReadStream::`vftable';
  if ( HIBYTE(v12) != 0 && hObject != (HANDLE)-1LL )
  {
    CloseHandle(hObject);
    hObject = (HANDLE)-1LL;
  }
  j__free_base(Block);
  return v4;
}
