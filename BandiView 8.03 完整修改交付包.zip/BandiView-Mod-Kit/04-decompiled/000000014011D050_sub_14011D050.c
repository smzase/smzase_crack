// EA 0x14011d050  name sub_14011D050  size 914
__int16 *__fastcall sub_14011D050(__int64 a1)
{
  __int64 *v2; // rax
  bool v3; // bl
  __int64 *v4; // rax
  bool v5; // bl
  __int64 *v6; // rax
  bool v7; // bl
  __int64 *v8; // rax
  bool v9; // bl
  __int64 *v10; // rax
  bool v11; // bl
  int v12; // ebx
  int v13; // ebx
  __int64 *v14; // rax
  bool v15; // bl
  __int64 *v16; // rax
  bool v17; // bl
  __int16 *result; // rax
  int *v19; // [rsp+38h] [rbp+18h] BYREF
  int **v20; // [rsp+40h] [rbp+20h]

  v20 = &v19;
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  v19 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  if ( (unsigned __int8)sub_14005F980(&v19, (__int64)L"CHK_ESC_TO_EXIT") == 0 )
    sub_14005FCF0(&v19, L"CHK_ESC_TO_EXIT", 15);
  v3 = sub_1400ACB10(a1, &v19);
  *((_BYTE *)sub_140075FE0() + 164) = v3;
  v20 = &v19;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v19 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( (unsigned __int8)sub_14005F980(&v19, (__int64)L"CHK_ONE_INSTANCE") == 0 )
    sub_14005FCF0(&v19, L"CHK_ONE_INSTANCE", 16);
  v5 = sub_1400ACB10(a1, &v19);
  *((_BYTE *)sub_140075FE0() + 165) = v5;
  v20 = &v19;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  v19 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  if ( (unsigned __int8)sub_14005F980(&v19, (__int64)L"CHK_ASK_DELETE") == 0 )
    sub_14005FCF0(&v19, L"CHK_ASK_DELETE", 14);
  v7 = sub_1400ACB10(a1, &v19);
  *((_BYTE *)sub_140075FE0() + 166) = v7;
  v20 = &v19;
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  v19 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24);
  if ( (unsigned __int8)sub_14005F980(&v19, (__int64)L"CHK_ALWAYS_ON_TOP") == 0 )
    sub_14005FCF0(&v19, L"CHK_ALWAYS_ON_TOP", 17);
  v9 = sub_1400ACB10(a1, &v19);
  *((_BYTE *)sub_140075FE0() + 167) = v9;
  v20 = &v19;
  v10 = sub_1400601C0();
  if ( v10 == nullptr )
    sub_14005FF30(0x80004005);
  v19 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24);
  if ( (unsigned __int8)sub_14005F980(&v19, (__int64)L"CHK_USESNAP") == 0 )
    sub_14005FCF0(&v19, L"CHK_USESNAP", 11);
  v11 = sub_1400ACB10(a1, &v19);
  *((_BYTE *)sub_140075FE0() + 168) = v11;
  v12 = *(_DWORD *)(*(_QWORD *)(a1 + 632) + 1076LL);
  *((_DWORD *)sub_140075FE0() + 43) = v12;
  v13 = *(_DWORD *)(*(_QWORD *)(a1 + 640) + 1076LL);
  *((_DWORD *)sub_140075FE0() + 44) = v13;
  v20 = &v19;
  v14 = sub_1400601C0();
  if ( v14 == nullptr )
    sub_14005FF30(0x80004005);
  v19 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
  if ( (unsigned __int8)sub_14005F980(&v19, (__int64)L"CHK_UPDATE_0") == 0 )
    sub_14005FCF0(&v19, L"CHK_UPDATE_0", 12);
  v15 = sub_1400ACB10(a1, &v19);
  *((_BYTE *)sub_140075FE0() + 180) = v15;
  v20 = &v19;
  v16 = sub_1400601C0();
  if ( v16 == nullptr )
    sub_14005FF30(0x80004005);
  v19 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v16 + 24))(v16) + 24);
  if ( (unsigned __int8)sub_14005F980(&v19, (__int64)L"CHK_UPDATE_1") == 0 )
    sub_14005FCF0(&v19, L"CHK_UPDATE_1", 12);
  v17 = sub_1400ACB10(a1, &v19);
  result = sub_140075FE0();
  *((_BYTE *)result + 181) = v17;
  return result;
}
