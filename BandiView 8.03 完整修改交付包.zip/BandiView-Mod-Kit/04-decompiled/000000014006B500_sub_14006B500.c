// EA 0x14006b500  name sub_14006B500  size 143
int **__fastcall sub_14006B500(int **a1, _BYTE **a2)
{
  _BYTE *v2; // rdx
  int *v4; // rdi
  volatile signed __int32 *v5; // rcx
  volatile signed __int32 *v6; // rdi
  __int64 v7; // rsi

  v2 = *a2;
  v4 = *a1;
  v5 = (volatile signed __int32 *)(v2 - 24);
  v6 = v4 - 6;
  if ( v2 - 24 == (_BYTE *)v6 )
    return a1;
  if ( *((int *)v6 + 4) < 0 || *(_QWORD *)v5 != *(_QWORD *)v6 )
  {
    sub_14005FCF0(a1, v2, *((_DWORD *)v2 - 4));
    return a1;
  }
  v7 = sub_14005F710(v5);
  if ( _InterlockedExchangeAdd(v6 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v6 + 8LL))(*(_QWORD *)v6, v6);
  *a1 = (int *)(v7 + 24);
  return a1;
}
