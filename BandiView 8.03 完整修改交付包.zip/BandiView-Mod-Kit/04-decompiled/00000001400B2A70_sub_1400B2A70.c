// EA 0x1400b2a70  name sub_1400B2A70  size 912
int __fastcall sub_1400B2A70(__int64 a1, __int64 *a2)
{
  int v4; // ebp
  __int64 v5; // r8
  __int64 i; // rcx
  int v7; // edx
  __int64 v8; // rcx
  int v9; // edx
  __int64 j; // rcx
  __int16 *v11; // rax
  int v12; // edx
  __int64 v13; // r8
  __int64 k; // rcx
  int v15; // edx
  unsigned __int8 v16; // di
  __int64 *v17; // rax
  __int64 v18; // r8
  __int64 v19; // rcx
  int v20; // edx
  unsigned __int8 v21; // di
  __int64 *v22; // rax
  __int64 v23; // r8
  __int64 m; // rcx
  int v25; // edx
  unsigned __int8 v26; // di
  __int64 *v27; // rax
  volatile signed __int32 *v28; // rdx
  int *v30; // [rsp+70h] [rbp+18h] BYREF
  int **v31; // [rsp+78h] [rbp+20h]

  v4 = *((_DWORD *)sub_140075FE0() + 49);
  v5 = *a2;
  for ( i = 0; i != 22; i += 2 )
  {
    v7 = *(unsigned __int16 *)(v5 + 2 * i) - aChkColorthemeS[i];
    if ( v7 != 0 )
      break;
    v7 = *(unsigned __int16 *)(v5 + 2 * i + 2) - aChkColorthemeS[i + 1];
    if ( v7 != 0 )
      break;
  }
  if ( v7 != 0 )
  {
    v8 = -1;
    do
    {
      v9 = *(unsigned __int16 *)(v5 + 2 * v8 + 2) - aChkColorthemeL[v8 + 1];
      if ( v9 != 0 )
        break;
      v8 += 2;
      if ( v8 == 21 )
        break;
      v9 = *(unsigned __int16 *)(v5 + 2 * v8) - aChkColorthemeL[v8];
    }
    while ( v9 == 0 );
    if ( v9 != 0 )
    {
      for ( j = 0; j != 20; j += 2 )
      {
        LODWORD(v11) = aChkColorthemeD[j];
        v12 = *(unsigned __int16 *)(v5 + 2 * j) - (_DWORD)v11;
        if ( v12 != 0 )
          break;
        LODWORD(v11) = aChkColorthemeD[j + 1];
        v12 = *(unsigned __int16 *)(v5 + 2 * j + 2) - (_DWORD)v11;
        if ( v12 != 0 )
          break;
      }
      if ( v12 != 0 )
      {
        v28 = (volatile signed __int32 *)(v5 - 24);
        goto LABEL_44;
      }
      *((_DWORD *)sub_140075FE0() + 49) = 2;
    }
    else
    {
      *((_DWORD *)sub_140075FE0() + 49) = 1;
    }
  }
  else
  {
    *((_DWORD *)sub_140075FE0() + 49) = 0;
  }
  v13 = *a2;
  for ( k = 0; k != 22; k += 2 )
  {
    v15 = *(unsigned __int16 *)(v13 + 2 * k) - aChkColorthemeS[k];
    if ( v15 != 0 )
      break;
    v15 = *(unsigned __int16 *)(v13 + 2 * k + 2) - aChkColorthemeS[k + 1];
    if ( v15 != 0 )
      break;
  }
  v16 = v15 == 0;
  v31 = &v30;
  v17 = sub_1400601C0();
  if ( v17 == nullptr )
    sub_14005FF30(0x80004005);
  v30 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v17 + 24))(v17) + 24);
  if ( (unsigned __int8)sub_14005F980(&v30, (__int64)L"CHK_COLORTHEME_SYSTEM") == 0 )
    sub_14005FCF0(&v30, L"CHK_COLORTHEME_SYSTEM", 21);
  sub_1400ACE70(a1, &v30, v16);
  v18 = *a2;
  v19 = -1;
  do
  {
    v20 = *(unsigned __int16 *)(v18 + 2 * v19 + 2) - aChkColorthemeL[v19 + 1];
    if ( v20 != 0 )
      break;
    v19 += 2;
    if ( v19 == 21 )
      break;
    v20 = *(unsigned __int16 *)(v18 + 2 * v19) - aChkColorthemeL[v19];
  }
  while ( v20 == 0 );
  v21 = v20 == 0;
  v31 = &v30;
  v22 = sub_1400601C0();
  if ( v22 == nullptr )
    sub_14005FF30(0x80004005);
  v30 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v22 + 24))(v22) + 24);
  if ( (unsigned __int8)sub_14005F980(&v30, (__int64)L"CHK_COLORTHEME_LIGHT") == 0 )
    sub_14005FCF0(&v30, L"CHK_COLORTHEME_LIGHT", 20);
  sub_1400ACE70(a1, &v30, v21);
  v23 = *a2;
  for ( m = 0; m != 20; m += 2 )
  {
    v25 = *(unsigned __int16 *)(v23 + 2 * m) - aChkColorthemeD[m];
    if ( v25 != 0 )
      break;
    v25 = *(unsigned __int16 *)(v23 + 2 * m + 2) - aChkColorthemeD[m + 1];
    if ( v25 != 0 )
      break;
  }
  v26 = v25 == 0;
  v31 = &v30;
  v27 = sub_1400601C0();
  if ( v27 == nullptr )
    sub_14005FF30(0x80004005);
  v30 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v27 + 24))(v27) + 24);
  if ( (unsigned __int8)sub_14005F980(&v30, (__int64)L"CHK_COLORTHEME_DARK") == 0 )
    sub_14005FCF0(&v30, L"CHK_COLORTHEME_DARK", 19);
  sub_1400ACE70(a1, &v30, v26);
  v11 = sub_140075FE0();
  if ( v4 != *((_DWORD *)v11 + 49) )
  {
    SendMessageW(*(HWND *)(a1 + 616), 0x111u, 0x8072u, 0);
    *(_BYTE *)(a1 + 77) = 1;
    LODWORD(v11) = EndDialog(*(HWND *)(a1 + 8), 1);
  }
  v28 = (volatile signed __int32 *)(*a2 - 24);
LABEL_44:
  if ( _InterlockedExchangeAdd(v28 + 4, 0xFFFFFFFF) <= 1 )
    LODWORD(v11) = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v28 + 8LL))(*(_QWORD *)v28);
  return (int)v11;
}
