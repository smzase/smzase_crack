// EA 0x14005fc80  name sub_14005FC80  size 103
void __fastcall sub_14005FC80(_QWORD *a1, int a2)
{
  int v3; // r8d
  __int64 v4; // rcx
  int v5; // ecx
  int v6; // eax
  _QWORD *v7; // rcx
  int v8; // eax

  v3 = a2;
  v4 = *a1;
  if ( *(_DWORD *)(v4 - 16) > a2 )
    v3 = *(_DWORD *)(v4 - 16);
  if ( *(int *)(v4 - 8) <= 1 )
  {
    v5 = *(_DWORD *)(v4 - 12);
    if ( v5 < v3 )
    {
      if ( v5 <= 0x40000000 )
      {
        v8 = v5 + v5 / 2;
        v7 = a1;
        if ( v8 >= v3 )
          v3 = v8;
      }
      else
      {
        v6 = v5 + 0x100000;
        v7 = a1;
        if ( v6 >= v3 )
          v3 = v6;
      }
      sub_14005FC30(v7, (unsigned int)v3);
    }
  }
  else
  {
    sub_14005FB40(a1, (unsigned int)v3);
  }
}
