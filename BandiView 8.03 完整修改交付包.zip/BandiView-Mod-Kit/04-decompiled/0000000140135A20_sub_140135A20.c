// EA 0x140135a20  name sub_140135A20  size 2055
__int64 __fastcall sub_140135A20(__int64 a1)
{
  void **v3; // rbx
  unsigned __int64 v4; // rax
  __int64 v5; // rcx
  __int64 v6; // rax
  _BYTE **v7; // rax
  int *v8; // rdx
  int **v9; // rdx
  const __m128i **v10; // rbx
  const __m128i *v11; // rdx
  unsigned __int64 v12; // r8
  const __m128i *v13; // rcx
  unsigned __int64 v14; // rax
  const __m128i *v15; // rcx
  const __m128i *v16; // rdx
  unsigned __int64 v17; // r8
  _BYTE *v18; // rbx
  __int64 v19; // rdx
  int v20; // eax
  _BYTE *v21; // rbx
  int v22; // eax
  _BYTE *v23; // rbx
  int v24; // eax
  _BYTE *v25; // rbx
  int v26; // eax
  _BYTE *v27; // rbx
  int v28; // eax
  _BYTE *v29; // rdx
  volatile signed __int32 *v30; // rcx
  int *v31; // rbx
  __int64 v32; // r14
  __int64 *v33; // rax
  _BYTE *v34; // rdx
  __int64 v35; // r8
  volatile signed __int32 *v36; // rcx
  int *v37; // rbx
  __int64 v38; // r14
  int **v39; // rdx
  int **v40; // rdx
  int *v41; // rdx
  void (__fastcall ***v42)(_QWORD, __int64); // r14
  __int64 v43; // rcx
  int *v44; // rbx
  unsigned __int64 v45; // rax
  char v46; // bl
  __int64 v47; // rax
  _BYTE *v48; // rbx
  __int64 *v49; // rax
  int v50; // eax
  __int64 *v51; // rax
  __int64 *v52; // rax
  __int64 *v53; // rax
  _QWORD *v54; // rdx
  _QWORD *v55; // rdx
  int *v56; // [rsp+30h] [rbp-D0h] BYREF
  int *v57; // [rsp+38h] [rbp-C8h] BYREF
  int **v58; // [rsp+40h] [rbp-C0h] BYREF
  int **v59; // [rsp+48h] [rbp-B8h] BYREF
  int *v60; // [rsp+50h] [rbp-B0h] BYREF
  int *v61; // [rsp+58h] [rbp-A8h] BYREF
  int *v62; // [rsp+60h] [rbp-A0h] BYREF
  int *v63; // [rsp+68h] [rbp-98h] BYREF
  int *v64; // [rsp+70h] [rbp-90h] BYREF
  int *v65[2]; // [rsp+78h] [rbp-88h] BYREF
  int *v66; // [rsp+88h] [rbp-78h] BYREF
  _QWORD v67[2]; // [rsp+A0h] [rbp-60h] BYREF
  int v68; // [rsp+B0h] [rbp-50h]
  int v69; // [rsp+BCh] [rbp-44h]
  __int64 v70; // [rsp+C8h] [rbp-38h]
  char v71; // [rsp+D0h] [rbp-30h]
  __int64 v72; // [rsp+D8h] [rbp-28h]
  int v73; // [rsp+E0h] [rbp-20h]
  __int128 v74; // [rsp+F0h] [rbp-10h] BYREF
  __int64 v75; // [rsp+100h] [rbp+0h]
  unsigned __int64 v76; // [rsp+108h] [rbp+8h]
  __int128 v77; // [rsp+110h] [rbp+10h] BYREF
  __int64 v78; // [rsp+120h] [rbp+20h]
  unsigned __int64 v79; // [rsp+128h] [rbp+28h]

  LODWORD(v57) = 0;
  if ( *(_BYTE *)(a1 + 328) != 0 )
    return 0;
  v3 = (void **)(a1 + 264);
  if ( *(_QWORD *)(a1 + 280) == 0 )
  {
    v4 = sub_1404ADC20(L"BANDIVIEW-SETUP.EXE");
    sub_140069540(v3, L"BANDIVIEW-SETUP.EXE", v4);
  }
  if ( (unsigned __int64)v3[3] > 7 )
    v3 = (void **)*v3;
  sub_14007D5E0();
  v6 = sub_14007DD10(v5, &v58);
  v7 = (_BYTE **)sub_140060B30(&v56, v6, v3);
  sub_14006B500((int **)(a1 + 320), v7);
  v8 = v56 - 6;
  if ( _InterlockedExchangeAdd(v56 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v8 + 8LL))(*(_QWORD *)v8);
  v9 = v58 - 3;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v58 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(int *))(*(_QWORD *)*v9 + 8LL))(*v9);
  if ( (unsigned int)sub_14006FEE0(*(LPCWSTR *)(a1 + 320)) != 0 )
  {
    LODWORD(v56) = 0;
    if ( (unsigned int)sub_14006DE70(*(_QWORD *)(a1 + 320), &v56) != 0 )
    {
      v74 = 0;
      v75 = 0;
      v76 = 7;
      LOWORD(v74) = 0;
      v77 = 0;
      v78 = 0;
      v79 = 7;
      LOWORD(v77) = 0;
      sub_1401CB1C0(&v74, L"%x", (unsigned int)v56);
      sub_1401CB1C0(&v77, L"%08x", (unsigned int)v56);
      v10 = (const __m128i **)(a1 + 232);
      v11 = (const __m128i *)&v74;
      if ( v76 > 7 )
        v11 = (const __m128i *)v74;
      v12 = *(_QWORD *)(a1 + 248);
      v13 = (const __m128i *)(a1 + 232);
      v14 = *(_QWORD *)(a1 + 256);
      if ( v14 > 7 )
        v13 = *v10;
      if ( v12 == v75 )
      {
        if ( v12 == 0 || (unsigned int)sub_140074220(v13, v11, v12) == 0 )
          goto LABEL_35;
        v14 = *(_QWORD *)(a1 + 256);
      }
      v15 = (const __m128i *)(a1 + 232);
      v16 = (const __m128i *)&v77;
      if ( v79 > 7 )
        v16 = (const __m128i *)v77;
      v17 = *(_QWORD *)(a1 + 248);
      if ( v14 > 7 )
        v15 = (const __m128i *)v15->m128i_i64[0];
      if ( v17 != v78 || v17 != 0 && (unsigned int)sub_140074220(v15, v16, v17) != 0 )
      {
        sub_14005D410((char **)&v77);
        sub_14005D410((char **)&v74);
        goto LABEL_29;
      }
LABEL_35:
      if ( *(_QWORD *)(a1 + 256) > 7u )
        v10 = (const __m128i **)*v10;
      sub_14006DB60((__int64)&unk_140638FB8, v10);
      sub_140136F30(a1);
      sub_14005D410((char **)&v77);
      sub_14005D410((char **)&v74);
      return 1;
    }
  }
LABEL_29:
  v18 = (_BYTE *)(a1 + 72);
  v19 = a1 + 72;
  if ( *(_QWORD *)(a1 + 96) > 7u )
    v19 = *(_QWORD *)v18;
  sub_14006DB60((__int64)L"StartSetupDownload - url:%s", v19);
  sub_14007A820(v67);
  v73 = 0x100000;
  v71 = 1;
  v72 = *(_QWORD *)(a1 + 8);
  v68 = 20;
  v69 = 104857600;
  sub_14012EEA0(&v60);
  if ( *(_QWORD *)(a1 + 96) > 7u )
    v18 = *(_BYTE **)v18;
  if ( v18 != nullptr )
    v20 = sub_1404ADC20(v18);
  else
    v20 = 0;
  sub_14005FCF0(&v60, v18, v20);
  v21 = (_BYTE *)(a1 + 104);
  if ( *(_QWORD *)(a1 + 128) > 7u )
    v21 = *(_BYTE **)v21;
  if ( v21 != nullptr )
    v22 = sub_1404ADC20(v21);
  else
    v22 = 0;
  sub_14005FCF0(&v61, v21, v22);
  v23 = (_BYTE *)(a1 + 136);
  if ( *(_QWORD *)(a1 + 160) > 7u )
    v23 = *(_BYTE **)v23;
  if ( v23 != nullptr )
    v24 = sub_1404ADC20(v23);
  else
    v24 = 0;
  sub_14005FCF0(&v62, v23, v24);
  v25 = (_BYTE *)(a1 + 168);
  if ( *(_QWORD *)(a1 + 192) > 7u )
    v25 = *(_BYTE **)v25;
  if ( v25 != nullptr )
    v26 = sub_1404ADC20(v25);
  else
    v26 = 0;
  sub_14005FCF0(&v63, v25, v26);
  v27 = (_BYTE *)(a1 + 200);
  if ( *(_QWORD *)(a1 + 224) > 7u )
    v27 = *(_BYTE **)v27;
  if ( v27 != nullptr )
    v28 = sub_1404ADC20(v27);
  else
    v28 = 0;
  sub_14005FCF0(&v64, v27, v28);
  v29 = *(_BYTE **)(a1 + 320);
  v30 = (volatile signed __int32 *)(v29 - 24);
  v31 = v65[0] - 6;
  if ( v29 - 24 != (_BYTE *)v65[0] - 24 )
  {
    if ( v31[4] >= 0 && *(_QWORD *)v30 == *(_QWORD *)v31 )
    {
      v32 = sub_14005F710(v30);
      if ( _InterlockedExchangeAdd(v31 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD, int *))(**(_QWORD **)v31 + 8LL))(*(_QWORD *)v31, v31);
      v65[0] = (int *)(v32 + 24);
    }
    else
    {
      sub_14005FCF0(v65, v29, *((_DWORD *)v29 - 4));
    }
  }
  v65[1] = *(int **)(a1 + 8);
  sub_14007D5E0();
  sub_14007D640(&v56);
  LODWORD(v57) = 1;
  if ( dword_1406DC8FC != 0 )
    sub_14005EB50((__int64)&v56, (__int64)L"%sb%d", v56);
  v33 = sub_1400609A0((__int64 *)&v59, L"BandiView", (const void **)&v56);
  v34 = (_BYTE *)*sub_140072490(&v58, (__int64)L"%s(%s)", *v33, L"XHttpMulti");
  v36 = (volatile signed __int32 *)(v34 - 24);
  v37 = v66 - 6;
  if ( v34 - 24 != (_BYTE *)(v66 - 6) )
  {
    if ( v37[4] >= 0 && *(_QWORD *)v36 == *(_QWORD *)v37 )
    {
      v38 = sub_14005F710(v36);
      if ( _InterlockedExchangeAdd(v37 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD, int *))(**(_QWORD **)v37 + 8LL))(*(_QWORD *)v37, v37);
      v66 = (int *)(v38 + 24);
    }
    else
    {
      sub_14005FCF0(&v66, v34, *((_DWORD *)v34 - 4));
    }
  }
  v39 = v58 - 3;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v58 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(int *))(*(_QWORD *)*v39 + 8LL))(*v39);
  v40 = v59 - 3;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v59 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(int *))(*(_QWORD *)*v40 + 8LL))(*v40);
  v41 = v56 - 6;
  if ( _InterlockedExchangeAdd(v56 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v41 + 8LL))(*(_QWORD *)v41);
  v42 = nullptr;
  if ( *(v65[0] - 4) == 0 )
    goto LABEL_86;
  v59 = (int **)operator new(0x58u);
  v42 = (void (__fastcall ***)(_QWORD, __int64))sub_1401CC580(v59);
  v44 = v65[0];
  if ( v65[0] == nullptr )
    goto LABEL_84;
  v74 = 0;
  v75 = 0;
  v76 = 0;
  v45 = sub_1404ADC20(v65[0]);
  sub_140061270((char **)&v74, v44, v45);
  v46 = sub_1401CC890(v42, &v74);
  sub_14005D410((char **)&v74);
  if ( v46 != 0 )
  {
LABEL_86:
    if ( (unsigned int)sub_140168200(&v60, v42, v35, v67) != 0 )
    {
      *(_BYTE *)(a1 + 328) = 1;
      v59 = &v57;
      v52 = sub_1400601C0();
      if ( v52 == nullptr )
        sub_14005FF30(0x80004005);
      v57 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v52 + 24))(v52) + 24);
      if ( (unsigned __int8)sub_14005F980(&v57, (__int64)L"-") == 0 )
        sub_14005FCF0(&v57, L"-", 1);
      v58 = &v56;
      v53 = sub_1400601C0();
      if ( v53 == nullptr )
        sub_14005FF30(0x80004005);
      v56 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v53 + 24))(v53) + 24);
      if ( (unsigned __int8)sub_14005F980(&v56, (__int64)L"IDOK") == 0 )
        sub_14005FCF0(&v56, L"IDOK", 4);
      goto LABEL_103;
    }
  }
  else
  {
LABEL_84:
    if ( v42 != nullptr )
      (**v42)(v42, 1);
  }
  *(_BYTE *)(a1 + 328) = 0;
  v59 = &v57;
  v47 = sub_1401C5640(v43);
  v48 = (_BYTE *)sub_1401C81E0(v47, L"TEXT_UPDATE_DOWNLOAD_FAILED", L"TEXT");
  v49 = sub_1400601C0();
  if ( v49 == nullptr )
    sub_14005FF30(0x80004005);
  v57 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v49 + 24))(v49) + 24);
  if ( (unsigned __int8)sub_14005F980(&v57, (__int64)v48) == 0 )
  {
    if ( v48 != nullptr )
      v50 = sub_1404ADC20(v48);
    else
      v50 = 0;
    sub_14005FCF0(&v57, v48, v50);
  }
  v58 = &v56;
  v51 = sub_1400601C0();
  if ( v51 == nullptr )
    sub_14005FF30(0x80004005);
  v56 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v51 + 24))(v51) + 24);
  if ( (unsigned __int8)sub_14005F980(&v56, (__int64)L"IDOK") == 0 )
    sub_14005FCF0(&v56, L"IDOK", 4);
LABEL_103:
  sub_1401C5020(a1 + 336, &v56, &v57);
  *(_BYTE *)(a1 + 328) = 1;
  *(_QWORD *)(a1 + 2376) = GetTickCount64();
  sub_140132F50(&v60);
  v54 = (_QWORD *)(v70 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v70 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v54 + 8LL))(*v54);
  v55 = (_QWORD *)(v67[0] - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v67[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v55 + 8LL))(*v55);
  return 1;
}
