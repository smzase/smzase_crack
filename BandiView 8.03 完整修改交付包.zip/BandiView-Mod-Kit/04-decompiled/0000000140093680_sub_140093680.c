// EA 0x140093680  name sub_140093680  size 1521
__int64 sub_140093680()
{
  __int64 *v0; // rax
  __int64 *v1; // rax
  __int64 v2; // rax
  _BYTE *v3; // rbx
  __int64 *v4; // rax
  int v5; // eax
  unsigned int i; // r13d
  __int64 *v7; // rax
  int *v8; // rbx
  __int64 *v9; // rax
  int *v10; // r15
  wchar_t *v11; // rdi
  __int64 *v12; // rax
  _BYTE *v13; // rdx
  volatile signed __int32 *v14; // rcx
  volatile signed __int32 *v15; // rbx
  __int64 v16; // rdi
  _QWORD *v17; // rdx
  int *v18; // rdx
  _BYTE *v19; // rdx
  volatile signed __int32 *v20; // rcx
  volatile signed __int32 *v21; // rbx
  __int64 v22; // r15
  _QWORD *v23; // rdx
  __int64 *j; // rbx
  __int64 v25; // rcx
  _QWORD *v26; // rax
  int v27; // edx
  __int64 *v28; // rax
  __int64 v29; // rsi
  int *v30; // r12
  int *v31; // rsi
  int *v32; // rdi
  int *v33; // rbx
  int *v34; // rdx
  signed __int32 v35; // eax
  bool v36; // cc
  __int64 result; // rax
  int *v38; // [rsp+30h] [rbp-69h] BYREF
  int *v39; // [rsp+38h] [rbp-61h] BYREF
  __int64 v40; // [rsp+40h] [rbp-59h] BYREF
  __int64 v41; // [rsp+48h] [rbp-51h] BYREF
  __int64 v42; // [rsp+50h] [rbp-49h] BYREF
  __int128 v43; // [rsp+58h] [rbp-41h] BYREF
  __int64 v44; // [rsp+68h] [rbp-31h]
  __int128 v45; // [rsp+70h] [rbp-29h]
  unsigned int v46; // [rsp+80h] [rbp-19h]
  int *v47[13]; // [rsp+88h] [rbp-11h] BYREF
  int *v48; // [rsp+100h] [rbp+67h] BYREF
  int *v49; // [rsp+108h] [rbp+6Fh] BYREF
  int *v50; // [rsp+110h] [rbp+77h] BYREF
  int *v51; // [rsp+118h] [rbp+7Fh] BYREF

  sub_1400922F0(1u, 0, 1, 0x3E8u);
  v0 = sub_1400601C0();
  if ( v0 == nullptr )
    sub_14005FF30(0x80004005);
  v49 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v0 + 24))(v0) + 24);
  if ( (unsigned __int8)sub_14005F980(&v49, (__int64)L"BandiView") == 0 )
    sub_14005FCF0(&v49, L"BandiView", 9);
  v1 = sub_1400601C0();
  if ( v1 == nullptr )
    sub_14005FF30(0x80004005);
  v51 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v1 + 24))(v1) + 24);
  if ( (unsigned __int8)sub_14005F980(&v51, (__int64)L"SOFTWARE\\BandiView") == 0 )
    sub_14005FCF0(&v51, L"SOFTWARE\\BandiView", 18);
  v2 = sub_1401C5640();
  v3 = (_BYTE *)sub_1401C81E0(v2, L"TEXT_APP_DESC", L"TEXT");
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v50 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( (unsigned __int8)sub_14005F980(&v50, (__int64)v3) == 0 )
  {
    if ( v3 != nullptr )
      v5 = sub_1404ADC20(v3);
    else
      v5 = 0;
    sub_14005FCF0(&v50, v3, v5);
  }
  sub_14007D7F0(v47);
  v43 = 0;
  v44 = 0;
  v45 = 0;
  v46 = 10;
  for ( i = 0; i < 0x44; ++i )
  {
    v7 = sub_1400601C0();
    if ( v7 == nullptr )
      sub_14005FF30(0x80004005);
    v8 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
    v38 = v8;
    v9 = sub_1400601C0();
    if ( v9 == nullptr )
      sub_14005FF30(0x80004005);
    v10 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
    v39 = v10;
    v11 = off_1406DCBA0[4 * (int)i];
    v12 = sub_1400601C0();
    if ( v12 == nullptr )
      sub_14005FF30(0x80004005);
    v48 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24);
    if ( (unsigned __int8)sub_14005F980(&v48, (__int64)L".") == 0 )
      sub_14005FCF0(&v48, L".", 1);
    v13 = *(_BYTE **)sub_140060B30(&v41, &v48, v11);
    v14 = (volatile signed __int32 *)(v13 - 24);
    v15 = v8 - 6;
    if ( v13 - 24 != (_BYTE *)v15 )
    {
      if ( *((int *)v15 + 4) >= 0 && *(_QWORD *)v14 == *(_QWORD *)v15 )
      {
        v16 = sub_14005F710(v14);
        if ( _InterlockedExchangeAdd(v15 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v15 + 8LL))(*(_QWORD *)v15, v15);
        v38 = (int *)(v16 + 24);
      }
      else
      {
        sub_14005FCF0(&v38, v13, *((_DWORD *)v13 - 4));
        v10 = v39;
      }
    }
    v17 = (_QWORD *)(v41 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v41 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v17 + 8LL))(*v17);
    v18 = v48 - 6;
    if ( _InterlockedExchangeAdd(v48 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v18 + 8LL))(*(_QWORD *)v18);
    v19 = *(_BYTE **)sub_14006AFD0(&v40, &v49, &v38);
    v20 = (volatile signed __int32 *)(v19 - 24);
    v21 = v10 - 6;
    if ( v19 - 24 != (_BYTE *)(v10 - 6) )
    {
      if ( *((int *)v21 + 4) >= 0 && *(_QWORD *)v20 == *(_QWORD *)v21 )
      {
        v22 = sub_14005F710(v20);
        if ( _InterlockedExchangeAdd(v21 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v21 + 8LL))(*(_QWORD *)v21, v21);
        v10 = (int *)(v22 + 24);
        v39 = v10;
      }
      else
      {
        sub_14005FCF0(&v39, v19, *((_DWORD *)v19 - 4));
        v10 = v39;
      }
    }
    v23 = (_QWORD *)(v40 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v40 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v23 + 8LL))(*v23);
    v48 = *((int **)&v43 + 1);
    j = *((__int64 **)&v45 + 1);
    if ( *((_QWORD *)&v45 + 1) == 0 )
    {
      v25 = v46;
      if ( v46 != 0 )
      {
        if ( 0xFFFFFFFFFFFFFFFFuLL / v46 < 0x20 )
          goto LABEL_70;
        v25 = 32LL * v46;
      }
      v26 = j__malloc_base(v25 + 8);
      if ( v26 == nullptr )
LABEL_70:
        sub_14005FF30(0x8007000E);
      *v26 = v45;
      *(_QWORD *)&v45 = v26;
      v27 = v46 - 1;
      v28 = &v26[4 * v46 - 3];
      for ( j = *((__int64 **)&v45 + 1); v27 >= 0; --v27 )
      {
        *v28 = (__int64)j;
        j = v28;
        *((_QWORD *)&v45 + 1) = v28;
        v28 -= 4;
      }
    }
    v29 = *j;
    v42 = (__int64)(j + 2);
    v30 = v38;
    j[2] = sub_14005F710(v38 - 6) + 24;
    j[3] = sub_14005F710(v10 - 6) + 24;
    *((_QWORD *)&v45 + 1) = v29;
    j[1] = (__int64)v48;
    *j = 0;
    ++v44;
    if ( *((_QWORD *)&v43 + 1) != 0 )
      **((_QWORD **)&v43 + 1) = j;
    else
      *(_QWORD *)&v43 = j;
    *((_QWORD *)&v43 + 1) = j;
    if ( _InterlockedExchangeAdd(v10 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD, int *))(**((_QWORD **)v10 - 3) + 8LL))(*((_QWORD *)v10 - 3), v10 - 6);
    if ( _InterlockedExchangeAdd(v30 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD, int *))(**((_QWORD **)v30 - 3) + 8LL))(*((_QWORD *)v30 - 3), v30 - 6);
  }
  v47[1] = (int *)&v48;
  v48 = (int *)(sub_14005F710(v47[0] - 6) + 24);
  v47[2] = (int *)&v42;
  v31 = v50;
  v42 = sub_14005F710(v50 - 6) + 24;
  v47[3] = (int *)&v40;
  v32 = v51;
  v40 = sub_14005F710(v51 - 6) + 24;
  v33 = v49;
  v41 = sub_14005F710(v49 - 6) + 24;
  if ( (unsigned int)sub_1400C5C60(
                       (unsigned int)&v41,
                       (unsigned int)&v40,
                       (unsigned int)&v42,
                       (unsigned int)&v48,
                       (__int64)&v43) == 0 )
    sub_14006DB60((__int64)L"@@rRegDefaultProgram() - failed");
  SHChangeNotify(0x8000000, 0x1003u, nullptr, nullptr);
  Sleep(0x3E8u);
  sub_140094050(&v43);
  v34 = v47[0] - 6;
  if ( _InterlockedExchangeAdd(v47[0] - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v34 + 8LL))(*(_QWORD *)v34);
  if ( _InterlockedExchangeAdd(v31 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, int *))(**((_QWORD **)v31 - 3) + 8LL))(*((_QWORD *)v31 - 3), v31 - 6);
  v35 = _InterlockedExchangeAdd(v32 - 2, 0xFFFFFFFF);
  v36 = v35 <= 1;
  result = (unsigned int)(v35 - 1);
  if ( v36 )
    result = (*(__int64 (__fastcall **)(_QWORD, int *))(**((_QWORD **)v32 - 3) + 8LL))(*((_QWORD *)v32 - 3), v32 - 6);
  if ( _InterlockedExchangeAdd(v33 - 2, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD, int *))(**((_QWORD **)v33 - 3) + 8LL))(*((_QWORD *)v33 - 3), v33 - 6);
  return result;
}
