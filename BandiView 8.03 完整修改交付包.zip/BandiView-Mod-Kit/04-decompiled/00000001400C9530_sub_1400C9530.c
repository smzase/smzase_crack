// EA 0x1400c9530  name sub_1400C9530  size 775
__int64 __fastcall sub_1400C9530(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  __int64 v6; // rax
  volatile signed __int32 *v7; // rdx
  volatile signed __int32 *v8; // rax
  __int64 v9; // rdi
  volatile signed __int32 *v10; // rdx
  volatile signed __int32 *v11; // r11
  volatile signed __int32 *v12; // r10
  volatile signed __int32 *v13; // r9
  __int64 v14; // r8
  int v15; // edi
  __int64 *v16; // rax
  __int64 v17; // rax
  _QWORD *v18; // rax
  _QWORD *v19; // rdx
  _QWORD *v20; // rdx
  int *v21; // rdx
  __int64 v22; // rax
  __int64 v23; // rdx
  int v24; // r8d
  volatile signed __int32 *v25; // rdx
  volatile signed __int32 *v26; // rdx
  int *v28; // [rsp+28h] [rbp-30h] BYREF
  __int64 v29; // [rsp+30h] [rbp-28h] BYREF
  __int64 v30; // [rsp+38h] [rbp-20h] BYREF
  __int64 v31[3]; // [rsp+40h] [rbp-18h] BYREF
  volatile signed __int32 *v32; // [rsp+A8h] [rbp+50h] BYREF

  v6 = sub_140060B30(&v32, a2, L"/");
  sub_14006AFD0(a1, v6, a3);
  v7 = v32 - 6;
  if ( _InterlockedExchangeAdd(v32 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v7 + 8LL))(*(_QWORD *)v7);
  sub_140072AD0(&v32);
  v8 = v32;
  v9 = *((int *)v32 - 4);
  if ( (_DWORD)v9 != 0 )
  {
    if ( (int)v9 < 0 )
      goto LABEL_41;
    if ( (int)((*((_DWORD *)v32 - 3) - v9) | (1 - *((_DWORD *)v32 - 2))) < 0 )
    {
      sub_14005FC80(&v32, v9);
      v8 = v32;
    }
    v10 = v8;
    v11 = (volatile signed __int32 *)((char *)v8 + 2 * v9);
    if ( v8 < v11 )
    {
      do
      {
        v12 = (volatile signed __int32 *)((char *)v8 + 2);
        if ( *(_WORD *)v8 != 58 )
        {
          v13 = (volatile signed __int32 *)((char *)v10 + 2);
          v14 = 0;
          do
          {
            if ( v14 != 0 )
              break;
            *(_WORD *)v10 = *(_WORD *)v8;
            v8 = (volatile signed __int32 *)((char *)v8 + 2);
            v10 = (volatile signed __int32 *)((char *)v10 + 2);
            v14 = 1;
          }
          while ( v10 != v13 );
        }
        v8 = v12;
      }
      while ( v12 < v11 );
    }
    *(_WORD *)v10 = 0;
    v15 = v9 - (((char *)v8 - (char *)v10) >> 1);
    if ( v15 < 0 || v15 > *((_DWORD *)v32 - 3) )
LABEL_41:
      sub_14005FF30(0x80070057);
    *((_DWORD *)v32 - 4) = v15;
    *((_WORD *)v32 + v15) = 0;
    sub_1400C8100(&v29, v32);
    v16 = sub_1400601C0();
    if ( v16 == nullptr )
      sub_14005FF30(0x80004005);
    v28 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v16 + 24))(v16) + 24);
    if ( (unsigned __int8)sub_14005F980(&v28, (__int64)byte_14062BA40) == 0 )
      sub_14005FCF0(&v28, byte_14062BA40, 1);
    v17 = sub_14006AFD0(v31, &v28, &v29);
    v18 = (_QWORD *)sub_140060B30(&v30, v17, L")");
    sub_140069690(a1, *v18, *(unsigned int *)(*v18 - 16LL));
    v19 = (_QWORD *)(v30 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v30 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v19 + 8LL))(*v19);
    v20 = (_QWORD *)(v31[0] - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v31[0] - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v20 + 8LL))(*v20);
    v21 = v28 - 6;
    if ( _InterlockedExchangeAdd(v28 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v21 + 8LL))(*(_QWORD *)v21);
    v22 = v29;
    v23 = -1;
    do
    {
      v24 = *(unsigned __int16 *)(v29 + 2 * v23 + 2) - a266783cf9d09c4[v23 + 1];
      if ( v24 != 0 )
        break;
      v23 += 2;
      if ( v23 == 33 )
        break;
      v24 = *(unsigned __int16 *)(v29 + 2 * v23) - a266783cf9d09c4[v23];
    }
    while ( v24 == 0 );
    if ( v24 == 0 )
    {
      sub_140069690(a1, v32, *((unsigned int *)v32 - 4));
      v22 = v29;
    }
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v22 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v22 - 24) + 8LL))(*(_QWORD *)(v22 - 24));
    v8 = v32;
  }
  if ( _InterlockedExchangeAdd(v8 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v8 - 3) + 8LL))(*((_QWORD *)v8 - 3));
  v25 = (volatile signed __int32 *)(*a2 - 24LL);
  if ( _InterlockedExchangeAdd(v25 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v25 + 8LL))(*(_QWORD *)v25);
  v26 = (volatile signed __int32 *)(*a3 - 24LL);
  if ( _InterlockedExchangeAdd(v26 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v26 + 8LL))(*(_QWORD *)v26);
  return a1;
}
