// EA 0x140082560  name sub_140082560  size 429
void __fastcall sub_140082560(__int64 a1)
{
  __int64 v1; // rbx
  __int16 *v2; // rax
  __int16 *v3; // rax
  __int64 v4; // rsi
  __int64 *v5; // rax
  HMODULE *v6; // rax
  HMODULE v7; // rdi
  void (__fastcall *v8)(HMODULE, __int64, _BYTE **, __int64 *, int *); // rbx
  int *v9; // rax
  _BYTE *v10; // rbx
  int **v11; // rdi
  int v12; // eax
  __int64 v13; // [rsp+50h] [rbp+8h] BYREF
  int *v14; // [rsp+58h] [rbp+10h] BYREF
  _BYTE *v15; // [rsp+60h] [rbp+18h] BYREF
  int **v16; // [rsp+68h] [rbp+20h]

  v13 = a1;
  if ( byte_1406DC8F5 != 0 )
  {
    v1 = sub_1400A07F0();
    if ( (unsigned __int8)sub_1400A0DB0(v1) != 0
      && *(_QWORD *)(v1 + 8) != 0
      && *(_QWORD *)(v1 + 8) >= unknown_libname_553(0) )
    {
      v2 = sub_140075FE0();
      sub_14005FCF0((int **)v2 + 1, L"SUB", 3);
      dword_1406F8958 = 744355897;
    }
    else
    {
      v3 = sub_140075FE0();
      sub_14005FCF0((int **)v3 + 1, L"TRI", 3);
      dword_1406F8958 = 744393529;
    }
  }
  else
  {
    v4 = sub_1400A1680();
    v16 = &v14;
    v5 = sub_1400601C0();
    if ( v5 == nullptr )
      sub_14005FF30(0x80004005);
    v14 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
    if ( (unsigned __int8)sub_14005F980(&v14, (__int64)&Data) == 0 )
      sub_14005FCF0(&v14, &Data, 0);
    v6 = sub_14007D020(&v14);
    v15 = nullptr;
    LODWORD(v13) = __ROR4__(__ROR4__(dword_1406F8958, 3) + 1412567278, 5) ^ 0xABCDEF12;
    v7 = v6[2];
    v8 = *(void (__fastcall **)(HMODULE, __int64, _BYTE **, __int64 *, int *))(*(_QWORD *)v7 + 88LL);
    v9 = sub_14007D5E0();
    v8(v7, v4, &v15, &v13, v9 + 48);
    dword_1406F8958 = __ROR4__(__ROR4__(v13 ^ 0xABCDEF12, 27) - 1412567278, 29);
    v10 = v15;
    v11 = (int **)(sub_140075FE0() + 4);
    if ( v10 != nullptr )
      v12 = sub_1404ADC20(v10);
    else
      v12 = 0;
    sub_14005FCF0(v11, v10, v12);
  }
}
