// EA 0x1401c7e40  name sub_1401C7E40  size 544
__int64 __fastcall sub_1401C7E40(LPARAM lParam, HWND hWnd, unsigned int a3)
{
  __int64 *v6; // rax
  _WORD *v7; // r14
  unsigned int v8; // edi
  unsigned __int16 v9; // ax
  _WORD *v10; // rcx
  __int64 v11; // rbx
  LONG WindowLongW; // eax
  _QWORD *v13; // rbx
  _QWORD *v14; // rcx
  LPCWSTR v15; // rax
  _QWORD *v16; // rdx
  signed __int32 v17; // eax
  bool v18; // cc
  __int64 result; // rax
  _WORD *v20; // [rsp+60h] [rbp+8h] BYREF
  LPCWSTR lpString; // [rsp+68h] [rbp+10h] BYREF

  *(_QWORD *)(lParam + 192) = hWnd;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (_WORD *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  sub_14005EB50((__int64)&v20, (__int64)L"%u", a3);
  sub_14005FA90((int **)(lParam + 304));
  v7 = v20;
  if ( v20 == nullptr )
    sub_14005FF30(0x80004005);
  v8 = 0;
  v9 = *v20;
  if ( *v20 != 0 )
  {
    v10 = v20;
    do
    {
      v8 = v9 + 33 * v8;
      v9 = *++v10;
    }
    while ( *v10 != 0 );
  }
  if ( *(_QWORD *)lParam != 0 && (v11 = *(_QWORD *)(*(_QWORD *)lParam + 8LL * (v8 % *(_DWORD *)(lParam + 16)))) != 0 )
  {
    while ( *(_DWORD *)(v11 + 24) != v8 || (unsigned int)sub_1404D8590(*(_QWORD *)v11, v7) != 0 )
    {
      v11 = *(_QWORD *)(v11 + 16);
      if ( v11 == 0 )
        goto LABEL_11;
    }
  }
  else
  {
LABEL_11:
    v11 = 0;
  }
  if ( v11 != 0 )
    sub_14006B500((int **)(lParam + 304), (_BYTE **)(v11 + 8));
  EnumChildWindows(hWnd, sub_1401C7910, lParam);
  sub_1401C8060(lParam, hWnd);
  if ( *(_DWORD *)(lParam + 312) != 0 )
  {
    WindowLongW = GetWindowLongW(hWnd, -20);
    if ( WindowLongW != (WindowLongW | 0x400000) )
      SetWindowLongW(hWnd, -20, WindowLongW | 0x400000);
    v13 = *(_QWORD **)(lParam + 144);
    while ( v13 != nullptr )
    {
      v14 = v13;
      v13 = (_QWORD *)*v13;
      MoveWindow(
        (HWND)v14[2],
        *((_DWORD *)v14 + 6),
        *((_DWORD *)v14 + 7),
        *((_DWORD *)v14 + 8) - *((_DWORD *)v14 + 6),
        *((_DWORD *)v14 + 9) - *((_DWORD *)v14 + 7),
        true);
    }
    sub_14006D9B0(lParam + 144);
  }
  sub_1401C6AF0(lParam, &lpString, a3);
  v15 = lpString;
  if ( *((_DWORD *)lpString - 4) != 0 )
  {
    SetWindowTextW(hWnd, lpString);
    v15 = lpString;
  }
  v16 = v15 - 12;
  v17 = _InterlockedExchangeAdd((volatile signed __int32 *)v15 - 2, 0xFFFFFFFF);
  v18 = v17 <= 1;
  result = (unsigned int)(v17 - 1);
  if ( v18 )
    result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v16 + 8LL))(*v16);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v7 - 2, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v7 - 3) + 8LL))(*((_QWORD *)v7 - 3));
  return result;
}
