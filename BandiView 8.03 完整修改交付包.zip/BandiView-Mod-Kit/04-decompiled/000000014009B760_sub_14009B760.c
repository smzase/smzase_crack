// EA 0x14009b760  name sub_14009B760  size 254
__int64 __fastcall sub_14009B760(__int64 a1, __int64 a2, _DWORD *a3, int a4)
{
  int v8; // ecx
  _QWORD *v9; // rax
  unsigned int v10; // ebx
  __int64 v11; // rdx
  const WCHAR *v12; // rdx
  volatile signed __int32 *v13; // rdx
  DWORD cbData; // [rsp+30h] [rbp-38h] BYREF
  DWORD Type[2]; // [rsp+38h] [rbp-30h] BYREF
  __int64 v16; // [rsp+40h] [rbp-28h] BYREF
  BYTE Data[32]; // [rsp+48h] [rbp-20h] BYREF

  if ( *(_DWORD *)(a1 + 180) == 0 )
    return 0;
  v8 = *(_DWORD *)(a1 + 136) - 1;
  if ( v8 != 0 )
  {
    if ( v8 != 1 )
      return 0;
    v9 = (_QWORD *)sub_140060B30(Type, a1 + 184, a2);
    v10 = sub_1401E9D20((int)a1 + 8, *(_QWORD *)(a1 + 168), *v9, (_DWORD)a3, a4);
    v11 = *(_QWORD *)Type;
  }
  else
  {
    v12 = *(const WCHAR **)sub_140060B30(&v16, a1 + 184, a2);
    *(_DWORD *)Data = 0;
    cbData = 4;
    Type[0] = 4;
    *a3 = a4;
    if ( RegQueryValueExW(*(HKEY *)a1, v12, nullptr, Type, Data, &cbData) != 0 )
    {
      v10 = 0;
    }
    else
    {
      *a3 = *(_DWORD *)Data;
      v10 = 1;
    }
    v11 = v16;
  }
  v13 = (volatile signed __int32 *)(v11 - 24);
  if ( _InterlockedExchangeAdd(v13 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v13 + 8LL))(*(_QWORD *)v13);
  return v10;
}
