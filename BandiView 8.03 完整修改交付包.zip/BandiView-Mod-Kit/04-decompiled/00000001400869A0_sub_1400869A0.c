// EA 0x1400869a0  name sub_1400869A0  size 676
__int64 __fastcall sub_1400869A0(const WCHAR *a1, __int64 a2)
{
  WCHAR *v3; // rbx
  WCHAR v4; // ax
  __int64 *v5; // rax
  int v6; // eax
  const void *v7; // rbx
  unsigned __int64 v8; // rax
  _QWORD *v9; // rdx
  char **v10; // rdi
  __int64 v11; // r15
  __m128i si128; // xmm6
  unsigned __int64 v13; // rcx
  BOOL v14; // esi
  unsigned __int64 v15; // rax
  unsigned int v16; // ebx
  __int128 v18; // [rsp+20h] [rbp-39h] BYREF
  __int64 v19; // [rsp+30h] [rbp-29h]
  int *v20; // [rsp+38h] [rbp-21h] BYREF
  _QWORD v21[2]; // [rsp+40h] [rbp-19h] BYREF
  __int128 Src; // [rsp+50h] [rbp-9h] BYREF
  __m128i v23; // [rsp+60h] [rbp+7h]

  v3 = (WCHAR *)a1;
  if ( a1 == nullptr )
    return sub_1400867C0(a2);
  v4 = *a1;
  if ( *a1 == 0 )
    return sub_1400867C0(a2);
  v18 = 0;
  v19 = 0;
  if ( v4 == 47 || (unsigned int)sub_140070060(a1) == 0 )
  {
    v10 = (char **)v18;
    if ( (_QWORD)v18 != *((_QWORD *)&v18 + 1) )
    {
      do
      {
        sub_14005D410(v10);
        v10 += 4;
      }
      while ( v10 != *((char ***)&v18 + 1) );
      *((_QWORD *)&v18 + 1) = v18;
    }
    v11 = 0x100002600LL;
    si128 = _mm_load_si128((const __m128i *)&xmmword_140662F90);
    while ( 1 )
    {
      Src = 0;
      v23 = si128;
      LOWORD(Src) = 0;
      while ( 1 )
      {
        v13 = *v3;
        if ( (unsigned int)v13 > 0x20 || !_bittest64(&v11, v13) )
          break;
        ++v3;
      }
      if ( (_WORD)v13 == 0 )
        break;
      v14 = false;
      do
      {
        if ( !v14 )
        {
          v15 = *v3;
          if ( (unsigned int)v15 <= 0x20 )
          {
            if ( _bittest64(&v11, v15) )
              break;
          }
        }
        if ( *v3 == 34 )
        {
          if ( v3[1] == 34 )
          {
            sub_14006B590(&Src);
            ++v3;
          }
          else
          {
            v14 = !v14;
          }
        }
        else
        {
          sub_14006B590(&Src);
        }
        ++v3;
      }
      while ( *v3 != 0 );
      if ( *((_QWORD *)&v18 + 1) == v19 )
      {
        sub_140088250(&v18, *((_QWORD *)&v18 + 1), &Src);
      }
      else
      {
        sub_1400693B0(*((__int64 *)&v18 + 1), (__int64)&Src);
        *((_QWORD *)&v18 + 1) += 32LL;
      }
      sub_14005D410((char **)&Src);
    }
  }
  else
  {
    v21[1] = &v20;
    v5 = sub_1400601C0();
    if ( v5 == nullptr )
      sub_14005FF30(0x80004005);
    v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
    if ( (unsigned __int8)sub_14005F980(&v20, (__int64)v3) == 0 )
    {
      v6 = sub_1404ADC20(v3);
      sub_14005FCF0(&v20, v3, v6);
    }
    v7 = *(const void **)sub_1400841D0(v21, &v20);
    Src = 0;
    v23 = 0;
    v8 = sub_1404ADC20(v7);
    sub_140061270((char **)&Src, v7, v8);
    v9 = (_QWORD *)(v21[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v21[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v9 + 8LL))(*v9);
    if ( *((_QWORD *)&v18 + 1) == v19 )
    {
      sub_140088250(&v18, *((_QWORD *)&v18 + 1), &Src);
    }
    else
    {
      sub_1400693B0(*((__int64 *)&v18 + 1), (__int64)&Src);
      *((_QWORD *)&v18 + 1) += 32LL;
    }
  }
  sub_14005D410((char **)&Src);
  v16 = sub_1400847A0(&v18, a2);
  sub_140087FE0(&v18);
  return v16;
}
