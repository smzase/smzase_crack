// EA 0x1404ae3c8  name unknown_libname_553  size 113
// Microsoft VisualC 64bit universal runtime
__int64 __fastcall unknown_libname_553(__int64 *a1)
{
  __int64 v2; // rdx
  __int64 result; // rax
  struct _FILETIME SystemTimeAsFileTime; // [rsp+30h] [rbp+8h] BYREF

  SystemTimeAsFileTime = 0;
  GetSystemTimeAsFileTime(&SystemTimeAsFileTime);
  v2 = (*(_QWORD *)&SystemTimeAsFileTime - 116444736000000000LL) / 10000000;
  if ( v2 > 0x793582AFFLL )
    v2 = -1;
  result = v2;
  if ( a1 != nullptr )
    *a1 = v2;
  return result;
}
