// EA 0x14009bfc0  name sub_14009BFC0  size 1510
__int64 __fastcall sub_14009BFC0(__int64 a1, char a2, int *a3, unsigned int *a4)
{
  __int64 *v6; // rax
  __int64 *v7; // rax
  _QWORD *v8; // rdx
  int *v9; // rdx
  __int64 *v10; // rax
  __int64 *v11; // rax
  _QWORD *v12; // rdx
  int *v13; // rdx
  __int64 *v14; // rax
  __int64 *v15; // rax
  _QWORD *v16; // rdx
  int *v17; // rdx
  __int64 *v18; // rax
  __int64 *v19; // rax
  _QWORD *v20; // rdx
  signed __int32 v21; // eax
  bool v22; // cc
  __int64 result; // rax
  unsigned int v24; // ebx
  __int64 *v25; // rax
  __int64 *v26; // rax
  _QWORD *v27; // rdx
  int *v28; // rdx
  unsigned int v29; // esi
  __int64 *v30; // rax
  __int64 *v31; // rax
  _QWORD *v32; // rdx
  int *v33; // rdx
  unsigned int v34; // esi
  __int64 *v35; // rax
  __int64 *v36; // rax
  _QWORD *v37; // rdx
  int *v38; // rdx
  unsigned int v39; // edi
  __int64 *v40; // rax
  __int64 *v41; // rax
  _QWORD *v42; // rdx
  signed __int32 v43; // eax
  int *v44; // rdx
  _QWORD v45[2]; // [rsp+20h] [rbp-10h] BYREF
  int *v46; // [rsp+60h] [rbp+30h] BYREF

  v46 = a3;
  if ( a2 != 0 )
  {
    v6 = sub_1400601C0();
    if ( v6 == nullptr )
      sub_14005FF30(0x80004005);
    v46 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
    if ( (unsigned __int8)sub_14005F980(&v46, (__int64)L"rectBookmark") == 0 )
      sub_14005FCF0(&v46, L"rectBookmark", 12);
    v7 = (__int64 *)sub_140060B30(v45, &v46, L".left");
    sub_14009B760(a1, *v7, a4, 0);
    v8 = (_QWORD *)(v45[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v45[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v8 + 8LL))(*v8);
    v9 = v46 - 6;
    if ( _InterlockedExchangeAdd(v46 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v9 + 8LL))(*(_QWORD *)v9);
    v10 = sub_1400601C0();
    if ( v10 == nullptr )
      sub_14005FF30(0x80004005);
    v46 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24);
    if ( (unsigned __int8)sub_14005F980(&v46, (__int64)L"rectBookmark") == 0 )
      sub_14005FCF0(&v46, L"rectBookmark", 12);
    v11 = (__int64 *)sub_140060B30(v45, &v46, L".top");
    sub_14009B760(a1, *v11, a4 + 1, 0);
    v12 = (_QWORD *)(v45[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v45[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v12 + 8LL))(*v12);
    v13 = v46 - 6;
    if ( _InterlockedExchangeAdd(v46 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v13 + 8LL))(*(_QWORD *)v13);
    v14 = sub_1400601C0();
    if ( v14 == nullptr )
      sub_14005FF30(0x80004005);
    v46 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
    if ( (unsigned __int8)sub_14005F980(&v46, (__int64)L"rectBookmark") == 0 )
      sub_14005FCF0(&v46, L"rectBookmark", 12);
    v15 = (__int64 *)sub_140060B30(v45, &v46, L".right");
    sub_14009B760(a1, *v15, a4 + 2, 0);
    v16 = (_QWORD *)(v45[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v45[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v16 + 8LL))(*v16);
    v17 = v46 - 6;
    if ( _InterlockedExchangeAdd(v46 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v17 + 8LL))(*(_QWORD *)v17);
    v18 = sub_1400601C0();
    if ( v18 == nullptr )
      sub_14005FF30(0x80004005);
    v46 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v18 + 24))(v18) + 24);
    if ( (unsigned __int8)sub_14005F980(&v46, (__int64)L"rectBookmark") == 0 )
      sub_14005FCF0(&v46, L"rectBookmark", 12);
    v19 = (__int64 *)sub_140060B30(v45, &v46, L".bottom");
    sub_14009B760(a1, *v19, a4 + 3, 0);
    v20 = (_QWORD *)(v45[0] - 24LL);
    v21 = _InterlockedExchangeAdd((volatile signed __int32 *)(v45[0] - 24LL + 16), 0xFFFFFFFF);
    v22 = v21 <= 1;
    result = (unsigned int)(v21 - 1);
    if ( v22 )
      result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v20 + 8LL))(*v20);
  }
  else
  {
    v24 = *a4;
    v25 = sub_1400601C0();
    if ( v25 == nullptr )
      sub_14005FF30(0x80004005);
    v46 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v25 + 24))(v25) + 24);
    if ( (unsigned __int8)sub_14005F980(&v46, (__int64)L"rectBookmark") == 0 )
      sub_14005FCF0(&v46, L"rectBookmark", 12);
    v26 = (__int64 *)sub_140060B30(v45, &v46, L".left");
    sub_14009B970(a1, *v26, v24);
    v27 = (_QWORD *)(v45[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v45[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v27 + 8LL))(*v27);
    v28 = v46 - 6;
    if ( _InterlockedExchangeAdd(v46 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v28 + 8LL))(*(_QWORD *)v28);
    v29 = a4[1];
    v30 = sub_1400601C0();
    if ( v30 == nullptr )
      sub_14005FF30(0x80004005);
    v46 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v30 + 24))(v30) + 24);
    if ( (unsigned __int8)sub_14005F980(&v46, (__int64)L"rectBookmark") == 0 )
      sub_14005FCF0(&v46, L"rectBookmark", 12);
    v31 = (__int64 *)sub_140060B30(v45, &v46, L".top");
    sub_14009B970(a1, *v31, v29);
    v32 = (_QWORD *)(v45[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v45[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v32 + 8LL))(*v32);
    v33 = v46 - 6;
    if ( _InterlockedExchangeAdd(v46 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v33 + 8LL))(*(_QWORD *)v33);
    v34 = a4[2];
    v35 = sub_1400601C0();
    if ( v35 == nullptr )
      sub_14005FF30(0x80004005);
    v46 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v35 + 24))(v35) + 24);
    if ( (unsigned __int8)sub_14005F980(&v46, (__int64)L"rectBookmark") == 0 )
      sub_14005FCF0(&v46, L"rectBookmark", 12);
    v36 = (__int64 *)sub_140060B30(v45, &v46, L".right");
    sub_14009B970(a1, *v36, v34);
    v37 = (_QWORD *)(v45[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v45[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v37 + 8LL))(*v37);
    v38 = v46 - 6;
    if ( _InterlockedExchangeAdd(v46 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v38 + 8LL))(*(_QWORD *)v38);
    v39 = a4[3];
    v40 = sub_1400601C0();
    if ( v40 == nullptr )
      sub_14005FF30(0x80004005);
    v46 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v40 + 24))(v40) + 24);
    if ( (unsigned __int8)sub_14005F980(&v46, (__int64)L"rectBookmark") == 0 )
      sub_14005FCF0(&v46, L"rectBookmark", 12);
    v41 = (__int64 *)sub_140060B30(v45, &v46, L".bottom");
    sub_14009B970(a1, *v41, v39);
    v42 = (_QWORD *)(v45[0] - 24LL);
    v43 = _InterlockedExchangeAdd((volatile signed __int32 *)(v45[0] - 24LL + 16), 0xFFFFFFFF);
    v22 = v43 <= 1;
    result = (unsigned int)(v43 - 1);
    if ( v22 )
      result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v42 + 8LL))(*v42);
  }
  v44 = v46 - 6;
  if ( _InterlockedExchangeAdd(v46 - 2, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v44 + 8LL))(*(_QWORD *)v44);
  return result;
}
