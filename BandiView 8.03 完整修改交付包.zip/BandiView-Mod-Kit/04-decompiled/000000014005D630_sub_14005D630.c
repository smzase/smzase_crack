// EA 0x14005d630  name sub_14005D630  size 431
__int64 __fastcall sub_14005D630(__int64 a1, __int64 a2, int a3, __int64 a4, int a5, _QWORD *a6, int a7)
{
  __int64 v8; // rcx
  __int64 v10; // rcx

  if ( a7 != 0 )
    return 0;
  if ( a3 != 2 )
  {
    switch ( a3 )
    {
      case 275:
        *a6 = sub_14005E7E0(a1, a2, a4);
        return 1;
      case 273:
        if ( (_WORD)a4 == 0xFDE8 )
        {
          KillTimer(*(HWND *)(a1 + 8), 1u);
          SetTimer(*(HWND *)(a1 + 8), 2u, 0xAu, nullptr);
          GetWindowRect(*(HWND *)(a1 + 8), (LPRECT)(a1 + 2024));
          *a6 = 0;
          return 1;
        }
        if ( (_WORD)a4 == 0xFDE9 )
        {
          ShellExecuteW(nullptr, L"open", L"https://notice.bandisoft.com/ad/bandiview/", nullptr, nullptr, 1);
          *a6 = 0;
          return 1;
        }
        goto LABEL_21;
      case 258:
LABEL_21:
        *a6 = 0;
        return 1;
      case 3:
        v10 = *(_QWORD *)(a1 + 2064);
        if ( v10 != 0 )
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v10 + 56LL))(v10);
        goto LABEL_21;
      default:
        break;
    }
    return 0;
  }
  if ( *(_BYTE *)(a1 + 2088) != 0 )
  {
    if ( *(_QWORD *)(a1 + 2048) != 0 )
    {
      v8 = *(_QWORD *)(a1 + 2064);
      if ( v8 != 0 )
      {
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 16LL))(v8);
        *(_QWORD *)(a1 + 2064) = 0;
      }
      FreeLibrary(*(HMODULE *)(a1 + 2048));
      *(_QWORD *)(a1 + 2048) = 0;
    }
  }
  else
  {
    sub_14006CAF0(a1 + 2096);
  }
  PostQuitMessage(0);
  *a6 = 0;
  return 1;
}
