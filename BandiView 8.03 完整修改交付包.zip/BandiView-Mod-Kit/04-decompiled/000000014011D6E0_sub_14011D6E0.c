// EA 0x14011d6e0  name sub_14011D6E0  size 252
__int64 __fastcall sub_14011D6E0(__int64 a1)
{
  __int64 v2; // rax
  unsigned int v3; // edi
  __int64 v4; // rax
  __int64 v6; // [rsp+38h] [rbp+10h] BYREF
  __int64 *v7; // [rsp+40h] [rbp+18h]

  v7 = &v6;
  v2 = sub_1400601C0();
  if ( v2 == 0 )
    sub_14005FF30(2147500037LL);
  v6 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v2 + 24LL))(v2) + 24;
  if ( (unsigned __int8)sub_14005F980(&v6, L"CHK_UPDATE_0") == 0 )
    sub_14005FCF0(&v6, L"CHK_UPDATE_0", 12);
  v3 = (unsigned __int8)sub_1400ACB10(a1, &v6);
  v7 = &v6;
  v4 = sub_1400601C0();
  if ( v4 == 0 )
    sub_14005FF30(2147500037LL);
  v6 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4) + 24;
  if ( (unsigned __int8)sub_14005F980(&v6, L"CHK_UPDATE_1") == 0 )
    sub_14005FCF0(&v6, L"CHK_UPDATE_1", 12);
  return sub_1401C4F90(a1 + 728, &v6, v3);
}
