// EA 0x1400aec80  name sub_1400AEC80  size 169
__int64 __fastcall sub_1400AEC80(__int64 a1, __int64 a2)
{
  __int64 v4; // rdx
  __int64 v5; // rax
  __int64 *v6; // rax
  LPCWSTR v7; // rbx
  signed __int32 v8; // eax
  bool v9; // cc
  __int64 result; // rax
  LPCWSTR lpString; // [rsp+30h] [rbp+8h] BYREF

  v4 = *(int *)(a1 + 84);
  v5 = v4;
  if ( a2 < v4 )
    v5 = a2;
  if ( v5 <= *(int *)(a1 + 80) )
  {
    a2 = *(int *)(a1 + 80);
  }
  else if ( a2 >= v4 )
  {
    a2 = *(int *)(a1 + 84);
  }
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  lpString = (LPCWSTR)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  sub_14005EB50((__int64)&lpString, (__int64)L"%I64d", a2);
  v7 = lpString;
  SetWindowTextW(*(HWND *)(a1 + 8), lpString);
  v8 = _InterlockedExchangeAdd((volatile signed __int32 *)v7 - 2, 0xFFFFFFFF);
  v9 = v8 <= 1;
  result = (unsigned int)(v8 - 1);
  if ( v9 )
    return (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v7 - 3) + 8LL))(*((_QWORD *)v7 - 3));
  return result;
}
