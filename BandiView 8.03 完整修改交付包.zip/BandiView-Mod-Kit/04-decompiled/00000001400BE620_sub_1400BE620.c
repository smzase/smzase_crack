// EA 0x1400be620  name sub_1400BE620  size 604
void __fastcall sub_1400BE620(__int64 a1)
{
  __int64 *v2; // rax
  int *v3; // rbx
  __int64 *v4; // rax
  __int64 v5; // rcx
  __int64 v6; // rax
  __int64 v7; // rdi
  __int16 *v8; // rax
  _BYTE *v9; // rdx
  volatile signed __int32 *v10; // rcx
  volatile signed __int32 *v11; // rsi
  __int64 v12; // rbx
  _QWORD *v13; // rdx
  __int64 *v14; // rax
  _QWORD v15[5]; // [rsp+30h] [rbp-28h] BYREF
  int **v16; // [rsp+68h] [rbp+10h] BYREF
  int *v17; // [rsp+70h] [rbp+18h] BYREF
  int *v18; // [rsp+78h] [rbp+20h] BYREF

  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  v3 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  v18 = v3;
  v16 = &v17;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v17 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( (unsigned __int8)sub_14005F980(&v17, (__int64)L"GetDirectory") == 0 )
    sub_14005FCF0(&v17, L"GetDirectory", 12);
  sub_1400A5990(&v16, &v17);
  v6 = sub_1401C5640(v5);
  v7 = sub_1401C81E0(v6, L"TEXT_MSG_SET_TEMP_PATH", L"TEXT");
  v8 = sub_140075FE0();
  v9 = *(_BYTE **)sub_1400703B0(v15, *(_QWORD *)(a1 + 8), *((_QWORD *)v8 + 61), v7);
  v10 = (volatile signed __int32 *)(v9 - 24);
  v11 = v3 - 6;
  if ( v9 - 24 != (_BYTE *)(v3 - 6) )
  {
    if ( *((int *)v11 + 4) >= 0 && *(_QWORD *)v10 == *(_QWORD *)v11 )
    {
      v12 = sub_14005F710(v10);
      if ( _InterlockedExchangeAdd(v11 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v11 + 8LL))(*(_QWORD *)v11, v11);
      v3 = (int *)(v12 + 24);
      v18 = v3;
    }
    else
    {
      sub_14005FCF0(&v18, v9, *((_DWORD *)v9 - 4));
      v3 = v18;
    }
  }
  v13 = (_QWORD *)(v15[0] - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v15[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v13 + 8LL))(*v13);
  if ( *(v3 - 4) != 0 )
  {
    sub_14005FCF0((int **)&qword_140709C30, &Data, 0);
    v15[0] = &v17;
    v17 = (int *)(sub_14005F710(v3 - 6) + 24);
    v15[1] = &v16;
    v14 = sub_1400601C0();
    if ( v14 == nullptr )
      sub_14005FF30(0x80004005);
    v16 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
    if ( (unsigned __int8)sub_14005F980(&v16, (__int64)L"EDIT_TEMP_FOLDER") == 0 )
      sub_14005FCF0((int **)&v16, L"EDIT_TEMP_FOLDER", 16);
    sub_1401C5020(a1 + 728, &v16, &v17);
  }
  else
  {
    sub_14005FCF0((int **)&qword_140709C30, &Data, 0);
  }
  if ( _InterlockedExchangeAdd(v3 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, int *))(**((_QWORD **)v3 - 3) + 8LL))(*((_QWORD *)v3 - 3), v3 - 6);
}
