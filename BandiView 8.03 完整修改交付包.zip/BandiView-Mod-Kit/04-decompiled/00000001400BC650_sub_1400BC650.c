// EA 0x1400bc650  name sub_1400BC650  size 935
__int64 __fastcall sub_1400BC650(HWND *a1)
{
  __int64 *v2; // rax
  BOOL v3; // esi
  __int64 *v4; // rax
  _QWORD *v5; // rbx
  __int64 v6; // rcx
  __int64 *v7; // rax
  __int64 v8; // rax
  __int64 *v9; // rax
  BOOL v10; // ebx
  __int64 *v11; // rax
  __int64 v12; // rax
  __int64 *v13; // rax
  BOOL v14; // ebx
  __int64 *v15; // rax
  __int64 v16; // rax
  int *v18; // [rsp+48h] [rbp+28h] BYREF
  int **v19; // [rsp+50h] [rbp+30h]

  v19 = &v18;
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  v18 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  if ( (unsigned __int8)sub_14005F980(&v18, (__int64)L"CHK_CACHE_IMAGE") == 0 )
    sub_14005FCF0(&v18, L"CHK_CACHE_IMAGE", 15);
  v3 = sub_1400ACB10((__int64)a1, &v18);
  EnableWindow(a1[15], v3);
  v19 = &v18;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v18 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( (unsigned __int8)sub_14005F980(&v18, (__int64)L"STATIC_CACHESIZE_UNIT") == 0 )
    sub_14005FCF0(&v18, L"STATIC_CACHESIZE_UNIT", 21);
  v5 = (_QWORD *)sub_1401BE5D0(a1 + 91, &v18);
  *((_BYTE *)v5 + 520) = v3;
  (*(void (__fastcall **)(_QWORD *))(*v5 + 264LL))(v5);
  (*(void (__fastcall **)(_QWORD *, _QWORD))(*v5 + 224LL))(v5, 0);
  v6 = v5[66];
  if ( v6 != 0 )
    sub_1401BC8D0(v6, v5 + 33);
  v19 = &v18;
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  v18 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
  if ( (unsigned __int8)sub_14005F980(&v18, (__int64)L"STATIC_CACHESIZE_BG") == 0 )
    sub_14005FCF0(&v18, L"STATIC_CACHESIZE_BG", 19);
  v8 = sub_1401BE5D0(a1 + 91, &v18);
  sub_1401DACD0(v8, !v3);
  v19 = &v18;
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    sub_14005FF30(0x80004005);
  v18 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
  if ( (unsigned __int8)sub_14005F980(&v18, (__int64)L"CHK_WEBTOON_SPACE") == 0 )
    sub_14005FCF0(&v18, L"CHK_WEBTOON_SPACE", 17);
  v10 = sub_1400ACB10((__int64)a1, &v18);
  EnableWindow(a1[12], v10);
  v19 = &v18;
  v11 = sub_1400601C0();
  if ( v11 == nullptr )
    sub_14005FF30(0x80004005);
  v18 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24);
  if ( (unsigned __int8)sub_14005F980(&v18, (__int64)L"STATIC_WEBTOON_SPACE_BG") == 0 )
    sub_14005FCF0(&v18, L"STATIC_WEBTOON_SPACE_BG", 23);
  v12 = sub_1401BE5D0(a1 + 91, &v18);
  sub_1401DACD0(v12, !v10);
  v19 = &v18;
  v13 = sub_1400601C0();
  if ( v13 == nullptr )
    sub_14005FF30(0x80004005);
  v18 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24);
  if ( (unsigned __int8)sub_14005F980(&v18, (__int64)L"CHK_2PAGE_SPACE") == 0 )
    sub_14005FCF0(&v18, L"CHK_2PAGE_SPACE", 15);
  v14 = sub_1400ACB10((__int64)a1, &v18);
  EnableWindow(a1[13], v14);
  v19 = &v18;
  v15 = sub_1400601C0();
  if ( v15 == nullptr )
    sub_14005FF30(0x80004005);
  v18 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
  if ( (unsigned __int8)sub_14005F980(&v18, (__int64)L"STATIC_2PAGE_SPACE_BG") == 0 )
    sub_14005FCF0(&v18, L"STATIC_2PAGE_SPACE_BG", 21);
  v16 = sub_1401BE5D0(a1 + 91, &v18);
  return sub_1401DACD0(v16, !v14);
}
