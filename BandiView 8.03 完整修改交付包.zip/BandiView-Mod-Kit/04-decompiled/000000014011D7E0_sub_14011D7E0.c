// EA 0x14011d7e0  name sub_14011D7E0  size 1012
__int64 __fastcall sub_14011D7E0(__int64 a1)
{
  unsigned int v2; // eax
  __int64 *v3; // rax
  _QWORD *v4; // rbx
  __int64 *v5; // rax
  __int64 v6; // rcx
  __int64 v7; // rax
  _BYTE *v8; // rbx
  __int64 *v9; // rax
  int v10; // eax
  HWND v11; // r14
  volatile signed __int32 *v12; // rcx
  int *v13; // rdi
  __int64 v14; // rsi
  int *v15; // rdx
  int *v16; // rdx
  int *v18; // [rsp+30h] [rbp-D0h] BYREF
  int *v19; // [rsp+38h] [rbp-C8h] BYREF
  int **v20; // [rsp+40h] [rbp-C0h] BYREF
  int **v21; // [rsp+48h] [rbp-B8h]
  LPARAM dwInitParam; // [rsp+50h] [rbp-B0h] BYREF
  int *v23; // [rsp+58h] [rbp-A8h] BYREF
  int v24; // [rsp+68h] [rbp-98h]
  char *v25[4]; // [rsp+110h] [rbp+10h] BYREF
  _QWORD v26[2]; // [rsp+130h] [rbp+30h] BYREF
  __int64 v27; // [rsp+140h] [rbp+40h]
  __int64 v28; // [rsp+148h] [rbp+48h]
  char *v29; // [rsp+158h] [rbp+58h] BYREF
  char v30; // [rsp+389h] [rbp+289h]
  char *v31; // [rsp+390h] [rbp+290h] BYREF
  char *v32[4]; // [rsp+3B0h] [rbp+2B0h] BYREF
  __int64 v33; // [rsp+3D0h] [rbp+2D0h]
  int v34; // [rsp+3D8h] [rbp+2D8h]

  sub_1401513E0(v26);
  sub_14008F4C0(v25);
  sub_140151500(v26, 4, v25);
  sub_14005D410(v25);
  sub_14018CFE0(v26);
  v30 = 0;
  if ( (unsigned __int8)sub_14018D180(v26, v32, 6) != 0
    && ((unsigned int)(v34 - 2) > 2
     || (unsigned __int8)sub_14018D2C0(
                           v26,
                           "CREATE TABLE IF NOT EXISTS _cache_db_ (_key_name_ TEXT PRIMARY KEY UNIQUE, _value_ BLOB, _last_t_ INTEGER); ") != 0
     && (unsigned __int8)sub_14018D2C0(
                           v26,
                           "CREATE UNIQUE INDEX IF NOT EXISTS _idx_key_name_ ON _cache_db_(_key_name_);") != 0) )
  {
    v30 = 1;
  }
  else
  {
    v33 = v27;
    if ( v30 == 0 )
    {
      v33 = 3134259206LL;
LABEL_10:
      v20 = (int **)v33;
      v21 = &v19;
      v4 = (_QWORD *)sub_1401C0850(&v19, &v20);
      v20 = &v18;
      v5 = sub_1400601C0();
      if ( v5 == nullptr )
        sub_14005FF30(0x80004005);
      v18 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
      if ( (unsigned __int8)sub_14005F980(&v18, (__int64)L"filePosCacheMan.ClearAllData() failed. [%s]") == 0 )
        sub_14005FCF0(&v18, L"filePosCacheMan.ClearAllData() failed. [%s]", 43);
      sub_140074840((unsigned __int64 *)&v18, v4, 1);
      goto LABEL_31;
    }
  }
  v18 = nullptr;
  v2 = (*(__int64 (__fastcall **)(__int64, _QWORD, const char *, _QWORD, _QWORD, int **))(*(_QWORD *)v28 + 48LL))(
         v28,
         v26[0],
         "DELETE FROM _cache_db_ ;",
         0,
         0,
         &v18);
  if ( v2 != 0 )
  {
    v3 = (__int64 *)sub_14019A900(&v19, v2);
    v27 = 0;
    v27 = *v3;
    v33 = v27;
    goto LABEL_10;
  }
  sub_14007D7F0(&v19);
  v21 = &v18;
  v7 = sub_1401C5640(v6);
  v8 = (_BYTE *)sub_1401C81E0(v7, L"TEXT_MSG_DELETED", L"TEXT");
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    sub_14005FF30(0x80004005);
  v18 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
  if ( (unsigned __int8)sub_14005F980(&v18, (__int64)v8) == 0 )
  {
    if ( v8 != nullptr )
      v10 = sub_1404ADC20(v8);
    else
      v10 = 0;
    sub_14005FCF0(&v18, v8, v10);
  }
  v21 = &v18;
  v11 = *(HWND *)(a1 + 8);
  sub_14008B4B0(&dwInitParam);
  v24 = 2000;
  v12 = v18 - 6;
  v13 = v23 - 6;
  if ( v18 - 6 != v23 - 6 )
  {
    if ( v13[4] >= 0 && *(_QWORD *)v12 == *(_QWORD *)v13 )
    {
      v14 = sub_14005F710(v12);
      if ( _InterlockedExchangeAdd(v13 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD, int *))(**(_QWORD **)v13 + 8LL))(*(_QWORD *)v13, v13);
      v23 = (int *)(v14 + 24);
    }
    else
    {
      sub_14005FCF0(&v23, v18, *(v18 - 4));
    }
  }
  sub_14008B6C0((LPARAM)&dwInitParam, v11);
  sub_14008B5E0(&dwInitParam);
  v15 = v18 - 6;
  if ( _InterlockedExchangeAdd(v18 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v15 + 8LL))(*(_QWORD *)v15);
  v16 = v19 - 6;
  if ( _InterlockedExchangeAdd(v19 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v16 + 8LL))(*(_QWORD *)v16);
LABEL_31:
  sub_14018CFE0(v26);
  v30 = 0;
  sub_14005D410(v32);
  sub_14005D410(&v31);
  sub_14018CFE0(v26);
  if ( v28 != 0 )
  {
    (**(void (__fastcall ***)(__int64))v28)(v28);
    v28 = 0;
  }
  return sub_14005D410(&v29);
}
