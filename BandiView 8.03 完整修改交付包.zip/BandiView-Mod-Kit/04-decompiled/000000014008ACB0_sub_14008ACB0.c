// EA 0x14008acb0  name sub_14008ACB0  size 287
__int64 __fastcall sub_14008ACB0(_QWORD *a1)
{
  volatile signed __int32 *v1; // rdx
  volatile signed __int32 *v3; // rdx
  volatile signed __int32 *v4; // rdx
  volatile signed __int32 *v5; // rdx
  volatile signed __int32 *v6; // rdx
  volatile signed __int32 *v7; // rdx
  volatile signed __int32 *v8; // rdx
  volatile signed __int32 *v9; // rdx
  signed __int32 v10; // eax
  bool v11; // cc
  __int64 result; // rax
  volatile signed __int32 *v13; // rdx

  v1 = (volatile signed __int32 *)(a1[8] - 24LL);
  if ( _InterlockedExchangeAdd(v1 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v1 + 8LL))(*(_QWORD *)v1);
  v3 = (volatile signed __int32 *)(a1[7] - 24LL);
  if ( _InterlockedExchangeAdd(v3 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v3 + 8LL))(*(_QWORD *)v3);
  v4 = (volatile signed __int32 *)(a1[6] - 24LL);
  if ( _InterlockedExchangeAdd(v4 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v4 + 8LL))(*(_QWORD *)v4);
  v5 = (volatile signed __int32 *)(a1[5] - 24LL);
  if ( _InterlockedExchangeAdd(v5 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v5 + 8LL))(*(_QWORD *)v5);
  v6 = (volatile signed __int32 *)(a1[4] - 24LL);
  if ( _InterlockedExchangeAdd(v6 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v6 + 8LL))(*(_QWORD *)v6);
  v7 = (volatile signed __int32 *)(a1[3] - 24LL);
  if ( _InterlockedExchangeAdd(v7 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v7 + 8LL))(*(_QWORD *)v7);
  v8 = (volatile signed __int32 *)(a1[2] - 24LL);
  if ( _InterlockedExchangeAdd(v8 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v8 + 8LL))(*(_QWORD *)v8);
  v9 = (volatile signed __int32 *)(a1[1] - 24LL);
  v10 = _InterlockedExchangeAdd(v9 + 4, 0xFFFFFFFF);
  v11 = v10 <= 1;
  result = (unsigned int)(v10 - 1);
  if ( v11 )
    result = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v9 + 8LL))(*(_QWORD *)v9);
  v13 = (volatile signed __int32 *)(*a1 - 24LL);
  if ( _InterlockedExchangeAdd(v13 + 4, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v13 + 8LL))(*(_QWORD *)v13);
  return result;
}
