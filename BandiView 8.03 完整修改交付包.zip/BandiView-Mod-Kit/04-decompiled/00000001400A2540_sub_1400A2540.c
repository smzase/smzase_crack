// EA 0x1400a2540  name sub_1400A2540  size 2516
__int64 __fastcall sub_1400A2540(int *a1, int *a2)
{
  __int64 *v4; // rax
  int v5; // eax
  const wchar_t *v6; // r8
  _QWORD *v7; // rbx
  int *v8; // rdx
  LSTATUS v9; // esi
  unsigned __int8 v10; // bl
  __int64 *v11; // rax
  int *v12; // r12
  BYTE *v13; // rbx
  int v14; // esi
  int v15; // eax
  int i; // edi
  BYTE *v17; // rbx
  int v18; // eax
  BYTE *v19; // rbx
  int v20; // eax
  BYTE *v21; // rbx
  int v22; // eax
  BYTE *v23; // rbx
  int v24; // eax
  BYTE *v25; // rbx
  int v26; // eax
  BYTE *v27; // rbx
  int v28; // eax
  _BYTE **v29; // rax
  int **v30; // rdx
  _BYTE **v31; // rax
  int **v32; // rdx
  _BYTE **v33; // rax
  int **v34; // rdx
  _BYTE **v35; // rax
  int **v36; // rdx
  _BYTE **v37; // rax
  int **v38; // rdx
  _BYTE **v39; // rax
  int **v40; // rdx
  int v41; // eax
  int *v43; // [rsp+30h] [rbp-10h] BYREF
  int *cbData; // [rsp+80h] [rbp+40h] BYREF
  int **Type; // [rsp+90h] [rbp+50h] BYREF
  HKEY hKey; // [rsp+98h] [rbp+58h] BYREF

  hKey = nullptr;
  Type = &cbData;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  cbData = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( (unsigned __int8)sub_14005F980(&cbData, (__int64)L"SOFTWARE\\$app$\\l") == 0 )
    sub_14005FCF0(&cbData, L"SOFTWARE\\$app$\\l", 16);
  Type = &cbData;
  v5 = *a1;
  if ( *a1 == 1 )
  {
    v6 = L"BandiView";
  }
  else if ( v5 == 2 )
  {
    v6 = L"Bandizip";
  }
  else
  {
    if ( v5 != 3 )
      goto LABEL_11;
    v6 = L"Honeycam";
  }
  sub_140060D20((unsigned __int64 *)&cbData, (__int64)L"$app$", v6);
LABEL_11:
  v7 = (_QWORD *)sub_14005F710(cbData - 6);
  v8 = cbData - 6;
  if ( _InterlockedExchangeAdd(cbData - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v8 + 8LL))(*(_QWORD *)v8);
  if ( hKey != nullptr )
    RegCloseKey(hKey);
  hKey = nullptr;
  v9 = RegOpenKeyExW(HKEY_LOCAL_MACHINE, (LPCWSTR)v7 + 12, 0, 0x20019u, &hKey);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v7 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, _QWORD *))(*(_QWORD *)*v7 + 8LL))(*v7, v7);
  if ( v9 != 0 )
  {
    a2[1] = 0;
    *a2 = -1159777792;
    v10 = 0;
    goto LABEL_105;
  }
  v11 = sub_1400601C0();
  if ( v11 == nullptr )
    sub_14005FF30(0x80004005);
  v12 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24);
  v43 = v12;
  if ( hKey != nullptr )
  {
    LODWORD(cbData) = 0;
    LODWORD(Type) = 1;
    RegQueryValueExW(hKey, L"g", nullptr, (LPDWORD)&Type, nullptr, (LPDWORD)&cbData);
    if ( (_DWORD)cbData != 0 && ((unsigned int)((_DWORD)Type - 1) <= 1 || (_DWORD)Type == 7) )
    {
      v13 = (BYTE *)j__calloc_base(1u, (unsigned int)cbData + 2LL);
      if ( v13 != nullptr )
      {
        v14 = 0;
        if ( RegQueryValueExW(hKey, L"g", nullptr, (LPDWORD)&Type, v13, (LPDWORD)&cbData) == 0 )
        {
          v15 = sub_1404ADC20(v13);
          sub_14005FCF0(&v43, v13, v15);
          v14 = 1;
          v12 = v43;
        }
        j__free_base(v13);
        if ( v14 != 0 )
        {
          if ( (unsigned int)(*(v12 - 4) - 32) >= 2 )
          {
            v41 = -1159777791;
LABEL_101:
            a2[1] = 0;
            *a2 = v41;
            goto LABEL_102;
          }
          for ( i = 0; i < 16; ++i )
          {
            sub_14006B720((wchar_t *)&v12[i], (wchar_t *)L"%02x", &cbData);
            *((_BYTE *)a1 + (unsigned int)i + 48) = (_BYTE)cbData;
          }
          LODWORD(cbData) = sub_1400CCC00();
          sub_1400CE3B0(a1 + 12, 16, &cbData, 4);
          if ( hKey != nullptr )
          {
            LODWORD(cbData) = 0;
            LODWORD(Type) = 1;
            RegQueryValueExW(hKey, L"l", nullptr, (LPDWORD)&Type, nullptr, (LPDWORD)&cbData);
            if ( (_DWORD)cbData != 0 && ((unsigned int)((_DWORD)Type - 1) <= 1 || (_DWORD)Type == 7) )
            {
              v17 = (BYTE *)j__calloc_base(1u, (unsigned int)cbData + 2LL);
              if ( v17 != nullptr )
              {
                if ( RegQueryValueExW(hKey, L"l", nullptr, (LPDWORD)&Type, v17, (LPDWORD)&cbData) == 0 )
                {
                  v18 = sub_1404ADC20(v17);
                  sub_14005FCF0((int **)a1 + 1, v17, v18);
                }
                j__free_base(v17);
              }
            }
            if ( hKey != nullptr )
            {
              LODWORD(cbData) = 0;
              LODWORD(Type) = 1;
              RegQueryValueExW(hKey, L"k", nullptr, (LPDWORD)&Type, nullptr, (LPDWORD)&cbData);
              if ( (_DWORD)cbData != 0 && ((unsigned int)((_DWORD)Type - 1) <= 1 || (_DWORD)Type == 7) )
              {
                v19 = (BYTE *)j__calloc_base(1u, (unsigned int)cbData + 2LL);
                if ( v19 != nullptr )
                {
                  if ( RegQueryValueExW(hKey, L"k", nullptr, (LPDWORD)&Type, v19, (LPDWORD)&cbData) == 0 )
                  {
                    v20 = sub_1404ADC20(v19);
                    sub_14005FCF0((int **)a1 + 3, v19, v20);
                  }
                  j__free_base(v19);
                }
              }
              if ( hKey != nullptr )
              {
                LODWORD(cbData) = 0;
                LODWORD(Type) = 1;
                RegQueryValueExW(hKey, L"h", nullptr, (LPDWORD)&Type, nullptr, (LPDWORD)&cbData);
                if ( (_DWORD)cbData != 0 && ((unsigned int)((_DWORD)Type - 1) <= 1 || (_DWORD)Type == 7) )
                {
                  v21 = (BYTE *)j__calloc_base(1u, (unsigned int)cbData + 2LL);
                  if ( v21 != nullptr )
                  {
                    if ( RegQueryValueExW(hKey, L"h", nullptr, (LPDWORD)&Type, v21, (LPDWORD)&cbData) == 0 )
                    {
                      v22 = sub_1404ADC20(v21);
                      sub_14005FCF0((int **)a1 + 4, v21, v22);
                    }
                    j__free_base(v21);
                  }
                }
                if ( hKey != nullptr )
                {
                  LODWORD(cbData) = 0;
                  LODWORD(Type) = 1;
                  RegQueryValueExW(hKey, L"P", nullptr, (LPDWORD)&Type, nullptr, (LPDWORD)&cbData);
                  if ( (_DWORD)cbData != 0 && ((unsigned int)((_DWORD)Type - 1) <= 1 || (_DWORD)Type == 7) )
                  {
                    v23 = (BYTE *)j__calloc_base(1u, (unsigned int)cbData + 2LL);
                    if ( v23 != nullptr )
                    {
                      if ( RegQueryValueExW(hKey, L"P", nullptr, (LPDWORD)&Type, v23, (LPDWORD)&cbData) == 0 )
                      {
                        v24 = sub_1404ADC20(v23);
                        sub_14005FCF0((int **)a1 + 5, v23, v24);
                      }
                      j__free_base(v23);
                    }
                  }
                  if ( hKey != nullptr )
                  {
                    LODWORD(cbData) = 0;
                    LODWORD(Type) = 1;
                    RegQueryValueExW(hKey, L"m", nullptr, (LPDWORD)&Type, nullptr, (LPDWORD)&cbData);
                    if ( (_DWORD)cbData != 0 && ((unsigned int)((_DWORD)Type - 1) <= 1 || (_DWORD)Type == 7) )
                    {
                      v25 = (BYTE *)j__calloc_base(1u, (unsigned int)cbData + 2LL);
                      if ( v25 != nullptr )
                      {
                        if ( RegQueryValueExW(hKey, L"m", nullptr, (LPDWORD)&Type, v25, (LPDWORD)&cbData) == 0 )
                        {
                          v26 = sub_1404ADC20(v25);
                          sub_14005FCF0((int **)a1 + 8, v25, v26);
                        }
                        j__free_base(v25);
                      }
                    }
                    if ( hKey != nullptr )
                    {
                      LODWORD(cbData) = 0;
                      LODWORD(Type) = 1;
                      RegQueryValueExW(hKey, L"t", nullptr, (LPDWORD)&Type, nullptr, (LPDWORD)&cbData);
                      if ( (_DWORD)cbData != 0 && ((unsigned int)((_DWORD)Type - 1) <= 1 || (_DWORD)Type == 7) )
                      {
                        v27 = (BYTE *)j__calloc_base(1u, (unsigned int)cbData + 2LL);
                        if ( v27 != nullptr )
                        {
                          if ( RegQueryValueExW(hKey, L"t", nullptr, (LPDWORD)&Type, v27, (LPDWORD)&cbData) == 0 )
                          {
                            v28 = sub_1404ADC20(v27);
                            sub_14005FCF0((int **)a1 + 9, v27, v28);
                          }
                          j__free_base(v27);
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          cbData = (int *)(sub_14005F710((volatile signed __int32 *)(*((_QWORD *)a1 + 1) - 24LL)) + 24);
          v29 = (_BYTE **)sub_1400C91A0(&Type, &cbData, a1 + 12, 16);
          sub_14006B500((int **)a1 + 1, v29);
          v30 = Type - 3;
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)Type - 2, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(int *))(*(_QWORD *)*v30 + 8LL))(*v30);
          cbData = (int *)(sub_14005F710((volatile signed __int32 *)(*((_QWORD *)a1 + 3) - 24LL)) + 24);
          v31 = (_BYTE **)sub_1400C91A0(&Type, &cbData, a1 + 12, 16);
          sub_14006B500((int **)a1 + 3, v31);
          v32 = Type - 3;
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)Type - 2, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(int *))(*(_QWORD *)*v32 + 8LL))(*v32);
          cbData = (int *)(sub_14005F710((volatile signed __int32 *)(*((_QWORD *)a1 + 4) - 24LL)) + 24);
          v33 = (_BYTE **)sub_1400C91A0(&Type, &cbData, a1 + 12, 16);
          sub_14006B500((int **)a1 + 4, v33);
          v34 = Type - 3;
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)Type - 2, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(int *))(*(_QWORD *)*v34 + 8LL))(*v34);
          cbData = (int *)(sub_14005F710((volatile signed __int32 *)(*((_QWORD *)a1 + 5) - 24LL)) + 24);
          v35 = (_BYTE **)sub_1400C91A0(&Type, &cbData, a1 + 12, 16);
          sub_14006B500((int **)a1 + 5, v35);
          v36 = Type - 3;
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)Type - 2, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(int *))(*(_QWORD *)*v36 + 8LL))(*v36);
          cbData = (int *)(sub_14005F710((volatile signed __int32 *)(*((_QWORD *)a1 + 8) - 24LL)) + 24);
          v37 = (_BYTE **)sub_1400C91A0(&Type, &cbData, a1 + 12, 16);
          sub_14006B500((int **)a1 + 8, v37);
          v38 = Type - 3;
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)Type - 2, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(int *))(*(_QWORD *)*v38 + 8LL))(*v38);
          cbData = (int *)(sub_14005F710((volatile signed __int32 *)(*((_QWORD *)a1 + 9) - 24LL)) + 24);
          v39 = (_BYTE **)sub_1400C91A0(&Type, &cbData, a1 + 12, 16);
          sub_14006B500((int **)a1 + 9, v39);
          v40 = Type - 3;
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)Type - 2, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(int *))(*(_QWORD *)*v40 + 8LL))(*v40);
          if ( *(_DWORD *)(*((_QWORD *)a1 + 1) - 16LL) != 0
            && *(_DWORD *)(*((_QWORD *)a1 + 3) - 16LL) != 0
            && *(_DWORD *)(*((_QWORD *)a1 + 4) - 16LL) != 0
            && *(_DWORD *)(*((_QWORD *)a1 + 5) - 16LL) != 0
            && *(_DWORD *)(*((_QWORD *)a1 + 8) - 16LL) != 0
            && *(_DWORD *)(*((_QWORD *)a1 + 9) - 16LL) != 0 )
          {
            v10 = 1;
            goto LABEL_103;
          }
          sub_14005FA90((int **)a1 + 1);
          sub_14005FA90((int **)a1 + 2);
          sub_14005FA90((int **)a1 + 4);
          sub_14005FA90((int **)a1 + 5);
          sub_14005FA90((int **)a1 + 8);
          sub_14005FA90((int **)a1 + 9);
          *((_OWORD *)a1 + 3) = 0;
LABEL_102:
          v10 = 0;
LABEL_103:
          if ( _InterlockedExchangeAdd(v12 - 2, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v12 - 3) + 8LL))(*((_QWORD *)v12 - 3));
LABEL_105:
          if ( hKey != nullptr )
            RegCloseKey(hKey);
          return v10;
        }
      }
    }
  }
  v41 = -1159778047;
  goto LABEL_101;
}
