// EA 0x1400a0db0  name sub_1400A0DB0  size 1594
__int64 __fastcall sub_1400A0DB0(__int64 a1)
{
  __int64 *v2; // rax
  _QWORD *v3; // rbx
  int *v4; // rdx
  LSTATUS v5; // r14d
  unsigned __int8 v6; // bl
  __int64 *v7; // rax
  int *v8; // rbx
  BYTE *v9; // r14
  int v10; // eax
  _BYTE **v11; // rax
  int **v12; // rdx
  __int64 v13; // r13
  unsigned int v14; // r15d
  BYTE *v15; // r14
  int v16; // eax
  volatile signed __int32 *v17; // r14
  __int64 *v18; // rax
  __int64 *v19; // rax
  __int64 *v20; // rax
  char v21; // al
  __int64 v22; // rbx
  __int64 v23; // rdx
  _QWORD *v24; // rdx
  _QWORD *v25; // rdx
  _QWORD *v27; // rdx
  __int64 *v28; // rax
  __int64 *v29; // rax
  HKEY hKey; // [rsp+30h] [rbp-40h] BYREF
  int *v31; // [rsp+38h] [rbp-38h] BYREF
  _QWORD v32[3]; // [rsp+40h] [rbp-30h] BYREF
  __int64 v33; // [rsp+58h] [rbp-18h] BYREF
  __int64 v34; // [rsp+60h] [rbp-10h]
  __int64 v35; // [rsp+68h] [rbp-8h]
  int *cbData; // [rsp+B8h] [rbp+48h] BYREF
  int **Type; // [rsp+C0h] [rbp+50h] BYREF
  int **p_cbData; // [rsp+C8h] [rbp+58h] BYREF

  hKey = nullptr;
  Type = &cbData;
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  cbData = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  if ( (unsigned __int8)sub_14005F980(&cbData, (__int64)L"SOFTWARE\\$app$\\s") == 0 )
    sub_14005FCF0(&cbData, L"SOFTWARE\\$app$\\s", 16);
  Type = &cbData;
  sub_140060D20((unsigned __int64 *)&cbData, (__int64)L"$app$", L"BandiView");
  v3 = (_QWORD *)sub_14005F710(cbData - 6);
  v4 = cbData - 6;
  if ( _InterlockedExchangeAdd(cbData - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v4 + 8LL))(*(_QWORD *)v4);
  hKey = nullptr;
  v5 = RegOpenKeyExW(HKEY_CURRENT_USER, (LPCWSTR)v3 + 12, 0, 0x20019u, &hKey);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v3 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, _QWORD *))(*(_QWORD *)*v3 + 8LL))(*v3, v3);
  if ( v5 != 0 )
  {
    *(_DWORD *)(a1 + 4) = 0;
    *(_DWORD *)a1 = -1159777790;
    v6 = 0;
    goto LABEL_47;
  }
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  v8 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
  v31 = v8;
  LODWORD(p_cbData) = sub_1400CCC00();
  if ( hKey != nullptr )
  {
    LODWORD(cbData) = 0;
    LODWORD(Type) = 1;
    RegQueryValueExW(hKey, L"d", nullptr, (LPDWORD)&Type, nullptr, (LPDWORD)&cbData);
    if ( (_DWORD)cbData != 0 && ((unsigned int)((_DWORD)Type - 1) <= 1 || (_DWORD)Type == 7) )
    {
      v9 = (BYTE *)j__calloc_base(1u, (unsigned int)cbData + 2LL);
      if ( v9 != nullptr )
      {
        if ( RegQueryValueExW(hKey, L"d", nullptr, (LPDWORD)&Type, v9, (LPDWORD)&cbData) == 0 )
        {
          v10 = sub_1404ADC20(v9);
          sub_14005FCF0(&v31, v9, v10);
          v8 = v31;
        }
        j__free_base(v9);
      }
    }
  }
  cbData = (int *)(sub_14005F710(v8 - 6) + 24);
  v11 = (_BYTE **)sub_1400C91A0(&Type, &cbData, &p_cbData, 4);
  sub_14006B500((int **)(a1 + 16), v11);
  v12 = Type - 3;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)Type - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(int *))(*(_QWORD *)*v12 + 8LL))(*v12);
  v13 = *(_QWORD *)(a1 + 16);
  v14 = 2 * *(_DWORD *)(v13 - 16);
  if ( hKey != nullptr )
  {
    LODWORD(cbData) = 0;
    LODWORD(Type) = 1;
    RegQueryValueExW(hKey, L"r", nullptr, (LPDWORD)&Type, nullptr, (LPDWORD)&cbData);
    if ( (_DWORD)cbData != 0 && ((unsigned int)((_DWORD)Type - 1) <= 1 || (_DWORD)Type == 7) )
    {
      v15 = (BYTE *)j__calloc_base(1u, (unsigned int)cbData + 2LL);
      if ( v15 != nullptr )
      {
        if ( RegQueryValueExW(hKey, L"r", nullptr, (LPDWORD)&Type, v15, (LPDWORD)&cbData) == 0 )
        {
          v16 = sub_1404ADC20(v15);
          sub_14005FCF0(&v31, v15, v16);
          v8 = v31;
        }
        j__free_base(v15);
      }
    }
  }
  v17 = v8 - 6;
  Type = (int **)(sub_14005F710(v8 - 6) + 24);
  sub_1400C91A0(v32, &Type, v13, v14);
  v33 = 0;
  v18 = sub_1400601C0();
  if ( v18 == nullptr )
    sub_14005FF30(0x80004005);
  v34 = (*(__int64 (__fastcall **)(__int64 *))(*v18 + 24))(v18) + 24;
  v19 = sub_1400601C0();
  if ( v19 == nullptr )
    sub_14005FF30(0x80004005);
  v35 = (*(__int64 (__fastcall **)(__int64 *))(*v19 + 24))(v19) + 24;
  v32[1] = &cbData;
  v20 = sub_1400601C0();
  if ( v20 == nullptr )
    sub_14005FF30(0x80004005);
  cbData = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v20 + 24))(v20) + 24);
  if ( (unsigned __int8)sub_14005F980(&cbData, (__int64)L"test_plan") == 0 )
    sub_14005FCF0(&cbData, L"test_plan", 9);
  p_cbData = (int **)(sub_14005F710((volatile signed __int32 *)(v32[0] - 24LL)) + 24);
  v21 = sub_1400CD4C0(&p_cbData, &cbData, &v33, a1);
  v22 = v34;
  if ( v21 != 0 )
  {
    v23 = *(_QWORD *)(a1 + 16);
    if ( v23 == 0 )
      sub_14005FF30(0x80004005);
    if ( (unsigned int)sub_1404D8590(v34, v23) == 0 )
    {
      *(_QWORD *)(a1 + 8) = v33;
      v27 = (_QWORD *)(v35 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v35 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v27 + 8LL))(*v27);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v22 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v22 - 24) + 8LL))(*(_QWORD *)(v22 - 24));
      if ( *(_QWORD *)(a1 + 8) != 0 && *(_QWORD *)(a1 + 8) >= unknown_libname_553(0) )
      {
        p_cbData = &cbData;
        v28 = sub_1400601C0();
        if ( v28 == nullptr )
          sub_14005FF30(0x80004005);
        cbData = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24);
        if ( (unsigned __int8)sub_14005F980(&cbData, (__int64)L"SUB") == 0 )
          sub_14005FCF0(&cbData, L"SUB", 3);
      }
      else
      {
        p_cbData = &cbData;
        v29 = sub_1400601C0();
        if ( v29 == nullptr )
          sub_14005FF30(0x80004005);
        cbData = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v29 + 24))(v29) + 24);
        if ( (unsigned __int8)sub_14005F980(&cbData, (__int64)L"TRI") == 0 )
          sub_14005FCF0(&cbData, L"TRI", 3);
      }
      sub_1400A0860(&cbData);
      v6 = 1;
      goto LABEL_43;
    }
    *(_DWORD *)(a1 + 4) = 0;
    *(_DWORD *)a1 = -1159773695;
  }
  v24 = (_QWORD *)(v35 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v35 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v24 + 8LL))(*v24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v22 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v22 - 24) + 8LL))(*(_QWORD *)(v22 - 24));
  v6 = 0;
LABEL_43:
  v25 = (_QWORD *)(v32[0] - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v32[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v25 + 8LL))(*v25);
  if ( _InterlockedExchangeAdd(v17 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v17 + 8LL))(*(_QWORD *)v17, v17);
LABEL_47:
  if ( hKey != nullptr )
    RegCloseKey(hKey);
  return v6;
}
