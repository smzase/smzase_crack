// EA 0x1400bed70  name sub_1400BED70  size 1395
__int64 __fastcall sub_1400BED70(__int64 a1)
{
  __int64 *v2; // rax
  __int64 v3; // rcx
  __int64 v4; // rax
  const void *v5; // rax
  int *v6; // rdx
  __int64 *v7; // rax
  _QWORD *v8; // rax
  int *v9; // rdx
  int *v10; // rdi
  HWND v11; // rbx
  _QWORD *v12; // rax
  __int64 v13; // rcx
  __int64 *v14; // rax
  int *v15; // rbx
  volatile signed __int32 *v16; // rcx
  volatile signed __int32 *v17; // r14
  __int64 v18; // rdi
  int v19; // ebx
  int *v20; // rdx
  __int64 *v21; // rax
  _BYTE *v22; // rdx
  volatile signed __int32 *v23; // rcx
  volatile signed __int32 *v24; // rbx
  __int64 v25; // rdi
  int *v26; // rdx
  __int16 *v27; // rbx
  __int64 *v28; // rax
  int v29; // eax
  int v30; // edx
  signed __int32 v31; // eax
  bool v32; // cc
  __int64 result; // rax
  _QWORD *v34; // rdx
  int *v35; // [rsp+20h] [rbp-E0h] BYREF
  int *v36; // [rsp+28h] [rbp-D8h] BYREF
  int *v37; // [rsp+30h] [rbp-D0h] BYREF
  __int64 v38; // [rsp+38h] [rbp-C8h] BYREF
  int **v39; // [rsp+40h] [rbp-C0h]
  _QWORD v40[3]; // [rsp+48h] [rbp-B8h] BYREF
  _QWORD v41[6]; // [rsp+60h] [rbp-A0h]
  __int128 v42; // [rsp+90h] [rbp-70h]
  __int128 v43; // [rsp+A0h] [rbp-60h]
  const wchar_t *v44; // [rsp+B0h] [rbp-50h]
  _QWORD v45[10]; // [rsp+C0h] [rbp-40h] BYREF
  const wchar_t *v46; // [rsp+110h] [rbp+10h]
  HWND ActiveWindow; // [rsp+118h] [rbp+18h]
  int v48; // [rsp+120h] [rbp+20h]
  void *Block; // [rsp+128h] [rbp+28h]
  __int64 v50; // [rsp+130h] [rbp+30h]
  int v51; // [rsp+138h] [rbp+38h]

  LODWORD(v35) = 0;
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  v36 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  if ( (unsigned __int8)sub_14005F980(&v36, (__int64)L"(*.reg)") == 0 )
    sub_14005FCF0(&v36, L"(*.reg)", 7);
  v4 = sub_1401C5640(v3);
  v5 = (const void *)sub_1401C81E0(v4, L"TEXT_REGISTRY_FILE", L"IDD_SETTING_ETC");
  sub_1400609A0(&v38, v5, (const void **)&v36);
  v6 = v36 - 6;
  if ( _InterlockedExchangeAdd(v36 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v6 + 8LL))(*(_QWORD *)v6);
  v40[0] = v38;
  v40[1] = L"*.reg";
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  v36 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
  v8 = (_QWORD *)sub_14006E090(&v37);
  sub_14005EB50((__int64)&v36, (__int64)L"BandiView Settings - %s.reg", *v8);
  v9 = v37 - 6;
  if ( _InterlockedExchangeAdd(v37 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v9 + 8LL))(*(_QWORD *)v9);
  *((_QWORD *)&v43 + 1) = L"All Files(*.*)";
  v44 = L"*.*";
  LOBYTE(v41[0]) = 0;
  v41[3] = &Data;
  *(_OWORD *)&v41[4] = 0;
  *(_QWORD *)&v43 = 0;
  BYTE8(v42) = 1;
  v41[1] = v40;
  v41[2] = 0x100000001LL;
  v10 = v36;
  *(_QWORD *)&v42 = v36;
  HIDWORD(v42) = 34826;
  v11 = *(HWND *)(a1 + 8);
  qmemcpy(v45, v41, 32);
  *(_OWORD *)&v45[4] = 0;
  *(_OWORD *)&v45[6] = v42;
  *(_OWORD *)&v45[8] = v43;
  v46 = L"*.*";
  Block = nullptr;
  v50 = 0;
  v12 = operator new(0x18u);
  *v12 = v12;
  v12[1] = v12;
  Block = v12;
  v51 = 0;
  if ( v11 != nullptr )
    ActiveWindow = v11;
  else
    ActiveWindow = GetActiveWindow();
  v48 = 0;
  if ( (unsigned int)sub_140121B00(v45) != 0 )
  {
    v14 = sub_1400601C0();
    if ( v14 == nullptr )
      sub_14005FF30(0x80004005);
    v15 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
    v37 = v15;
    LODWORD(v35) = 1;
    if ( v50 != 0 )
    {
      sub_14006B500(&v37, (_BYTE **)(*(_QWORD *)Block + 16LL));
      v15 = v37;
    }
    v16 = v15 - 6;
    v17 = v10 - 6;
    if ( v15 - 6 != v10 - 6 )
    {
      if ( *((int *)v17 + 4) >= 0 && *(_QWORD *)v16 == *(_QWORD *)v17 )
      {
        v18 = sub_14005F710(v16);
        if ( _InterlockedExchangeAdd(v17 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v17 + 8LL))(*(_QWORD *)v17, v17);
        v10 = (int *)(v18 + 24);
        v36 = v10;
      }
      else
      {
        sub_14005FCF0(&v36, v15, *(v15 - 4));
        v10 = v36;
      }
    }
    if ( _InterlockedExchangeAdd(v15 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v15 - 3) + 8LL))(*((_QWORD *)v15 - 3));
    v19 = **(unsigned __int16 **)sub_14006EFC0(&v37, v10);
    v20 = v37 - 6;
    if ( _InterlockedExchangeAdd(v37 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v20 + 8LL))(*(_QWORD *)v20);
    if ( v19 == 0 )
    {
      v39 = &v35;
      v21 = sub_1400601C0();
      if ( v21 == nullptr )
        sub_14005FF30(0x80004005);
      v35 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v21 + 24))(v21) + 24);
      if ( (unsigned __int8)sub_14005F980(&v35, (__int64)L".reg") == 0 )
        sub_14005FCF0(&v35, L".reg", 4);
      v22 = *(_BYTE **)sub_140070E00(&v37, &v36, &v35);
      v23 = (volatile signed __int32 *)(v22 - 24);
      v24 = v10 - 6;
      if ( v22 - 24 != (_BYTE *)(v10 - 6) )
      {
        if ( *((int *)v24 + 4) >= 0 && *(_QWORD *)v23 == *(_QWORD *)v24 )
        {
          v25 = sub_14005F710(v23);
          if ( _InterlockedExchangeAdd(v24 + 4, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v24 + 8LL))(*(_QWORD *)v24, v24);
          v10 = (int *)(v25 + 24);
          v36 = v10;
        }
        else
        {
          sub_14005FCF0(&v36, v22, *((_DWORD *)v22 - 4));
          v10 = v36;
        }
      }
      v26 = v37 - 6;
      if ( _InterlockedExchangeAdd(v37 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v26 + 8LL))(*(_QWORD *)v26);
    }
    sub_1400AC6A0(a1);
    v27 = sub_140075FE0();
    v39 = &v35;
    v28 = sub_1400601C0();
    if ( v10 != nullptr )
    {
      if ( v28 == nullptr )
        sub_14005FF30(0x80004005);
      v35 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24);
      if ( (unsigned __int8)sub_14005F980(&v35, (__int64)v10) == 0 )
      {
        v29 = sub_1404ADC20(v10);
        sub_14005FCF0(&v35, v10, v29);
      }
      v30 = 2;
    }
    else
    {
      if ( v28 == nullptr )
        sub_14005FF30(0x80004005);
      v35 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24);
      if ( (unsigned __int8)sub_14005F980(&v35, (__int64)&Data) == 0 )
        sub_14005FCF0(&v35, &Data, 0);
      v30 = 1;
    }
    sub_140076F50((__int64)v27, v30, &v35);
  }
  sub_140065D40(v13, (_QWORD **)Block);
  j_j_j__free_base(Block);
  v31 = _InterlockedExchangeAdd(v10 - 2, 0xFFFFFFFF);
  v32 = v31 <= 1;
  result = (unsigned int)(v31 - 1);
  if ( v32 )
    result = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v10 - 3) + 8LL))(*((_QWORD *)v10 - 3));
  v34 = (_QWORD *)(v38 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v38 - 24 + 16), 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v34 + 8LL))(*v34);
  return result;
}
