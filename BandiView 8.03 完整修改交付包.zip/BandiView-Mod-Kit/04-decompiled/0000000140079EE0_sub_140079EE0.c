// EA 0x140079ee0  name sub_140079EE0  size 535
__int64 __fastcall sub_140079EE0(__int64 a1, __int64 a2)
{
  __int64 v2; // rdi
  __int64 v4; // r14
  __int64 result; // rax
  unsigned int v6; // ebx
  int i; // r12d
  __int64 *v8; // rax
  __int64 *v9; // rax
  volatile signed __int32 *v10; // rax
  __int64 v11; // r13
  __int64 *v12; // rax
  volatile signed __int32 *v13; // r15
  unsigned __int64 v14; // rax
  __int64 v15; // rdi
  __int64 v16; // rsi
  signed __int32 v17; // eax
  bool v18; // cc
  int v19; // [rsp+28h] [rbp-40h] BYREF
  __int64 v20; // [rsp+30h] [rbp-38h]
  int v21; // [rsp+38h] [rbp-30h]
  __int128 v22; // [rsp+40h] [rbp-28h] BYREF
  __int64 v23; // [rsp+50h] [rbp-18h]
  __int64 v24; // [rsp+58h] [rbp-10h]
  __int64 v25; // [rsp+B0h] [rbp+48h] BYREF
  __int64 v26; // [rsp+B8h] [rbp+50h]
  __int64 v27; // [rsp+C0h] [rbp+58h] BYREF
  volatile signed __int32 *v28; // [rsp+C8h] [rbp+60h] BYREF

  v26 = a2;
  v2 = a2;
  LODWORD(v25) = 0;
  sub_14009B760(a2, L"userKeys.count", &v25, 0);
  v4 = a1 + 280;
  result = sub_14007A100(v4);
  v6 = 0;
  for ( i = v25; (int)v6 < i; v2 = v26 )
  {
    v8 = sub_1400601C0();
    if ( v8 == nullptr )
      sub_14005FF30(0x80004005);
    v25 = (*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24;
    sub_14005EB50((__int64)&v25, (__int64)L"%s.%d", L"userKeys", v6);
    v9 = sub_1400601C0();
    if ( v9 == nullptr )
      sub_14005FF30(0x80004005);
    v10 = (volatile signed __int32 *)(*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9);
    v28 = v10 + 6;
    v11 = v25;
    v27 = sub_14005F710(v10) + 24;
    sub_14009B860(v2, v11, &v28, &v27);
    v19 = 1;
    v12 = sub_1400601C0();
    if ( v12 == nullptr )
      sub_14005FF30(0x80004005);
    v20 = (*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24;
    v21 = 0;
    v13 = v28;
    v22 = 0;
    v23 = 0;
    v24 = 0;
    v14 = sub_1404ADC20(v28);
    sub_140061270((char **)&v22, (const void *)v13, v14);
    sub_14009D7C0(&v22, &v19);
    v15 = *(_QWORD *)(v4 + 8);
    if ( v15 == *(_QWORD *)(v4 + 16) )
    {
      sub_14007A3B0(v4, *(_QWORD *)(v4 + 8), &v19);
      v16 = v20;
    }
    else
    {
      *(_DWORD *)v15 = v19;
      v16 = v20;
      *(_QWORD *)(v15 + 8) = sub_14005F710((volatile signed __int32 *)(v20 - 24)) + 24;
      *(_DWORD *)(v15 + 16) = v21;
      *(_QWORD *)(v4 + 8) += 24LL;
    }
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v16 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v16 - 24) + 8LL))(*(_QWORD *)(v16 - 24));
    if ( _InterlockedExchangeAdd(v13 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v13 - 3) + 8LL))(*((_QWORD *)v13 - 3));
    v17 = _InterlockedExchangeAdd((volatile signed __int32 *)(v11 - 24 + 16), 0xFFFFFFFF);
    v18 = v17 <= 1;
    result = (unsigned int)(v17 - 1);
    if ( v18 )
      result = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(v11 - 24) + 8LL))(*(_QWORD *)(v11 - 24));
    ++v6;
  }
  return result;
}
