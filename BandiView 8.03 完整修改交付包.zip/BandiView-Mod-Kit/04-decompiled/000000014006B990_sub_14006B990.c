// EA 0x14006b990  name sub_14006B990  size 753
char __fastcall sub_14006B990(__int64 a1, LPCWSTR *a2, __int64 a3, __int64 a4)
{
  __int64 v8; // rcx
  HMODULE LibraryW; // rax
  unsigned __int8 (*ProcAddress)(void); // rax
  _QWORD *v11; // rdi
  __int64 *v12; // rax
  __int64 v13; // rcx
  HMENU v14; // rdi
  __int64 v15; // rdx
  __int64 v16; // rcx
  HWND v17; // rbp
  unsigned __int16 v18; // ax
  volatile signed __int32 *v19; // rdx
  FARPROC v20; // rax
  unsigned __int8 (__fastcall ***v21)(_QWORD, __int64, __int64); // rax
  volatile signed __int32 *v22; // rdx
  volatile signed __int32 *v24; // rdx
  struct tagRECT rcDst; // [rsp+60h] [rbp-48h] BYREF
  struct tagRECT v26; // [rsp+70h] [rbp-38h] BYREF
  volatile signed __int32 *v27; // [rsp+B0h] [rbp+8h] BYREF
  LPCWSTR *v28; // [rsp+B8h] [rbp+10h]

  v28 = a2;
  if ( *(_QWORD *)a1 != 0 )
  {
    v8 = *(_QWORD *)(a1 + 16);
    if ( v8 != 0 )
    {
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 16LL))(v8);
      *(_QWORD *)(a1 + 16) = 0;
    }
    FreeLibrary(*(HMODULE *)a1);
    *(_QWORD *)a1 = 0;
  }
  LibraryW = LoadLibraryW(*a2);
  *(_QWORD *)a1 = LibraryW;
  if ( LibraryW == nullptr )
  {
    *(_DWORD *)(a1 + 8) = -1159770112;
LABEL_26:
    *(_DWORD *)(a1 + 12) = 0;
    v22 = (volatile signed __int32 *)(*a2 - 12);
    if ( _InterlockedExchangeAdd(v22 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v22 + 8LL))(*(_QWORD *)v22);
    return 0;
  }
  ProcAddress = (unsigned __int8 (*)(void))GetProcAddress(LibraryW, "WebViewInstalled");
  if ( ProcAddress == nullptr )
  {
    *(_DWORD *)(a1 + 8) = -1159770111;
    goto LABEL_26;
  }
  if ( ProcAddress() != 0 )
  {
    v20 = GetProcAddress(*(HMODULE *)a1, "CreateWebView");
    if ( v20 == nullptr )
    {
      *(_DWORD *)(a1 + 8) = -1159770111;
      goto LABEL_26;
    }
    v21 = (unsigned __int8 (__fastcall ***)(_QWORD, __int64, __int64))((__int64 (__fastcall *)(__int64))v20)(539363617);
    *(_QWORD *)(a1 + 16) = v21;
    if ( v21 == nullptr )
    {
      *(_DWORD *)(a1 + 8) = -1159770109;
      goto LABEL_26;
    }
    if ( (**v21)(v21, a3, a4) == 0 )
    {
      *(_DWORD *)(a1 + 8) = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a1 + 16) + 24LL))(*(_QWORD *)(a1 + 16));
      goto LABEL_26;
    }
  }
  else
  {
    if ( *(_BYTE *)(a3 + 40) == 0 )
    {
      *(_DWORD *)(a1 + 8) = -1159770110;
      goto LABEL_26;
    }
    v11 = operator new(0x60u);
    v11[1] = 0;
    v11[5] = 0;
    v11[6] = 0;
    *((_DWORD *)v11 + 14) = 0;
    v11[8] = DefWindowProcW;
    *v11 = &WebView2InstWnd::`vftable';
    v12 = sub_1400601C0();
    if ( v12 == nullptr )
      sub_14005FF30(0x80004005);
    v11[9] = (*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24;
    v11[10] = 0;
    *((_BYTE *)v11 + 88) = 0;
    *((_DWORD *)v11 + 23) = 0;
    v13 = *(_QWORD *)(a1 + 24);
    *(_QWORD *)(a1 + 24) = v11;
    if ( v13 != 0 )
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v13 + 8LL))(v13, 1);
    v14 = *(HMENU *)(a1 + 24);
    v27 = (volatile signed __int32 *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 32) - 24LL)) + 24);
    CopyRect(&rcDst, (const RECT *)(a3 + 8));
    v17 = *(HWND *)a3;
    v26 = rcDst;
    qword_1406FA5F0 = (__int64)L"WebView2InstWndClass";
    dword_1406FA5B4 = 3;
    qword_1406FA5E0 = 6;
    if ( qword_1406FA600 == 0 )
      qword_1406FA600 = 0;
    v18 = sub_14005F3B0(v16, v15, (__int64)&unk_1406FA5B0, (_QWORD *)v14 + 8);
    sub_14005F250(v14, v17, &v26.left, L"WebView2InstWnd", 0x46000000u, 0, nullptr, v18);
    ShowWindow(*((HWND *)v14 + 1), 5);
    sub_14006B500((int **)v14 + 9, (_BYTE **)&v27);
    *((_QWORD *)v14 + 10) = LoadCursorW(nullptr, (LPCWSTR)0x7F89);
    v19 = v27 - 6;
    if ( _InterlockedExchangeAdd(v27 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v19 + 8LL))(*(_QWORD *)v19);
  }
  v24 = (volatile signed __int32 *)(*a2 - 12);
  if ( _InterlockedExchangeAdd(v24 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v24 + 8LL))(*(_QWORD *)v24);
  return 1;
}
