// EA 0x14006ea30  name sub_14006EA30  size 168
int **__fastcall sub_14006EA30(int **a1)
{
  __int64 *v2; // rax
  int v3; // eax

  if ( dword_1406DC8E8 != 0 )
  {
    GetModuleFileNameW(nullptr, Str, 0x410u);
    wcsrchr(Str, 0x5Cu)[1] = 0;
    dword_1406DC8E8 = 0;
  }
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  if ( (unsigned __int8)sub_14005F980(a1, (__int64)Str) == 0 )
  {
    v3 = sub_1404ADC20(Str);
    sub_14005FCF0(a1, Str, v3);
  }
  return a1;
}
