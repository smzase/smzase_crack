// EA 0x1400c91a0  name sub_1400C91A0  size 909
int **__fastcall sub_1400C91A0(int **a1, __int64 *a2, __int64 a3, unsigned int a4)
{
  unsigned int v6; // ebp
  int v7; // ecx
  __int64 *v8; // rax
  __int64 *v9; // rax
  unsigned __int64 v10; // r15
  _DWORD *v11; // rsi
  __int64 v12; // r12
  __int64 *v13; // rax
  __int64 *v14; // rax
  __int64 *v15; // rax
  __int64 *v16; // rax
  __int64 v17; // r15
  __int64 *v18; // rax
  volatile signed __int32 *v19; // rdx
  _QWORD v21[3]; // [rsp+20h] [rbp-78h] BYREF
  unsigned __int64 v22; // [rsp+38h] [rbp-60h]
  unsigned __int64 v23; // [rsp+40h] [rbp-58h]

  v6 = 0;
  v7 = *(_DWORD *)(*a2 - 16);
  if ( v7 == 0 )
  {
    v8 = sub_1400601C0();
    if ( v8 != nullptr )
    {
      *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24);
      if ( (unsigned __int8)sub_14005F980(a1, (__int64)&Data) == 0 )
        sub_14005FCF0(a1, &Data, 0);
      goto LABEL_38;
    }
LABEL_41:
    sub_14005FF30(0x80004005);
  }
  if ( v7 % 16 == 0 )
  {
    v10 = v7 / 2;
    v11 = j__calloc_base(v10 + 2, 1u);
    v21[2] = v11;
    v23 = v10 + 2;
    v22 = 0;
    if ( v11 != nullptr )
    {
      v22 = v10;
      v12 = *a2;
      if ( (int)v10 > 0 )
      {
        do
        {
          sub_14006B720((wchar_t *)(v12 + 4LL * v6), (wchar_t *)L"%02x", v21);
          *((_BYTE *)v11 + v6++) = v21[0];
        }
        while ( (int)v6 < (int)v10 );
      }
      if ( v10 >= 0x10 )
      {
        sub_1400CE3B0(v11, 16, a3, a4);
        if ( v11[1] == 1 )
        {
          if ( v11[2] <= (unsigned int)(v10 - 16) )
          {
            sub_1400CE3B0(v11 + 4, v10 - 16, a3, a4);
            v16 = sub_1400601C0();
            if ( v16 != nullptr )
            {
              v21[0] = (*(__int64 (__fastcall **)(__int64 *))(*v16 + 24))(v16) + 24;
              if ( (unsigned __int8)sub_14005F980(v21, (__int64)(v11 + 4)) == 0 )
                sub_140073980(v21, v11 + 4);
              v17 = v21[0];
              *a1 = (int *)(sub_14005F710((volatile signed __int32 *)(v21[0] - 24LL)) + 24);
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v17 - 8), 0xFFFFFFFF) <= 1 )
                (*(void (__fastcall **)(_QWORD, __int64))(**(_QWORD **)(v17 - 24) + 8LL))(
                  *(_QWORD *)(v17 - 24),
                  v17 - 24);
              goto LABEL_28;
            }
          }
          else
          {
            v15 = sub_1400601C0();
            if ( v15 != nullptr )
            {
              *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
              if ( (unsigned __int8)sub_14005F980(a1, (__int64)&Data) == 0 )
                sub_14005FCF0(a1, &Data, 0);
              goto LABEL_28;
            }
          }
        }
        else
        {
          v14 = sub_1400601C0();
          if ( v14 != nullptr )
          {
            *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
            if ( (unsigned __int8)sub_14005F980(a1, (__int64)&Data) == 0 )
              sub_14005FCF0(a1, &Data, 0);
            goto LABEL_28;
          }
        }
      }
      else
      {
        v13 = sub_1400601C0();
        if ( v13 != nullptr )
        {
          *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24);
          if ( (unsigned __int8)sub_14005F980(a1, (__int64)&Data) == 0 )
            sub_14005FCF0(a1, &Data, 0);
LABEL_28:
          j__free_base(v11);
          goto LABEL_38;
        }
      }
    }
    else
    {
      v18 = sub_1400601C0();
      if ( v18 != nullptr )
      {
        *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v18 + 24))(v18) + 24);
        if ( (unsigned __int8)sub_14005F980(a1, (__int64)&Data) == 0 )
          sub_14005FCF0(a1, &Data, 0);
        goto LABEL_38;
      }
    }
    sub_14005FF30(0x80004005);
  }
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    goto LABEL_41;
  *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
  if ( (unsigned __int8)sub_14005F980(a1, (__int64)&Data) == 0 )
    sub_14005FCF0(a1, &Data, 0);
LABEL_38:
  v19 = (volatile signed __int32 *)(*a2 - 24);
  if ( _InterlockedExchangeAdd(v19 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v19 + 8LL))(*(_QWORD *)v19);
  return a1;
}
