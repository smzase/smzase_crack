// EA 0x14006dab0  name sub_14006DAB0  size 174
__int64 __fastcall sub_14006DAB0(__int64 (__fastcall ***a1)(_QWORD, void *, __int64 *), __int64 a2, unsigned int a3)
{
  int v6; // ebx
  __int64 v7; // [rsp+30h] [rbp+8h] BYREF
  __int64 v8; // [rsp+48h] [rbp+20h] BYREF

  if ( a1 == nullptr )
    return 2147942487LL;
  v8 = 0;
  v7 = 0;
  v6 = (**a1)(a1, &unk_1405E7518, &v8);
  if ( v6 >= 0 )
  {
    v6 = (*(__int64 (__fastcall **)(__int64, __int64, __int64 *))(*(_QWORD *)v8 + 32LL))(v8, a2, &v7);
    if ( v6 >= 0 )
      v6 = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v7 + 48LL))(v7, a3);
  }
  if ( v7 != 0 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v7 + 16LL))(v7);
  if ( v8 != 0 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 16LL))(v8);
  return (unsigned int)v6;
}
