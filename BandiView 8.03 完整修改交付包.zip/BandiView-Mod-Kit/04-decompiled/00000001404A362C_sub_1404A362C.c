// EA 0x1404a362c  name sub_1404A362C  size 358
__int64 __fastcall sub_1404A362C(_QWORD *a1, int a2, __int64 a3, __int64 a4, int a5)
{
  int v8; // esi
  __int64 v9; // rbx
  _DWORD *v11; // rdi
  char *v12; // r14
  char *v13; // r9
  int v14; // ecx
  int *v15; // rax
  __int64 v16; // r8
  int v17; // r9d
  __int64 v18; // [rsp+28h] [rbp-50h]
  _BYTE v19[32]; // [rsp+30h] [rbp-48h] BYREF
  PVOID BaseOfImage; // [rsp+80h] [rbp+8h] BYREF

  v8 = (int)a1;
  v9 = 0;
  if ( a1 == nullptr )
    return 0;
  v11 = *(_DWORD **)(*a1 - 8LL);
  v12 = (char *)a1 - (v11[2] != 0 ? *(_DWORD *)((char *)a1 - (unsigned int)v11[2]) : 0) - (unsigned int)v11[1];
  if ( *v11 != 0 )
  {
    v13 = (char *)v11 - (int)v11[5];
  }
  else
  {
    v13 = (char *)RtlPcToFileHeader(v11, &BaseOfImage);
    BaseOfImage = v13;
  }
  v14 = *(_DWORD *)&v13[v11[4] + 4];
  if ( (v14 & 1) != 0 )
  {
    v18 = (__int64)v13;
    v17 = v8 - a2 - (_DWORD)v12;
    if ( (v14 & 2) != 0 )
      v15 = (int *)sub_1404A33A8((_DWORD)v12, (_DWORD)v11, a3, v17, a4, v18);
    else
      v15 = (int *)sub_1404A3118((_DWORD)v12, (_DWORD)v11, a3, v17, a4, v18);
  }
  else
  {
    v15 = (int *)sub_1404A3290(v11, a3, a4);
  }
  if ( v15 != nullptr )
  {
    if ( v15[3] >= 0 )
      v9 = v15[3] + (__int64)*(int *)(v15[4] + *(_QWORD *)&v12[v15[3]]);
    return (__int64)&v12[v15[2] + v9];
  }
  else
  {
    if ( a5 != 0 )
    {
      sub_1404A35F4(v19, "Bad dynamic_cast!", v16, 0);
      sub_1404A2BE0(v19, &_TI2_AVbad_cast_std__);
      __debugbreak();
    }
    return 0;
  }
}
