// EA 0x140079b50  name sub_140079B50  size 179
__int64 __fastcall sub_140079B50(__int64 a1)
{
  HKEY phkResult[17]; // [rsp+20h] [rbp-C8h] BYREF
  int v4; // [rsp+A8h] [rbp-40h]
  LPCWSTR lpSubKey[2]; // [rsp+C0h] [rbp-28h] BYREF
  int v6; // [rsp+D0h] [rbp-18h]
  int v7; // [rsp+D4h] [rbp-14h]
  __int64 v8; // [rsp+F0h] [rbp+8h] BYREF

  sub_14009B190(phkResult, 0);
  v6 = 1;
  v4 = 1;
  sub_14005FCF0(lpSubKey, L"SOFTWARE\\BandiView", 18);
  v7 = 1;
  sub_140082940(phkResult, HKEY_CURRENT_USER, lpSubKey[0]);
  v8 = sub_14005F710(*(_QWORD *)(a1 + 8) - 24LL) + 24;
  sub_14009BBC0(phkResult, L"appEditionStrEn", &v8);
  return sub_14009B2F0(phkResult);
}
