// EA 0x14019c680  name sub_14019C680  size 128
__int64 __fastcall sub_14019C680(__int64 a1, int *a2)
{
  __int64 *v3; // rax
  int *v5; // [rsp+38h] [rbp+10h] BYREF
  int **v6; // [rsp+40h] [rbp+18h]

  v5 = a2;
  v6 = &v5;
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  v5 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
  if ( (unsigned __int8)sub_14005F980(&v5, (__int64)&Data) == 0 )
    sub_14005FCF0(&v5, &Data, 0);
  return sub_14019BD50(a1, 1, &v5);
}
