// EA 0x1401cc050  name sub_1401CC050  size 598
char __fastcall sub_1401CC050(__int64 a1, const WCHAR *a2)
{
  __int64 v4; // rax
  HANDLE FileW; // rax
  DWORD LastError; // eax
  DWORD v7; // edi
  unsigned __int64 v8; // rax
  _QWORD *v9; // rax
  const WCHAR *v10; // rcx
  HANDLE v11; // rax
  LPCWSTR lpFileName[2]; // [rsp+48h] [rbp-60h] BYREF
  __int128 v14; // [rsp+58h] [rbp-50h]
  char *Src[4]; // [rsp+68h] [rbp-40h] BYREF

  if ( a2 == nullptr || *(_QWORD *)(a1 + 8) != -1 )
    return 0;
  v4 = *(_QWORD *)(a1 + 16);
  *(_QWORD *)(a1 + 32) = v4;
  *(_QWORD *)(a1 + 24) = v4;
  *(_QWORD *)(a1 + 40) = 0;
  *(_QWORD *)(a1 + 8) = -1;
  *(_WORD *)(a1 + 48) = 0;
  FileW = CreateFileW(a2, 0x80000000, 5u, nullptr, 3u, 0x80u, nullptr);
  *(_QWORD *)(a1 + 8) = FileW;
  if ( FileW == (HANDLE)-1LL )
  {
    LastError = GetLastError();
    v7 = LastError;
    if ( LastError == 3 )
    {
      memset(Src, 0, sizeof(Src));
      sub_140061270(Src, L"\\\\?\\", 4u);
      v8 = sub_1404ADC20(a2);
      v9 = sub_14005ED20(Src, a2, v8);
      *(_OWORD *)lpFileName = 0;
      v14 = 0;
      *(_OWORD *)lpFileName = *(_OWORD *)v9;
      v14 = *((_OWORD *)v9 + 1);
      v9[2] = 0;
      v9[3] = 7;
      *(_WORD *)v9 = 0;
      sub_14005D410(Src);
      v10 = (const WCHAR *)lpFileName;
      if ( *((_QWORD *)&v14 + 1) > 7u )
        v10 = lpFileName[0];
      *(_QWORD *)(a1 + 8) = CreateFileW(v10, 0x80000000, 5u, nullptr, 3u, 0x80u, nullptr);
      sub_14005D410((char **)lpFileName);
    }
    else if ( LastError - 32 <= 1 )
    {
      v11 = CreateFileW(a2, 0x80000000, 0, nullptr, 3u, 0x80u, nullptr);
      *(_QWORD *)(a1 + 8) = v11;
      if ( v11 == (HANDLE)-1LL )
      {
        *(_QWORD *)(a1 + 8) = CreateFileW(a2, 0x80000000, 7u, nullptr, 3u, 0x80u, nullptr);
        GetLastError();
      }
      if ( *(_QWORD *)(a1 + 8) != -1 )
        goto LABEL_16;
      *(_QWORD *)(a1 + 8) = CreateFileW(a2, 0x80000000, 7u, nullptr, 3u, 0x80u, nullptr);
      v7 = GetLastError();
    }
    if ( *(_QWORD *)(a1 + 8) == -1 )
    {
      *(_DWORD *)(a1 + 52) = v7;
      return 0;
    }
  }
LABEL_16:
  *(_BYTE *)(a1 + 49) = 1;
  return 1;
}
