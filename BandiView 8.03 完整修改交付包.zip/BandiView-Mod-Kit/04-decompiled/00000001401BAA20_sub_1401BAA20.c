// EA 0x1401baa20  name sub_1401BAA20  size 198
__int64 __fastcall sub_1401BAA20(__int64 a1)
{
  HWND v2; // rcx
  HWND v4; // rcx
  int v5; // r9d
  struct tagRECT Rect; // [rsp+30h] [rbp-58h] BYREF
  WINDOWPLACEMENT wndpl; // [rsp+40h] [rbp-48h] BYREF

  v2 = *(HWND *)(a1 + 1136);
  if ( v2 == nullptr || *(_DWORD *)(a1 + 872) == 0 )
    return 1;
  wndpl.length = 44;
  if ( GetWindowPlacement(v2, &wndpl) && wndpl.showCmd == 2 )
  {
    SetRectEmpty((LPRECT)(a1 + 264));
    sub_140214380(a1 + 888, 0, 0);
    return 1;
  }
  v4 = *(HWND *)(a1 + 1136);
  Rect = 0;
  GetClientRect(v4, &Rect);
  return sub_1401BAB60(a1, Rect.right - Rect.left, Rect.bottom - Rect.top, v5, 0);
}
