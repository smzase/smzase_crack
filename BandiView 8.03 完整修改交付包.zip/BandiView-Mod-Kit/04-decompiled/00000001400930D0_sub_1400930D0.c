// EA 0x1400930d0  name sub_1400930D0  size 1441
__int64 __fastcall sub_1400930D0(unsigned int a1)
{
  __int64 *v2; // rax
  int *v3; // rdi
  __int64 *v4; // rax
  int *v5; // rbx
  __int64 *v6; // rax
  __int64 *v7; // rax
  __int64 *v8; // rax
  __int64 *v9; // rax
  int **v10; // rsi
  __int64 *v11; // rax
  int **v12; // rax
  int v13; // r14d
  __int64 *v14; // rax
  __int64 v15; // rcx
  int v16; // eax
  int *v17; // rdx
  unsigned int i; // r15d
  wchar_t *v19; // rsi
  __int64 *v20; // rax
  _BYTE *v21; // rdx
  volatile signed __int32 *v22; // rcx
  volatile signed __int32 *v23; // rsi
  __int64 v24; // rbx
  int *v25; // rdx
  int *v26; // rdx
  int *v27; // rdx
  __int64 result; // rax
  int *v29; // [rsp+50h] [rbp-B0h] BYREF
  int *v30; // [rsp+58h] [rbp-A8h] BYREF
  int *v31; // [rsp+60h] [rbp-A0h] BYREF
  int *v32; // [rsp+68h] [rbp-98h] BYREF
  __int64 v33; // [rsp+70h] [rbp-90h] BYREF
  int *v34; // [rsp+78h] [rbp-88h] BYREF
  int *v35; // [rsp+80h] [rbp-80h] BYREF
  _BYTE v36[8]; // [rsp+88h] [rbp-78h] BYREF
  _BYTE v37[8]; // [rsp+90h] [rbp-70h] BYREF
  int *v38[11]; // [rsp+98h] [rbp-68h] BYREF
  _BYTE v39[128]; // [rsp+F0h] [rbp-10h] BYREF
  int *v40; // [rsp+188h] [rbp+88h] BYREF
  int *v41; // [rsp+190h] [rbp+90h] BYREF
  int *v42; // [rsp+198h] [rbp+98h] BYREF

  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  v3 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  v38[2] = v3;
  sub_1400C32E0(v39, a1);
  sub_14006EAE0(&v34);
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v5 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  v32 = v5;
  v38[3] = (int *)&v41;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  v41 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  if ( (unsigned __int8)sub_14005F980(&v41, (__int64)&Data) == 0 )
    sub_14005FCF0(&v41, &Data, 0);
  v38[4] = (int *)&v42;
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  v42 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
  if ( (unsigned __int8)sub_14005F980(&v42, (__int64)&Data) == 0 )
    sub_14005FCF0(&v42, &Data, 0);
  v38[5] = (int *)&v29;
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  v29 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24);
  if ( (unsigned __int8)sub_14005F980(&v29, (__int64)&Data) == 0 )
    sub_14005FCF0(&v29, &Data, 0);
  v38[6] = (int *)&v30;
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    sub_14005FF30(0x80004005);
  v30 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
  if ( (unsigned __int8)sub_14005F980(&v30, (__int64)&Data) == 0 )
    sub_14005FCF0(&v30, &Data, 0);
  v38[7] = (int *)&v35;
  v10 = sub_14007D7F0(&v35);
  v38[8] = (int *)&v31;
  v11 = sub_1400601C0();
  if ( v11 == nullptr )
    sub_14005FF30(0x80004005);
  v31 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24);
  if ( (unsigned __int8)sub_14005F980(&v31, (__int64)L"BandiView") == 0 )
    sub_14005FCF0(&v31, L"BandiView", 9);
  v38[9] = (int *)v36;
  v12 = sub_14006EA30(v38);
  v13 = sub_140060B30(v36, v12, L"icons\\");
  v38[1] = (int *)&v40;
  v14 = sub_1400601C0();
  if ( v14 == nullptr )
    sub_14005FF30(0x80004005);
  v40 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
  if ( (unsigned __int8)sub_14005F980(&v40, (__int64)&Data) == 0 )
    sub_14005FCF0(&v40, &Data, 0);
  v33 = sub_14005F710(v34 - 6) + 24;
  v16 = sub_1400C3460(v15, v37, &v33, &v40);
  sub_1400C36C0(
    (unsigned int)v39,
    v16,
    v13,
    (unsigned int)&v31,
    (__int64)v10,
    (__int64)&v30,
    (__int64)&v29,
    (__int64)&v42,
    (__int64)&v41);
  v17 = v38[0] - 6;
  if ( _InterlockedExchangeAdd(v38[0] - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v17 + 8LL))(*(_QWORD *)v17);
  for ( i = 0; i < 0x44; ++i )
  {
    v19 = off_1406DCBA0[4 * (int)i];
    v20 = sub_1400601C0();
    if ( v20 == nullptr )
      sub_14005FF30(0x80004005);
    v40 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v20 + 24))(v20) + 24);
    if ( (unsigned __int8)sub_14005F980(&v40, (__int64)L".") == 0 )
      sub_14005FCF0(&v40, L".", 1);
    v21 = *(_BYTE **)sub_140060B30(&v42, &v40, v19);
    v22 = (volatile signed __int32 *)(v21 - 24);
    v23 = v5 - 6;
    if ( v21 - 24 != (_BYTE *)(v5 - 6) )
    {
      if ( *((int *)v23 + 4) >= 0 && *(_QWORD *)v22 == *(_QWORD *)v23 )
      {
        v24 = sub_14005F710(v22);
        if ( _InterlockedExchangeAdd(v23 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v23 + 8LL))(*(_QWORD *)v23, v23);
        v5 = (int *)(v24 + 24);
        v32 = v5;
      }
      else
      {
        sub_14005FCF0(&v32, v21, *((_DWORD *)v21 - 4));
        v5 = v32;
      }
    }
    v25 = v42 - 6;
    if ( _InterlockedExchangeAdd(v42 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v25 + 8LL))(*(_QWORD *)v25);
    v26 = v40 - 6;
    if ( _InterlockedExchangeAdd(v40 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v26 + 8LL))(*(_QWORD *)v26);
    v41 = (int *)(sub_14005F710(v5 - 6) + 24);
    sub_1400C5040(v39, &v41);
  }
  SHChangeNotify(0x8000000, 0x1003u, nullptr, nullptr);
  Sleep(0x3E8u);
  if ( _InterlockedExchangeAdd(v5 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, int *))(**((_QWORD **)v5 - 3) + 8LL))(*((_QWORD *)v5 - 3), v5 - 6);
  v27 = v34 - 6;
  if ( _InterlockedExchangeAdd(v34 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v27 + 8LL))(*(_QWORD *)v27);
  result = sub_1400B3600(v39);
  if ( _InterlockedExchangeAdd(v3 - 2, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v3 - 3) + 8LL))(*((_QWORD *)v3 - 3));
  return result;
}
