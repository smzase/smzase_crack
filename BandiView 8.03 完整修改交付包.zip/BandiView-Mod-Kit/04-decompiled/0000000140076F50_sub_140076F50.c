// EA 0x140076f50  name sub_140076F50  size 11262
char __fastcall sub_140076F50(__int64 a1, int a2, _QWORD *a3)
{
  unsigned __int8 v6; // r12
  __int64 *v7; // rax
  __int64 v8; // rdi
  __int64 *v9; // rax
  _WORD *v10; // rbx
  _QWORD *v11; // r14
  __int64 v12; // rcx
  int v13; // eax
  volatile signed __int32 *v14; // rdx
  __int64 v15; // rbx
  __int64 *v16; // rax
  __int64 v17; // r15
  _QWORD *v18; // r14
  _QWORD *v19; // rcx
  __int64 v20; // r8
  int v21; // r14d
  _QWORD *v22; // r15
  _QWORD *i; // rbx
  __int64 v24; // r8
  __int64 v25; // r8
  __int64 v26; // r8
  int v27; // ecx
  unsigned __int64 v28; // rax
  __int64 v29; // rdx
  __int64 v30; // r8
  unsigned int v31; // eax
  unsigned __int64 v32; // r15
  __int64 j; // r14
  __int64 v34; // rdx
  __int64 *v35; // rax
  volatile signed __int32 *v36; // rbx
  _QWORD *v37; // rdx
  __int64 v38; // r8
  __int64 v39; // rbx
  __int64 v40; // rcx
  _BYTE **v41; // rax
  _QWORD *v42; // rdx
  _BYTE **v43; // rax
  _QWORD *v44; // rdx
  unsigned int v45; // eax
  __int64 v46; // r8
  __int64 v47; // r8
  unsigned int k; // r14d
  __int64 *v49; // rax
  volatile signed __int32 *v50; // rbx
  __int128 *v51; // rdx
  unsigned int v52; // eax
  unsigned int v53; // eax
  _BYTE *v54; // r14
  __int64 v55; // rbx
  __int64 v56; // r8
  unsigned int v57; // eax
  unsigned int v58; // eax
  int m; // ebx
  __int64 v60; // rcx
  __int64 v61; // r8
  _QWORD *v62; // rdx
  unsigned int v63; // eax
  unsigned int v64; // eax
  volatile signed __int32 *v65; // rdx
  volatile signed __int32 *v67; // rdx
  const void *v68[2]; // [rsp+30h] [rbp-D0h] BYREF
  char v69[16]; // [rsp+40h] [rbp-C0h] BYREF
  HKEY hKey[17]; // [rsp+50h] [rbp-B0h] BYREF
  int v71; // [rsp+D8h] [rbp-28h]
  LPCWSTR lpSubKey[2]; // [rsp+F0h] [rbp-10h] BYREF
  int v73; // [rsp+100h] [rbp+0h]
  int v74; // [rsp+104h] [rbp+4h]
  int *v75; // [rsp+110h] [rbp+10h] BYREF
  __int64 v76; // [rsp+118h] [rbp+18h] BYREF
  __int64 v77; // [rsp+120h] [rbp+20h] BYREF
  _QWORD *v78; // [rsp+128h] [rbp+28h]
  _QWORD *v79; // [rsp+130h] [rbp+30h]
  __int128 v80; // [rsp+138h] [rbp+38h] BYREF
  __int64 v81; // [rsp+148h] [rbp+48h]
  unsigned __int64 v82; // [rsp+150h] [rbp+50h]

  v78 = a3;
  v79 = a3;
  sub_14009B190(hKey, 0);
  if ( a2 == 0 )
  {
    v6 = 1;
    *(_BYTE *)a1 = 1;
    v73 = 0;
    v71 = 1;
    sub_14005FCF0((int **)lpSubKey, L"SOFTWARE\\BandiView", 18);
    v74 = 1;
    if ( hKey[0] != nullptr )
      RegCloseKey(hKey[0]);
    hKey[0] = nullptr;
    RegOpenKeyExW(HKEY_CURRENT_USER, L"SOFTWARE\\BandiView", 0, 0x20019u, hKey);
    sub_14009BE90(hKey, 1, L"isFirst", a1 + 1);
    v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 8) - 24LL)) + 24);
    sub_14009B860(hKey, L"appEditionStrEn", a1 + 8, v68);
    sub_14009B760(hKey, L"lastErrorDay", a1 + 24, *(unsigned int *)(a1 + 24));
    sub_14009B760(hKey, L"lastErrorDayCount", a1 + 28, *(unsigned int *)(a1 + 28));
    sub_14009B760(hKey, L"serverBuildNo", a1 + 32, *(unsigned int *)(a1 + 32));
    sub_14009B760(hKey, L"serverBuildNoCur", a1 + 36, *(unsigned int *)(a1 + 36));
    sub_14009B760(hKey, L"lastUpdateCheckDay", a1 + 40, *(unsigned int *)(a1 + 40));
    sub_14009B760(hKey, L"lastShowADDay", a1 + 44, *(unsigned int *)(a1 + 44));
    sub_14009B760(hKey, L"sizeSelFolderDlg.cx", a1 + 48, *(unsigned int *)(a1 + 48));
    sub_14009B760(hKey, L"sizeSelFolderDlg.cy", a1 + 52, *(unsigned int *)(a1 + 52));
LABEL_10:
    v7 = sub_1400601C0();
    if ( v7 == nullptr )
      sub_14005FF30(0x80004005);
    v8 = (*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24;
    v77 = v8;
    if ( v6 != 0 )
    {
      v9 = sub_1400601C0();
      if ( v9 == nullptr )
        sub_14005FF30(0x80004005);
      v10 = (_WORD *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
      v68[0] = v10;
      v11 = (_QWORD *)(a1 + 56);
      sub_140065D40(v12, *(_QWORD ***)(a1 + 56));
      *(_QWORD *)*v11 = *v11;
      *(_QWORD *)(*v11 + 8LL) = *v11;
      *(_QWORD *)(a1 + 64) = 0;
      v13 = 0;
      LODWORD(v76) = 0;
      while ( 1 )
      {
        sub_14005EB50((__int64)&v77, (__int64)L"RecentFolder%d", (unsigned int)v13);
        v14 = (volatile signed __int32 *)(v10 - 12);
        if ( *((_DWORD *)v10 - 4) != 0 )
        {
          if ( *((int *)v14 + 4) >= 0 )
          {
            v15 = *(_QWORD *)v14;
            if ( _InterlockedExchangeAdd(v14 + 4, 0xFFFFFFFF) <= 1 )
              (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v14 + 8LL))(*(_QWORD *)v14);
            v68[0] = (const void *)((*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v15 + 24LL))(v15) + 24);
          }
          else
          {
            if ( *((int *)v10 - 3) < 0 )
              sub_14005FF30(0x80070057);
            *((_DWORD *)v10 - 4) = 0;
            *v10 = 0;
          }
        }
        v68[1] = &v75;
        v16 = sub_1400601C0();
        if ( v16 == nullptr )
          sub_14005FF30(0x80004005);
        v75 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v16 + 24))(v16) + 24);
        if ( (unsigned __int8)sub_14005F980(&v75, (__int64)&Data) == 0 )
          sub_14005FCF0(&v75, &Data, 0);
        v8 = v77;
        sub_14009B860(hKey, v77, v68, &v75);
        v10 = v68[0];
        if ( *((_DWORD *)v68[0] - 4) == 0 )
          break;
        if ( v11[1] == 0xAAAAAAAAAAAAAAALL )
          sub_1404962E4("list too long");
        v17 = *v11;
        v80 = (unsigned __int64)v11;
        v18 = operator new(0x18u);
        *((_QWORD *)&v80 + 1) = v18;
        v18[2] = sub_14005F710((volatile signed __int32 *)v10 - 6) + 24;
        ++*(_QWORD *)(a1 + 64);
        v19 = *(_QWORD **)(v17 + 8);
        *v18 = v17;
        v18[1] = v19;
        *((_QWORD *)&v80 + 1) = 0;
        *(_QWORD *)(v17 + 8) = v18;
        *v19 = v18;
        v13 = v76 + 1;
        LODWORD(v76) = v13;
        if ( v13 >= 10 )
          break;
        v11 = (_QWORD *)(a1 + 56);
      }
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)v10 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v10 - 3) + 8LL))(*((_QWORD *)v10 - 3));
      sub_14009BE90(hKey, v6, L"openFolderRecursive", a1 + 72);
      sub_14009B760(hKey, L"maximizeState", a1 + 76, *(unsigned int *)(a1 + 76));
      sub_14009B760(hKey, L"rectView.left", a1 + 80, *(unsigned int *)(a1 + 80));
      sub_14009B760(hKey, L"rectView.top", a1 + 84, *(unsigned int *)(a1 + 84));
      sub_14009B760(hKey, L"rectView.right", a1 + 88, *(unsigned int *)(a1 + 88));
      sub_14009B760(hKey, L"rectView.bottom", a1 + 92, *(unsigned int *)(a1 + 92));
      sub_14009B760(hKey, L"rectViewMaximized.left", a1 + 96, *(unsigned int *)(a1 + 96));
      sub_14009B760(hKey, L"rectViewMaximized.top", a1 + 100, *(unsigned int *)(a1 + 100));
      sub_14009B760(hKey, L"rectViewMaximized.right", a1 + 104, *(unsigned int *)(a1 + 104));
      sub_14009B760(hKey, L"rectViewMaximized.bottom", a1 + 108, *(unsigned int *)(a1 + 108));
      sub_14009BFC0(hKey, v6, v20, a1 + 116);
      sub_14009B760(hKey, L"sizeNavDlg96.cx", a1 + 132, *(unsigned int *)(a1 + 132));
      sub_14009B760(hKey, L"sizeNavDlg96.cy", a1 + 136, *(unsigned int *)(a1 + 136));
      sub_14009B760(hKey, L"navListItemWidth96[NAVLISTITEM_NAME]", a1 + 140, *(unsigned int *)(a1 + 140));
      sub_14009B760(hKey, L"navListItemWidth96[NAVLISTITEM_DATE]", a1 + 144, *(unsigned int *)(a1 + 144));
      sub_14009B760(hKey, L"navListItemWidth96[NAVLISTITEM_SIZE]", a1 + 148, *(unsigned int *)(a1 + 148));
      sub_14009B760(hKey, L"navThumbPanelHeight", a1 + 152, *(unsigned int *)(a1 + 152));
      sub_14009B760(hKey, L"sizeMetaDlg96.cx", a1 + 156, *(unsigned int *)(a1 + 156));
      sub_14009B760(hKey, L"sizeMetaDlg96.cy", a1 + 160, *(unsigned int *)(a1 + 160));
    }
    else
    {
      v21 = 0;
      v22 = *(_QWORD **)(a1 + 56);
      for ( i = (_QWORD *)*v22; i != v22; i = (_QWORD *)*i )
      {
        if ( v21 >= 10 )
          break;
        sub_14005EB50((__int64)&v77, (__int64)L"RecentFolder%d", (unsigned int)v21);
        v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(i[2] - 24LL)) + 24);
        v8 = v77;
        sub_14009BBC0(hKey, v77, v68);
        ++v21;
      }
      sub_14009BE90(hKey, 0, L"openFolderRecursive", a1 + 72);
      sub_14009B970(hKey, L"maximizeState", *(unsigned int *)(a1 + 76));
      sub_14009B970(hKey, L"rectView.left", *(unsigned int *)(a1 + 80));
      sub_14009B970(hKey, L"rectView.top", *(unsigned int *)(a1 + 84));
      sub_14009B970(hKey, L"rectView.right", *(unsigned int *)(a1 + 88));
      sub_14009B970(hKey, L"rectView.bottom", *(unsigned int *)(a1 + 92));
      sub_14009B970(hKey, L"rectViewMaximized.left", *(unsigned int *)(a1 + 96));
      sub_14009B970(hKey, L"rectViewMaximized.top", *(unsigned int *)(a1 + 100));
      sub_14009B970(hKey, L"rectViewMaximized.right", *(unsigned int *)(a1 + 104));
      sub_14009B970(hKey, L"rectViewMaximized.bottom", *(unsigned int *)(a1 + 108));
      sub_14009BFC0(hKey, 0, v24, a1 + 116);
      sub_14009B970(hKey, L"sizeNavDlg96.cx", *(unsigned int *)(a1 + 132));
      sub_14009B970(hKey, L"sizeNavDlg96.cy", *(unsigned int *)(a1 + 136));
      sub_14009B970(hKey, L"navListItemWidth96[NAVLISTITEM_NAME]", *(unsigned int *)(a1 + 140));
      sub_14009B970(hKey, L"navListItemWidth96[NAVLISTITEM_DATE]", *(unsigned int *)(a1 + 144));
      sub_14009B970(hKey, L"navListItemWidth96[NAVLISTITEM_SIZE]", *(unsigned int *)(a1 + 148));
      sub_14009B970(hKey, L"navThumbPanelHeight", *(unsigned int *)(a1 + 152));
      sub_14009B970(hKey, L"sizeMetaDlg96.cx", *(unsigned int *)(a1 + 156));
      sub_14009B970(hKey, L"sizeMetaDlg96.cy", *(unsigned int *)(a1 + 160));
    }
    sub_14009BE90(hKey, v6, L"esc2exit", a1 + 164);
    sub_14009BE90(hKey, v6, L"oneInstance", a1 + 165);
    sub_14009BE90(hKey, v6, L"askDelete", a1 + 166);
    sub_14009BE90(hKey, v6, L"alwaysOnTop", a1 + 167);
    sub_14009BE90(hKey, v6, L"useSnap", a1 + 168);
    v25 = *(unsigned int *)(a1 + 172);
    if ( v6 != 0 )
    {
      sub_14009B760(hKey, L"lastFileActionImage", a1 + 172, (unsigned int)v25);
      sub_14009B760(hKey, L"lastFileActionArchive", a1 + 176, *(unsigned int *)(a1 + 176));
    }
    else
    {
      sub_14009B970(hKey, L"lastFileActionImage", v25);
      sub_14009B970(hKey, L"lastFileActionArchive", *(unsigned int *)(a1 + 176));
    }
    sub_14009BE90(hKey, v6, L"updateChk", a1 + 180);
    sub_14009BE90(hKey, v6, L"updateBeta", a1 + 181);
    sub_14009BE90(hKey, v6, L"lockTitleBarFull", a1 + 182);
    sub_14009BE90(hKey, v6, L"lockTitleBarNormal", a1 + 183);
    sub_14009BE90(hKey, v6, L"lockControlBar", a1 + 184);
    sub_14009BE90(hKey, v6, L"showTitlebar", a1 + 185);
    sub_14009BE90(hKey, v6, L"showControlbar", a1 + 186);
    sub_14009BE90(hKey, v6, L"showScrollbar", a1 + 187);
    sub_14009BE90(hKey, v6, L"showSideArrow", a1 + 188);
    sub_14009BE90(hKey, v6, L"showExifInfo", a1 + 189);
    sub_14009BE90(hKey, v6, L"showBorder", a1 + 190);
    sub_14009BE90(hKey, v6, L"showMiniTitle", a1 + 191);
    sub_14009BE90(hKey, v6, L"showAnimInfo", a1 + 192);
    sub_14009BE90(hKey, v6, L"showMessage", a1 + 193);
    sub_14009BE90(hKey, v6, L"showZoomControl", a1 + 194);
    sub_14009BE90(hKey, v6, L"showLogo", a1 + 195);
    v26 = *(unsigned int *)(a1 + 196);
    if ( v6 != 0 )
    {
      sub_14009B760(hKey, L"darkModeOption", a1 + 196, (unsigned int)v26);
      sub_14009B760(hKey, L"bkgndClrOption", a1 + 200, *(unsigned int *)(a1 + 200));
      sub_14009B760(hKey, L"clrBkgnd", a1 + 204, *(unsigned int *)(a1 + 204));
      sub_14009B760(hKey, L"clrBorder", a1 + 208, *(unsigned int *)(a1 + 208));
      sub_14009B760(hKey, L"dpiPercent", a1 + 212, *(unsigned int *)(a1 + 212));
      v27 = *(_DWORD *)(a1 + 212);
      if ( v27 != 0 )
      {
        v28 = (unsigned int)(v27 - 100);
        if ( (unsigned int)v28 > 0x32 || (v29 = 0x4000002000001LL, !_bittest64(&v29, v28)) )
        {
          if ( v27 != 175 && v27 != 200 && v27 != 250 )
            *(_DWORD *)(a1 + 212) = 0;
        }
      }
      sub_14009BE90(hKey, v6, L"applyDPISettings2Img", a1 + 216);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 224) - 24LL)) + 24);
      sub_14009B860(hKey, L"titleFormat", a1 + 224, v68);
    }
    else
    {
      sub_14009B970(hKey, L"darkModeOption", v26);
      sub_14009B970(hKey, L"bkgndClrOption", *(unsigned int *)(a1 + 200));
      sub_14009B970(hKey, L"clrBkgnd", *(unsigned int *)(a1 + 204));
      sub_14009B970(hKey, L"clrBorder", *(unsigned int *)(a1 + 208));
      sub_14009B970(hKey, L"dpiPercent", *(unsigned int *)(a1 + 212));
      sub_14009BE90(hKey, 0, L"applyDPISettings2Img", a1 + 216);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 224) - 24LL)) + 24);
      sub_14009BBC0(hKey, L"titleFormat", v68);
    }
    sub_14009BE90(hKey, v6, L"exifRotation", a1 + 232);
    sub_14009BE90(hKey, v6, L"cacheImage", a1 + 233);
    v30 = *(unsigned int *)(a1 + 236);
    if ( v6 != 0 )
      sub_14009B760(hKey, L"cacheSizeMB64", a1 + 236, (unsigned int)v30);
    else
      sub_14009B970(hKey, L"cacheSizeMB64", v30);
    sub_14009BE90(hKey, v6, L"usePreviewMode", a1 + 240);
    sub_14009BE90(hKey, v6, L"applyImageIccProfile", a1 + 241);
    sub_14009BE90(hKey, v6, L"applyMonitorIccProfile", a1 + 242);
    v31 = *(_DWORD *)(a1 + 244);
    if ( v6 != 0 )
    {
      sub_14009B760(hKey, L"transImgBkgnd2", a1 + 244, v31);
      sub_14009B760(hKey, L"clrTileColor1", a1 + 248, *(unsigned int *)(a1 + 248));
      sub_14009B760(hKey, L"clrTileColor2", a1 + 252, *(unsigned int *)(a1 + 252));
      sub_14009BE90(hKey, v6, L"setwebptoonspace", a1 + 256);
      sub_14009B760(hKey, L"webtoonSpace", a1 + 260, *(unsigned int *)(a1 + 260));
      sub_14009BE90(hKey, v6, L"set2pagespace", a1 + 264);
      sub_14009B760(hKey, L"twoPageSpace", a1 + 268, *(unsigned int *)(a1 + 268));
    }
    else
    {
      sub_14009B970(hKey, L"transImgBkgnd2", v31);
      sub_14009B970(hKey, L"clrTileColor1", *(unsigned int *)(a1 + 248));
      sub_14009B970(hKey, L"clrTileColor2", *(unsigned int *)(a1 + 252));
      sub_14009BE90(hKey, 0, L"setwebptoonspace", a1 + 256);
      sub_14009B970(hKey, L"webtoonSpace", *(unsigned int *)(a1 + 260));
      sub_14009BE90(hKey, 0, L"set2pagespace", a1 + 264);
      sub_14009B970(hKey, L"twoPageSpace", *(unsigned int *)(a1 + 268));
    }
    sub_14009BE90(hKey, v6, L"separateCoverPage", a1 + 272);
    sub_14009BE90(hKey, v6, L"clipAdvanced", a1 + 273);
    sub_14009BE90(hKey, v6, L"rawfileJpegThumbnail", a1 + 274);
    sub_14009BE90(hKey, v6, L"centerImageIfLarger", a1 + 275);
    sub_14009BE90(hKey, v6, L"useArrowKey2ScrollOnly", a1 + 276);
    if ( v6 != 0 )
    {
      sub_140079EE0(a1, hKey);
      sub_14009BE90(hKey, v6, L"mouseCustom.lbtn.enable", a1 + 304);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 312) - 24LL)) + 24);
      sub_14009B860(hKey, L"mouseCustom.lbtn.cmd", a1 + 312, v68);
      sub_14009BE90(hKey, v6, L"mouseCustom.dbtn.enable", a1 + 320);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 328) - 24LL)) + 24);
      sub_14009B860(hKey, L"mouseCustom.dbtn.cmd", a1 + 328, v68);
      sub_14009BE90(hKey, v6, L"mouseCustom.mbtn.enable", a1 + 336);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 344) - 24LL)) + 24);
      sub_14009B860(hKey, L"mouseCustom.mbtn.cmd", a1 + 344, v68);
      sub_14009BE90(hKey, v6, L"mouseCustom.rbtn.enable", a1 + 352);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 360) - 24LL)) + 24);
      sub_14009B860(hKey, L"mouseCustom.rbtn.cmd", a1 + 360, v68);
      sub_14009BE90(hKey, v6, L"mouseCustom.xbtn.enable", a1 + 368);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 376) - 24LL)) + 24);
      sub_14009B860(hKey, L"mouseCustom.xbtn.cmd", a1 + 376, v68);
      sub_14009BE90(hKey, v6, L"mouseCustom.ybtn.enable", a1 + 384);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 392) - 24LL)) + 24);
      sub_14009B860(hKey, L"mouseCustom.ybtn.cmd", a1 + 392, v68);
      sub_14009BE90(hKey, v6, L"mouseCustom.wheelup.enable", a1 + 400);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 408) - 24LL)) + 24);
      sub_14009B860(hKey, L"mouseCustom.wheelup.cmd", a1 + 408, v68);
      sub_14009BE90(hKey, v6, L"mouseCustom.wheeldn.enable", a1 + 416);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 424) - 24LL)) + 24);
      sub_14009B860(hKey, L"mouseCustom.wheeldn.cmd", a1 + 424, v68);
    }
    else
    {
      v32 = 0xAAAAAAAAAAAAAAABuLL * ((__int64)(*(_QWORD *)(a1 + 288) - *(_QWORD *)(a1 + 280)) >> 3);
      sub_14009B970(
        hKey,
        L"userKeys.count",
        -1431655765 * (unsigned int)((__int64)(*(_QWORD *)(a1 + 288) - *(_QWORD *)(a1 + 280)) >> 3));
      for ( j = 0; (int)j < (int)v32; j = (unsigned int)(j + 1) )
      {
        v34 = *(_QWORD *)(a1 + 280);
        if ( 0xAAAAAAAAAAAAAAABuLL * ((*(_QWORD *)(a1 + 288) - v34) >> 3) <= (unsigned int)j )
          unknown_libname_5();
        sub_14009D990(&v76, v34 + 24 * j);
        v35 = sub_1400601C0();
        if ( v35 == nullptr )
          sub_14005FF30(0x80004005);
        v68[0] = (const void *)((*(__int64 (__fastcall **)(__int64 *))(*v35 + 24))(v35) + 24);
        sub_14005EB50((__int64)v68, (__int64)L"%s.%d", L"userKeys", (unsigned int)j);
        v36 = (volatile signed __int32 *)v68[0];
        v75 = (int *)(sub_14005F710((volatile signed __int32 *)(v76 - 24)) + 24);
        sub_14009BBC0(hKey, v36, &v75);
        if ( _InterlockedExchangeAdd(v36 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v36 - 3) + 8LL))(*((_QWORD *)v36 - 3));
        v37 = (_QWORD *)(v76 - 24);
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v76 - 24 + 16), 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v37 + 8LL))(*v37);
      }
      sub_14009BE90(hKey, 0, L"mouseCustom.lbtn.enable", a1 + 304);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 312) - 24LL)) + 24);
      sub_14009BBC0(hKey, L"mouseCustom.lbtn.cmd", v68);
      sub_14009BE90(hKey, 0, L"mouseCustom.dbtn.enable", a1 + 320);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 328) - 24LL)) + 24);
      sub_14009BBC0(hKey, L"mouseCustom.dbtn.cmd", v68);
      sub_14009BE90(hKey, 0, L"mouseCustom.mbtn.enable", a1 + 336);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 344) - 24LL)) + 24);
      sub_14009BBC0(hKey, L"mouseCustom.mbtn.cmd", v68);
      sub_14009BE90(hKey, 0, L"mouseCustom.rbtn.enable", a1 + 352);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 360) - 24LL)) + 24);
      sub_14009BBC0(hKey, L"mouseCustom.rbtn.cmd", v68);
      sub_14009BE90(hKey, 0, L"mouseCustom.xbtn.enable", a1 + 368);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 376) - 24LL)) + 24);
      sub_14009BBC0(hKey, L"mouseCustom.xbtn.cmd", v68);
      sub_14009BE90(hKey, 0, L"mouseCustom.ybtn.enable", a1 + 384);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 392) - 24LL)) + 24);
      sub_14009BBC0(hKey, L"mouseCustom.ybtn.cmd", v68);
      sub_14009BE90(hKey, 0, L"mouseCustom.wheelup.enable", a1 + 400);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 408) - 24LL)) + 24);
      sub_14009BBC0(hKey, L"mouseCustom.wheelup.cmd", v68);
      sub_14009BE90(hKey, 0, L"mouseCustom.wheeldn.enable", a1 + 416);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 424) - 24LL)) + 24);
      sub_14009BBC0(hKey, L"mouseCustom.wheeldn.cmd", v68);
    }
    sub_14009BE90(hKey, v6, L"mouseCustom.leftClick2PageTurn", a1 + 432);
    sub_14009BE90(hKey, v6, L"clickCanvas2ShowControls", a1 + 440);
    sub_14009BE90(hKey, v6, L"useMouseWheelBounce", a1 + 441);
    v38 = *(unsigned int *)(a1 + 444);
    if ( v6 != 0 )
      sub_14009B760(hKey, L"wheelScrollSpeed", a1 + 444, (unsigned int)v38);
    else
      sub_14009B970(hKey, L"wheelScrollSpeed", v38);
    sub_14009BE90(hKey, v6, L"rememberFilePosInArchive", a1 + 448);
    sub_14009BE90(hKey, v6, L"rememberFilePosInFolder", a1 + 449);
    sub_14009BE90(hKey, v6, L"shellMenuEnable", a1 + 450);
    sub_14009BE90(hKey, v6, L"shellMenuViewer", a1 + 451);
    sub_14009BE90(hKey, v6, L"shellMenuConv", a1 + 452);
    sub_14009BE90(hKey, v6, L"shellMenuConvShift", a1 + 453);
    sub_14009BE90(hKey, v6, L"shellMenuOnFolder", a1 + 454);
    sub_14009BE90(hKey, v6, L"shellMenuOnBkgnd", a1 + 455);
    sub_14009BE90(hKey, v6, L"shellPreviewIcon", a1 + 456);
    v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 464) - 24LL)) + 24);
    if ( v6 != 0 )
    {
      sub_14009B860(hKey, L"photoFolder1", a1 + 464, v68);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 472) - 24LL)) + 24);
      sub_14009B860(hKey, L"photoFolder2", a1 + 472, v68);
      sub_14009BE90(hKey, v6, L"useUserTempFolder", a1 + 480);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 488) - 24LL)) + 24);
      sub_14009B860(hKey, L"userTempFolder", a1 + 488, v68);
      sub_14006AC90(a1 + 488);
    }
    else
    {
      sub_14009BBC0(hKey, L"photoFolder1", v68);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 472) - 24LL)) + 24);
      sub_14009BBC0(hKey, L"photoFolder2", v68);
      sub_14009BE90(hKey, 0, L"useUserTempFolder", a1 + 480);
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 488) - 24LL)) + 24);
      sub_14009BBC0(hKey, L"userTempFolder", v68);
    }
    sub_14009BE90(hKey, v6, L"resizeWindow2FitImage", a1 + 496);
    sub_14009BE90(hKey, v6, L"syncToFolder", a1 + 497);
    sub_14009BE90(hKey, v6, L"disableScreenSaver", a1 + 498);
    sub_14009BE90(hKey, v6, L"fixNewWindowPos", a1 + 499);
    sub_14009BE90(hKey, v6, L"doNotRemeberRecentFolder", a1 + 500);
    if ( *(_BYTE *)(a1 + 500) != 0 )
    {
      if ( v6 != 0 )
      {
        v43 = (_BYTE **)sub_14009ACB0(v68);
        sub_14006B500((int **)(a1 + 16), v43);
        v44 = (char *)v68[0] - 24;
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)v68[0] - 2, 0xFFFFFFFF) <= 1 )
        {
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v44 + 8LL))(*v44);
          v39 = a1 + 504;
          v40 = *(_QWORD *)(a1 + 504);
          goto LABEL_85;
        }
      }
      v39 = a1 + 504;
      v40 = *(_QWORD *)(a1 + 504);
      if ( v6 != 0 )
        goto LABEL_85;
    }
    else
    {
      v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 16) - 24LL)) + 24);
      if ( v6 != 0 )
      {
        sub_14009B860(hKey, L"sRecentFolder", a1 + 16, v68);
        v39 = a1 + 504;
        v40 = *(_QWORD *)(a1 + 504);
LABEL_85:
        v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(v40 - 24)) + 24);
        sub_14009B860(hKey, L"extProg0", v39, v68);
        sub_14009B760(hKey, L"videoOutput", a1 + 512, *(unsigned int *)(a1 + 512));
LABEL_76:
        sub_14009BE90(hKey, v6, L"pageturnSound", a1 + 516);
        sub_14009BE90(hKey, v6, L"useUserDefineImageFormat", a1 + 517);
        v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 520) - 24LL)) + 24);
        if ( v6 != 0 )
        {
          sub_14009B860(hKey, L"userDefineImageFormat", a1 + 520, v68);
          sub_14009BE90(hKey, v6, L"useUserDefineIgnoreImageFormat", a1 + 528);
          v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 536) - 24LL)) + 24);
          sub_14009B860(hKey, L"userDefineIgnoreImageFormat", a1 + 536, v68);
          v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 544) - 24LL)) + 24);
          sub_14009B860(hKey, L"language", a1 + 544, v68);
          if ( *(_DWORD *)(*(_QWORD *)(a1 + 544) - 16LL) == 0 )
          {
            v41 = (_BYTE **)sub_14009CE70(v68);
            sub_14006B500((int **)(a1 + 544), v41);
            v42 = (char *)v68[0] - 24;
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)v68[0] - 2, 0xFFFFFFFF) <= 1 )
              (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v42 + 8LL))(*v42);
          }
          sub_14009B760(hKey, L"hdrMode", a1 + 556, *(unsigned int *)(a1 + 556));
          sub_14009BE90(hKey, v6, L"useAdaptiveHDRToneMapping", a1 + 560);
          sub_14009B760(hKey, L"viewMode.stretchMode", a1 + 568, *(unsigned int *)(a1 + 568));
        }
        else
        {
          sub_14009BBC0(hKey, L"userDefineImageFormat", v68);
          sub_14009BE90(hKey, 0, L"useUserDefineIgnoreImageFormat", a1 + 528);
          v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 536) - 24LL)) + 24);
          sub_14009BBC0(hKey, L"userDefineIgnoreImageFormat", v68);
          v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 544) - 24LL)) + 24);
          sub_14009BBC0(hKey, L"language", v68);
          sub_14009B970(hKey, L"hdrMode", *(unsigned int *)(a1 + 556));
          sub_14009BE90(hKey, 0, L"useAdaptiveHDRToneMapping", a1 + 560);
          sub_14009B970(hKey, L"viewMode.stretchMode", *(unsigned int *)(a1 + 568));
        }
        sub_14009BE90(hKey, v6, L"viewMode.enlage_when_small", a1 + 572);
        sub_14009BE90(hKey, v6, L"viewMode.rotateUsingExif", a1 + 573);
        v45 = *(_DWORD *)(a1 + 576);
        if ( v6 != 0 )
        {
          sub_14009B760(hKey, L"viewMode.resizeMode", a1 + 576, v45);
          sub_14009B760(hKey, L"viewMode.interMode", a1 + 600, *(unsigned int *)(a1 + 600));
          sub_14009B760(hKey, L"viewMode.sharpeness", a1 + 580, *(unsigned int *)(a1 + 580));
          sub_14009B760(hKey, L"viewMode.gamma1000", a1 + 584, *(unsigned int *)(a1 + 584));
          sub_14009B760(hKey, L"viewMode.brightness100", a1 + 588, *(unsigned int *)(a1 + 588));
          sub_14009B760(hKey, L"viewMode.contrast100", a1 + 592, *(unsigned int *)(a1 + 592));
          sub_14009B760(hKey, L"viewMode.saturation255", a1 + 596, *(unsigned int *)(a1 + 596));
          sub_14009BE90(hKey, v6, L"viewMode.applyWebtoonWidth", a1 + 616);
          sub_14009B760(hKey, L"viewMode.webtoonWidth", a1 + 620, *(unsigned int *)(a1 + 620));
        }
        else
        {
          sub_14009B970(hKey, L"viewMode.resizeMode", v45);
          sub_14009B970(hKey, L"viewMode.interMode", *(unsigned int *)(a1 + 600));
          sub_14009B970(hKey, L"viewMode.sharpeness", *(unsigned int *)(a1 + 580));
          sub_14009B970(hKey, L"viewMode.gamma1000", *(unsigned int *)(a1 + 584));
          sub_14009B970(hKey, L"viewMode.brightness100", *(unsigned int *)(a1 + 588));
          sub_14009B970(hKey, L"viewMode.contrast100", *(unsigned int *)(a1 + 592));
          sub_14009B970(hKey, L"viewMode.saturation255", *(unsigned int *)(a1 + 596));
          sub_14009BE90(hKey, 0, L"viewMode.applyWebtoonWidth", a1 + 616);
          sub_14009B970(hKey, L"viewMode.webtoonWidth", *(unsigned int *)(a1 + 620));
        }
        sub_14009BE90(hKey, v6, L"viewMode.saveImageProc", a1 + 670);
        if ( *(_BYTE *)(a1 + 670) != 0 )
        {
          sub_14009BE90(hKey, v6, L"viewMode.imageProc.negative", a1 + 672);
          sub_14009BE90(hKey, v6, L"viewMode.imageProc.gamma", a1 + 673);
          sub_14009BE90(hKey, v6, L"viewMode.imageProc.flip", a1 + 674);
          sub_14009BE90(hKey, v6, L"viewMode.imageProc.mirror", a1 + 675);
          sub_14009BE90(hKey, v6, L"viewMode.imageProc.gray", a1 + 676);
          sub_14009BE90(hKey, v6, L"viewMode.imageProc.sepia", a1 + 677);
          sub_14009BE90(hKey, v6, L"viewMode.imageProc.useRgbChannel", a1 + 678);
          v46 = *(unsigned int *)(a1 + 680);
          if ( v6 != 0 )
            sub_14009B760(hKey, L"viewMode.imageProc.rgbChannel", a1 + 680, (unsigned int)v46);
          else
            sub_14009B970(hKey, L"viewMode.imageProc.rgbChannel", v46);
          sub_14009BE90(hKey, v6, L"viewMode.imageProc.brightness", a1 + 684);
          sub_14009BE90(hKey, v6, L"viewMode.imageProc.contrast", a1 + 685);
          sub_14009BE90(hKey, v6, L"viewMode.imageProc.saturation", a1 + 686);
          v47 = *(unsigned int *)(a1 + 688);
          if ( v6 != 0 )
            sub_14009B760(hKey, L"viewMode.imageProc.rotate", a1 + 688, (unsigned int)v47);
          else
            sub_14009B970(hKey, L"viewMode.imageProc.rotate", v47);
        }
        for ( k = 0; (int)k < 3; ++k )
        {
          v49 = sub_1400601C0();
          if ( v49 == nullptr )
            sub_14005FF30(0x80004005);
          v68[0] = (const void *)((*(__int64 (__fastcall **)(__int64 *))(*v49 + 24))(v49) + 24);
          sub_14005EB50((__int64)v68, (__int64)L"webtoon.preset.w-%d", k);
          v80 = 0;
          v81 = 0;
          v82 = 0;
          v50 = (volatile signed __int32 *)v68[0];
          sub_140061270((char **)&v80, v68[0], *((int *)v68[0] - 4));
          if ( _InterlockedExchangeAdd(v50 - 2, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v50 - 3) + 8LL))(*((_QWORD *)v50 - 3));
          v51 = &v80;
          if ( v6 != 0 )
          {
            if ( v82 > 7 )
              v51 = (__int128 *)v80;
            sub_14009B760(hKey, v51, a1 + 624 + 4LL * k, (unsigned int)dword_1405EACA0[k]);
          }
          else
          {
            if ( v82 > 7 )
              v51 = (__int128 *)v80;
            sub_14009B970(hKey, v51, *(unsigned int *)(a1 + 4LL * k + 624));
          }
          sub_14005D410((char **)&v80);
        }
        v52 = *(_DWORD *)(a1 + 712);
        if ( v6 != 0 )
        {
          sub_14009B760(hKey, L"sort.method", a1 + 712, v52);
          sub_14009BE90(hKey, v6, L"sort.ascending", a1 + 716);
          sub_14009B760(hKey, L"folder_sort.method", a1 + 720, *(unsigned int *)(a1 + 720));
        }
        else
        {
          sub_14009B970(hKey, L"sort.method", v52);
          sub_14009BE90(hKey, 0, L"sort.ascending", a1 + 716);
          sub_14009B970(hKey, L"folder_sort.method", *(unsigned int *)(a1 + 720));
        }
        sub_14009BE90(hKey, v6, L"folder_sort.ascending", a1 + 724);
        sub_14009BE90(hKey, v6, L"zoomLock", a1 + 728);
        v53 = *(_DWORD *)(a1 + 732);
        if ( v6 != 0 )
        {
          sub_14009B760(hKey, L"zoomLastValuePercent", a1 + 732, v53);
          v54 = (_BYTE *)(a1 + 736);
          sub_14009BE90(hKey, v6, L"scrollLock", a1 + 736);
          v55 = a1 + 740;
          sub_14009B760(hKey, L"scrollLockInfo.pos.x", a1 + 740, *(unsigned int *)(a1 + 740));
          sub_14009B760(hKey, L"scrollLockInfo.pos.y", a1 + 744, *(unsigned int *)(a1 + 744));
        }
        else
        {
          sub_14009B970(hKey, L"zoomLastValuePercent", v53);
          v54 = (_BYTE *)(a1 + 736);
          sub_14009BE90(hKey, 0, L"scrollLock", a1 + 736);
          v55 = a1 + 740;
          sub_14009B970(hKey, L"scrollLockInfo.pos.x", *(unsigned int *)(a1 + 740));
          sub_14009B970(hKey, L"scrollLockInfo.pos.y", *(unsigned int *)(a1 + 744));
        }
        sub_14009BE90(hKey, v6, L"scrollLockInfo.snapR", a1 + 748);
        sub_14009BE90(hKey, v6, L"scrollLockInfo.snapB", a1 + 749);
        if ( v6 == 0 || *v54 != 0 )
        {
          v56 = a1 + 756;
          v57 = *(_DWORD *)(a1 + 756);
          if ( v6 == 0 )
          {
            sub_14009B970(hKey, L"popt.marginL", v57);
            sub_14009B970(hKey, L"popt.marginT", *(unsigned int *)(a1 + 760));
            sub_14009B970(hKey, L"popt.marginR", *(unsigned int *)(a1 + 764));
            sub_14009B970(hKey, L"popt.marginB", *(unsigned int *)(a1 + 768));
            sub_14009B970(hKey, L"popt.zoomRatio", *(unsigned int *)(a1 + 772));
LABEL_121:
            sub_14009BE90(hKey, v6, L"popt.rotate", a1 + 776);
            sub_14009BE90(hKey, v6, L"popt.fitIn", a1 + 777);
            v58 = *(_DWORD *)(a1 + 780);
            if ( v6 != 0 )
            {
              sub_14009B760(hKey, L"wp_bkcolorMode", a1 + 780, v58);
              sub_14009B760(hKey, L"wp_bkcolor", a1 + 784, *(unsigned int *)(a1 + 784));
              sub_14009B760(hKey, L"wp_apply", a1 + 788, *(unsigned int *)(a1 + 788));
            }
            else
            {
              sub_14009B970(hKey, L"wp_bkcolorMode", v58);
              sub_14009B970(hKey, L"wp_bkcolor", *(unsigned int *)(a1 + 784));
              sub_14009B970(hKey, L"wp_apply", *(unsigned int *)(a1 + 788));
            }
            sub_14009BE90(hKey, v6, L"slideShow.loop", a1 + 792);
            sub_14009BE90(hKey, v6, L"slideShow.random", a1 + 793);
            sub_14009BE90(hKey, v6, L"slideShow.show_timer", a1 + 794);
            for ( m = 0; m < 9; ++m )
            {
              sub_140072490(v68, (__int64)L"slideShowTime[%d]", (unsigned int)m);
              v60 = a1 + 4LL * (unsigned int)m;
              v61 = *(unsigned int *)(v60 + 796);
              if ( v6 != 0 )
                sub_14009B760(hKey, v68[0], v60 + 796, (unsigned int)v61);
              else
                sub_14009B970(hKey, v68[0], v61);
              v62 = (char *)v68[0] - 24;
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)v68[0] - 2, 0xFFFFFFFF) <= 1 )
                (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v62 + 8LL))(*v62);
            }
            v63 = *(_DWORD *)(a1 + 832);
            if ( v6 != 0 )
              sub_14009B760(hKey, L"slideShow.pageTurnFX", a1 + 832, v63);
            else
              sub_14009B970(hKey, L"slideShow.pageTurnFX", v63);
            sub_14009BE90(hKey, v6, L"group.raw_jpg", a1 + 836);
            sub_14009BE90(hKey, v6, L"group.raw_show_jpg", a1 + 837);
            sub_14009BE90(hKey, v6, L"group.psd_jpg", a1 + 838);
            sub_14009BE90(hKey, v6, L"group.psd_show_jpg", a1 + 839);
            sub_14009BE90(hKey, v6, L"group.del_both", a1 + 840);
            sub_14009BE90(hKey, v6, L"group.ren_both", a1 + 841);
            sub_14009BE90(hKey, v6, L"group.cpy_both", a1 + 842);
            v64 = *(_DWORD *)(a1 + 844);
            if ( v6 != 0 )
            {
              sub_14009B760(hKey, L"custColor[0]", a1 + 844, v64);
              sub_14009B760(hKey, L"custColor[1]", a1 + 848, *(unsigned int *)(a1 + 848));
              sub_14009B760(hKey, L"custColor[2]", a1 + 852, *(unsigned int *)(a1 + 852));
              sub_14009B760(hKey, L"custColor[3]", a1 + 856, *(unsigned int *)(a1 + 856));
              sub_14009B760(hKey, L"custColor[4]", a1 + 860, *(unsigned int *)(a1 + 860));
              sub_14009B760(hKey, L"custColor[5]", a1 + 864, *(unsigned int *)(a1 + 864));
              sub_14009B760(hKey, L"custColor[6]", a1 + 868, *(unsigned int *)(a1 + 868));
              sub_14009B760(hKey, L"custColor[7]", a1 + 872, *(unsigned int *)(a1 + 872));
              sub_14009B760(hKey, L"custColor[8]", a1 + 876, *(unsigned int *)(a1 + 876));
              sub_14009B760(hKey, L"custColor[9]", a1 + 880, *(unsigned int *)(a1 + 880));
              sub_14009B760(hKey, L"custColor[10]", a1 + 884, *(unsigned int *)(a1 + 884));
              sub_14009B760(hKey, L"custColor[11]", a1 + 888, *(unsigned int *)(a1 + 888));
              sub_14009B760(hKey, L"custColor[12]", a1 + 892, *(unsigned int *)(a1 + 892));
              sub_14009B760(hKey, L"custColor[13]", a1 + 896, *(unsigned int *)(a1 + 896));
              sub_14009B760(hKey, L"custColor[14]", a1 + 900, *(unsigned int *)(a1 + 900));
              sub_14009B760(hKey, L"custColor[15]", a1 + 904, *(unsigned int *)(a1 + 904));
              sub_14009B760(hKey, L"debug_setting_tab", a1 + 908, *(unsigned int *)(a1 + 908));
            }
            else
            {
              sub_14009B970(hKey, L"custColor[0]", v64);
              sub_14009B970(hKey, L"custColor[1]", *(unsigned int *)(a1 + 848));
              sub_14009B970(hKey, L"custColor[2]", *(unsigned int *)(a1 + 852));
              sub_14009B970(hKey, L"custColor[3]", *(unsigned int *)(a1 + 856));
              sub_14009B970(hKey, L"custColor[4]", *(unsigned int *)(a1 + 860));
              sub_14009B970(hKey, L"custColor[5]", *(unsigned int *)(a1 + 864));
              sub_14009B970(hKey, L"custColor[6]", *(unsigned int *)(a1 + 868));
              sub_14009B970(hKey, L"custColor[7]", *(unsigned int *)(a1 + 872));
              sub_14009B970(hKey, L"custColor[8]", *(unsigned int *)(a1 + 876));
              sub_14009B970(hKey, L"custColor[9]", *(unsigned int *)(a1 + 880));
              sub_14009B970(hKey, L"custColor[10]", *(unsigned int *)(a1 + 884));
              sub_14009B970(hKey, L"custColor[11]", *(unsigned int *)(a1 + 888));
              sub_14009B970(hKey, L"custColor[12]", *(unsigned int *)(a1 + 892));
              sub_14009B970(hKey, L"custColor[13]", *(unsigned int *)(a1 + 896));
              sub_14009B970(hKey, L"custColor[14]", *(unsigned int *)(a1 + 900));
              sub_14009B970(hKey, L"custColor[15]", *(unsigned int *)(a1 + 904));
              sub_14009B970(hKey, L"debug_setting_tab", *(unsigned int *)(a1 + 908));
            }
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v8 - 24 + 16), 0xFFFFFFFF) <= 1 )
              (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v8 - 24) + 8LL))(*(_QWORD *)(v8 - 24));
            sub_14009B2F0(hKey);
            v65 = (volatile signed __int32 *)(*v78 - 24LL);
            if ( _InterlockedExchangeAdd(v65 + 4, 0xFFFFFFFF) <= 1 )
              (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v65 + 8LL))(*(_QWORD *)v65);
            return 1;
          }
        }
        else
        {
          *(_QWORD *)v55 = 0;
          *(_WORD *)(v55 + 8) = 0;
          v56 = a1 + 756;
          v57 = *(_DWORD *)(a1 + 756);
        }
        sub_14009B760(hKey, L"popt.marginL", v56, v57);
        sub_14009B760(hKey, L"popt.marginT", a1 + 760, *(unsigned int *)(a1 + 760));
        sub_14009B760(hKey, L"popt.marginR", a1 + 764, *(unsigned int *)(a1 + 764));
        sub_14009B760(hKey, L"popt.marginB", a1 + 768, *(unsigned int *)(a1 + 768));
        sub_14009B760(hKey, L"popt.zoomRatio", a1 + 772, *(unsigned int *)(a1 + 772));
        goto LABEL_121;
      }
      sub_14009BBC0(hKey, L"sRecentFolder", v68);
      v40 = *(_QWORD *)(a1 + 504);
    }
    v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(v40 - 24)) + 24);
    sub_14009BBC0(hKey, L"extProg0", v68);
    sub_14009B970(hKey, L"videoOutput", *(unsigned int *)(a1 + 512));
    goto LABEL_76;
  }
  if ( a2 == 1 )
  {
    v73 = 1;
    v71 = 1;
    sub_14005FCF0((int **)lpSubKey, L"SOFTWARE\\BandiView", 18);
    v74 = 1;
    sub_140082940(hKey, HKEY_CURRENT_USER, lpSubKey[0]);
LABEL_9:
    v6 = 0;
    v69[0] = 0;
    sub_14009BE90(hKey, 0, L"isFirst", v69);
    v68[0] = (const void *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 8) - 24LL)) + 24);
    sub_14009BBC0(hKey, L"appEditionStrEn", v68);
    sub_14009B970(hKey, L"lastErrorDay", *(unsigned int *)(a1 + 24));
    sub_14009B970(hKey, L"lastErrorDayCount", *(unsigned int *)(a1 + 28));
    sub_14009B970(hKey, L"serverBuildNo", *(unsigned int *)(a1 + 32));
    sub_14009B970(hKey, L"serverBuildNoCur", *(unsigned int *)(a1 + 36));
    sub_14009B970(hKey, L"lastUpdateCheckDay", *(unsigned int *)(a1 + 40));
    sub_14009B970(hKey, L"lastShowADDay", *(unsigned int *)(a1 + 44));
    sub_14009B970(hKey, L"sizeSelFolderDlg.cx", *(unsigned int *)(a1 + 48));
    sub_14009B970(hKey, L"sizeSelFolderDlg.cy", *(unsigned int *)(a1 + 52));
    goto LABEL_10;
  }
  if ( a2 == 2 && (unsigned int)sub_14009B3E0(hKey, *a3) != 0 )
    goto LABEL_9;
  sub_14009B2F0(hKey);
  v67 = (volatile signed __int32 *)(*a3 - 24LL);
  if ( _InterlockedExchangeAdd(v67 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v67 + 8LL))(*(_QWORD *)v67);
  return 0;
}
