// EA 0x1401d0b60  name sub_1401D0B60  size 447
char __fastcall sub_1401D0B60(__int64 a1, _QWORD *a2)
{
  void *v4; // rcx
  char *v6; // rsi
  __int64 v7; // rax
  unsigned __int64 v8; // rdi
  __int64 v9; // rbp
  _BYTE *v10; // rbx
  _BYTE *v11; // rax
  _QWORD *v12; // rdx
  char v13; // bl
  LARGE_INTEGER FileSize; // [rsp+20h] [rbp-78h] BYREF
  _BYTE *v15; // [rsp+28h] [rbp-70h]
  unsigned __int64 v16; // [rsp+30h] [rbp-68h]
  __int64 v17; // [rsp+38h] [rbp-60h]
  _QWORD v18[4]; // [rsp+40h] [rbp-58h] BYREF

  v4 = (void *)a2[1];
  if ( v4 != (void *)-1LL && GetFileSizeEx(v4, &FileSize) && FileSize.QuadPart > 104857600 )
    return 0;
  v6 = nullptr;
  v15 = nullptr;
  v17 = 0;
  v16 = 0;
  v7 = (*(__int64 (__fastcall **)(_QWORD *))(*a2 + 32LL))(a2);
  v8 = v7;
  v9 = v7 + 2;
  if ( v7 == -2 )
  {
    v15 = nullptr;
    v9 = 0;
    v17 = 0;
    v10 = nullptr;
  }
  else
  {
    v11 = j__realloc_base(nullptr, v7 + 2);
    v10 = v11;
    if ( v11 == nullptr )
      goto LABEL_23;
    v6 = v11;
    v15 = v11;
    v17 = v9;
  }
  v16 = 0;
  (*(void (__fastcall **)(_QWORD *, _QWORD))(*a2 + 16LL))(a2, 0);
  FileSize.QuadPart = 0;
  if ( (*(unsigned __int8 (__fastcall **)(_QWORD *, char *, unsigned __int64, LARGE_INTEGER *))(*a2 + 8LL))(
         a2,
         v6,
         v8,
         &FileSize) != 0
    && v8 == FileSize.QuadPart )
  {
    *(_WORD *)&v6[v9 - 2] = 0;
    v16 = v8;
    if ( v8 > 2 && *v10 == 0xFF && v10[1] == 0xFE )
    {
      sub_1401CB620(v18, v10 + 2, (unsigned int)(((int)v8 - 2) / 2));
      v12 = v18;
      if ( v18[3] > 0xFu )
        v12 = (_QWORD *)v18[0];
      v13 = sub_1401D0D20(a1, v12, v18[2]);
      sub_14007F110(v18);
    }
    else
    {
      if ( v8 > 3 && *v10 == 0xEF && v10[1] == 0xBB && v10[2] == 0xBF )
      {
        v10 += 3;
        v8 -= 3LL;
      }
      v13 = sub_1401D0D20(a1, v10, v8);
    }
    goto LABEL_24;
  }
LABEL_23:
  v13 = 0;
LABEL_24:
  if ( v6 != nullptr )
    j__free_base(v6);
  return v13;
}
