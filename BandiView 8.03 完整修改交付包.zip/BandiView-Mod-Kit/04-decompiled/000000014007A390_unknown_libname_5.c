// EA 0x14007a390  name unknown_libname_5  size 17
// Microsoft VisualC v14 64bit runtime
void __noreturn unknown_libname_5()
{
  sub_140496310("invalid vector subscript");
}
