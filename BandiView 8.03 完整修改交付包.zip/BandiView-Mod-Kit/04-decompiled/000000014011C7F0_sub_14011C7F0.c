// EA 0x14011c7f0  name sub_14011C7F0  size 2139
__int64 __fastcall sub_14011C7F0(__int64 a1)
{
  unsigned __int8 v2; // bl
  __int64 *v3; // rax
  unsigned __int8 v4; // bl
  __int64 *v5; // rax
  unsigned __int8 v6; // bl
  __int64 *v7; // rax
  unsigned __int8 v8; // bl
  __int64 *v9; // rax
  unsigned __int8 v10; // bl
  __int64 *v11; // rax
  __int64 v12; // rcx
  __int64 *v13; // rdi
  __int64 v14; // rax
  const void *v15; // rbx
  unsigned __int64 v16; // rax
  __int64 *v17; // rdi
  __int64 v18; // rcx
  __int64 v19; // rax
  const void *v20; // rbx
  unsigned __int64 v21; // rax
  __int64 *v22; // rdi
  __int64 v23; // rcx
  __int64 v24; // rax
  const void *v25; // rbx
  unsigned __int64 v26; // rax
  __int64 *v27; // rdi
  __int64 v28; // rcx
  __int64 v29; // rax
  const void *v30; // rbx
  unsigned __int64 v31; // rax
  __int64 *v32; // rbx
  __int16 *v33; // rax
  __int64 *v34; // rdi
  __int64 v35; // rax
  const void *v36; // rbx
  unsigned __int64 v37; // rax
  __int64 *v38; // rdi
  __int64 v39; // rcx
  __int64 v40; // rax
  const void *v41; // rbx
  unsigned __int64 v42; // rax
  __int64 *v43; // rdi
  __int64 v44; // rcx
  __int64 v45; // rax
  const void *v46; // rbx
  unsigned __int64 v47; // rax
  __int64 *v48; // rdi
  __int64 v49; // rcx
  __int64 v50; // rax
  const void *v51; // rbx
  unsigned __int64 v52; // rax
  __int64 *v53; // rbx
  __int16 *v54; // rax
  unsigned __int8 v55; // bl
  __int64 *v56; // rax
  unsigned __int8 v57; // bl
  __int64 *v58; // rax
  int *v60; // [rsp+20h] [rbp-48h] BYREF
  int **v61; // [rsp+28h] [rbp-40h]
  __int128 v62; // [rsp+30h] [rbp-38h] BYREF
  __int128 v63; // [rsp+40h] [rbp-28h]

  v2 = *((_BYTE *)sub_140075FE0() + 164);
  v61 = &v60;
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  v60 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
  if ( (unsigned __int8)sub_14005F980(&v60, (__int64)L"CHK_ESC_TO_EXIT") == 0 )
    sub_14005FCF0(&v60, L"CHK_ESC_TO_EXIT", 15);
  sub_1400ACE70(a1, &v60, v2);
  v4 = *((_BYTE *)sub_140075FE0() + 165);
  v61 = &v60;
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  v60 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
  if ( (unsigned __int8)sub_14005F980(&v60, (__int64)L"CHK_ONE_INSTANCE") == 0 )
    sub_14005FCF0(&v60, L"CHK_ONE_INSTANCE", 16);
  sub_1400ACE70(a1, &v60, v4);
  v6 = *((_BYTE *)sub_140075FE0() + 166);
  v61 = &v60;
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  v60 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
  if ( (unsigned __int8)sub_14005F980(&v60, (__int64)L"CHK_ASK_DELETE") == 0 )
    sub_14005FCF0(&v60, L"CHK_ASK_DELETE", 14);
  sub_1400ACE70(a1, &v60, v6);
  v8 = *((_BYTE *)sub_140075FE0() + 167);
  v61 = &v60;
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    sub_14005FF30(0x80004005);
  v60 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
  if ( (unsigned __int8)sub_14005F980(&v60, (__int64)L"CHK_ALWAYS_ON_TOP") == 0 )
    sub_14005FCF0(&v60, L"CHK_ALWAYS_ON_TOP", 17);
  sub_1400ACE70(a1, &v60, v8);
  v10 = *((_BYTE *)sub_140075FE0() + 168);
  v61 = &v60;
  v11 = sub_1400601C0();
  if ( v11 == nullptr )
    sub_14005FF30(0x80004005);
  v60 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24);
  if ( (unsigned __int8)sub_14005F980(&v60, (__int64)L"CHK_USESNAP") == 0 )
    sub_14005FCF0(&v60, L"CHK_USESNAP", 11);
  sub_1400ACE70(a1, &v60, v10);
  v13 = *(__int64 **)(a1 + 632);
  if ( v13 != nullptr )
  {
    v14 = sub_1401C5640(v12);
    v15 = (const void *)sub_1401C81E0(v14, L"TEXT_COMBO_LASTFILE_ACTION_NONE", L"IDD_SETTING_GENERAL");
    v62 = 0;
    v63 = 0;
    v16 = sub_1404ADC20(v15);
    sub_140061270((char **)&v62, v15, v16);
    if ( v13[132] == v13[133] )
    {
      sub_140088250(v13 + 131, v13[132], (__int64)&v62);
    }
    else
    {
      sub_1400693B0(v13[132], (__int64)&v62);
      v13[132] += 32;
    }
    sub_14005D410((char **)&v62);
    v17 = *(__int64 **)(a1 + 632);
    v19 = sub_1401C5640(v18);
    v20 = (const void *)sub_1401C81E0(v19, L"TEXT_COMBO_LASTFILE_ACTION_ASK", L"IDD_SETTING_GENERAL");
    v62 = 0;
    v63 = 0;
    v21 = sub_1404ADC20(v20);
    sub_140061270((char **)&v62, v20, v21);
    if ( v17[132] == v17[133] )
    {
      sub_140088250(v17 + 131, v17[132], (__int64)&v62);
    }
    else
    {
      sub_1400693B0(v17[132], (__int64)&v62);
      v17[132] += 32;
    }
    sub_14005D410((char **)&v62);
    v22 = *(__int64 **)(a1 + 632);
    v24 = sub_1401C5640(v23);
    v25 = (const void *)sub_1401C81E0(v24, L"TEXT_COMBO_LASTFILE_ACTION_LOOP", L"IDD_SETTING_GENERAL");
    v62 = 0;
    v63 = 0;
    v26 = sub_1404ADC20(v25);
    sub_140061270((char **)&v62, v25, v26);
    if ( v22[132] == v22[133] )
    {
      sub_140088250(v22 + 131, v22[132], (__int64)&v62);
    }
    else
    {
      sub_1400693B0(v22[132], (__int64)&v62);
      v22[132] += 32;
    }
    sub_14005D410((char **)&v62);
    v27 = *(__int64 **)(a1 + 632);
    v29 = sub_1401C5640(v28);
    v30 = (const void *)sub_1401C81E0(v29, L"TEXT_COMBO_LASTFILE_ACTION_NEXTPATH", L"IDD_SETTING_GENERAL");
    v62 = 0;
    v63 = 0;
    v31 = sub_1404ADC20(v30);
    sub_140061270((char **)&v62, v30, v31);
    if ( v27[132] == v27[133] )
    {
      sub_140088250(v27 + 131, v27[132], (__int64)&v62);
    }
    else
    {
      sub_1400693B0(v27[132], (__int64)&v62);
      v27[132] += 32;
    }
    sub_14005D410((char **)&v62);
    v32 = *(__int64 **)(a1 + 632);
    v33 = sub_140075FE0();
    sub_1400BF760(v32, *((_DWORD *)v33 + 43));
    sub_1400BF940(*(__int64 **)(a1 + 632));
  }
  v34 = *(__int64 **)(a1 + 640);
  if ( v34 != nullptr )
  {
    v35 = sub_1401C5640(v12);
    v36 = (const void *)sub_1401C81E0(v35, L"TEXT_COMBO_LASTFILE_ACTION_NONE", L"IDD_SETTING_GENERAL");
    v62 = 0;
    v63 = 0;
    v37 = sub_1404ADC20(v36);
    sub_140061270((char **)&v62, v36, v37);
    if ( v34[132] == v34[133] )
    {
      sub_140088250(v34 + 131, v34[132], (__int64)&v62);
    }
    else
    {
      sub_1400693B0(v34[132], (__int64)&v62);
      v34[132] += 32;
    }
    sub_14005D410((char **)&v62);
    v38 = *(__int64 **)(a1 + 640);
    v40 = sub_1401C5640(v39);
    v41 = (const void *)sub_1401C81E0(v40, L"TEXT_COMBO_LASTFILE_ACTION_ASK", L"IDD_SETTING_GENERAL");
    v62 = 0;
    v63 = 0;
    v42 = sub_1404ADC20(v41);
    sub_140061270((char **)&v62, v41, v42);
    if ( v38[132] == v38[133] )
    {
      sub_140088250(v38 + 131, v38[132], (__int64)&v62);
    }
    else
    {
      sub_1400693B0(v38[132], (__int64)&v62);
      v38[132] += 32;
    }
    sub_14005D410((char **)&v62);
    v43 = *(__int64 **)(a1 + 640);
    v45 = sub_1401C5640(v44);
    v46 = (const void *)sub_1401C81E0(v45, L"TEXT_COMBO_LASTFILE_ACTION_LOOP", L"IDD_SETTING_GENERAL");
    v62 = 0;
    v63 = 0;
    v47 = sub_1404ADC20(v46);
    sub_140061270((char **)&v62, v46, v47);
    if ( v43[132] == v43[133] )
    {
      sub_140088250(v43 + 131, v43[132], (__int64)&v62);
    }
    else
    {
      sub_1400693B0(v43[132], (__int64)&v62);
      v43[132] += 32;
    }
    sub_14005D410((char **)&v62);
    v48 = *(__int64 **)(a1 + 640);
    v50 = sub_1401C5640(v49);
    v51 = (const void *)sub_1401C81E0(v50, L"TEXT_COMBO_LASTFILE_ACTION_NEXTPATH", L"IDD_SETTING_GENERAL");
    v62 = 0;
    v63 = 0;
    v52 = sub_1404ADC20(v51);
    sub_140061270((char **)&v62, v51, v52);
    if ( v48[132] == v48[133] )
    {
      sub_140088250(v48 + 131, v48[132], (__int64)&v62);
    }
    else
    {
      sub_1400693B0(v48[132], (__int64)&v62);
      v48[132] += 32;
    }
    sub_14005D410((char **)&v62);
    v53 = *(__int64 **)(a1 + 640);
    v54 = sub_140075FE0();
    sub_1400BF760(v53, *((_DWORD *)v54 + 44));
    sub_1400BF940(*(__int64 **)(a1 + 640));
  }
  v55 = *((_BYTE *)sub_140075FE0() + 180);
  v61 = &v60;
  v56 = sub_1400601C0();
  if ( v56 == nullptr )
    sub_14005FF30(0x80004005);
  v60 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v56 + 24))(v56) + 24);
  if ( (unsigned __int8)sub_14005F980(&v60, (__int64)L"CHK_UPDATE_0") == 0 )
    sub_14005FCF0(&v60, L"CHK_UPDATE_0", 12);
  sub_1400ACE70(a1, &v60, v55);
  v57 = *((_BYTE *)sub_140075FE0() + 181);
  v61 = &v60;
  v58 = sub_1400601C0();
  if ( v58 == nullptr )
    sub_14005FF30(0x80004005);
  v60 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v58 + 24))(v58) + 24);
  if ( (unsigned __int8)sub_14005F980(&v60, (__int64)L"CHK_UPDATE_1") == 0 )
    sub_14005FCF0(&v60, L"CHK_UPDATE_1", 12);
  sub_1400ACE70(a1, &v60, v57);
  return sub_14011D6E0(a1);
}
