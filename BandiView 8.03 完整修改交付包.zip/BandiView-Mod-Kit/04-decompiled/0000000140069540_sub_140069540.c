// EA 0x140069540  name sub_140069540  size 331
void **__fastcall sub_140069540(void **a1, const void *a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // rsi
  char *v7; // rsi
  __int64 v8; // rbx
  __int64 v10; // rbx
  __int64 v11; // rdx
  __int64 v12; // rcx
  _WORD *v13; // rax
  _WORD *v14; // rbp
  char *v15; // rcx
  _BYTE *v16; // rax

  v3 = (unsigned __int64)a1[3];
  if ( a3 > v3 )
  {
    v10 = 0x7FFFFFFFFFFFFFFELL;
    if ( a3 > 0x7FFFFFFFFFFFFFFELL )
      unknown_libname_3();
    if ( (a3 | 7) > 0x7FFFFFFFFFFFFFFELL || (v11 = v3 >> 1, v3 > 0x7FFFFFFFFFFFFFFELL - (v3 >> 1)) )
    {
      v12 = 0x7FFFFFFFFFFFFFFFLL;
    }
    else
    {
      v10 = a3 | 7;
      if ( (a3 | 7) < v11 + v3 )
        v10 = v11 + v3;
      v12 = v10 + 1;
      if ( (unsigned __int64)(v10 + 1) > 0x7FFFFFFFFFFFFFFFLL )
      {
        sub_14005D3C0();
        JUMPOUT(0x14006968ALL);
      }
    }
    v13 = (_WORD *)sub_14005D1E0(2 * v12);
    a1[3] = (void *)v10;
    a1[2] = (void *)a3;
    v14 = v13;
    memcpy(v13, a2, 2 * a3);
    v14[a3] = 0;
    if ( v3 > 7 )
    {
      v15 = (char *)*a1;
      if ( 2 * v3 + 2 < 0x1000 )
      {
        v16 = *a1;
      }
      else
      {
        v16 = *((_BYTE **)v15 - 1);
        if ( (unsigned __int64)(v15 - v16 - 8) > 0x1F )
          __fastfail(5u);
      }
      j_j_j__free_base(v16);
    }
    *a1 = v14;
    return a1;
  }
  else
  {
    if ( v3 <= 7 )
      v7 = (char *)a1;
    else
      v7 = (char *)*a1;
    v8 = 2 * a3;
    a1[2] = (void *)a3;
    memcpy(v7, a2, 2 * a3);
    *(_WORD *)&v7[v8] = 0;
    return a1;
  }
}
