// EA 0x14009e9c0  name sub_14009E9C0  size 1120
__int64 __fastcall sub_14009E9C0(__int64 a1, unsigned __int64 *a2, unsigned __int64 *a3, __int64 a4, __int64 a5)
{
  const void *v9; // rdx
  const void *v10; // rdx
  _QWORD *v11; // rax
  _QWORD *v12; // rax
  _QWORD *v13; // rax
  unsigned int v14; // r14d
  unsigned int v15; // r12d
  unsigned int v16; // r15d
  __int64 v18; // [rsp+20h] [rbp-E0h] BYREF
  __int64 v19; // [rsp+28h] [rbp-D8h]
  __int64 v20; // [rsp+30h] [rbp-D0h]
  __int64 v21; // [rsp+38h] [rbp-C8h]
  void *Block[4]; // [rsp+40h] [rbp-C0h] BYREF
  __int128 v23; // [rsp+60h] [rbp-A0h] BYREF
  __int64 v24; // [rsp+70h] [rbp-90h]
  __int64 v25; // [rsp+78h] [rbp-88h]
  __int128 v26; // [rsp+80h] [rbp-80h] BYREF
  __int64 v27; // [rsp+90h] [rbp-70h]
  __int64 v28; // [rsp+98h] [rbp-68h]
  unsigned __int64 *v29; // [rsp+A0h] [rbp-60h]
  unsigned __int64 *v30; // [rsp+A8h] [rbp-58h]
  __int128 v31; // [rsp+B0h] [rbp-50h] BYREF
  __int128 v32; // [rsp+C0h] [rbp-40h]
  __int128 v33; // [rsp+D0h] [rbp-30h] BYREF
  __int64 v34; // [rsp+E0h] [rbp-20h]
  __int64 v35; // [rsp+E8h] [rbp-18h]

  v29 = a2;
  v30 = a3;
  v33 = 0;
  v34 = 0;
  v35 = 0;
  sub_140061270((char **)&v33, L"reportSpeed", 0xBu);
  v31 = 0;
  v32 = 0u;
  sub_140061270((char **)&v31, L"Version", 7u);
  *(_BYTE *)(a4 + 232) = (unsigned int)sub_1401D18C0(a1, &v31, &v33, 0) != 0;
  sub_14005D410((char **)&v31);
  sub_14005D410((char **)&v33);
  Block[2] = &v23;
  v23 = 0;
  v24 = 0;
  v25 = 7;
  LOWORD(v23) = 0;
  if ( &v23 != (__int128 *)a3 )
  {
    if ( a3[3] <= 7 )
      v9 = a3;
    else
      v9 = (const void *)*a3;
    sub_140069540((void **)&v23, v9, a3[2]);
  }
  Block[3] = &v26;
  v26 = 0;
  v27 = 0;
  v28 = 7;
  LOWORD(v26) = 0;
  if ( &v26 != (__int128 *)a2 )
  {
    if ( a2[3] <= 7 )
      v10 = a2;
    else
      v10 = (const void *)*a2;
    sub_140069540((void **)&v26, v10, a2[2]);
  }
  sub_14009E480(a1, (unsigned __int64 *)&v26, (char *)&v23, a4);
  Block[1] = nullptr;
  v11 = operator new(0x48u);
  *v11 = v11;
  v11[1] = v11;
  v11[2] = v11;
  *((_WORD *)v11 + 12) = 257;
  Block[0] = v11;
  *(_WORD *)((char *)&v18 + 1) = 0;
  v19 = 0;
  v20 = 0;
  v21 = 0;
  LOBYTE(v18) = 0;
  v12 = (_QWORD *)sub_140069AD0((__int64)&v33);
  v13 = sub_14005ED20(v12, L"version.ini", 0xBu);
  v31 = 0;
  v32 = 0u;
  v31 = *(_OWORD *)v13;
  v32 = *((_OWORD *)v13 + 1);
  v13[2] = 0;
  v13[3] = 7;
  *(_WORD *)v13 = 0;
  sub_1401D0A80(&v18, &v31);
  sub_14005D410((char **)&v31);
  sub_14005D410((char **)&v33);
  v31 = 0;
  v32 = 0u;
  sub_140061270((char **)&v31, L"BuildNoCur", 0xAu);
  v33 = 0;
  v34 = 0;
  v35 = 0;
  sub_140061270((char **)&v33, L"Version", 7u);
  v14 = sub_1401D18C0(a1, &v33, &v31, 0);
  sub_14005D410((char **)&v33);
  sub_14005D410((char **)&v31);
  v31 = 0;
  v32 = 0u;
  sub_140061270((char **)&v31, L"BuildNo", 7u);
  v33 = 0;
  v34 = 0;
  v35 = 0;
  sub_140061270((char **)&v33, L"Version", 7u);
  v15 = sub_1401D18C0(a1, &v33, &v31, 0);
  sub_14005D410((char **)&v33);
  sub_14005D410((char **)&v31);
  v31 = 0;
  v32 = 0u;
  sub_140061270((char **)&v31, L"BuildNo", 7u);
  v33 = 0;
  v34 = 0;
  v35 = 0;
  sub_140061270((char **)&v33, L"Version", 7u);
  v16 = sub_1401D18C0(&v18, &v33, &v31, 0);
  sub_14005D410((char **)&v33);
  sub_14005D410((char **)&v31);
  sub_14006DB60((__int64)L"CheckHavetoUpdate() - local:%d, server:%d, serverCur:%d", v16, v15, v14, v18, v19, v20, v21);
  if ( v14 != 0 && v16 != 0 )
  {
    *(_DWORD *)(a5 + 32) = v15;
    *(_DWORD *)(a5 + 36) = v14;
    sub_1401D0940(&v18);
    sub_1401067C0(Block, Block, *((_QWORD *)Block[0] + 1));
    j_j_j__free_base(Block[0]);
    sub_14005D410((char **)a2);
    sub_14005D410((char **)a3);
    if ( (int)v14 > (int)v16 )
      return 2;
    else
      return 1;
  }
  else
  {
    sub_1401D0940(&v18);
    sub_1401067C0(Block, Block, *((_QWORD *)Block[0] + 1));
    j_j_j__free_base(Block[0]);
    sub_14005D410((char **)a2);
    sub_14005D410((char **)a3);
    return 0;
  }
}
