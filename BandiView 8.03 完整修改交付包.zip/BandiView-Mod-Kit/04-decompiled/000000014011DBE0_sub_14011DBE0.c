// EA 0x14011dbe0  name sub_14011DBE0  size 348
__int64 __fastcall sub_14011DBE0(int *a1)
{
  __int64 *v1; // rax
  __int64 *v2; // rax
  LPCWSTR v3; // rdx
  signed __int32 v4; // eax
  bool v5; // cc
  __int64 result; // rax
  int **v7; // [rsp+20h] [rbp-20h] BYREF
  int **v8; // [rsp+28h] [rbp-18h]
  int *v9; // [rsp+50h] [rbp+10h] BYREF
  int *v10; // [rsp+58h] [rbp+18h] BYREF
  LPCWSTR lpString; // [rsp+60h] [rbp+20h] BYREF
  char v12; // [rsp+68h] [rbp+28h] BYREF

  v9 = a1;
  v7 = &v9;
  v1 = sub_1400601C0();
  if ( v1 == nullptr )
    sub_14005FF30(0x80004005);
  v9 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v1 + 24))(v1) + 24);
  if ( (unsigned __int8)sub_14005F980(&v9, (__int64)L"\\") == 0 )
    sub_14005FCF0(&v9, L"\\", 1);
  v8 = &v10;
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  v10 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  if ( (unsigned __int8)sub_14005F980(&v10, (__int64)L"Bookmarks") == 0 )
    sub_14005FCF0(&v10, L"Bookmarks", 9);
  sub_140072510(&v12, 28, L"BandiView");
  sub_1400705B0(&lpString, &v12, &v10, &v9, v7, v8);
  if ( (unsigned int)sub_14006FEE0(lpString) != 0 )
    v7 = (int **)(sub_14005F710((volatile signed __int32 *)lpString - 6) + 24);
  else
    sub_140072510(&v7, 28, L"BandiView");
  sub_1400719E0(&v7);
  v3 = lpString - 12;
  v4 = _InterlockedExchangeAdd((volatile signed __int32 *)lpString - 2, 0xFFFFFFFF);
  v5 = v4 <= 1;
  result = (unsigned int)(v4 - 1);
  if ( v5 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v3 + 8LL))(*(_QWORD *)v3);
  return result;
}
