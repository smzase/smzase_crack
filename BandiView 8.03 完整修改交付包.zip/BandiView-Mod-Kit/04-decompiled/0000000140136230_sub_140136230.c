// EA 0x140136230  name sub_140136230  size 3317
__int64 __fastcall sub_140136230(__int64 a1, __int64 a2, unsigned __int64 a3, int a4)
{
  char v6; // al
  __int64 v7; // rax
  _BYTE *v8; // rbx
  __int64 *v9; // rax
  int v10; // eax
  __int64 *v11; // rax
  __int64 *v12; // rax
  _QWORD *v13; // rdx
  __int64 *v14; // rax
  __int64 *v15; // rax
  __int64 v16; // rcx
  __int64 v17; // rax
  const void *v18; // rax
  __int64 *v19; // rbx
  __int64 *v20; // rax
  int *v21; // rdx
  volatile signed __int32 *v22; // rdx
  __int64 *v23; // rax
  __int64 *v24; // rax
  _QWORD *v25; // rbx
  _QWORD *v26; // rdx
  unsigned __int64 v27; // r14
  int ***v28; // rsi
  int v29; // eax
  __int64 v30; // rdi
  _QWORD *v31; // rdx
  __int64 *v32; // rax
  __int64 *v33; // rax
  __int64 v34; // rcx
  __int64 v35; // rax
  const void *v36; // rax
  __int64 *v37; // rbx
  __int64 *v38; // rax
  int *v39; // rdx
  _QWORD *v40; // rdx
  unsigned __int64 v41; // r15
  __int64 v42; // r12
  _QWORD *v43; // rdx
  void **v44; // rax
  int v45; // ebx
  void **v46; // r15
  __m128i si128; // xmm6
  _QWORD *v48; // rdx
  void **v49; // r8
  int v50; // ebx
  void **v51; // rdx
  _QWORD *v52; // rdx
  void **v53; // r8
  int v54; // ebx
  void **v55; // rdx
  _QWORD *v56; // rdx
  void **v57; // r8
  int v58; // ebx
  void **v59; // rdx
  _QWORD *v60; // rdx
  void **v61; // r8
  int v62; // ebx
  void **v63; // rdx
  __int64 *v64; // rax
  int v65; // eax
  __int16 *v66; // rax
  int *v67; // rbx
  __int64 *v68; // rax
  int **v69; // rdx
  int *v71; // [rsp+30h] [rbp-D0h] BYREF
  int *v72; // [rsp+38h] [rbp-C8h] BYREF
  ULONGLONG TickCount64; // [rsp+40h] [rbp-C0h] BYREF
  int **v74; // [rsp+48h] [rbp-B8h] BYREF
  int **v75; // [rsp+50h] [rbp-B0h] BYREF
  int ***v76; // [rsp+58h] [rbp-A8h] BYREF
  int ***v77; // [rsp+60h] [rbp-A0h] BYREF
  int **v78; // [rsp+68h] [rbp-98h]
  void *v79[4]; // [rsp+70h] [rbp-90h] BYREF
  void *v80[4]; // [rsp+90h] [rbp-70h] BYREF
  void *v81[4]; // [rsp+B0h] [rbp-50h] BYREF
  void *v82[4]; // [rsp+D0h] [rbp-30h] BYREF
  void *v83[4]; // [rsp+F0h] [rbp-10h] BYREF
  void *v84[4]; // [rsp+110h] [rbp+10h] BYREF
  void *v85[4]; // [rsp+130h] [rbp+30h] BYREF
  void *v86[4]; // [rsp+150h] [rbp+50h] BYREF
  void *v87[4]; // [rsp+170h] [rbp+70h] BYREF
  void *v88[4]; // [rsp+190h] [rbp+90h] BYREF

  LODWORD(v72) = 0;
  v6 = *(_BYTE *)(a1 + 328);
  if ( a4 != 0 )
  {
    if ( v6 != 0 )
    {
      LODWORD(v71) = 0;
      if ( (unsigned int)sub_14006DE70(*(_QWORD *)(a1 + 320), &v71) != 0 )
      {
        v23 = sub_1400601C0();
        if ( v23 == nullptr )
          sub_14005FF30(0x80004005);
        v76 = (int ***)((*(__int64 (__fastcall **)(__int64 *))(*v23 + 24))(v23) + 24);
        v24 = sub_1400601C0();
        if ( v24 == nullptr )
          sub_14005FF30(0x80004005);
        v75 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v24 + 24))(v24) + 24);
        sub_14005EB50((__int64)&v76, (__int64)L"%x", (unsigned int)v71);
        sub_14005EB50((__int64)&v75, (__int64)L"%08x", (unsigned int)v71);
        v25 = (_QWORD *)(a1 + 232);
        v26 = (_QWORD *)(a1 + 232);
        v27 = *(_QWORD *)(a1 + 256);
        if ( v27 > 7 )
          v26 = (_QWORD *)*v25;
        if ( v26 == nullptr )
          sub_14005FF30(0x80004005);
        v28 = v76;
        v29 = sub_1404D8590(v76, v26);
        v30 = (__int64)v75;
        if ( v29 == 0 )
          goto LABEL_57;
        v31 = (_QWORD *)(a1 + 232);
        if ( v27 > 7 )
          v31 = (_QWORD *)*v25;
        if ( v31 == nullptr )
          sub_14005FF30(0x80004005);
        if ( (unsigned int)sub_1404D8590(v75, v31) != 0 )
        {
          if ( v27 > 7 )
            v25 = (_QWORD *)*v25;
          sub_140072490(&TickCount64, (__int64)aUpdatedlgCrc_0, 307, v28, v30, v25);
          sub_14006DB60(TickCount64);
          v77 = (int ***)&v71;
          v32 = sub_1400601C0();
          if ( v32 == nullptr )
            sub_14005FF30(0x80004005);
          v71 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v32 + 24))(v32) + 24);
          if ( (unsigned __int8)sub_14005F980(&v71, (__int64)L"error") == 0 )
            sub_14005FCF0(&v71, L"error", 5);
          v74 = (int **)(sub_14005F710((volatile signed __int32 *)(TickCount64 - 24)) + 24);
          sub_140074840((unsigned __int64 *)&v74, &v71, 1);
          v77 = &v74;
          v33 = sub_1400601C0();
          if ( v33 == nullptr )
            sub_14005FF30(0x80004005);
          v72 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v33 + 24))(v33) + 24);
          if ( (unsigned __int8)sub_14005F980(&v72, (__int64)L"(DiffCRC)") == 0 )
            sub_14005FCF0(&v72, L"(DiffCRC)", 9);
          v35 = sub_1401C5640(v34);
          v36 = (const void *)sub_1401C81E0(v35, L"TEXT_UPDATE_DOWNLOAD_FAILED", L"TEXT");
          v37 = sub_1400609A0((__int64 *)&v74, v36, (const void **)&v72);
          v78 = &v71;
          v38 = sub_1400601C0();
          if ( v38 == nullptr )
            sub_14005FF30(0x80004005);
          v71 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v38 + 24))(v38) + 24);
          if ( (unsigned __int8)sub_14005F980(&v71, (__int64)L"IDOK") == 0 )
            sub_14005FCF0(&v71, L"IDOK", 4);
          sub_1401C5020(a1 + 336, &v71, v37);
          v39 = v72 - 6;
          if ( _InterlockedExchangeAdd(v72 - 2, 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v39 + 8LL))(*(_QWORD *)v39);
          v40 = (_QWORD *)(TickCount64 - 24);
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)(TickCount64 - 24 + 16), 0xFFFFFFFF) <= 1 )
            (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v40 + 8LL))(*v40);
        }
        else
        {
LABEL_57:
          if ( *(_BYTE *)(a1 + 304) != 0 )
          {
            v41 = a3 >> 16;
            TickCount64 = GetTickCount64();
            v42 = *(_QWORD *)(a1 + 2376);
            if ( (_WORD)v41 != 0 )
            {
              si128 = _mm_load_si128((const __m128i *)&xmmword_140662F90);
              if ( (_WORD)v41 == 1 )
              {
                *(_OWORD *)v86 = 0;
                *(__m128i *)&v86[2] = si128;
                LOWORD(v86[0]) = 0;
                v48 = (_QWORD *)(a1 + 104);
                if ( v86 != (void **)(a1 + 104) )
                {
                  if ( *(_QWORD *)(a1 + 128) > 7u )
                    v48 = (_QWORD *)*v48;
                  sub_140069540(v86, v48, *(_QWORD *)(a1 + 120));
                }
                v49 = v86;
                v50 = 2;
                v51 = (void **)v86[0];
              }
              else
              {
                if ( (_WORD)v41 == 2 )
                {
                  *(_OWORD *)v85 = 0;
                  *(__m128i *)&v85[2] = si128;
                  LOWORD(v85[0]) = 0;
                  v52 = (_QWORD *)(a1 + 136);
                  if ( v85 != (void **)(a1 + 136) )
                  {
                    if ( *(_QWORD *)(a1 + 160) > 7u )
                      v52 = (_QWORD *)*v52;
                    sub_140069540(v85, v52, *(_QWORD *)(a1 + 152));
                  }
                  v53 = v85;
                  v54 = 4;
                  v55 = (void **)v85[0];
                }
                else
                {
                  if ( (_WORD)v41 == 3 )
                  {
                    *(_OWORD *)v84 = 0;
                    *(__m128i *)&v84[2] = si128;
                    LOWORD(v84[0]) = 0;
                    v56 = (_QWORD *)(a1 + 168);
                    if ( v84 != (void **)(a1 + 168) )
                    {
                      if ( *(_QWORD *)(a1 + 192) > 7u )
                        v56 = (_QWORD *)*v56;
                      sub_140069540(v84, v56, *(_QWORD *)(a1 + 184));
                    }
                    v57 = v84;
                    v58 = 8;
                    v59 = (void **)v84[0];
                  }
                  else
                  {
                    if ( (_WORD)v41 == 4 )
                    {
                      *(_OWORD *)v83 = 0;
                      *(__m128i *)&v83[2] = si128;
                      LOWORD(v83[0]) = 0;
                      v60 = (_QWORD *)(a1 + 200);
                      if ( v83 != (void **)(a1 + 200) )
                      {
                        if ( *(_QWORD *)(a1 + 224) > 7u )
                          v60 = (_QWORD *)*v60;
                        sub_140069540(v83, v60, *(_QWORD *)(a1 + 216));
                      }
                      v61 = v83;
                      v62 = 16;
                      v63 = (void **)v83[0];
                    }
                    else
                    {
                      *(_OWORD *)v88 = 0;
                      *(__m128i *)&v88[2] = si128;
                      LOWORD(v88[0]) = 0;
                      sub_140069540(v88, L"??", 2u);
                      v61 = v88;
                      v62 = 32;
                      v63 = (void **)v88[0];
                    }
                    LODWORD(v72) = v62;
                    *(_OWORD *)v82 = 0;
                    *(__m128i *)&v82[2] = si128;
                    LOWORD(v82[0]) = 0;
                    if ( v82 != v61 )
                    {
                      if ( (unsigned __int64)v61[3] <= 7 )
                        v63 = v61;
                      sub_140069540(v82, v63, (unsigned __int64)v61[2]);
                    }
                    v57 = v82;
                    v58 = v62 | 0x40;
                    v59 = (void **)v82[0];
                  }
                  LODWORD(v72) = v58;
                  *(_OWORD *)v81 = 0;
                  *(__m128i *)&v81[2] = si128;
                  LOWORD(v81[0]) = 0;
                  if ( v81 != v57 )
                  {
                    if ( (unsigned __int64)v57[3] <= 7 )
                      v59 = v57;
                    sub_140069540(v81, v59, (unsigned __int64)v57[2]);
                  }
                  v53 = v81;
                  v54 = v58 | 0x80;
                  v55 = (void **)v81[0];
                }
                LODWORD(v72) = v54;
                *(_OWORD *)v80 = 0;
                *(__m128i *)&v80[2] = si128;
                LOWORD(v80[0]) = 0;
                if ( v80 != v53 )
                {
                  if ( (unsigned __int64)v53[3] <= 7 )
                    v55 = v53;
                  sub_140069540(v80, v55, (unsigned __int64)v53[2]);
                }
                v49 = v80;
                v50 = v54 | 0x100;
                v51 = (void **)v80[0];
              }
              LODWORD(v72) = v50;
              *(_OWORD *)v79 = 0;
              *(__m128i *)&v79[2] = si128;
              LOWORD(v79[0]) = 0;
              if ( v79 != v49 )
              {
                if ( (unsigned __int64)v49[3] <= 7 )
                  v51 = v49;
                sub_140069540(v79, v51, (unsigned __int64)v49[2]);
              }
              v44 = v79;
              v45 = v50 | 0x200;
              v46 = (void **)v79[0];
            }
            else
            {
              *(_OWORD *)v87 = 0;
              *(__m128i *)&v87[2] = _mm_load_si128((const __m128i *)&xmmword_140662F90);
              LOWORD(v87[0]) = 0;
              v43 = (_QWORD *)(a1 + 72);
              if ( v87 != (void **)(a1 + 72) )
              {
                if ( *(_QWORD *)(a1 + 96) > 7u )
                  v43 = (_QWORD *)*v43;
                sub_140069540(v87, v43, *(_QWORD *)(a1 + 88));
              }
              v44 = v87;
              v45 = 1;
              v46 = (void **)v87[0];
            }
            LODWORD(v72) = v45;
            if ( (unsigned __int64)v44[3] <= 7 )
              v46 = v44;
            v64 = sub_1400601C0();
            if ( v64 == nullptr )
              sub_14005FF30(0x80004005);
            TickCount64 -= v42;
            v77 = (int ***)((*(__int64 (__fastcall **)(__int64 *))(*v64 + 24))(v64) + 24);
            if ( (unsigned __int8)sub_14005F980(&v77, (__int64)v46) == 0 )
            {
              if ( v46 != nullptr )
                v65 = sub_1404ADC20(v46);
              else
                v65 = 0;
              sub_14005FCF0((int **)&v77, v46, v65);
            }
            if ( (v45 & 0x200) != 0 )
            {
              LOWORD(v45) = v45 & 0xFDFF;
              sub_14005D410((char **)v79);
            }
            if ( (v45 & 0x100) != 0 )
              sub_14005D410((char **)v80);
            if ( (v45 & 0x80u) != 0 )
            {
              LOBYTE(v45) = v45 & 0x7F;
              sub_14005D410((char **)v81);
            }
            if ( (v45 & 0x40) != 0 )
            {
              LOBYTE(v45) = v45 & 0xBF;
              sub_14005D410((char **)v82);
            }
            if ( (v45 & 0x20) != 0 )
            {
              LOBYTE(v45) = v45 & 0xDF;
              sub_14005D410((char **)v88);
            }
            if ( (v45 & 0x10) != 0 )
            {
              LOBYTE(v45) = v45 & 0xEF;
              sub_14005D410((char **)v83);
            }
            if ( (v45 & 8) != 0 )
            {
              LOBYTE(v45) = v45 & 0xF7;
              sub_14005D410((char **)v84);
            }
            if ( (v45 & 4) != 0 )
            {
              LOBYTE(v45) = v45 & 0xFB;
              sub_14005D410((char **)v85);
            }
            if ( (v45 & 2) != 0 )
            {
              LOBYTE(v45) = v45 & 0xFD;
              sub_14005D410((char **)v86);
            }
            if ( (v45 & 1) != 0 )
              sub_14005D410((char **)v87);
            v66 = sub_140075FE0();
            v67 = (int *)v77;
            sub_140072490(
              &v74,
              (__int64)L"UpdateDlg DownReport - DL Time: %4dms, Lang:%s, url: %s",
              TickCount64,
              *((_QWORD *)v66 + 68),
              v77);
            sub_14006DB60((__int64)v74);
            v78 = &v71;
            v68 = sub_1400601C0();
            if ( v68 == nullptr )
              sub_14005FF30(0x80004005);
            v71 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v68 + 24))(v68) + 24);
            if ( (unsigned __int8)sub_14005F980(&v71, (__int64)L"report") == 0 )
              sub_14005FCF0(&v71, L"report", 6);
            TickCount64 = sub_14005F710((volatile signed __int32 *)v74 - 6) + 24;
            sub_140074840(&TickCount64, &v71, 1);
            v69 = v74 - 3;
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)v74 - 2, 0xFFFFFFFF) <= 1 )
              (*(void (__fastcall **)(int *))(*(_QWORD *)*v69 + 8LL))(*v69);
            if ( _InterlockedExchangeAdd(v67 - 2, 0xFFFFFFFF) <= 1 )
              (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v67 - 3) + 8LL))(*((_QWORD *)v67 - 3));
          }
          sub_140136F30(a1);
        }
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v30 - 24 + 16), 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v30 - 24) + 8LL))(*(_QWORD *)(v30 - 24));
        v22 = (volatile signed __int32 *)(v28 - 3);
      }
      else
      {
        sub_140072490(&TickCount64, (__int64)aUpdatedlgCrc, 294);
        sub_14006DB60(TickCount64);
        v75 = &v71;
        v14 = sub_1400601C0();
        if ( v14 == nullptr )
          sub_14005FF30(0x80004005);
        v71 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
        if ( (unsigned __int8)sub_14005F980(&v71, (__int64)L"error") == 0 )
          sub_14005FCF0(&v71, L"error", 5);
        v74 = (int **)(sub_14005F710((volatile signed __int32 *)(TickCount64 - 24)) + 24);
        sub_140074840((unsigned __int64 *)&v74, &v71, 1);
        v76 = &v75;
        v15 = sub_1400601C0();
        if ( v15 == nullptr )
          sub_14005FF30(0x80004005);
        v72 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
        if ( (unsigned __int8)sub_14005F980(&v72, (__int64)L"(GetCRC)") == 0 )
          sub_14005FCF0(&v72, L"(GetCRC)", 8);
        v17 = sub_1401C5640(v16);
        v18 = (const void *)sub_1401C81E0(v17, L"TEXT_UPDATE_DOWNLOAD_FAILED", L"TEXT");
        v19 = sub_1400609A0((__int64 *)&v75, v18, (const void **)&v72);
        v74 = &v71;
        v20 = sub_1400601C0();
        if ( v20 == nullptr )
          sub_14005FF30(0x80004005);
        v71 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v20 + 24))(v20) + 24);
        if ( (unsigned __int8)sub_14005F980(&v71, (__int64)L"IDOK") == 0 )
          sub_14005FCF0(&v71, L"IDOK", 4);
        sub_1401C5020(a1 + 336, &v71, v19);
        v21 = v72 - 6;
        if ( _InterlockedExchangeAdd(v72 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v21 + 8LL))(*(_QWORD *)v21);
        v22 = (volatile signed __int32 *)(TickCount64 - 24);
      }
      if ( _InterlockedExchangeAdd(v22 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v22 + 8LL))(*(_QWORD *)v22);
    }
  }
  else
  {
    if ( v6 != 0 )
    {
      v75 = &v71;
      v7 = sub_1401C5640(a1);
      v8 = (_BYTE *)sub_1401C81E0(v7, L"TEXT_UPDATE_VERSION_CHECK_FAILED", L"TEXT");
      v9 = sub_1400601C0();
      if ( v9 == nullptr )
        sub_14005FF30(0x80004005);
      v71 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
      if ( (unsigned __int8)sub_14005F980(&v71, (__int64)v8) == 0 )
      {
        if ( v8 != nullptr )
          v10 = sub_1404ADC20(v8);
        else
          v10 = 0;
        sub_14005FCF0(&v71, v8, v10);
      }
      v76 = (int ***)&v72;
      v11 = sub_1400601C0();
      if ( v11 == nullptr )
        sub_14005FF30(0x80004005);
      v72 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24);
      if ( (unsigned __int8)sub_14005F980(&v72, (__int64)L"IDOK") == 0 )
        sub_14005FCF0(&v72, L"IDOK", 4);
      sub_1401C5020(a1 + 336, &v72, &v71);
      sub_140072490(&TickCount64, (__int64)aUpdatedlg, 279);
      sub_14006DB60(TickCount64);
      v75 = &v71;
      v12 = sub_1400601C0();
      if ( v12 == nullptr )
        sub_14005FF30(0x80004005);
      v71 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24);
      if ( (unsigned __int8)sub_14005F980(&v71, (__int64)L"error") == 0 )
        sub_14005FCF0(&v71, L"error", 5);
      v74 = (int **)(sub_14005F710((volatile signed __int32 *)(TickCount64 - 24)) + 24);
      sub_140074840((unsigned __int64 *)&v74, &v71, 1);
      v13 = (_QWORD *)(TickCount64 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(TickCount64 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v13 + 8LL))(*v13);
    }
    *(_BYTE *)(a1 + 328) = 0;
  }
  return 0;
}
