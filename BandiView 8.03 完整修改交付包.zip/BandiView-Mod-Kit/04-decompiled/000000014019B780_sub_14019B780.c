// EA 0x14019b780  name sub_14019B780  size 407
__int64 __fastcall sub_14019B780(__int64 a1, _DWORD *a2)
{
  __int64 v4; // rbx
  void *v5; // rax
  __int64 v6; // rdi
  HACCEL AcceleratorsW; // r14
  unsigned int v8; // ebx
  HWND hwnd; // rax
  HWND v10; // rbx
  struct tagMSG Msg; // [rsp+20h] [rbp-48h] BYREF

  v4 = sub_14019BB00() + 16;
  v5 = operator new(0xFB0u);
  v6 = sub_14019D270(v5, v4);
  memset(&Msg, 0, sizeof(Msg));
  AcceleratorsW = LoadAcceleratorsW(hInstance, (LPCWSTR)0x65);
  if ( (unsigned int)sub_14019E010(v6, a1) != 0 )
  {
    if ( *a2 != 0 )
      sub_14019ED20(v6, a2);
    if ( GetMessageW(&Msg, nullptr, 0, 0) )
    {
      do
      {
        hwnd = Msg.hwnd;
        v10 = Msg.hwnd;
        if ( Msg.hwnd != nullptr )
        {
          while ( 1 )
          {
            hwnd = GetParent(hwnd);
            if ( hwnd == nullptr )
              break;
            v10 = hwnd;
          }
        }
        if ( !IsDialogMessageW(v10, &Msg) && TranslateAcceleratorW(*(HWND *)(v6 + 8), AcceleratorsW, &Msg) == 0 )
        {
          TranslateMessage(&Msg);
          DispatchMessageW(&Msg);
        }
      }
      while ( (a1 == 0 || *(_BYTE *)(v6 + 2168) == 0) && GetMessageW(&Msg, nullptr, 0, 0) );
    }
    if ( v6 != 0 )
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v6 + 8LL))(v6, 1);
    v8 = 0;
    v6 = 0;
  }
  else
  {
    v8 = 1;
  }
  if ( v6 != 0 )
    (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v6 + 8LL))(v6, 1);
  return v8;
}
