// EA 0x14007d020  name sub_14007D020  size 899
HMODULE *__fastcall sub_14007D020(_QWORD *a1)
{
  _DWORD *v2; // rbx
  __int64 *v3; // rax
  ULONGLONG TickCount64; // r15
  __int64 v5; // rcx
  int i; // ebx
  __int64 v7; // rcx
  int v8; // edi
  __int64 v9; // rcx
  __int64 v10; // rax
  __int64 v11; // rdx
  __int64 v12; // rax
  UINT v13; // ebx
  __int64 v14; // r8
  _QWORD *v15; // rdi
  unsigned __int64 *v16; // rax
  HWND ForegroundWindow; // rdi
  HWND v18; // rsi
  __int64 v19; // rax
  __int64 v20; // rdx
  __int64 v21; // r8
  __int64 v22; // rax
  __int64 v23; // rdx
  const WCHAR *v24; // rax
  LPCWSTR v25; // r8
  __int64 v26; // rbx
  __int64 *v27; // rax
  __int64 *v28; // rax
  __int64 v29; // rbx
  volatile signed __int32 *v30; // rdx
  _BYTE v32[8]; // [rsp+30h] [rbp-20h] BYREF
  int **p_uExitCode; // [rsp+38h] [rbp-18h]
  int **v34; // [rsp+40h] [rbp-10h]
  int *uExitCode; // [rsp+98h] [rbp+48h] BYREF
  __int64 v36; // [rsp+A0h] [rbp+50h] BYREF
  __int64 v37; // [rsp+A8h] [rbp+58h] BYREF

  v2 = (_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL);
  if ( dword_14070D200 > *v2 )
  {
    sub_140496500(&dword_14070D200);
    if ( dword_14070D200 == -1 )
    {
      hLibModule = nullptr;
      qword_14070D210 = 0;
      qword_14070D218 = 0;
      v3 = sub_1400601C0();
      if ( v3 == nullptr )
        sub_14005FF30(0x80004005);
      lpLibFileName = (LPCWSTR)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
      atexit(sub_140592860);
      Init_thread_footer(&dword_14070D200);
    }
  }
  if ( hLibModule == nullptr || qword_14070D218 == 0 )
  {
    if ( dword_14070D228 > *v2 )
    {
      sub_140496500(&dword_14070D228);
      if ( dword_14070D228 == -1 )
      {
        GetCurrentThreadId();
        Init_thread_footer(&dword_14070D228);
      }
    }
    TickCount64 = GetTickCount64();
    uExitCode = (int *)(sub_14005F710((volatile signed __int32 *)(*a1 - 24LL)) + 24);
    if ( (unsigned int)sub_14007D3B0(v5, &uExitCode) == 0 )
    {
      for ( i = 0; i < 10; ++i )
      {
        uExitCode = (int *)(sub_14005F710((volatile signed __int32 *)(*a1 - 24LL)) + 24);
        v8 = sub_14007D3B0(v7, &uExitCode);
        if ( v8 != 0 )
          break;
        Sleep(0x64u);
      }
      if ( v8 == 0 )
      {
        sub_1400602E0(&v36);
        sub_14007CF00(v9, &uExitCode);
        sub_1401C0850(&v37, &uExitCode);
        v10 = sub_14007CF10();
        v12 = sub_14005F700(&v37, v11, v10);
        v13 = (unsigned int)uExitCode;
        sub_14005EB50(
          (__int64)&v36,
          (__int64)L"Error: Cannot load %s. Code: 0x%x (%u, %s)",
          v14,
          (unsigned int)uExitCode,
          HIDWORD(uExitCode),
          v12);
        p_uExitCode = &uExitCode;
        v15 = (_QWORD *)sub_14005FE70(&uExitCode, L"lm.dll");
        v16 = (unsigned __int64 *)sub_14005F840(v32, &v36);
        sub_140074840(v16, v15, 1);
        ForegroundWindow = GetForegroundWindow();
        v18 = nullptr;
        if ( (unsigned __int8)sub_14006A9D0(ForegroundWindow) != 0 )
          v18 = ForegroundWindow;
        v19 = sub_14007D7F0(&uExitCode);
        v22 = sub_14005F700(v19, v20, v21);
        v24 = (const WCHAR *)sub_14005F700(&v36, v23, v22);
        MessageBoxW(v18, v24, v25, 0x1030u);
        `std::locale::global'::`1'::dtor$2(&uExitCode);
        ExitProcess(v13);
      }
    }
    v26 = GetTickCount64() - TickCount64;
    if ( v26 > 1000 )
    {
      v27 = sub_1400601C0();
      if ( v27 == nullptr )
        sub_14005FF30(0x80004005);
      v36 = (*(__int64 (__fastcall **)(__int64 *))(*v27 + 24))(v27) + 24;
      sub_14005EB50((__int64)&v36, (__int64)L"Error: It takes too long to load lm.dll [%dms]", (unsigned int)v26);
      v34 = &uExitCode;
      v28 = sub_1400601C0();
      if ( v28 == nullptr )
        sub_14005FF30(0x80004005);
      uExitCode = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24);
      if ( (unsigned __int8)sub_14005F980(&uExitCode, (__int64)L"lm.dll") == 0 )
        sub_14005FCF0(&uExitCode, L"lm.dll", 6);
      v29 = v36;
      v37 = sub_14005F710((volatile signed __int32 *)(v36 - 24)) + 24;
      sub_140074840((unsigned __int64 *)&v37, &uExitCode, 1);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v29 - 8), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD, __int64))(**(_QWORD **)(v29 - 24) + 8LL))(*(_QWORD *)(v29 - 24), v29 - 24);
    }
    (*(void (__fastcall **)(__int64))(*(_QWORD *)qword_14070D218 + 24LL))(qword_14070D218);
  }
  v30 = (volatile signed __int32 *)(*a1 - 24LL);
  if ( _InterlockedExchangeAdd(v30 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v30 + 8LL))(*(_QWORD *)v30);
  return &hLibModule;
}
