// EA 0x14011dd40  name sub_14011DD40  size 1320
void __fastcall sub_14011DD40(__int64 a1)
{
  __int64 v2; // rcx
  __int64 v3; // rax
  _BYTE *v4; // rbx
  __int64 *v5; // rax
  int v6; // r15d
  int *v7; // rdx
  int v8; // r15d
  _QWORD *v9; // rax
  __int64 v10; // rcx
  __int64 v11; // rcx
  __int64 v12; // rax
  _BYTE *v13; // rbx
  __int64 *v14; // rax
  __int64 v15; // rcx
  int *v16; // rdx
  char v17; // r12
  int *v18; // rbx
  __int64 v19; // rsi
  unsigned __int64 v20; // rax
  char v21; // di
  _QWORD *v22; // rax
  _QWORD *v23; // rdx
  __int64 *v24; // rax
  int *v25; // rdx
  __int64 v26; // rcx
  __int64 v27; // rax
  _BYTE *v28; // rbx
  __int64 *v29; // rax
  __int64 v30; // rax
  _BYTE *v31; // rbx
  __int64 *v32; // rax
  volatile signed __int32 *v33; // rdx
  int *v34; // [rsp+20h] [rbp-59h] BYREF
  int *v35; // [rsp+28h] [rbp-51h] BYREF
  int *v36; // [rsp+30h] [rbp-49h] BYREF
  void *Block; // [rsp+38h] [rbp-41h] BYREF
  __int64 v38; // [rsp+40h] [rbp-39h]
  __int64 v39; // [rsp+48h] [rbp-31h] BYREF
  int **v40; // [rsp+50h] [rbp-29h] BYREF
  int **v41; // [rsp+58h] [rbp-21h]
  __int64 v42; // [rsp+60h] [rbp-19h] BYREF
  __int128 v43; // [rsp+68h] [rbp-11h] BYREF
  __int64 v44; // [rsp+78h] [rbp-1h]
  __int64 v45; // [rsp+80h] [rbp+7h]

  if ( *(_QWORD *)(a1 + 520) != 0 )
  {
    v8 = 0;
    v38 = 0;
    v9 = operator new(0x18u);
    *v9 = v9;
    v9[1] = v9;
    Block = v9;
    sub_14011E270(v10, &Block);
    if ( v38 != 0 )
    {
      v17 = 0;
      v35 = (int *)Block;
      v18 = *(int **)Block;
      if ( *(void **)Block != Block )
      {
        do
        {
          v19 = *(_QWORD *)(a1 + 520);
          v43 = 0;
          v44 = 0;
          v45 = 0;
          v20 = sub_1404ADC20(*((_QWORD *)v18 + 2));
          sub_140061270((char **)&v43, *((const void **)v18 + 2), v20);
          v21 = sub_140103600(v19, &v43);
          sub_14005D410((char **)&v43);
          if ( v21 == 0 )
          {
            if ( v17 == 0 )
            {
              v40 = *(int ***)(*(_QWORD *)(a1 + 520) + 8LL);
              v22 = (_QWORD *)sub_1401C0850(&v42, &v40);
              sub_140072490(&v36, (__int64)L"Error at AddBookmark() - %s", *v22);
              v23 = (_QWORD *)(v42 - 24);
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v42 - 24 + 16), 0xFFFFFFFF) <= 1 )
                (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v23 + 8LL))(*v23);
              v40 = &v34;
              v24 = sub_1400601C0();
              if ( v24 == nullptr )
                sub_14005FF30(0x80004005);
              v34 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v24 + 24))(v24) + 24);
              if ( (unsigned __int8)sub_14005F980(&v34, (__int64)L"error") == 0 )
                sub_14005FCF0(&v34, L"error", 5);
              v39 = sub_14005F710(v36 - 6) + 24;
              sub_140074840((unsigned __int64 *)&v39, &v34, 1);
              v25 = v36 - 6;
              if ( _InterlockedExchangeAdd(v36 - 2, 0xFFFFFFFF) <= 1 )
                (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v25 + 8LL))(*(_QWORD *)v25);
            }
            v17 = 1;
          }
          v18 = *(int **)v18;
        }
        while ( v18 != v35 );
      }
      PostMessageW(*(HWND *)(a1 + 616), 0x111u, 0x8224u, 0);
      sub_14007D7F0(&v35);
      if ( v17 != 0 )
      {
        v41 = &v34;
        v27 = sub_1401C5640(v26);
        v28 = (_BYTE *)sub_1401C81E0(v27, L"TEXT_MSG_BOOKMARK_IMPORT_FAILED", L"TEXT");
        v29 = sub_1400601C0();
        if ( v29 == nullptr )
          sub_14005FF30(0x80004005);
        v34 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v29 + 24))(v29) + 24);
        if ( (unsigned __int8)sub_14005F980(&v34, (__int64)v28) == 0 )
        {
          if ( v28 != nullptr )
            v8 = sub_1404ADC20(v28);
          sub_14005FCF0(&v34, v28, v8);
        }
      }
      else
      {
        v41 = &v34;
        v30 = sub_1401C5640(v26);
        v31 = (_BYTE *)sub_1401C81E0(v30, L"TEXT_MSG_BOOKMARK_IMPORTED", L"TEXT");
        v32 = sub_1400601C0();
        if ( v32 == nullptr )
          sub_14005FF30(0x80004005);
        v34 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v32 + 24))(v32) + 24);
        if ( (unsigned __int8)sub_14005F980(&v34, (__int64)v31) == 0 )
        {
          if ( v31 != nullptr )
            v8 = sub_1404ADC20(v31);
          sub_14005FCF0(&v34, v31, v8);
        }
      }
      sub_14008B0F0(*(HWND *)(a1 + 8), (_BYTE **)&v34);
      v16 = v35;
    }
    else
    {
      sub_14007D7F0(&v36);
      v35 = (int *)&v34;
      v12 = sub_1401C5640(v11);
      v13 = (_BYTE *)sub_1401C81E0(v12, L"TEXT_MSG_BOOKMARK_IMPORT_FAILED", L"TEXT");
      v14 = sub_1400601C0();
      if ( v14 == nullptr )
        sub_14005FF30(0x80004005);
      v34 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
      if ( (unsigned __int8)sub_14005F980(&v34, (__int64)v13) == 0 )
      {
        if ( v13 != nullptr )
          v8 = sub_1404ADC20(v13);
        sub_14005FCF0(&v34, v13, v8);
      }
      sub_14008B0F0(*(HWND *)(a1 + 8), (_BYTE **)&v34);
      v16 = v36;
    }
    v33 = v16 - 6;
    if ( _InterlockedExchangeAdd(v33 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v33 + 8LL))(*(_QWORD *)v33);
    sub_140065D40(v15, (_QWORD **)Block);
    j_j_j__free_base(Block);
  }
  else
  {
    sub_14007D7F0(&v36);
    v35 = (int *)&v34;
    v3 = sub_1401C5640(v2);
    v4 = (_BYTE *)sub_1401C81E0(v3, L"TEXT_MSG_BOOKMARK_IMPORT_FAILED", L"TEXT");
    v5 = sub_1400601C0();
    if ( v5 == nullptr )
      sub_14005FF30(0x80004005);
    v34 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
    if ( (unsigned __int8)sub_14005F980(&v34, (__int64)v4) == 0 )
    {
      if ( v4 != nullptr )
        v6 = sub_1404ADC20(v4);
      else
        v6 = 0;
      sub_14005FCF0(&v34, v4, v6);
    }
    sub_14008B0F0(*(HWND *)(a1 + 8), (_BYTE **)&v34);
    v7 = v36 - 6;
    if ( _InterlockedExchangeAdd(v36 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v7 + 8LL))(*(_QWORD *)v7);
  }
}
