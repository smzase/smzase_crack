// EA 0x14005f250  name sub_14005F250  size 351
HWND __fastcall sub_14005F250(
        HMENU a1,
        HWND a2,
        int *a3,
        const WCHAR *a4,
        DWORD dwStyle,
        DWORD dwExStyle,
        HMENU a7,
        unsigned __int16 a8)
{
  __int64 v8; // rax
  HMENU hMenu; // rcx
  int *v15; // rax

  v8 = *((_QWORD *)a1 + 5);
  if ( v8 == 0 )
  {
    v8 = sub_140495D90();
    *((_QWORD *)a1 + 5) = v8;
    if ( v8 == 0 )
    {
      SetLastError(0xEu);
      return nullptr;
    }
  }
  sub_140495EC0(v8, 0, 0);
  if ( a8 == 0 )
    return nullptr;
  if ( a1 == (HMENU)-16LL || a1 == nullptr )
  {
    sub_14005F240(3221225477LL, 1);
    JUMPOUT(0x14005F3AELL);
  }
  *((_QWORD *)a1 + 2) = a1;
  *((_DWORD *)a1 + 6) = GetCurrentThreadId();
  EnterCriticalSection(&CriticalSection);
  *((_QWORD *)a1 + 4) = qword_1406FBC60;
  qword_1406FBC60 = (__int64)(a1 + 4);
  LeaveCriticalSection(&CriticalSection);
  hMenu = a7;
  if ( a7 == nullptr && (dwStyle & 0x40000000) != 0 )
    hMenu = a1;
  v15 = (int *)&unk_1406DC8D8;
  if ( a3 != nullptr )
    v15 = a3;
  return CreateWindowExW(
           dwExStyle,
           (LPCWSTR)a8,
           a4,
           dwStyle,
           *v15,
           v15[1],
           v15[2] - *v15,
           v15[3] - v15[1],
           a2,
           hMenu,
           hModule,
           nullptr);
}
