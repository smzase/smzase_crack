// EA 0x1404a6f80  name sub_1404A6F80  size 36
__int64 __fastcall sub_1404A6F80(__int64 a1, __int64 a2)
{
  if ( dword_140706A14 != 0 )
    return sub_1404A6FB0(a1, a2, 0);
  if ( a1 != 0 && a2 != 0 )
    return sub_1404A6F20();
  return sub_1404A6EF0();
}
