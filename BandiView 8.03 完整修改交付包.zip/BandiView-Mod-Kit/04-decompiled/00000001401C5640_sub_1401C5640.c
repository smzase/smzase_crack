// EA 0x1401c5640  name sub_1401C5640  size 95
__int64 *sub_1401C5640()
{
  if ( dword_14071EDA0 > *(_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL) )
  {
    sub_140496500(&dword_14071EDA0);
    if ( dword_14071EDA0 == -1 )
    {
      sub_1401C5790();
      atexit(sub_140592E80);
      Init_thread_footer(&dword_14071EDA0);
    }
  }
  return &qword_14071EDB0;
}
