// EA 0x140088250  name sub_140088250  size 472
__int64 __fastcall sub_140088250(__int64 *a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rbx
  __int64 v6; // r8
  __int64 v7; // rax
  __int64 v8; // r14
  unsigned __int64 v9; // r12
  unsigned __int64 v10; // rcx
  unsigned __int64 v11; // rax
  unsigned __int64 v12; // rcx
  __int64 v13; // rdi
  __int64 v14; // rbp
  __int64 v15; // rcx
  __int64 v16; // r8
  __int64 v17; // rdx
  __int64 v18; // rcx
  __int64 v19; // rdi
  __int64 v20; // rdx
  __int64 i; // rcx
  __int64 v23; // [rsp+38h] [rbp-50h]
  __int64 v24; // [rsp+40h] [rbp-48h]

  v4 = a2;
  v6 = *a1;
  v7 = (a1[1] - *a1) >> 5;
  v8 = 0x7FFFFFFFFFFFFFFLL;
  if ( v7 == 0x7FFFFFFFFFFFFFFLL )
    unknown_libname_4();
  v9 = v7 + 1;
  v10 = (a1[2] - v6) >> 5;
  if ( v10 <= 0x7FFFFFFFFFFFFFFLL - (v10 >> 1) )
  {
    v11 = (v10 >> 1) + v10;
    v12 = v9;
    if ( v11 >= v9 )
      v12 = v11;
    if ( v12 > 0x7FFFFFFFFFFFFFFLL )
    {
      sub_14005D3C0();
      __debugbreak();
    }
    v8 = v12;
  }
  v13 = (a2 - v6) >> 5;
  v14 = sub_14005D1E0(32 * v8);
  v15 = v14 + 32 * v13;
  v23 = v15 + 32;
  v24 = v15 + 32;
  sub_1400693B0(v15, a3);
  v16 = a1[1];
  v17 = v14;
  v18 = *a1;
  if ( v4 == v16 )
  {
    for ( ; v18 != v16; v18 += 32 )
    {
      *(_OWORD *)v17 = 0;
      *(_QWORD *)(v17 + 16) = 0;
      *(_QWORD *)(v17 + 24) = 0;
      *(_OWORD *)v17 = *(_OWORD *)v18;
      *(_OWORD *)(v17 + 16) = *(_OWORD *)(v18 + 16);
      *(_QWORD *)(v18 + 16) = 0;
      *(_QWORD *)(v18 + 24) = 7;
      *(_WORD *)v18 = 0;
      v17 += 32;
    }
    v19 = 32 * v13;
  }
  else
  {
    for ( ; v18 != v4; v18 += 32 )
    {
      *(_OWORD *)v17 = 0;
      *(_QWORD *)(v17 + 16) = 0;
      *(_QWORD *)(v17 + 24) = 0;
      *(_OWORD *)v17 = *(_OWORD *)v18;
      *(_OWORD *)(v17 + 16) = *(_OWORD *)(v18 + 16);
      *(_QWORD *)(v18 + 16) = 0;
      *(_QWORD *)(v18 + 24) = 7;
      *(_WORD *)v18 = 0;
      v17 += 32;
    }
    v19 = 32 * v13;
    v20 = a1[1];
    for ( i = v14 + v19 + 32; v4 != v20; v4 += 32 )
    {
      *(_OWORD *)i = 0;
      *(_QWORD *)(i + 16) = 0;
      *(_QWORD *)(i + 24) = 0;
      *(_OWORD *)i = *(_OWORD *)v4;
      *(_OWORD *)(i + 16) = *(_OWORD *)(v4 + 16);
      *(_QWORD *)(v4 + 16) = 0;
      *(_QWORD *)(v4 + 24) = 7;
      *(_WORD *)v4 = 0;
      i += 32;
    }
  }
  sub_140088820(a1, v14, v9, v8, a1, v14, v8, v23, v24);
  return v19 + v14;
}
