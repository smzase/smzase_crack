// EA 0x1400693b0  name sub_1400693B0  size 235
__int64 __fastcall sub_1400693B0(__int64 a1, __int64 a2)
{
  _OWORD *v2; // r14
  unsigned __int64 v4; // rsi
  __int64 v5; // rdi
  __int64 v7; // rcx
  void *v8; // rax

  *(_OWORD *)a1 = 0;
  *(_QWORD *)(a1 + 16) = 0;
  v2 = (_OWORD *)a2;
  *(_QWORD *)(a1 + 24) = 0;
  v4 = *(_QWORD *)(a2 + 16);
  if ( *(_QWORD *)(a2 + 24) > 7u )
    v2 = *(_OWORD **)a2;
  v5 = 0x7FFFFFFFFFFFFFFELL;
  if ( v4 > 0x7FFFFFFFFFFFFFFELL )
    unknown_libname_3();
  if ( v4 > 7 )
  {
    if ( (v4 | 7) <= 0x7FFFFFFFFFFFFFFELL )
    {
      v5 = v4 | 7;
      if ( (v4 | 7) < 0xA )
        v5 = 10;
      v7 = v5 + 1;
      if ( (unsigned __int64)(v5 + 1) > 0x7FFFFFFFFFFFFFFFLL )
      {
        sub_14005D3C0();
        JUMPOUT(0x14006949ALL);
      }
    }
    else
    {
      v7 = 0x7FFFFFFFFFFFFFFFLL;
    }
    v8 = (void *)sub_14005D1E0(2 * v7);
    *(_QWORD *)a1 = v8;
    *(_QWORD *)(a1 + 16) = v4;
    *(_QWORD *)(a1 + 24) = v5;
    memcpy(v8, v2, 2 * v4 + 2);
    return a1;
  }
  else
  {
    *(_QWORD *)(a1 + 16) = v4;
    *(_QWORD *)(a1 + 24) = 7;
    *(_OWORD *)a1 = *v2;
    return a1;
  }
}
