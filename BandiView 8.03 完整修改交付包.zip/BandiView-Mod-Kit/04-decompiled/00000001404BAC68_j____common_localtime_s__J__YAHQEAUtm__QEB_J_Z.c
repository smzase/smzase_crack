// EA 0x1404bac68  name j_??$common_localtime_s@_J@@YAHQEAUtm@@QEB_J@Z  size 5
// attributes: thunk
__int64 __fastcall common_localtime_s<__int64>(struct tm *a1)
{
  return ??$common_localtime_s@_J@@YAHQEAUtm@@QEB_J@Z(a1);
}
