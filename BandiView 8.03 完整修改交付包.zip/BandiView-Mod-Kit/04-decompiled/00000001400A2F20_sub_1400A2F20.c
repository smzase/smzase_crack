// EA 0x1400a2f20  name sub_1400A2F20  size 1751
__int64 __fastcall sub_1400A2F20(__int64 a1, unsigned int a2, __int64 a3, _DWORD *a4)
{
  __int64 *v8; // rax
  const wchar_t *v9; // r8
  _QWORD *v10; // rbx
  _QWORD *v11; // rdx
  LSTATUS v12; // edi
  unsigned __int8 v13; // bl
  __int64 *v14; // rax
  int *v15; // rbx
  BYTE *v16; // rdi
  int v17; // eax
  _BYTE **v18; // rax
  _QWORD *v19; // rdx
  BYTE *v20; // rdi
  int v21; // eax
  _BYTE **v22; // rax
  _QWORD *v23; // rdx
  BYTE *v24; // rdi
  int v25; // eax
  volatile signed __int32 *v26; // rdi
  _BYTE **v27; // rax
  _QWORD *v28; // rdx
  BYTE *v29; // rbx
  int v30; // eax
  __int64 v31; // rax
  int v32; // ecx
  DWORD Type[2]; // [rsp+30h] [rbp-50h] BYREF
  DWORD lpcbData[2]; // [rsp+38h] [rbp-48h] BYREF
  HKEY hKey; // [rsp+40h] [rbp-40h] BYREF
  DWORD *v37; // [rsp+48h] [rbp-38h] BYREF
  __int128 v38; // [rsp+50h] [rbp-30h] BYREF
  _DWORD *v39; // [rsp+60h] [rbp-20h]
  DWORD cbData[2]; // [rsp+68h] [rbp-18h] BYREF

  v39 = a4;
  *(_QWORD *)&v38 = a3;
  hKey = nullptr;
  v37 = lpcbData;
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)lpcbData = (*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24;
  if ( (unsigned __int8)sub_14005F980(lpcbData, (__int64)L"SOFTWARE\\$app$\\l") == 0 )
    sub_14005FCF0((int **)lpcbData, L"SOFTWARE\\$app$\\l", 16);
  v37 = lpcbData;
  switch ( a2 )
  {
    case 1u:
      v9 = L"BandiView";
      break;
    case 2u:
      v9 = L"Bandizip";
      break;
    case 3u:
      v9 = L"Honeycam";
      break;
    default:
      goto LABEL_11;
  }
  sub_140060D20((unsigned __int64 *)lpcbData, (__int64)L"$app$", v9);
LABEL_11:
  v10 = (_QWORD *)sub_14005F710((volatile signed __int32 *)(*(_QWORD *)lpcbData - 24LL));
  v11 = (_QWORD *)(*(_QWORD *)lpcbData - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)lpcbData - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v11 + 8LL))(*v11);
  if ( hKey != nullptr )
    RegCloseKey(hKey);
  hKey = nullptr;
  v12 = RegOpenKeyExW(HKEY_CURRENT_USER, (LPCWSTR)v10 + 12, 0, 0x20019u, &hKey);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v10 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, _QWORD *))(*(_QWORD *)*v10 + 8LL))(*v10, v10);
  if ( v12 != 0 )
  {
    a4[1] = 0;
    *a4 = -1159777790;
    v13 = 0;
    goto LABEL_73;
  }
  v14 = sub_1400601C0();
  if ( v14 == nullptr )
    sub_14005FF30(0x80004005);
  v15 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
  v37 = (DWORD *)v15;
  lpcbData[0] = sub_1400CCC00();
  if ( hKey != nullptr )
  {
    cbData[0] = 0;
    Type[0] = 1;
    RegQueryValueExW(hKey, L"c", nullptr, Type, nullptr, cbData);
    if ( cbData[0] != 0 && (Type[0] - 1 <= 1 || Type[0] == 7) )
    {
      v16 = (BYTE *)j__calloc_base(1u, cbData[0] + 2LL);
      if ( v16 != nullptr )
      {
        if ( RegQueryValueExW(hKey, L"c", nullptr, Type, v16, cbData) == 0 )
        {
          v17 = sub_1404ADC20(v16);
          sub_14005FCF0((int **)&v37, v16, v17);
          v15 = (int *)v37;
        }
        j__free_base(v16);
      }
    }
  }
  *(_QWORD *)Type = sub_14005F710(v15 - 6) + 24;
  v18 = (_BYTE **)sub_1400C91A0(cbData, Type, a3, 16);
  sub_14006B500((int **)(a1 + 8), v18);
  v19 = (_QWORD *)(*(_QWORD *)cbData - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)cbData - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v19 + 8LL))(*v19);
  if ( hKey != nullptr )
  {
    Type[0] = 0;
    cbData[0] = 1;
    RegQueryValueExW(hKey, L"r", nullptr, cbData, nullptr, Type);
    if ( Type[0] != 0 && (cbData[0] - 1 <= 1 || cbData[0] == 7) )
    {
      v20 = (BYTE *)j__calloc_base(1u, Type[0] + 2LL);
      if ( v20 != nullptr )
      {
        if ( RegQueryValueExW(hKey, L"r", nullptr, cbData, v20, Type) == 0 )
        {
          v21 = sub_1404ADC20(v20);
          sub_14005FCF0((int **)&v37, v20, v21);
          v15 = (int *)v37;
        }
        j__free_base(v20);
      }
    }
  }
  *(_QWORD *)Type = sub_14005F710(v15 - 6) + 24;
  v22 = (_BYTE **)sub_1400C91A0(cbData, Type, v38, 16);
  sub_14006B500((int **)(a1 + 16), v22);
  v23 = (_QWORD *)(*(_QWORD *)cbData - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)cbData - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v23 + 8LL))(*v23);
  if ( hKey != nullptr )
  {
    Type[0] = 0;
    cbData[0] = 1;
    RegQueryValueExW(hKey, L"u", nullptr, cbData, nullptr, Type);
    if ( Type[0] != 0 && (cbData[0] - 1 <= 1 || cbData[0] == 7) )
    {
      v24 = (BYTE *)j__calloc_base(1u, Type[0] + 2LL);
      if ( v24 != nullptr )
      {
        if ( RegQueryValueExW(hKey, L"u", nullptr, cbData, v24, Type) == 0 )
        {
          v25 = sub_1404ADC20(v24);
          sub_14005FCF0((int **)&v37, v24, v25);
          v15 = (int *)v37;
        }
        j__free_base(v24);
      }
    }
  }
  v26 = v15 - 6;
  *(_QWORD *)Type = sub_14005F710(v15 - 6) + 24;
  v27 = (_BYTE **)sub_1400C91A0(cbData, Type, lpcbData, 4);
  sub_14006B500((int **)a1, v27);
  v28 = (_QWORD *)(*(_QWORD *)cbData - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)cbData - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v28 + 8LL))(*v28);
  *(_QWORD *)cbData = 0;
  lpcbData[0] = 8;
  Type[0] = 11;
  if ( RegQueryValueExW(hKey, L"f", nullptr, Type, (LPBYTE)cbData, lpcbData) == 0 && *(__int64 *)cbData > 0 )
    sub_14005EB50(a1 + 24, (__int64)L"%I64d");
  if ( hKey != nullptr )
  {
    Type[0] = 0;
    cbData[0] = 1;
    RegQueryValueExW(hKey, L"a", nullptr, cbData, nullptr, Type);
    if ( Type[0] != 0 && (cbData[0] - 1 <= 1 || cbData[0] == 7) )
    {
      v29 = (BYTE *)j__calloc_base(1u, Type[0] + 2LL);
      if ( v29 != nullptr )
      {
        if ( RegQueryValueExW(hKey, L"a", nullptr, cbData, v29, Type) == 0 )
        {
          v30 = sub_1404ADC20(v29);
          sub_14005FCF0((int **)(a1 + 32), v29, v30);
        }
        j__free_base(v29);
      }
    }
  }
  sub_1400A3600(a1);
  if ( *(_DWORD *)(*(_QWORD *)(a1 + 24) - 16LL) == 0 )
  {
    v31 = unknown_libname_553(0);
    sub_14005EB50(a1 + 24, (__int64)L"%I64d", v31);
  }
  v32 = *(_DWORD *)(*(_QWORD *)(a1 + 16) - 16LL);
  if ( *(_DWORD *)(*(_QWORD *)(a1 + 8) - 16LL) != 0 )
  {
    if ( v32 != 0 && *(_DWORD *)(*(_QWORD *)a1 - 16LL) != 0 )
    {
      v13 = 1;
      goto LABEL_71;
    }
  }
  else if ( v32 == 0 && *(_DWORD *)(*(_QWORD *)a1 - 16LL) == 0 )
  {
    v13 = 1;
    goto LABEL_71;
  }
  sub_14005FA90((int **)a1);
  sub_14005FA90((int **)(a1 + 8));
  sub_14005FA90((int **)(a1 + 16));
  v38 = *(_OWORD *)v38;
  sub_1400A36B0(a1, a2, &v38, v39);
  v13 = 0;
LABEL_71:
  if ( _InterlockedExchangeAdd(v26 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v26 + 8LL))(*(_QWORD *)v26, v26);
LABEL_73:
  if ( hKey != nullptr )
    RegCloseKey(hKey);
  return v13;
}
