// EA 0x1400b3720  name sub_1400B3720  size 101
__int64 __fastcall sub_1400B3720(HWND hWnd)
{
  int v2; // eax
  unsigned int v3; // edi

  v2 = SendMessageW(hWnd, 0x100Cu, 0xFFFFFFFFFFFFFFFFuLL, 2);
  v3 = v2;
  if ( v2 == -1 )
    return 0xFFFFFFFFLL;
  SendMessageW(hWnd, 0x100Cu, v2, 2);
  return v3;
}
