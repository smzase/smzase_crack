// EA 0x1400b41a0  name sub_1400B41A0  size 216
__int64 __fastcall sub_1400B41A0(__int64 a1)
{
  __int64 result; // rax
  __int64 v3; // rdi
  __int64 v4; // rsi
  __int64 *v5; // rax
  __int64 v6; // rdi
  int *v7; // [rsp+40h] [rbp+8h] BYREF
  __int64 v8; // [rsp+48h] [rbp+10h] BYREF
  int **v9; // [rsp+50h] [rbp+18h]

  result = sub_1400B3720(*(HWND *)(a1 + 328));
  if ( (int)result >= 0 )
  {
    v3 = (int)result;
    if ( (unsigned __int64)(int)result >= *(_QWORD *)(a1 + 424) )
      sub_14005FF30(0x80070057);
    v4 = *(_QWORD *)(a1 + 416);
    v9 = &v7;
    v5 = sub_1400601C0();
    if ( v5 == nullptr )
      sub_14005FF30(0x80004005);
    v6 = 32 * v3;
    v7 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
    if ( (unsigned __int8)sub_14005F980(&v7, (__int64)L"BandiView") == 0 )
      sub_14005FCF0(&v7, L"BandiView", 9);
    v8 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(v6 + v4 + 8) - 24LL)) + 24;
    return sub_1400AF460(a1 + 400, &v8, &v7);
  }
  return result;
}
