// EA 0x14011f0f0  name sub_14011F0F0  size 176
__int64 __fastcall sub_14011F0F0(__int64 a1)
{
  __int64 *v2; // rax
  __int64 *v3; // rax

  *(_QWORD *)(a1 + 8) = 0;
  *(_QWORD *)(a1 + 40) = 0;
  *(_QWORD *)(a1 + 48) = 0;
  *(_DWORD *)(a1 + 56) = 0;
  *(_QWORD *)a1 = &SettingKeyDlg::`vftable';
  *(_DWORD *)(a1 + 64) = 1;
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 72) = (*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24;
  *(_DWORD *)(a1 + 80) = 0;
  *(_QWORD *)(a1 + 88) = 0;
  *(_QWORD *)(a1 + 96) = 0;
  *(_QWORD *)(a1 + 104) = 0;
  *(_QWORD *)(a1 + 112) = 0;
  *(_QWORD *)(a1 + 120) = 0;
  sub_140094680(a1 + 128);
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 288) = (*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24;
  return a1;
}
