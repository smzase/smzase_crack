// EA 0x1404adc20  name sub_1404ADC20  size 328
// local variable allocation has failed, the output may be wrong!
__int64 __fastcall sub_1404ADC20(__m128i *a1, __int64 a2, double _XMM2_8)
{
  __m128i *v5; // rdx
  unsigned __int64 v6; // r9
  __int64 v7; // rcx
  unsigned __int64 v8; // r9
  __m128i *v9; // rax
  __int64 v10; // rdx
  __int64 result; // rax
  __m128i *i; // rax
  __int64 v16; // rcx
  unsigned __int64 v17; // r9
  __m128i *v18; // rax
  unsigned __int64 v19; // r9
  __m128i *v20; // rcx

  if ( dword_1406DA088 >= 5 )
  {
    v5 = a1;
    if ( ((unsigned __int8)a1 & 1) != 0 )
    {
      while ( v5->m128i_i16[0] != 0 )
        v5 = (__m128i *)((char *)v5 + 2);
    }
    else
    {
      v6 = 0;
      v7 = (unsigned __int8)a1 & 0x1F;
      if ( v7 != 0 )
        v6 = 32 - v7;
      v8 = v6 >> 1;
      v9 = (__m128i *)((char *)a1 + 2 * v8);
      if ( a1 != v9 )
      {
        do
        {
          if ( v5->m128i_i16[0] == 0 )
            break;
          v5 = (__m128i *)((char *)v5 + 2);
        }
        while ( v5 != v9 );
      }
      v10 = ((char *)v5 - (char *)a1) >> 1;
      if ( v10 != v8 )
        return v10;
      v5 = (__m128i *)((char *)a1 + 2 * v10);
      __asm { vpxor   xmm2, xmm2, xmm2 }
      while ( 1 )
      {
        __asm
        {
          vpcmpeqw ymm1, ymm2, ymmword ptr [rdx]
          vpmovmskb eax, ymm1
        }
        if ( _EAX != 0 )
          break;
        v5 += 2;
      }
      __asm { vzeroupper }
      while ( v5->m128i_i16[0] != 0 )
        v5 = (__m128i *)((char *)v5 + 2);
    }
    return ((char *)v5 - (char *)a1) >> 1;
  }
  if ( dword_1406DA088 < 1 )
  {
    for ( i = a1; i->m128i_i16[0] != 0; i = (__m128i *)((char *)i + 2) )
      ;
    return ((char *)i - (char *)a1) >> 1;
  }
  if ( ((unsigned __int8)a1 & 1) != 0 )
  {
    for ( i = a1; i->m128i_i16[0] != 0; i = (__m128i *)((char *)i + 2) )
      ;
    return ((char *)i - (char *)a1) >> 1;
  }
  v16 = (unsigned __int8)a1 & 0xF;
  v17 = 0;
  if ( v16 != 0 )
    v17 = 16 - v16;
  v18 = a1;
  v19 = v17 >> 1;
  v20 = (__m128i *)((char *)a1 + 2 * v19);
  if ( a1 != v20 )
  {
    do
    {
      if ( v18->m128i_i16[0] == 0 )
        break;
      v18 = (__m128i *)((char *)v18 + 2);
    }
    while ( v18 != v20 );
  }
  result = ((char *)v18 - (char *)a1) >> 1;
  if ( result == v19 )
  {
    for ( i = (__m128i *)((char *)a1 + 2 * result); _mm_movemask_epi8(_mm_cmpeq_epi16((__m128i)0LL, *i)) == 0; ++i )
      ;
    while ( i->m128i_i16[0] != 0 )
      i = (__m128i *)((char *)i + 2);
    return ((char *)i - (char *)a1) >> 1;
  }
  return result;
}
