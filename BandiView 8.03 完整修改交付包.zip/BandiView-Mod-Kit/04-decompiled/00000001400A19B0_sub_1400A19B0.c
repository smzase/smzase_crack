// EA 0x1400a19b0  name sub_1400A19B0  size 1821
__int64 __fastcall sub_1400A19B0(__int64 a1, _DWORD *a2)
{
  __int64 *v4; // rax
  int v5; // eax
  const wchar_t *v6; // r8
  _QWORD *v7; // rbx
  int *v8; // rdx
  bool v9; // si
  unsigned __int8 v10; // bl
  _BYTE **v11; // rax
  _QWORD *v12; // rdx
  LPCWSTR *v13; // rax
  char v14; // bl
  LPCWSTR v15; // rsi
  int v16; // eax
  LPCWSTR *v17; // rax
  LPCWSTR v18; // rsi
  int v19; // eax
  LPCWSTR *v20; // rax
  LPCWSTR v21; // rsi
  int v22; // eax
  LPCWSTR *v23; // rax
  LPCWSTR v24; // rsi
  int v25; // eax
  LPCWSTR *v26; // rax
  LPCWSTR v27; // rsi
  int v28; // eax
  LPCWSTR *v29; // rax
  LPCWSTR v30; // rsi
  int v31; // eax
  char v32; // si
  _QWORD *v33; // rdx
  _QWORD *v34; // rdx
  _QWORD *v35; // rdx
  _QWORD *v36; // rdx
  _QWORD *v37; // rdx
  int **v38; // rdx
  const BYTE *v39; // rbx
  int v40; // eax
  LPCWSTR v41; // rdx
  HKEY hKey; // [rsp+50h] [rbp-79h] BYREF
  int *v44; // [rsp+58h] [rbp-71h] BYREF
  __int64 v45; // [rsp+60h] [rbp-69h] BYREF
  DWORD dwDisposition; // [rsp+68h] [rbp-61h] BYREF
  int **v47; // [rsp+70h] [rbp-59h] BYREF
  __int64 v48; // [rsp+80h] [rbp-49h] BYREF
  __int64 v49; // [rsp+88h] [rbp-41h] BYREF
  __int64 v50; // [rsp+90h] [rbp-39h] BYREF
  __int64 v51; // [rsp+98h] [rbp-31h] BYREF
  __int64 v52; // [rsp+A0h] [rbp-29h] BYREF
  LPCWSTR lpString; // [rsp+A8h] [rbp-21h] BYREF
  __int64 v54; // [rsp+B0h] [rbp-19h] BYREF
  __int64 v55; // [rsp+B8h] [rbp-11h] BYREF
  __int64 v56; // [rsp+C0h] [rbp-9h] BYREF
  __int64 v57; // [rsp+C8h] [rbp-1h] BYREF
  __int64 v58; // [rsp+D0h] [rbp+7h] BYREF
  __int128 v59; // [rsp+D8h] [rbp+Fh] BYREF

  LODWORD(v44) = 0;
  hKey = nullptr;
  v47 = &v44;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v44 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( (unsigned __int8)sub_14005F980(&v44, (__int64)L"SOFTWARE\\$app$\\l") == 0 )
    sub_14005FCF0(&v44, L"SOFTWARE\\$app$\\l", 16);
  v47 = &v44;
  v5 = *(_DWORD *)a1;
  if ( *(_DWORD *)a1 == 1 )
  {
    v6 = L"BandiView";
  }
  else if ( v5 == 2 )
  {
    v6 = L"Bandizip";
  }
  else
  {
    if ( v5 != 3 )
      goto LABEL_11;
    v6 = L"Honeycam";
  }
  sub_140060D20((unsigned __int64 *)&v44, (__int64)L"$app$", v6);
LABEL_11:
  v7 = (_QWORD *)sub_14005F710(v44 - 6);
  v8 = v44 - 6;
  if ( _InterlockedExchangeAdd(v44 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v8 + 8LL))(*(_QWORD *)v8);
  hKey = nullptr;
  if ( RegOpenKeyExW(HKEY_LOCAL_MACHINE, (LPCWSTR)v7 + 12, 0, 0x2001Fu, &hKey) != 0 )
  {
    if ( hKey != nullptr )
      RegCloseKey(hKey);
    hKey = nullptr;
    v9 = RegCreateKeyExW(HKEY_LOCAL_MACHINE, (LPCWSTR)v7 + 12, 0, nullptr, 0, 0x2001Fu, nullptr, &hKey, &dwDisposition) != 0;
  }
  else
  {
    v9 = false;
  }
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v7 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, _QWORD *))(*(_QWORD *)*v7 + 8LL))(*v7, v7);
  if ( v9 )
  {
    a2[1] = 0;
    *a2 = -1159778302;
    v10 = 0;
  }
  else
  {
    dwDisposition = sub_1400CCC00();
    v59 = *(_OWORD *)(a1 + 48);
    v44 = (int *)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 16) - 24LL)) + 24);
    v11 = (_BYTE **)sub_1400CC810(&v45, &v44, 8);
    sub_14006B500((int **)(a1 + 24), v11);
    v12 = (_QWORD *)(v45 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v45 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v12 + 8LL))(*v12);
    v48 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 8) - 24LL)) + 24;
    v13 = (LPCWSTR *)sub_1400C8E00(&v47, &v48, &v59, 16);
    v14 = 65;
    LODWORD(v44) = 65;
    if ( hKey == nullptr )
      goto LABEL_43;
    v15 = *v13;
    if ( *v13 == nullptr )
      goto LABEL_43;
    v16 = lstrlenW(*v13);
    if ( RegSetValueExW(hKey, L"l", 0, 1u, (const BYTE *)v15, 2 * v16) != 0 )
      goto LABEL_43;
    v49 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 24) - 24LL)) + 24;
    v17 = (LPCWSTR *)sub_1400C8E00(&v58, &v49, &v59, 16);
    v14 = 67;
    LODWORD(v44) = 67;
    if ( hKey == nullptr )
      goto LABEL_43;
    v18 = *v17;
    if ( *v17 == nullptr )
      goto LABEL_43;
    v19 = lstrlenW(*v17);
    if ( RegSetValueExW(hKey, L"k", 0, 1u, (const BYTE *)v18, 2 * v19) != 0 )
      goto LABEL_43;
    v50 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 40) - 24LL)) + 24;
    v20 = (LPCWSTR *)sub_1400C8E00(&v57, &v50, &v59, 16);
    v14 = 71;
    LODWORD(v44) = 71;
    if ( hKey == nullptr )
      goto LABEL_43;
    v21 = *v20;
    if ( *v20 == nullptr )
      goto LABEL_43;
    v22 = lstrlenW(*v20);
    if ( RegSetValueExW(hKey, L"P", 0, 1u, (const BYTE *)v21, 2 * v22) != 0 )
      goto LABEL_43;
    v51 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 64) - 24LL)) + 24;
    v23 = (LPCWSTR *)sub_1400C8E00(&v56, &v51, &v59, 16);
    v14 = 79;
    LODWORD(v44) = 79;
    if ( hKey == nullptr )
      goto LABEL_43;
    v24 = *v23;
    if ( *v23 == nullptr )
      goto LABEL_43;
    v25 = lstrlenW(*v23);
    if ( RegSetValueExW(hKey, L"m", 0, 1u, (const BYTE *)v24, 2 * v25) != 0 )
      goto LABEL_43;
    v52 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 72) - 24LL)) + 24;
    v26 = (LPCWSTR *)sub_1400C8E00(&v55, &v52, &v59, 16);
    v14 = 95;
    LODWORD(v44) = 95;
    if ( hKey == nullptr )
      goto LABEL_43;
    v27 = *v26;
    if ( *v26 != nullptr
      && (v28 = lstrlenW(*v26), RegSetValueExW(hKey, L"t", 0, 1u, (const BYTE *)v27, 2 * v28) == 0)
      && (v45 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 32) - 24LL)) + 24,
          v29 = (LPCWSTR *)sub_1400C8E00(&v54, &v45, &v59, 16),
          v14 = 127,
          hKey != nullptr)
      && (v30 = *v29, *v29 != nullptr)
      && (v31 = lstrlenW(*v29), RegSetValueExW(hKey, L"h", 0, 1u, (const BYTE *)v30, 2 * v31) == 0) )
    {
      v32 = 0;
    }
    else
    {
LABEL_43:
      v32 = 1;
    }
    if ( (v14 & 0x20) != 0 )
    {
      v14 &= ~0x20u;
      v33 = (_QWORD *)(v54 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v54 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v33 + 8LL))(*v33);
    }
    if ( (v14 & 0x10) != 0 )
    {
      v14 &= ~0x10u;
      v34 = (_QWORD *)(v55 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v55 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v34 + 8LL))(*v34);
    }
    if ( (v14 & 8) != 0 )
    {
      v14 &= ~8u;
      v35 = (_QWORD *)(v56 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v56 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v35 + 8LL))(*v35);
    }
    if ( (v14 & 4) != 0 )
    {
      v14 &= ~4u;
      v36 = (_QWORD *)(v57 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v57 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v36 + 8LL))(*v36);
    }
    if ( (v14 & 2) != 0 )
    {
      v14 &= ~2u;
      v37 = (_QWORD *)(v58 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v58 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v37 + 8LL))(*v37);
    }
    if ( (v14 & 1) != 0 )
    {
      v38 = v47 - 3;
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)v47 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(int *))(*(_QWORD *)*v38 + 8LL))(*v38);
    }
    if ( v32 != 0 )
    {
      a2[1] = 0;
      *a2 = -1159778301;
      v10 = 0;
    }
    else
    {
      sub_1400CE240(&v59, 16, &dwDisposition, 4);
      sub_1400C8D10(&lpString, &v59);
      if ( hKey != nullptr
        && (v39 = (const BYTE *)lpString, lpString != nullptr)
        && (v40 = lstrlenW(lpString), RegSetValueExW(hKey, L"g", 0, 1u, v39, 2 * v40) == 0) )
      {
        v45 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 40) - 24LL)) + 24;
        sub_1400A1530(*(_DWORD *)a1, &v45);
        v10 = 1;
      }
      else
      {
        a2[1] = 0;
        *a2 = -1159778301;
        v10 = 0;
      }
      v41 = lpString - 12;
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)lpString - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v41 + 8LL))(*(_QWORD *)v41);
    }
  }
  if ( hKey != nullptr )
    RegCloseKey(hKey);
  return v10;
}
