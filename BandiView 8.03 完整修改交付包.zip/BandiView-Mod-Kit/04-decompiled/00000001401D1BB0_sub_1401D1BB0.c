// EA 0x1401d1bb0  name sub_1401D1BB0  size 868
_QWORD *__fastcall sub_1401D1BB0(__int64 a1, _QWORD *a2, __int64 *a3, __int64 **a4, __int64 *a5)
{
  __int64 *v6; // rax
  __int64 *v9; // rbx
  __int64 v10; // rdx
  __m128i si128; // xmm6
  __int64 v12; // rdx
  __int64 v13; // rdx
  __int64 v14; // rax
  __int64 v15; // rcx
  void **v16; // r14
  __int64 v17; // rbx
  unsigned __int64 v18; // rsi
  __int64 v19; // rsi
  __int128 *v20; // r14
  int v21; // ebx
  __int64 v22; // rax
  __int16 v23; // r11
  _WORD v25[2]; // [rsp+24h] [rbp-DCh] BYREF
  _QWORD *v26; // [rsp+28h] [rbp-D8h]
  __int128 v27; // [rsp+30h] [rbp-D0h] BYREF
  __int128 v28; // [rsp+40h] [rbp-C0h]
  _QWORD v29[4]; // [rsp+50h] [rbp-B0h] BYREF
  void *Src[2]; // [rsp+70h] [rbp-90h] BYREF
  unsigned __int64 v31; // [rsp+80h] [rbp-80h]
  unsigned __int64 v32; // [rsp+88h] [rbp-78h]
  int v33; // [rsp+90h] [rbp-70h]
  _QWORD v34[4]; // [rsp+A0h] [rbp-60h] BYREF
  _QWORD v35[4]; // [rsp+C0h] [rbp-40h] BYREF
  _QWORD v36[4]; // [rsp+E0h] [rbp-20h] BYREF

  v6 = a3;
  v9 = a5;
  v26 = a2;
  v10 = *((unsigned int *)a3 + 4);
  if ( (unsigned __int64)a3[3] > 7 )
    v6 = (__int64 *)*a3;
  *(_OWORD *)v36 = 0;
  si128 = _mm_load_si128((const __m128i *)&xmmword_140662FA0);
  *(__m128i *)&v36[2] = si128;
  LOBYTE(v36[0]) = 0;
  sub_1401CB4C0(v6, v10, v36);
  v12 = *((unsigned int *)a4 + 4);
  if ( (unsigned __int64)a4[3] > 7 )
    a4 = (__int64 **)*a4;
  *(_OWORD *)v35 = 0;
  *(__m128i *)&v35[2] = si128;
  LOBYTE(v35[0]) = 0;
  sub_1401CB4C0(a4, v12, v35);
  v13 = *((unsigned int *)a5 + 4);
  if ( (unsigned __int64)a5[3] > 7 )
    v9 = (__int64 *)*a5;
  *(_OWORD *)v34 = 0;
  *(__m128i *)&v34[2] = _mm_load_si128((const __m128i *)&xmmword_140662FA0);
  LOBYTE(v34[0]) = 0;
  sub_1401CB4C0(v9, v13, v34);
  v14 = sub_1401D2130(a1, v36);
  if ( v14 != 0 )
  {
    *(_OWORD *)v29 = 0;
    *(__m128i *)&v29[2] = _mm_load_si128((const __m128i *)&xmmword_140662FA0);
    LOBYTE(v29[0]) = 0;
    *(_OWORD *)Src = 0;
    v31 = 0;
    v32 = 15;
    LOBYTE(Src[0]) = 0;
    v33 = 0;
    if ( (unsigned __int8)sub_1401D17A0(v15, v14, v35, v29) != 0 )
    {
      v27 = 0;
      v28 = 0;
      v16 = Src;
      if ( v32 > 0xF )
        v16 = (void **)Src[0];
      v17 = 0x7FFFFFFFFFFFFFFFLL;
      v18 = v31;
      if ( v31 > 0x7FFFFFFFFFFFFFFFLL )
        unknown_libname_3();
      if ( v31 > 0xF )
      {
        if ( (v31 | 0xF) <= 0x7FFFFFFFFFFFFFFFLL )
        {
          v17 = v31 | 0xF;
          if ( (v31 | 0xF) < 0x16 )
            v17 = 22;
        }
        *(_QWORD *)&v27 = sub_14005D1E0(v17 + 1);
        *(_QWORD *)&v28 = v18;
        *((_QWORD *)&v28 + 1) = v17;
        memcpy((void *)v27, v16, v18 + 1);
      }
      else
      {
        *(_QWORD *)&v28 = v31;
        *((_QWORD *)&v28 + 1) = 15;
        v27 = *(_OWORD *)v16;
      }
    }
    else
    {
      sub_1400896C0(&v27, v34);
    }
    sub_14007F110(Src);
    sub_14007F110(v29);
  }
  else
  {
    sub_1400896C0(&v27, v34);
  }
  v19 = (int)v28;
  *(_OWORD *)a2 = 0;
  a2[2] = 0;
  a2[3] = 7;
  *(_WORD *)a2 = 0;
  v20 = &v27;
  if ( *((_QWORD *)&v28 + 1) > 0xFu )
    v20 = (__int128 *)v27;
  v21 = 0;
  if ( (int)v19 > 0 )
  {
    while ( 1 )
    {
      v22 = sub_1401CAC70(v20, v21, v19);
      if ( (int)v22 < 0 )
        break;
      v21 += v22;
      if ( HIDWORD(v22) < 0x10000 || HIDWORD(v22) >= 0x110000 )
        goto LABEL_29;
      v25[0] = ((unsigned int)(HIDWORD(v22) - 0x10000) >> 10) - 10240;
      v25[1] = (WORD2(v22) & 0x3FF) - v23;
      sub_14005ED20(a2, v25, 2u);
LABEL_30:
      if ( v21 >= (int)v19 )
        goto LABEL_31;
    }
    ++v21;
LABEL_29:
    sub_14006B590(a2);
    goto LABEL_30;
  }
LABEL_31:
  sub_14007F110(&v27);
  sub_14007F110(v34);
  sub_14007F110(v35);
  sub_14007F110(v36);
  return a2;
}
