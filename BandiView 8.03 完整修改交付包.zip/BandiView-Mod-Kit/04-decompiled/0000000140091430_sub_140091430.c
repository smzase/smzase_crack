// EA 0x140091430  name sub_140091430  size 119
__int64 __fastcall sub_140091430(__int64 a1)
{
  __int64 v1; // rdi
  __int64 v3; // rdx

  v1 = *(_QWORD *)(a1 + 8);
  if ( *((_DWORD *)sub_140075FE0() + 53) != 0 )
    v3 = (unsigned int)(96 * *((_DWORD *)sub_140075FE0() + 53) / 100);
  else
    v3 = (unsigned int)sub_1401C0420(v1);
  sub_1401DBEF0(a1 + 728, v3);
  return sub_14009ABE0(*(HWND *)(a1 + 8));
}
