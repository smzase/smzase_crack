// EA 0x140082940  name sub_140082940  size 169
_BOOL8 __fastcall sub_140082940(PHKEY phkResult, HKEY hKey, LPCWSTR lpSubKey)
{
  HKEY v5; // rcx
  DWORD dwDisposition; // [rsp+80h] [rbp+8h] BYREF

  v5 = *phkResult;
  if ( v5 != nullptr )
    RegCloseKey(v5);
  *phkResult = nullptr;
  if ( RegOpenKeyExW(hKey, lpSubKey, 0, 0x2001Fu, phkResult) == 0 )
    return true;
  if ( *phkResult != nullptr )
    RegCloseKey(*phkResult);
  *phkResult = nullptr;
  return RegCreateKeyExW(hKey, lpSubKey, 0, nullptr, 0, 0x2001Fu, nullptr, phkResult, &dwDisposition) == 0;
}
