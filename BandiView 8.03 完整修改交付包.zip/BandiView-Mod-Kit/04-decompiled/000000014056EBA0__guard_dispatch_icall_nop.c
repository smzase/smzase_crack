// EA 0x14056eba0  name _guard_dispatch_icall_nop  size 2
__int64 __fastcall guard_dispatch_icall_nop()
{
  __int64 (*v0)(void); // rax

  return v0();
}
