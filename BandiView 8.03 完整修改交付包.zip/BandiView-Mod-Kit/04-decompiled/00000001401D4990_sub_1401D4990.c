// EA 0x1401d4990  name sub_1401D4990  size 172
void __fastcall sub_1401D4990(HWND a1)
{
  unsigned int v2; // ebx
  int *v3; // rdi
  int *v4; // rax
  __int128 pvParam; // [rsp+20h] [rbp-18h] BYREF

  if ( *sub_1401D4680() == 1 )
  {
    v2 = 1;
    v3 = sub_1401D4680();
    *v3 = 1;
    sub_1402B51E0();
    *((_BYTE *)v3 + 8) = 1;
    if ( (unsigned __int8)sub_1402B5520() == 0
      || (pvParam = 0, LODWORD(pvParam) = 16, SystemParametersInfoW(0x42u, 0x10u, &pvParam, 0))
      && (BYTE4(pvParam) & 1) != 0 )
    {
      v2 = 3;
    }
    if ( v2 != v3[1] )
    {
      v3[1] = v2;
      sub_1402B5020(v2);
      sub_1402B4CB0();
    }
    v4 = sub_1401D4680();
    sub_1401D47B0((__int64)v4, a1);
  }
}
