// EA 0x1404a27ac  name sub_1404A27AC  size 543
const __m128i *__fastcall sub_1404A27AC(const __m128i *a1, const __m128i *a2)
{
  unsigned int v2; // edi
  const __m128i *v3; // rbx
  const __m128i *v4; // r8
  __m128i v6; // xmm4
  __m128i v7; // xmm1
  unsigned int v8; // eax
  unsigned int v9; // ecx
  const __m128i *v10; // rdx
  const __m128i *i; // r9
  __m128i v12; // xmm2
  unsigned int v13; // eax
  unsigned int v14; // ecx
  unsigned __int64 v15; // rcx
  __m128i inserted; // xmm0
  unsigned __int16 v17; // cx
  int j; // r9d
  unsigned __int16 v19; // si
  const __m128i *v20; // rax
  __m128i v21; // xmm1
  unsigned __int8 v22; // cf
  const __m128i *v23; // rdx
  const __m128i *k; // r9
  __m128i v25; // xmm1
  __m128i v26; // xmm2
  unsigned __int8 v27; // sf
  __int64 v28; // rax

  v2 = a2->m128i_u16[0];
  v3 = a2;
  v4 = a1;
  if ( (_WORD)v2 == 0 )
    return a1;
  if ( dword_1406DA088 < 2 )
  {
    v6 = _mm_shuffle_epi32(_mm_shufflelo_epi16(_mm_cvtsi32_si128(v2), 0), 0);
    while ( 1 )
    {
      if ( ((unsigned __int16)v4 & 0xFFFu) > 0xFF0uLL )
        goto LABEL_9;
      v7 = _mm_loadu_si128(v4);
      v8 = _mm_movemask_epi8((__m128i)_mm_or_ps(
                                        (__m128)_mm_cmpeq_epi16(v7, (__m128i)0LL),
                                        (__m128)_mm_cmpeq_epi16(v7, v6)));
      if ( v8 != 0 )
      {
        _BitScanForward(&v9, v8);
        v4 = (const __m128i *)((char *)v4 + 2 * ((unsigned __int64)v9 >> 1));
LABEL_9:
        if ( v4->m128i_i16[0] == 0 )
          return nullptr;
        if ( (_WORD)v2 == v4->m128i_i16[0] )
        {
          v10 = v4;
          for ( i = v3; ; i = (const __m128i *)((char *)i + 2) )
          {
            while ( 2 )
            {
              if ( ((unsigned __int16)i & 0xFFFu) <= 0xFF0uLL && ((unsigned __int16)v10 & 0xFFFu) <= 0xFF0uLL )
              {
                v12 = _mm_loadu_si128(i);
                v13 = _mm_movemask_epi8((__m128i)_mm_or_ps(
                                                   (__m128)_mm_cmpeq_epi16(
                                                             _mm_cmpeq_epi16(v12, _mm_loadu_si128(v10)),
                                                             (__m128i)0LL),
                                                   (__m128)_mm_cmpeq_epi16(v12, (__m128i)0LL)));
                if ( v13 == 0 )
                {
                  ++v10;
                  ++i;
                  continue;
                }
                _BitScanForward(&v14, v13);
                v15 = 2 * ((unsigned __int64)v14 >> 1);
                v10 = (const __m128i *)((char *)v10 + v15);
                i = (const __m128i *)((char *)i + v15);
              }
              break;
            }
            if ( i->m128i_i16[0] == 0 )
              return v4;
            if ( v10->m128i_i16[0] != i->m128i_i16[0] )
              break;
            v10 = (const __m128i *)((char *)v10 + 2);
          }
        }
        v4 = (const __m128i *)((char *)v4 + 2);
      }
      else
      {
        ++v4;
      }
    }
  }
  if ( ((unsigned __int16)a2 & 0xFFFu) > 0xFF0uLL )
  {
    inserted = 0;
    v17 = a2->m128i_i16[0];
    for ( j = 8; j != 0; --j )
    {
      v19 = v17;
      inserted = _mm_insert_epi16(_mm_srli_si128(inserted, 2), v17, 7);
      v20 = (const __m128i *)&a2->m128i_i16[1];
      if ( v17 != 0 )
        v17 = v20->m128i_i16[0];
      if ( v19 == 0 )
        v20 = a2;
      a2 = v20;
    }
  }
  else
  {
    inserted = _mm_loadu_si128(a2);
  }
  while ( 1 )
  {
    while ( ((unsigned __int16)v4 & 0xFFFu) > 0xFF0uLL )
    {
      if ( v4->m128i_i16[0] == 0 )
        return nullptr;
      if ( v4->m128i_i16[0] == (_WORD)v2 )
        goto LABEL_37;
LABEL_47:
      v4 = (const __m128i *)((char *)v4 + 2);
    }
    v21 = _mm_loadu_si128(v4);
    v22 = _mm_cmpistrc(inserted, v21, 13);
    if ( v22 | _mm_cmpistrz(inserted, v21, 13) )
      break;
    ++v4;
  }
  if ( v22 )
  {
    v4 = (const __m128i *)((char *)v4 + 2 * _mm_cmpistri(inserted, v21, 13));
LABEL_37:
    v23 = v4;
    for ( k = v3; ; k = (const __m128i *)((char *)k + v28) )
    {
      if ( ((unsigned __int16)v23 & 0xFFFu) > 0xFF0uLL || ((unsigned __int16)k & 0xFFFu) > 0xFF0uLL )
      {
        if ( k->m128i_i16[0] == 0 )
          return v4;
        if ( v23->m128i_i16[0] != k->m128i_i16[0] )
          goto LABEL_47;
        v28 = 2;
      }
      else
      {
        v25 = _mm_loadu_si128(v23);
        v26 = _mm_loadu_si128(k);
        v27 = _mm_cmpistrs(v26, v25, 13);
        if ( !_mm_cmpistro(v26, v25, 13) )
          goto LABEL_47;
        if ( v27 )
          return v4;
        v28 = 16;
      }
      v23 = (const __m128i *)((char *)v23 + v28);
    }
  }
  return nullptr;
}
