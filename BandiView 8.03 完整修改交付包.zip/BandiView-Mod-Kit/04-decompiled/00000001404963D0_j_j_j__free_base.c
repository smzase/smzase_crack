// EA 0x1404963d0  name j_j_j__free_base  size 5
// attributes: thunk
void __cdecl j_j_j__free_base(void *Block)
{
  j_j__free_base(Block);
}
