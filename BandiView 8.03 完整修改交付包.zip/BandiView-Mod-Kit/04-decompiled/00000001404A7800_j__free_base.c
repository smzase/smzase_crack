// EA 0x1404a7800  name j__free_base  size 5
// attributes: thunk
void __cdecl j__free_base(void *Block)
{
  free_base(Block);
}
