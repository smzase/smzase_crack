// EA 0x14005f3b0  name sub_14005F3B0  size 714
__int64 __fastcall sub_14005F3B0(__int64 a1, __int64 a2, __int64 a3, _QWORD *a4)
{
  const WCHAR *v6; // rdx
  __int64 v7; // rdi
  __int64 v8; // rsi
  __int128 v10; // xmm1
  __int128 v11; // xmm0
  __int128 v12; // xmm1
  __int128 v13; // xmm0
  HINSTANCE v14; // rcx
  HINSTANCE v15; // rax
  const WCHAR *v16; // rdi
  HINSTANCE v17; // rcx
  __int128 v18; // xmm1
  __int128 v19; // xmm0
  __int128 v20; // xmm1
  __int128 v21; // xmm0
  __int16 ClassInfo; // ax
  ATOM v23; // si
  int v24; // edx
  unsigned int v25; // edi
  char *v26; // rax
  char *v27; // rcx
  ATOM *v28; // r8
  _BYTE v29[16]; // [rsp+20h] [rbp-D8h] BYREF
  struct tagWNDCLASSEXW wcx; // [rsp+30h] [rbp-C8h] BYREF
  struct tagWNDCLASSEXW v31; // [rsp+80h] [rbp-78h] BYREF

  if ( a3 == 0 || a4 == nullptr )
    return 0;
  if ( *(_WORD *)(a3 + 108) != 0 )
    goto LABEL_33;
  EnterCriticalSection(&CriticalSection);
  if ( *(_WORD *)(a3 + 108) == 0 )
  {
    v6 = *(const WCHAR **)(a3 + 80);
    if ( v6 != nullptr )
    {
      v7 = *(_QWORD *)(a3 + 64);
      v8 = *(_QWORD *)(a3 + 8);
      wcx.cbSize = 80;
      if ( !GetClassInfoExW(nullptr, v6, &wcx) && !GetClassInfoExW(hModule, *(LPCWSTR *)(a3 + 80), &wcx) )
      {
        LeaveCriticalSection(&CriticalSection);
        return 0;
      }
      v10 = *(_OWORD *)&wcx.cbClsExtra;
      *(_OWORD *)a3 = *(_OWORD *)&wcx.cbSize;
      v11 = *(_OWORD *)&wcx.hIcon;
      *(_OWORD *)(a3 + 16) = v10;
      v12 = *(_OWORD *)&wcx.hbrBackground;
      *(_OWORD *)(a3 + 32) = v11;
      v13 = *(_OWORD *)&wcx.lpszClassName;
      *(_OWORD *)(a3 + 48) = v12;
      *(_OWORD *)(a3 + 64) = v13;
      *(_QWORD *)(a3 + 88) = *(_QWORD *)(a3 + 8);
      *(_QWORD *)(a3 + 64) = v7;
      *(_QWORD *)(a3 + 8) = v8;
    }
    else
    {
      v14 = hInstance;
      if ( *(_DWORD *)(a3 + 104) != 0 )
        v14 = nullptr;
      *(_QWORD *)(a3 + 40) = LoadCursorW(v14, *(LPCWSTR *)(a3 + 96));
    }
    v15 = hModule;
    *(_DWORD *)(a3 + 4) &= ~0x4000u;
    v16 = *(const WCHAR **)(a3 + 64);
    *(_QWORD *)(a3 + 24) = v15;
    if ( v16 == nullptr )
    {
      v16 = (const WCHAR *)(a3 + 110);
      sub_14005F690((wchar_t *)(a3 + 110), 0x45u, (wchar_t *)L"ATL:%p");
      *(_QWORD *)(a3 + 64) = a3 + 110;
    }
    v17 = *(HINSTANCE *)(a3 + 24);
    v18 = *(_OWORD *)(a3 + 16);
    *(_OWORD *)&v31.cbSize = *(_OWORD *)a3;
    v19 = *(_OWORD *)(a3 + 32);
    *(_OWORD *)&v31.cbClsExtra = v18;
    v20 = *(_OWORD *)(a3 + 48);
    *(_OWORD *)&v31.hIcon = v19;
    v21 = *(_OWORD *)(a3 + 64);
    *(_OWORD *)&v31.hbrBackground = v20;
    *(_OWORD *)&v31.lpszClassName = v21;
    ClassInfo = GetClassInfoExW(v17, v16, &v31);
    *(_WORD *)(a3 + 108) = ClassInfo;
    if ( ClassInfo == 0 )
    {
      v23 = RegisterClassExW((const WNDCLASSEXW *)a3);
      if ( v23 != 0 )
      {
        v24 = qword_1406FBC70;
        if ( (_DWORD)qword_1406FBC70 != HIDWORD(qword_1406FBC70) )
        {
          v27 = (char *)Block;
          goto LABEL_28;
        }
        if ( v29 >= Block && v29 < (char *)Block + 2 * SHIDWORD(qword_1406FBC70) )
          sub_14005FF30(2147500037LL);
        if ( HIDWORD(qword_1406FBC70) != 0 )
        {
          v25 = 2 * qword_1406FBC70;
          if ( (qword_1406FBC70 & 0x40000000) != 0 )
            goto LABEL_31;
        }
        else
        {
          v25 = 1;
        }
        if ( v25 <= 0x3FFFFFFFuLL )
        {
          v26 = (char *)j__recalloc_base(Block, v25, 2u);
          v27 = v26;
          if ( v26 != nullptr )
          {
            v24 = qword_1406FBC70;
            HIDWORD(qword_1406FBC70) = v25;
            Block = v26;
LABEL_28:
            v28 = (ATOM *)&v27[2 * v24];
            if ( v28 != nullptr )
            {
              *v28 = v23;
              v24 = qword_1406FBC70;
            }
            LODWORD(qword_1406FBC70) = v24 + 1;
          }
        }
      }
LABEL_31:
      *(_WORD *)(a3 + 108) = v23;
    }
  }
  LeaveCriticalSection(&CriticalSection);
LABEL_33:
  if ( *(_QWORD *)(a3 + 80) != 0 )
    *a4 = *(_QWORD *)(a3 + 88);
  return *(unsigned __int16 *)(a3 + 108);
}
