// EA 0x14007e480  name sub_14007E480  size 172
wint_t **__fastcall sub_14007E480(wint_t **a1)
{
  wint_t *v1; // rdi
  wint_t v3; // ax
  wint_t *v4; // rbx
  wint_t *v5; // rax
  __int64 v6; // rbx

  v1 = *a1;
  v3 = **a1;
  if ( v3 != 0 )
  {
    v4 = nullptr;
    do
    {
      if ( iswspace(v3) != 0 )
      {
        v5 = v1;
        if ( v4 != nullptr )
          v5 = v4;
        v4 = v5;
      }
      else
      {
        v4 = nullptr;
      }
      v3 = v1[1];
      ++v1;
    }
    while ( v3 != 0 );
    if ( v4 != nullptr )
    {
      v6 = v4 - *a1;
      if ( (int)v6 < 0 )
        goto LABEL_16;
      if ( (int)((*((_DWORD *)*a1 - 3) - v6) | (1 - *((_DWORD *)*a1 - 2))) < 0 )
        sub_14005FC80(a1, v6);
      if ( (int)v6 > *((_DWORD *)*a1 - 3) )
LABEL_16:
        sub_14005FF30(0x80070057);
      *((_DWORD *)*a1 - 4) = v6;
      (*a1)[(int)v6] = 0;
    }
  }
  return a1;
}
