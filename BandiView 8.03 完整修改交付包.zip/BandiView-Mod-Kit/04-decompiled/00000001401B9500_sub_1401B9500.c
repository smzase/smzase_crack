// EA 0x1401b9500  name sub_1401B9500  size 1793
__int64 __fastcall sub_1401B9500(__int64 a1)
{
  __int64 v2; // rbp
  _DWORD *v3; // rbx
  __int64 *v4; // rax
  __int64 v5; // rdx
  __int64 v6; // r8
  __int64 v7; // r9
  __int64 v8; // rdx
  __int64 v9; // r8
  __int64 v10; // r9
  __int64 *v11; // rax
  __int64 *v12; // rax
  __int64 *v13; // rax
  __int64 *v14; // rax
  __int64 *v15; // rax
  __int64 *v16; // rax
  __int64 *v17; // rax
  __int64 *v18; // rax
  __int64 v19; // rdx
  __int64 v20; // r8
  __int64 v21; // r9
  __int64 v22; // rdx
  __int64 v23; // r8
  _QWORD *v24; // rax
  volatile signed __int32 *v25; // rbx
  _QWORD *v27; // [rsp+58h] [rbp+10h]
  void *v28; // [rsp+58h] [rbp+10h]

  v2 = a1 + 1712;
  sub_1401DC9B0(a1, a1 + 1712);
  *(_QWORD *)a1 = &XXSkin::`vftable';
  *(_QWORD *)(a1 + 544) = &XXSkin::`vftable';
  v3 = (_DWORD *)(a1 + 552);
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 584) = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24;
  *v3 = 0;
  *(_QWORD *)(a1 + 624) = 0;
  *(_DWORD *)(a1 + 632) = 0;
  *(_WORD *)(a1 + 636) = 0;
  *(_QWORD *)(a1 + 640) = 0;
  *(_QWORD *)(a1 + 648) = 0;
  *(_QWORD *)(a1 + 656) = 0;
  *(_QWORD *)(a1 + 664) = 0;
  *(_QWORD *)(a1 + 672) = 0;
  *(_DWORD *)(a1 + 680) = 10;
  *(_OWORD *)(a1 + 688) = 0;
  *(_QWORD *)(a1 + 704) = 0;
  v27 = operator new(0xC8u);
  v27[7] = 0;
  v27[8] = 0;
  *((_DWORD *)v27 + 18) = 17;
  v27[11] = 0xFFFFFFFFLL;
  v27[12] = 0;
  *((_DWORD *)v27 + 26) = 0;
  *((_DWORD *)v27 + 27) = 10;
  v27[14] = 0;
  v27[15] = 0;
  *((_DWORD *)v27 + 19) = 1061158912;
  *((_DWORD *)v27 + 20) = 1048576000;
  *((_DWORD *)v27 + 21) = 1074790400;
  sub_140091C00(v27 + 7, v5, v6, v27);
  *(_QWORD *)(v7 + 128) = 0;
  *(_QWORD *)(v7 + 136) = 0;
  *(_DWORD *)(v7 + 144) = 17;
  *(_QWORD *)(v7 + 160) = 0xFFFFFFFFLL;
  *(_QWORD *)(v7 + 168) = 0;
  *(_DWORD *)(v7 + 176) = 0;
  *(_DWORD *)(v7 + 180) = 10;
  *(_QWORD *)(v7 + 184) = 0;
  *(_QWORD *)(v7 + 192) = 0;
  *(_DWORD *)(v7 + 148) = 1061158912;
  *(_DWORD *)(v7 + 152) = 1048576000;
  *(_DWORD *)(v7 + 156) = 1074790400;
  sub_140091C00(v7 + 128, v8, v9, v7);
  *(_QWORD *)v10 = v3;
  *(_QWORD *)(v10 + 24) = 0;
  *(_QWORD *)(v10 + 32) = 0;
  *(_QWORD *)(v10 + 40) = 0;
  *(_QWORD *)(v10 + 48) = 0;
  *(_DWORD *)(v10 + 8) = 0;
  *(_QWORD *)(v10 + 12) = -1;
  *(_QWORD *)(a1 + 592) = v10;
  *(_QWORD *)(a1 + 600) = 0;
  *(_QWORD *)(a1 + 608) = 0;
  *(_QWORD *)(a1 + 616) = 0;
  *(_DWORD *)(a1 + 712) = 0;
  sub_14008F930(a1 + 720);
  v11 = sub_1400601C0();
  if ( v11 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 800) = (*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24;
  v12 = sub_1400601C0();
  if ( v12 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 808) = (*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24;
  v13 = sub_1400601C0();
  if ( v13 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 816) = (*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24;
  v14 = sub_1400601C0();
  if ( v14 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 824) = (*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24;
  *(_QWORD *)(a1 + 840) = 0;
  *(_DWORD *)(a1 + 848) = 0;
  *(_QWORD *)(a1 + 856) = 0;
  *(_BYTE *)(a1 + 864) = 0;
  *(_QWORD *)(a1 + 880) = a1;
  *(_QWORD *)(a1 + 888) = 0;
  *(_QWORD *)(a1 + 896) = 0;
  *(_QWORD *)(a1 + 904) = 0;
  *(_QWORD *)(a1 + 912) = 0;
  v15 = sub_1400601C0();
  if ( v15 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 920) = (*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24;
  *(_QWORD *)(a1 + 928) = 0;
  v16 = sub_1400601C0();
  if ( v16 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 936) = (*(__int64 (__fastcall **)(__int64 *))(*v16 + 24))(v16) + 24;
  v17 = sub_1400601C0();
  if ( v17 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 944) = (*(__int64 (__fastcall **)(__int64 *))(*v17 + 24))(v17) + 24;
  *(_QWORD *)(a1 + 960) = 0;
  *(_QWORD *)(a1 + 928) = 0;
  sub_14005FA90((int **)(a1 + 936));
  sub_14005FA90((int **)(a1 + 944));
  *(_QWORD *)(a1 + 960) = 0;
  *(_QWORD *)(a1 + 968) = 0;
  *(_QWORD *)(a1 + 952) = 0;
  *(_QWORD *)(a1 + 976) = 0;
  *(_QWORD *)(a1 + 984) = 0;
  *(_QWORD *)(a1 + 992) = 0;
  *(_QWORD *)(a1 + 1000) = 0;
  *(_QWORD *)(a1 + 1008) = 0;
  *(_DWORD *)(a1 + 1016) = 10;
  *(_QWORD *)(a1 + 1024) = 0;
  *(_QWORD *)(a1 + 1032) = 0;
  *(_QWORD *)(a1 + 1040) = 0;
  *(_QWORD *)(a1 + 1048) = 0;
  *(_QWORD *)(a1 + 1056) = 0;
  *(_DWORD *)(a1 + 1064) = 10;
  *(_QWORD *)(a1 + 1072) = 0;
  *(_QWORD *)(a1 + 1080) = 0;
  *(_QWORD *)(a1 + 1088) = 0;
  *(_QWORD *)(a1 + 1096) = 0;
  *(_QWORD *)(a1 + 1104) = 0;
  *(_DWORD *)(a1 + 1112) = 10;
  *(_QWORD *)(a1 + 1160) = 0;
  *(_QWORD *)(a1 + 1192) = 0;
  *(_QWORD *)(a1 + 1200) = 0;
  *(_DWORD *)(a1 + 1208) = 0;
  *(_QWORD *)(a1 + 1216) = DefWindowProcW;
  *(_QWORD *)(a1 + 1152) = &XSkinMainWindowSubClasser::`vftable';
  *(_QWORD *)(a1 + 1224) = 0;
  *(_QWORD *)(a1 + 1232) = v2;
  *(_QWORD *)(a1 + 1248) = 0;
  *(_QWORD *)(a1 + 1256) = 0;
  *(_QWORD *)(a1 + 1264) = 0;
  *(_QWORD *)(a1 + 1272) = 0;
  *(_QWORD *)(a1 + 1280) = 0;
  *(_DWORD *)(a1 + 1288) = 10;
  *(_QWORD *)(a1 + 1296) = 0;
  *(_QWORD *)(a1 + 1304) = 0;
  v18 = sub_1400601C0();
  if ( v18 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 1336) = (*(__int64 (__fastcall **)(__int64 *))(*v18 + 24))(v18) + 24;
  *(_QWORD *)(a1 + 1360) = 0;
  *(_QWORD *)(a1 + 1368) = 0;
  *(_QWORD *)(a1 + 1376) = 0;
  *(_QWORD *)(a1 + 1384) = 0;
  *(_QWORD *)(a1 + 1392) = 0;
  *(_DWORD *)(a1 + 1400) = 10;
  *(_QWORD *)(a1 + 1448) = 0;
  *(_QWORD *)(a1 + 1456) = 0;
  *(_DWORD *)(a1 + 1464) = 17;
  *(_QWORD *)(a1 + 1480) = 0xFFFFFFFFLL;
  *(_QWORD *)(a1 + 1488) = 0;
  *(_DWORD *)(a1 + 1496) = 0;
  *(_DWORD *)(a1 + 1500) = 10;
  *(_QWORD *)(a1 + 1504) = 0;
  *(_QWORD *)(a1 + 1512) = 0;
  *(_DWORD *)(a1 + 1468) = 1061158912;
  *(_DWORD *)(a1 + 1472) = 1048576000;
  *(_DWORD *)(a1 + 1476) = 1074790400;
  sub_140091C00(a1 + 1448, v19, v20, v21);
  *(_QWORD *)(a1 + 1352) = 0;
  *(_QWORD *)(a1 + 1408) = 0;
  *(_QWORD *)(a1 + 1416) = 0;
  *(_QWORD *)(a1 + 1424) = 0;
  *(_QWORD *)(a1 + 1432) = 0;
  *(_DWORD *)(a1 + 1440) = 0;
  *(_QWORD *)(a1 + 1520) = 0;
  *(_QWORD *)(a1 + 1528) = 0;
  *(_QWORD *)(a1 + 1536) = 0;
  *(_QWORD *)(a1 + 1544) = 0;
  *(_QWORD *)(a1 + 1552) = 0;
  *(_DWORD *)(a1 + 1560) = 10;
  *(_QWORD *)(a1 + 1600) = 0;
  *(_QWORD *)(a1 + 1608) = 12386289;
  *(_QWORD *)(a1 + 1616) = 0;
  *(_QWORD *)(a1 + 1624) = 96;
  *(_QWORD *)(a1 + 1632) = -1;
  *(_QWORD *)(a1 + 1640) = 0;
  *(_QWORD *)(a1 + 1648) = 0;
  *(_QWORD *)(a1 + 1656) = 0;
  sub_1401B9490(a1 + 1664);
  sub_14005D490(v2, v22, v23);
  *(_WORD *)(a1 + 1856) = 256;
  *(_BYTE *)(a1 + 1858) = 0;
  *(_QWORD *)(a1 + 1880) = 0;
  *(_QWORD *)(a1 + 1888) = 0;
  v24 = operator new(0x18u);
  *v24 = v24;
  v24[1] = v24;
  *(_QWORD *)(a1 + 1880) = v24;
  *(_DWORD *)(a1 + 1912) = 0;
  if ( dword_140709AF4 == 0 )
    sub_1401C99A0();
  *(_QWORD *)(a1 + 1144) = 0;
  *(_QWORD *)(a1 + 1136) = 0;
  *(_QWORD *)(a1 + 1352) = a1;
  *(_QWORD *)(a1 + 1568) = 0;
  *(_DWORD *)(a1 + 1576) = 0;
  *(_QWORD *)(a1 + 1904) = 0;
  *(_DWORD *)(a1 + 1696) = 0;
  *(_DWORD *)(a1 + 1312) = 1;
  *(_QWORD *)(a1 + 1704) = 0;
  *(_QWORD *)(a1 + 1128) = 0;
  *(_QWORD *)(a1 + 904) = 0;
  v25 = *(volatile signed __int32 **)(a1 + 912);
  *(_QWORD *)(a1 + 912) = 0;
  if ( v25 != nullptr && _InterlockedExchangeAdd(v25 + 2, 0xFFFFFFFF) == 1 )
  {
    (**(void (__fastcall ***)(volatile signed __int32 *))v25)(v25);
    if ( _InterlockedExchangeAdd(v25 + 3, 0xFFFFFFFF) == 1 )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v25 + 8LL))(v25);
  }
  *(_QWORD *)(a1 + 1864) = 0;
  *(_QWORD *)(a1 + 1872) = 0;
  *(_QWORD *)(a1 + 1896) = 0;
  v28 = operator new(0x1C0u);
  *(_QWORD *)(a1 + 1240) = sub_1401D2B40(v28);
  *(_DWORD *)(a1 + 832) = 0;
  sub_1401B9F90(a1, 0);
  return a1;
}
