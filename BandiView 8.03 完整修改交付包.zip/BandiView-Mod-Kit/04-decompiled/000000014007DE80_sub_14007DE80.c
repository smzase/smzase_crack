// EA 0x14007de80  name sub_14007DE80  size 77
_QWORD *__fastcall sub_14007DE80(__int64 a1, _QWORD *a2)
{
  sub_14007D640(a2);
  if ( dword_1406DC8FC != 0 )
    sub_14005EB50((__int64)a2, (__int64)L"%sb%d", *a2);
  return a2;
}
