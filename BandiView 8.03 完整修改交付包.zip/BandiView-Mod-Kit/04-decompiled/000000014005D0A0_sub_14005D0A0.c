// EA 0x14005d0a0  name sub_14005D0A0  size 246
char *__fastcall sub_14005D0A0(char *a1, __int64 a2, __int64 a3, const void *a4, __int64 a5, void *Src, __int64 a7)
{
  __int64 v9; // rbp
  __int64 v10; // rbx
  __int64 v11; // rcx
  char *v12; // rsi

  *(_OWORD *)a1 = 0;
  *((_QWORD *)a1 + 2) = 0;
  v9 = a5 + a7;
  *((_QWORD *)a1 + 3) = 0;
  if ( (unsigned __int64)(a5 + a7) <= 7 )
  {
    v10 = 7;
    v12 = a1;
  }
  else
  {
    v10 = 0x7FFFFFFFFFFFFFFELL;
    if ( (v9 | 7uLL) <= 0x7FFFFFFFFFFFFFFELL )
    {
      v10 = v9 | 7;
      if ( (v9 | 7uLL) < 0xA )
        v10 = 10;
      v11 = v10 + 1;
      if ( (unsigned __int64)(v10 + 1) > 0x7FFFFFFFFFFFFFFFLL )
      {
        sub_14005D3C0();
        JUMPOUT(0x14005D195LL);
      }
    }
    else
    {
      v11 = 0x7FFFFFFFFFFFFFFFLL;
    }
    v12 = (char *)sub_14005D1E0(2 * v11);
    *(_QWORD *)a1 = v12;
  }
  *((_QWORD *)a1 + 3) = v10;
  *((_QWORD *)a1 + 2) = v9;
  memcpy(v12, a4, 2 * a5);
  memcpy(&v12[2 * a5], Src, 2 * a7);
  *(_WORD *)&v12[2 * v9] = 0;
  return a1;
}
