// EA 0x140066f10  name sub_140066F10  size 2959
__int64 __fastcall sub_140066F10(int *a1)
{
  __int64 *v1; // rbx
  char *v2; // rbx
  char *v3; // rcx
  __int64 v4; // rbx
  unsigned int v5; // eax
  HANDLE CurrentProcess; // rax
  int v7; // ecx
  int v8; // edi
  __int64 *v9; // rax
  __int64 v10; // rdi
  __int64 (__fastcall *v11)(__int64); // rax
  unsigned int v12; // esi
  int v13; // ebx
  int (__fastcall *v14)(__int64); // rax
  int *v15; // r14
  int DeviceCaps; // edi
  HDC DC; // rax
  HDC v18; // rbx
  __int64 v19; // rax
  __int64 v20; // rbx
  __int64 *v21; // rax
  __int64 v22; // rax
  __int64 v23; // rbx
  __int64 *v24; // rax
  int v25; // ebx
  DWORD CurrentProcessId; // eax
  __int64 v27; // rax
  __int64 *v28; // rax
  int *v29; // rbx
  __int64 v30; // rax
  _BYTE *v31; // rbx
  int v32; // eax
  __int64 v33; // rcx
  int v34; // edx
  __int64 v35; // rcx
  __int64 v36; // rdx
  int v37; // r15d
  _BYTE *v38; // rsi
  HINSTANCE v39; // r14
  HINSTANCE *v40; // rax
  HINSTANCE *v41; // rbx
  int v42; // eax
  int *v43; // rdx
  __int64 v44; // rax
  _BYTE *v45; // rbx
  __int64 *v46; // rax
  int v47; // eax
  __int64 v48; // rax
  _BYTE *v49; // rbx
  __int64 *v50; // rax
  int v51; // eax
  __int64 v52; // rax
  _BYTE *v53; // rbx
  __int64 *v54; // rax
  int v55; // eax
  __int64 v56; // rax
  _BYTE *v57; // rbx
  __int64 *v58; // rax
  int v59; // eax
  __int64 v60; // rax
  _BYTE *v61; // rbx
  __int64 *v62; // rax
  int v63; // eax
  __int64 v64; // rax
  _BYTE *v65; // rbx
  __int64 *v66; // rax
  int v67; // eax
  __int64 v68; // rax
  _BYTE *v69; // rbx
  __int64 *v70; // rax
  int v71; // eax
  __int64 v72; // rax
  _BYTE *v73; // rbx
  __int64 *v74; // rax
  int v75; // eax
  __int64 v76; // rax
  _BYTE *v77; // rbx
  __int64 *v78; // rax
  int v79; // eax
  int *v81; // [rsp+50h] [rbp-89h] BYREF
  int *v82; // [rsp+58h] [rbp-81h] BYREF
  int *v83; // [rsp+60h] [rbp-79h] BYREF
  int *v84; // [rsp+68h] [rbp-71h] BYREF
  int *v85[10]; // [rsp+70h] [rbp-69h] BYREF
  struct _SYSTEM_INFO SystemInfo; // [rsp+C0h] [rbp-19h] BYREF
  int *TokenInformation; // [rsp+140h] [rbp+67h] BYREF
  int **ReturnLength; // [rsp+148h] [rbp+6Fh] BYREF
  HANDLE TokenHandle; // [rsp+150h] [rbp+77h] BYREF
  int *v90; // [rsp+158h] [rbp+7Fh] BYREF

  TokenInformation = a1;
  v1 = &qword_14070A040;
  if ( &qword_14070A040 != (__int64 *)-1LL )
  {
    qword_140709C18 = (__int64)&qword_14070A040;
    if ( qword_14070A040 != 0 )
    {
      do
      {
        LOBYTE(a1) = 1;
        ((void (__fastcall *)(int *))v1[8])(a1);
        v1 += 9;
      }
      while ( *v1 != 0 );
    }
  }
  v2 = (char *)off_1406FBC90;
  v3 = (char *)off_1406FBC98;
  if ( off_1406FBC90 < off_1406FBC98 )
  {
    do
    {
      if ( *(_QWORD *)v2 != 0 )
      {
        LOBYTE(v3) = 1;
        (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 56LL))(v3);
        v3 = (char *)off_1406FBC98;
      }
      v2 += 8;
    }
    while ( v2 < v3 );
  }
  InitCommonControls();
  if ( OleInitialize(nullptr) < 0 || CoInitialize(nullptr) < 0 )
    return 0;
  SetErrorMode(1u);
  sub_140073D60((__int64)&unk_1406DC8F0);
  v4 = sub_14007D5E0();
  v5 = sub_14006E550();
  *(_DWORD *)(v4 + 8) = v5;
  if ( v5 >= 0x12 )
    *(_BYTE *)(v4 + 12) = 1;
  *(_BYTE *)(v4 + 14) = 1;
  *(_DWORD *)(v4 + 20) = 0;
  LODWORD(TokenInformation) = 0;
  CurrentProcess = GetCurrentProcess();
  OpenProcessToken(CurrentProcess, 8u, &TokenHandle);
  GetTokenInformation(TokenHandle, TokenElevationType, &TokenInformation, 4u, (PDWORD)&ReturnLength);
  if ( (_DWORD)TokenInformation == 1 )
  {
    *(_DWORD *)(v4 + 20) = 0;
    goto LABEL_18;
  }
  v7 = (_DWORD)TokenInformation - 2;
  if ( (_DWORD)TokenInformation == 2 )
  {
    v8 = 1;
    *(_DWORD *)(v4 + 20) = 1;
    goto LABEL_19;
  }
  *(_DWORD *)(v4 + 20) = 0;
  if ( v7 != 1 )
  {
LABEL_18:
    v8 = 0;
    goto LABEL_19;
  }
  v8 = 1;
LABEL_19:
  if ( TokenHandle != nullptr )
    CloseHandle(TokenHandle);
  *(_DWORD *)(v4 + 24) = v8;
  ReturnLength = &TokenInformation;
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    sub_14005FF30(0x80004005);
  TokenInformation = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
  if ( (unsigned __int8)sub_14005F980(&TokenInformation, (__int64)L"HKLM/SOFTWARE/BandiView/AutoReport") == 0 )
    sub_14005FCF0(&TokenInformation, L"HKLM/SOFTWARE/BandiView/AutoReport", 34);
  *(_BYTE *)(v4 + 96) = (unsigned int)sub_140083540(&TokenInformation) != 0;
  *(_QWORD *)(v4 + 104) = GetTickCount64();
  GetSystemInfo(&SystemInfo);
  *(_DWORD *)v4 = SystemInfo.dwNumberOfProcessors;
  sub_140082560();
  sub_14005FA90((int **)(v4 + 168));
  *(_QWORD *)(sub_14007D5E0() + 32) = 107;
  v10 = sub_1401C0040();
  sub_1401C0150(v10);
  v11 = *(__int64 (__fastcall **)(__int64))(v10 + 16);
  v12 = 2;
  if ( v11 == nullptr || (v13 = v11(-4), GetLastError(), sub_140060320(), v13 == 0) )
  {
    sub_1401C0150(v10);
    v14 = *(int (__fastcall **)(__int64))(v10 + 24);
    if ( v14 != nullptr )
    {
      if ( v14(2) < 0 )
        (*(void (__fastcall **)(__int64))(v10 + 24))(1);
    }
    else
    {
      SetProcessDPIAware();
    }
  }
  v15 = (int *)sub_1401C0040();
  sub_1401C0150(v15);
  DeviceCaps = 96;
  DC = GetDC(nullptr);
  v18 = DC;
  if ( DC != nullptr )
  {
    DeviceCaps = GetDeviceCaps(DC, 88);
    ReleaseDC(nullptr, v18);
  }
  *v15 = DeviceCaps;
  sub_140066D10();
  sub_1401C99A0();
  sub_14008A340();
  dword_140709AB4 = RegisterWindowMessageW(L"_WM_LICENSE_REGISTRATION_SUCCESS");
  dword_140709AB8 = RegisterWindowMessageW(L"_WM_LICENSE_EXPIRED");
  dword_140709AB0 = RegisterWindowMessageW(L"_WM_SKIN_RELOAD");
  v19 = sub_140075FE0();
  sub_140076800(v19);
  v20 = sub_140075FE0();
  ReturnLength = &TokenInformation;
  v21 = sub_1400601C0();
  if ( v21 == nullptr )
    sub_14005FF30(0x80004005);
  TokenInformation = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v21 + 24))(v21) + 24);
  if ( (unsigned __int8)sub_14005F980(&TokenInformation, (__int64)&Data) == 0 )
    sub_14005FCF0(&TokenInformation, &Data, 0);
  sub_140076F50(v20, 0, &TokenInformation);
  v22 = sub_14019BB00();
  sub_14019BC50(v22);
  v23 = sub_14019BB00();
  ReturnLength = &TokenInformation;
  v24 = sub_1400601C0();
  if ( v24 == nullptr )
    sub_14005FF30(0x80004005);
  TokenInformation = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v24 + 24))(v24) + 24);
  if ( (unsigned __int8)sub_14005F980(&TokenInformation, (__int64)&Data) == 0 )
    sub_14005FCF0(&TokenInformation, &Data, 0);
  sub_14019BD50(v23, 0, &TokenInformation);
  v25 = unknown_libname_553(0);
  CurrentProcessId = GetCurrentProcessId();
  srand(v25 + CurrentProcessId);
  if ( *(_DWORD *)(sub_140075FE0() + 196) != 2 )
  {
    v12 = 3;
    if ( *(_DWORD *)(sub_140075FE0() + 196) != 1 )
      v12 = 1;
  }
  v27 = sub_1401D4680();
  sub_1401D4700(v27, v12);
  if ( *(_BYTE *)(sub_140075FE0() + 1) != 0
    && *(_BYTE *)(sub_14007D5E0() + 12) != 0
    && *(_BYTE *)(sub_14007D5E0() + 13) == 0
    && byte_1406DC8F5 == 0 )
  {
    v28 = sub_1400601C0();
    if ( v28 == nullptr )
      sub_14005FF30(0x80004005);
    v29 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24);
    TokenInformation = v29;
    if ( *(int *)sub_1404AE468() > 2 )
    {
      v30 = sub_1404AE470();
      v31 = *(_BYTE **)(*(_QWORD *)v30 + 8LL);
      if ( v31 != nullptr )
        v32 = sub_1404ADC20(*(_QWORD *)(*(_QWORD *)v30 + 8LL));
      else
        v32 = 0;
      sub_14005FCF0(&TokenInformation, v31, v32);
      v29 = TokenInformation;
    }
    v33 = -1;
    do
    {
      v34 = *((unsigned __int16 *)v29 + v33 + 1) - aRegmandatoryad[v33 + 1];
      if ( v34 != 0 )
        break;
      v33 += 2;
      if ( v33 == 19 )
        break;
      v34 = *((unsigned __int16 *)v29 + v33) - aRegmandatoryad[v33];
    }
    while ( v34 == 0 );
    if ( v34 != 0 )
    {
      v35 = -1;
      do
      {
        v36 = *((unsigned __int16 *)v29 + v35 + 1) - (unsigned int)aSetdefaultprog[v35 + 1];
        if ( (_DWORD)v36 != 0 )
          break;
        v35 += 2;
        if ( v35 == 19 )
          break;
        v36 = *((unsigned __int16 *)v29 + v35) - (unsigned int)aSetdefaultprog[v35];
      }
      while ( (_DWORD)v36 == 0 );
      if ( (_DWORD)v36 != 0 )
        sub_140066A70(v35, v36, L"/setdefaultprogram");
    }
    if ( _InterlockedExchangeAdd(v29 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v29 - 3) + 8LL))(*((_QWORD *)v29 - 3));
  }
  sub_140066070();
  v37 = *(_DWORD *)(sub_1401C5640() + 312);
  v38 = *(_BYTE **)sub_14007D7F0(&TokenInformation);
  v39 = hModule;
  v40 = (HINSTANCE *)sub_14008ADD0();
  v41 = v40;
  if ( *v40 == nullptr )
  {
    *v40 = v39;
    if ( v38 != nullptr )
      v42 = sub_1404ADC20(v38);
    else
      v42 = 0;
    sub_14005FCF0((int **)v41 + 2, v38, v42);
    *((_DWORD *)v41 + 6) = v37;
    *((_DWORD *)v41 + 7) = 107;
  }
  v43 = TokenInformation - 6;
  if ( _InterlockedExchangeAdd(TokenInformation - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v43 + 8LL))(*(_QWORD *)v43);
  v85[1] = (int *)&TokenInformation;
  v44 = sub_1401C5640();
  v45 = (_BYTE *)sub_1401C81E0(v44, L"TEXT_MESSAGEBOX_DONOTSHOWTHISMSGAGAIN", L"TEXT");
  v46 = sub_1400601C0();
  if ( v46 == nullptr )
    sub_14005FF30(0x80004005);
  TokenInformation = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v46 + 24))(v46) + 24);
  if ( (unsigned __int8)sub_14005F980(&TokenInformation, (__int64)v45) == 0 )
  {
    if ( v45 != nullptr )
      v47 = sub_1404ADC20(v45);
    else
      v47 = 0;
    sub_14005FCF0(&TokenInformation, v45, v47);
  }
  v85[2] = (int *)&ReturnLength;
  v48 = sub_1401C5640();
  v49 = (_BYTE *)sub_1401C81E0(v48, L"TEXT_MESSAGEBOX_CONTINUE", L"TEXT");
  v50 = sub_1400601C0();
  if ( v50 == nullptr )
    sub_14005FF30(0x80004005);
  ReturnLength = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v50 + 24))(v50) + 24);
  if ( (unsigned __int8)sub_14005F980(&ReturnLength, (__int64)v49) == 0 )
  {
    if ( v49 != nullptr )
      v51 = sub_1404ADC20(v49);
    else
      v51 = 0;
    sub_14005FCF0((int **)&ReturnLength, v49, v51);
  }
  v85[3] = (int *)&TokenHandle;
  v52 = sub_1401C5640();
  v53 = (_BYTE *)sub_1401C81E0(v52, L"TEXT_MESSAGEBOX_NO", L"TEXT");
  v54 = sub_1400601C0();
  if ( v54 == nullptr )
    sub_14005FF30(0x80004005);
  TokenHandle = (HANDLE)((*(__int64 (__fastcall **)(__int64 *))(*v54 + 24))(v54) + 24);
  if ( (unsigned __int8)sub_14005F980(&TokenHandle, (__int64)v53) == 0 )
  {
    if ( v53 != nullptr )
      v55 = sub_1404ADC20(v53);
    else
      v55 = 0;
    sub_14005FCF0((int **)&TokenHandle, v53, v55);
  }
  v85[4] = (int *)&v90;
  v56 = sub_1401C5640();
  v57 = (_BYTE *)sub_1401C81E0(v56, L"TEXT_MESSAGEBOX_YES", L"TEXT");
  v58 = sub_1400601C0();
  if ( v58 == nullptr )
    sub_14005FF30(0x80004005);
  v90 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v58 + 24))(v58) + 24);
  if ( (unsigned __int8)sub_14005F980(&v90, (__int64)v57) == 0 )
  {
    if ( v57 != nullptr )
      v59 = sub_1404ADC20(v57);
    else
      v59 = 0;
    sub_14005FCF0(&v90, v57, v59);
  }
  v85[5] = (int *)&v81;
  v60 = sub_1401C5640();
  v61 = (_BYTE *)sub_1401C81E0(v60, L"TEXT_MESSAGEBOX_IGNORE", L"TEXT");
  v62 = sub_1400601C0();
  if ( v62 == nullptr )
    sub_14005FF30(0x80004005);
  v81 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v62 + 24))(v62) + 24);
  if ( (unsigned __int8)sub_14005F980(&v81, (__int64)v61) == 0 )
  {
    if ( v61 != nullptr )
      v63 = sub_1404ADC20(v61);
    else
      v63 = 0;
    sub_14005FCF0(&v81, v61, v63);
  }
  v85[6] = (int *)&v82;
  v64 = sub_1401C5640();
  v65 = (_BYTE *)sub_1401C81E0(v64, L"TEXT_MESSAGEBOX_RETRY", L"TEXT");
  v66 = sub_1400601C0();
  if ( v66 == nullptr )
    sub_14005FF30(0x80004005);
  v82 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v66 + 24))(v66) + 24);
  if ( (unsigned __int8)sub_14005F980(&v82, (__int64)v65) == 0 )
  {
    if ( v65 != nullptr )
      v67 = sub_1404ADC20(v65);
    else
      v67 = 0;
    sub_14005FCF0(&v82, v65, v67);
  }
  v85[7] = (int *)&v83;
  v68 = sub_1401C5640();
  v69 = (_BYTE *)sub_1401C81E0(v68, L"TEXT_MESSAGEBOX_ABORT", L"TEXT");
  v70 = sub_1400601C0();
  if ( v70 == nullptr )
    sub_14005FF30(0x80004005);
  v83 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v70 + 24))(v70) + 24);
  if ( (unsigned __int8)sub_14005F980(&v83, (__int64)v69) == 0 )
  {
    if ( v69 != nullptr )
      v71 = sub_1404ADC20(v69);
    else
      v71 = 0;
    sub_14005FCF0(&v83, v69, v71);
  }
  v85[8] = (int *)&v84;
  v72 = sub_1401C5640();
  v73 = (_BYTE *)sub_1401C81E0(v72, L"TEXT_MESSAGEBOX_CANCEL", L"TEXT");
  v74 = sub_1400601C0();
  if ( v74 == nullptr )
    sub_14005FF30(0x80004005);
  v84 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v74 + 24))(v74) + 24);
  if ( (unsigned __int8)sub_14005F980(&v84, (__int64)v73) == 0 )
  {
    if ( v73 != nullptr )
      v75 = sub_1404ADC20(v73);
    else
      v75 = 0;
    sub_14005FCF0(&v84, v73, v75);
  }
  v85[9] = (int *)v85;
  v76 = sub_1401C5640();
  v77 = (_BYTE *)sub_1401C81E0(v76, L"TEXT_MESSAGEBOX_OK", L"TEXT");
  v78 = sub_1400601C0();
  if ( v78 == nullptr )
    sub_14005FF30(0x80004005);
  v85[0] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v78 + 24))(v78) + 24);
  if ( (unsigned __int8)sub_14005F980(v85, (__int64)v77) == 0 )
  {
    if ( v77 != nullptr )
      v79 = sub_1404ADC20(v77);
    else
      v79 = 0;
    sub_14005FCF0(v85, v77, v79);
  }
  sub_14008AE80(
    (unsigned int)v85,
    (unsigned int)&v84,
    (unsigned int)&v83,
    (unsigned int)&v82,
    (__int64)&v81,
    (__int64)&v90,
    (__int64)&TokenHandle,
    (__int64)&ReturnLength,
    (__int64)&TokenInformation);
  setlocale(0, &Locale);
  timeBeginPeriod(1u);
  if ( *(_BYTE *)(sub_140075FE0() + 1) != 0 )
    sub_14008EA40();
  return 1;
}
