// EA 0x1400a36b0  name sub_1400A36B0  size 1467
__int64 __fastcall sub_1400A36B0(__int64 a1, int a2, __int64 a3, _DWORD *a4)
{
  __int64 *v8; // rax
  const wchar_t *v9; // r8
  _QWORD *v10; // rbx
  _QWORD *v11; // rdx
  bool v12; // si
  unsigned __int8 v13; // bl
  LPCWSTR *v14; // rax
  char v15; // bl
  LPCWSTR v16; // rsi
  int v17; // eax
  LPCWSTR *v18; // rax
  LPCWSTR v19; // rsi
  int v20; // eax
  LPCWSTR *v21; // rax
  LPCWSTR v22; // rsi
  int v23; // eax
  char v24; // si
  _QWORD *v25; // rdx
  _QWORD *v26; // rdx
  _QWORD *v27; // rdx
  __int64 v28; // rbx
  BYTE *v29; // rbx
  int v30; // eax
  const BYTE *v31; // rbx
  int v32; // eax
  DWORD dwDisposition; // [rsp+50h] [rbp-39h] BYREF
  HKEY hKey; // [rsp+58h] [rbp-31h] BYREF
  DWORD Type[2]; // [rsp+60h] [rbp-29h] BYREF
  BYTE v37[8]; // [rsp+68h] [rbp-21h] BYREF
  __int64 v38; // [rsp+70h] [rbp-19h] BYREF
  __int64 v39; // [rsp+78h] [rbp-11h] BYREF
  __int64 v40; // [rsp+80h] [rbp-9h] BYREF
  __int64 v41; // [rsp+88h] [rbp-1h] BYREF
  BYTE Data[8]; // [rsp+98h] [rbp+Fh] BYREF

  dwDisposition = 0;
  hKey = nullptr;
  *(_QWORD *)v37 = Type;
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)Type = (*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24;
  if ( (unsigned __int8)sub_14005F980(Type, (__int64)L"SOFTWARE\\$app$\\l") == 0 )
    sub_14005FCF0((int **)Type, L"SOFTWARE\\$app$\\l", 16);
  *(_QWORD *)v37 = Type;
  switch ( a2 )
  {
    case 1:
      v9 = L"BandiView";
      break;
    case 2:
      v9 = L"Bandizip";
      break;
    case 3:
      v9 = L"Honeycam";
      break;
    default:
      goto LABEL_11;
  }
  sub_140060D20((unsigned __int64 *)Type, (__int64)L"$app$", v9);
LABEL_11:
  v10 = (_QWORD *)sub_14005F710((volatile signed __int32 *)(*(_QWORD *)Type - 24LL));
  v11 = (_QWORD *)(*(_QWORD *)Type - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)Type - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v11 + 8LL))(*v11);
  hKey = nullptr;
  if ( RegOpenKeyExW(HKEY_CURRENT_USER, (LPCWSTR)v10 + 12, 0, 0x2001Fu, &hKey) != 0 )
  {
    if ( hKey != nullptr )
      RegCloseKey(hKey);
    hKey = nullptr;
    v12 = RegCreateKeyExW(HKEY_CURRENT_USER, (LPCWSTR)v10 + 12, 0, nullptr, 0, 0x2001Fu, nullptr, &hKey, &dwDisposition) != 0;
  }
  else
  {
    v12 = false;
  }
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v10 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, _QWORD *))(*(_QWORD *)*v10 + 8LL))(*v10, v10);
  if ( v12 )
  {
    a4[1] = 0;
    *a4 = -1159777789;
    v13 = 0;
  }
  else
  {
    Type[0] = sub_1400CCC00();
    v38 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 8) - 24LL)) + 24;
    v14 = (LPCWSTR *)sub_1400C8E00(v37, &v38, a3, 16);
    v15 = 9;
    dwDisposition = 9;
    if ( hKey == nullptr )
      goto LABEL_32;
    v16 = *v14;
    if ( *v14 == nullptr )
      goto LABEL_32;
    v17 = lstrlenW(*v14);
    if ( RegSetValueExW(hKey, L"c", 0, 1u, (const BYTE *)v16, 2 * v17) != 0 )
      goto LABEL_32;
    v39 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(a1 + 16) - 24LL)) + 24;
    v18 = (LPCWSTR *)sub_1400C8E00(&v41, &v39, a3, 16);
    v15 = 11;
    dwDisposition = 11;
    if ( hKey == nullptr )
      goto LABEL_32;
    v19 = *v18;
    if ( *v18 != nullptr
      && (v20 = lstrlenW(*v18), RegSetValueExW(hKey, L"r", 0, 1u, (const BYTE *)v19, 2 * v20) == 0)
      && (*(_QWORD *)Data = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)a1 - 24LL)) + 24,
          v21 = (LPCWSTR *)sub_1400C8E00(&v40, Data, Type, 4),
          v15 = 15,
          hKey != nullptr)
      && (v22 = *v21, *v21 != nullptr)
      && (v23 = lstrlenW(*v21), RegSetValueExW(hKey, L"u", 0, 1u, (const BYTE *)v22, 2 * v23) == 0) )
    {
      v24 = 0;
    }
    else
    {
LABEL_32:
      v24 = 1;
    }
    if ( (v15 & 4) != 0 )
    {
      v15 &= ~4u;
      v25 = (_QWORD *)(v40 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v40 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v25 + 8LL))(*v25);
    }
    if ( (v15 & 2) != 0 )
    {
      v15 &= ~2u;
      v26 = (_QWORD *)(v41 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v41 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v26 + 8LL))(*v26);
    }
    if ( (v15 & 1) != 0 )
    {
      v27 = (_QWORD *)(*(_QWORD *)v37 - 24LL);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)v37 - 24LL + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v27 + 8LL))(*v27);
    }
    if ( v24 != 0 )
    {
      a4[1] = 0;
      *a4 = -1159777788;
      v13 = 0;
    }
    else
    {
      v28 = sub_1404BF238(*(_QWORD *)(a1 + 24));
      if ( v28 == 0 )
      {
        *(_QWORD *)Data = 0;
        dwDisposition = 8;
        Type[0] = 11;
        if ( RegQueryValueExW(hKey, L"f", nullptr, Type, Data, &dwDisposition) != 0
          || (v28 = *(_QWORD *)Data, *(_QWORD *)Data == 0) )
        {
          v28 = unknown_libname_553(0);
        }
        sub_14005EB50(a1 + 24, (__int64)L"%I64d", v28);
      }
      *(_QWORD *)v37 = v28;
      RegSetValueExW(hKey, L"f", 0, 0xBu, v37, 8u);
      if ( *(_DWORD *)(*(_QWORD *)(a1 + 32) - 16LL) == 0 && hKey != nullptr )
      {
        Type[0] = 0;
        dwDisposition = 1;
        RegQueryValueExW(hKey, L"a", nullptr, &dwDisposition, nullptr, Type);
        if ( Type[0] != 0 && (dwDisposition - 1 <= 1 || dwDisposition == 7) )
        {
          v29 = (BYTE *)j__calloc_base(1u, Type[0] + 2LL);
          if ( v29 != nullptr )
          {
            if ( RegQueryValueExW(hKey, L"a", nullptr, &dwDisposition, v29, Type) == 0 )
            {
              v30 = sub_1404ADC20(v29);
              sub_14005FCF0((int **)(a1 + 32), v29, v30);
            }
            j__free_base(v29);
          }
        }
      }
      sub_1400A3600(a1);
      if ( hKey != nullptr )
      {
        v31 = *(const BYTE **)(a1 + 32);
        if ( v31 != nullptr )
        {
          v32 = lstrlenW(*(LPCWSTR *)(a1 + 32));
          RegSetValueExW(hKey, L"a", 0, 1u, v31, 2 * v32);
        }
      }
      v13 = 1;
    }
  }
  if ( hKey != nullptr )
    RegCloseKey(hKey);
  return v13;
}
