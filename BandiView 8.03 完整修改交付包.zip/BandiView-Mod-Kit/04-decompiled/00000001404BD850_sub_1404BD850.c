// EA 0x1404bd850  name sub_1404BD850  size 8
__int64 __fastcall sub_1404BD850(__int64 a1, __int64 a2)
{
  return sub_1404BD860(a1, a2, 0);
}
