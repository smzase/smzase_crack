// EA 0x14008e350  name sub_14008E350  size 549
__int64 __fastcall sub_14008E350(__int64 a1)
{
  unsigned int v2; // ebp
  _BYTE **v3; // rdi
  _BYTE **v4; // r14
  _BYTE *v5; // rbx
  __int64 *v6; // rax
  int v7; // eax
  unsigned int v8; // ebx
  __int64 *v9; // rax
  int *v11; // [rsp+20h] [rbp-88h] BYREF
  int **v12; // [rsp+28h] [rbp-80h]
  _QWORD v13[3]; // [rsp+30h] [rbp-78h] BYREF
  _QWORD Src[4]; // [rsp+48h] [rbp-60h] BYREF

  sub_14008DFE0();
  v2 = *((unsigned __int8 *)sub_140075FE0() + 450);
  Src[0] = L"IDC_CHK_SHELL_MENU_ENABLE_BANDIVIEW";
  Src[1] = L"IDC_CHK_SHELL_MENU_ENABLE_CONV";
  Src[2] = L"CHK_SHELL_MENU_WHEN_FOLDER";
  Src[3] = L"CHK_SHELL_MENU_WHEN_BKGND";
  v3 = (_BYTE **)sub_14005D1E0(32);
  v13[0] = v3;
  v4 = v3 + 4;
  v13[2] = v3 + 4;
  memcpy(v3, Src, 0x20u);
  v13[1] = v3 + 4;
  if ( v3 != v3 + 4 )
  {
    do
    {
      v5 = *v3;
      v12 = &v11;
      v6 = sub_1400601C0();
      if ( v6 == nullptr )
        sub_14005FF30(0x80004005);
      v11 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
      if ( (unsigned __int8)sub_14005F980(&v11, (__int64)v5) == 0 )
      {
        if ( v5 != nullptr )
          v7 = sub_1404ADC20(v5);
        else
          v7 = 0;
        sub_14005FCF0(&v11, v5, v7);
      }
      sub_1401C4F90(a1 + 728, &v11, v2);
      ++v3;
    }
    while ( v3 != v4 );
  }
  if ( (_BYTE)v2 == 0 )
    goto LABEL_15;
  if ( dword_14070CE60 > *(_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL) )
  {
    sub_140496500(&dword_14070CE60);
    if ( dword_14070CE60 == -1 )
    {
      sub_140076040();
      atexit(sub_140592850);
      Init_thread_footer(&dword_14070CE60);
    }
  }
  if ( byte_14070D034 != 0 )
    v8 = 1;
  else
LABEL_15:
    v8 = 0;
  v12 = &v11;
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    sub_14005FF30(0x80004005);
  v11 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
  if ( (unsigned __int8)sub_14005F980(&v11, (__int64)L"CHK_SHELL_MENU_CONV_SHIFT") == 0 )
    sub_14005FCF0(&v11, L"CHK_SHELL_MENU_CONV_SHIFT", 25);
  sub_1401C4F90(a1 + 728, &v11, v8);
  return sub_14008EEA0(v13);
}
