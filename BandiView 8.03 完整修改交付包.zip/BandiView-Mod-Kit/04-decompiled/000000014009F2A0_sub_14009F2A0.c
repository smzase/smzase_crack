// EA 0x14009f2a0  name sub_14009F2A0  size 728
_QWORD *__fastcall sub_14009F2A0(_QWORD *a1)
{
  _QWORD *v2; // rax
  __m128i *v3; // rax
  __m128i *v4; // xmm1_8
  __m128i v5; // xmm0
  __m128i *v6; // rbx
  unsigned __int64 v7; // rax
  _QWORD *v8; // rax
  __int128 *v9; // rdx
  __int64 v10; // rax
  const void *v11; // rdx
  char v13; // [rsp+30h] [rbp-D0h] BYREF
  __int16 v14; // [rsp+31h] [rbp-CFh]
  __int64 v15; // [rsp+38h] [rbp-C8h]
  __int64 v16; // [rsp+40h] [rbp-C0h]
  __int64 v17; // [rsp+48h] [rbp-B8h]
  void *v18[5]; // [rsp+50h] [rbp-B0h] BYREF
  void **v19; // [rsp+78h] [rbp-88h] BYREF
  HANDLE hObject; // [rsp+80h] [rbp-80h]
  void *Block; // [rsp+88h] [rbp-78h]
  void *v22; // [rsp+90h] [rbp-70h]
  void *v23; // [rsp+98h] [rbp-68h]
  __int64 v24; // [rsp+A0h] [rbp-60h]
  __int16 v25; // [rsp+A8h] [rbp-58h]
  int v26; // [rsp+ACh] [rbp-54h]
  __m128i v27; // [rsp+B0h] [rbp-50h] BYREF
  __m128i v28; // [rsp+C0h] [rbp-40h]
  __int128 v29; // [rsp+D0h] [rbp-30h] BYREF
  __int64 v30; // [rsp+E0h] [rbp-20h]
  unsigned __int64 v31; // [rsp+E8h] [rbp-18h]
  __int128 v32; // [rsp+F0h] [rbp-10h] BYREF
  __int64 v33; // [rsp+100h] [rbp+0h]
  __int64 v34; // [rsp+108h] [rbp+8h]
  __int128 v35; // [rsp+110h] [rbp+10h] BYREF
  __int64 v36; // [rsp+120h] [rbp+20h]
  __int64 v37; // [rsp+128h] [rbp+28h]
  char *v38[4]; // [rsp+130h] [rbp+30h] BYREF

  v18[3] = a1;
  v2 = (_QWORD *)sub_140069AD0((__int64)v38);
  v3 = (__m128i *)sub_14005ED20(v2, L"version.ini", 0xBu);
  v27 = *v3;
  v4 = (__m128i *)v27.m128i_i64[0];
  v28 = v3[1];
  v5 = v28;
  v3[1].m128i_i64[0] = 0;
  v3[1].m128i_i64[1] = 7;
  v3->m128i_i16[0] = 0;
  v6 = &v27;
  if ( _mm_srli_si128(v5, 8).m128i_u64[0] > 7 )
    v6 = v4;
  v29 = 0;
  v30 = 0;
  v31 = 0;
  v7 = sub_1404ADC20(v6);
  sub_140061270((char **)&v29, v6, v7);
  v18[1] = nullptr;
  v8 = operator new(0x48u);
  *v8 = v8;
  v8[1] = v8;
  v8[2] = v8;
  *((_WORD *)v8 + 12) = 257;
  v18[0] = v8;
  v14 = 0;
  v15 = 0;
  v16 = 0;
  v17 = 0;
  v13 = 0;
  sub_1401D0940(&v13);
  v19 = &XFileReadStream::`vftable';
  v26 = 0;
  Block = j__malloc_base(0x2000u);
  v23 = Block;
  v22 = Block;
  v24 = 0;
  hObject = (HANDLE)-1LL;
  v25 = 0;
  v9 = &v29;
  if ( v31 > 7 )
    v9 = (__int128 *)v29;
  if ( (unsigned __int8)sub_1401CC050(&v19, v9) != 0 )
    sub_1401D0B60(&v13, &v19);
  v19 = &XFileReadStream::`vftable';
  if ( HIBYTE(v25) != 0 && hObject != (HANDLE)-1LL )
  {
    CloseHandle(hObject);
    hObject = (HANDLE)-1LL;
  }
  j__free_base(Block);
  sub_14005D410((char **)&v29);
  sub_14005D410((char **)&v27);
  sub_14005D410(v38);
  v27 = 0;
  v28 = 0u;
  sub_140061270((char **)&v27, &Data, 0);
  v35 = 0;
  v36 = 0;
  v37 = 0;
  sub_140061270((char **)&v35, L"BuildNo", 7u);
  v32 = 0;
  v33 = 0;
  v34 = 0;
  sub_140061270((char **)&v32, L"Version", 7u);
  v10 = sub_1401D1BB0(&v13, &v19, &v32, &v35, &v27);
  v11 = (const void *)v10;
  *(_OWORD *)a1 = 0;
  a1[2] = 0;
  a1[3] = 7;
  *(_WORD *)a1 = 0;
  if ( a1 != (_QWORD *)v10 )
  {
    if ( *(_QWORD *)(v10 + 24) > 7u )
      v11 = *(const void **)v10;
    sub_140069540((void **)a1, v11, *(_QWORD *)(v10 + 16));
  }
  sub_14005D410((char **)&v19);
  sub_14005D410((char **)&v32);
  sub_14005D410((char **)&v35);
  sub_14005D410((char **)&v27);
  sub_1401D0940(&v13);
  sub_1401067C0(v18, v18, *((_QWORD *)v18[0] + 1));
  j_j_j__free_base(v18[0]);
  return a1;
}
