// EA 0x1400a1530  name sub_1400A1530  size 332
_BOOL8 __fastcall sub_1400A1530(int a1, _QWORD *a2)
{
  __int64 *v4; // rax
  const wchar_t *v5; // r8
  int *v6; // rdx
  bool v7; // di
  volatile signed __int32 *v8; // rdx
  _QWORD v10[2]; // [rsp+20h] [rbp-38h] BYREF
  int **v11; // [rsp+30h] [rbp-28h]
  int *v12; // [rsp+70h] [rbp+18h] BYREF
  __int64 v13; // [rsp+78h] [rbp+20h] BYREF

  v10[1] = &v13;
  v13 = sub_14005F710((volatile signed __int32 *)(*a2 - 24LL)) + 24;
  v11 = &v12;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v12 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( (unsigned __int8)sub_14005F980(&v12, (__int64)L"HKLM\\SOFTWARE\\$app$\\Edition") == 0 )
    sub_14005FCF0(&v12, L"HKLM\\SOFTWARE\\$app$\\Edition", 27);
  v11 = &v12;
  switch ( a1 )
  {
    case 1:
      v5 = L"BandiView";
      break;
    case 2:
      v5 = L"Bandizip";
      break;
    case 3:
      v5 = L"Honeycam";
      break;
    default:
      goto LABEL_11;
  }
  sub_140060D20((unsigned __int64 *)&v12, (__int64)L"$app$", v5);
LABEL_11:
  v10[0] = sub_14005F710(v12 - 6) + 24;
  v6 = v12 - 6;
  if ( _InterlockedExchangeAdd(v12 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v6 + 8LL))(*(_QWORD *)v6);
  v7 = (unsigned int)sub_1400836D0(v10, &v13) != 0;
  v8 = (volatile signed __int32 *)(*a2 - 24LL);
  if ( _InterlockedExchangeAdd(v8 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v8 + 8LL))(*(_QWORD *)v8);
  return v7;
}
