// EA 0x1400c2cf0  name sub_1400C2CF0  size 740
__int64 __fastcall sub_1400C2CF0(__int64 a1, __m128i *a2)
{
  __m128i *v4; // rbx
  __int64 *v5; // rax
  int v6; // eax
  int v7; // eax
  __int64 v8; // rax
  __int64 v9; // rbx
  int v10; // ebp
  unsigned __int64 v11; // r8
  __m128i *v12; // rdx
  const __m128i *v13; // rcx
  const __m128i *v14; // rcx
  __int64 v15; // rax
  __int64 v16; // rdi
  __int64 *v17; // rax
  int *v19; // [rsp+30h] [rbp-68h] BYREF
  int *v20[3]; // [rsp+38h] [rbp-60h] BYREF
  __int128 v21; // [rsp+50h] [rbp-48h] BYREF
  __int64 v22; // [rsp+60h] [rbp-38h]
  unsigned __int64 v23; // [rsp+68h] [rbp-30h]

  v20[2] = (int *)a2;
  v20[0] = (int *)&v19;
  v4 = a2;
  if ( a2[1].m128i_i64[1] > 7uLL )
    v4 = (__m128i *)a2->m128i_i64[0];
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  v19 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
  if ( (unsigned __int8)sub_14005F980(&v19, (__int64)v4) == 0 )
  {
    if ( v4 != nullptr )
      v6 = sub_1404ADC20(v4);
    else
      v6 = 0;
    sub_14005FCF0(&v19, v4, v6);
  }
  v7 = sub_1401BE5D0(a1 + 728, &v19);
  v8 = sub_1404A362C(
         v7,
         0,
         (unsigned int)&AControlBase `RTTI Type Descriptor',
         (unsigned int)&BvComboBox `RTTI Type Descriptor',
         0);
  v9 = v8;
  if ( v8 != 0 )
  {
    v21 = 0;
    v22 = 0;
    v23 = 0;
    v10 = *(_DWORD *)(v8 + 1076);
    v11 = 13;
    if ( a2[1].m128i_i64[0] < 0xDuLL )
      v11 = a2[1].m128i_u64[0];
    if ( a2[1].m128i_i64[1] <= 7uLL )
      v12 = a2;
    else
      v12 = (__m128i *)a2->m128i_i64[0];
    sub_140061270((char **)&v21, v12, v11);
    v13 = (const __m128i *)&v21;
    if ( v23 > 7 )
      v13 = (const __m128i *)v21;
    if ( v22 != 13 || (unsigned int)sub_140074220(v13, (const __m128i *)L"IDC_CB_CUSTOM", 0xDu) != 0 )
    {
      if ( a2[1].m128i_i64[1] <= 7uLL )
        v14 = a2;
      else
        v14 = (const __m128i *)a2->m128i_i64[0];
      if ( a2[1].m128i_i64[0] != 11 || (unsigned int)sub_140074220(v14, (const __m128i *)L"IDC_CB_LANG", 0xBu) != 0 )
      {
        sub_1400BFAD0(v9);
      }
      else
      {
        *(_BYTE *)(v9 + 1084) = 1;
        *(_DWORD *)(v9 + 1080) = 30;
        sub_140124F70(v9);
      }
    }
    else
    {
      *(_DWORD *)(v9 + 1080) = 20;
      sub_140124F70(v9);
    }
    v15 = *(_QWORD *)(a1 + 648);
    if ( v10 == *(_DWORD *)(v9 + 1076) )
    {
      if ( v9 == v15 || v9 == *(_QWORD *)(a1 + 672) )
      {
        v16 = *(_QWORD *)v9;
        v20[1] = (int *)v20;
        v17 = sub_1400601C0();
        if ( v17 == nullptr )
          sub_14005FF30(0x80004005);
        v20[0] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v17 + 24))(v17) + 24);
        if ( (unsigned __int8)sub_14005F980(v20, (__int64)&Data) == 0 )
          sub_14005FCF0(v20, &Data, 0);
        (*(void (__fastcall **)(__int64, int **))(v16 + 40))(v9, v20);
      }
    }
    else if ( v9 == v15 )
    {
      sub_1400B2E00(a1, 1);
    }
    else if ( v9 == *(_QWORD *)(a1 + 656) )
    {
      sub_1400BBEA0(a1);
      sub_1400BCA00(a1);
      PostMessageW(*(HWND *)(a1 + 616), 0x111u, 0x806Au, 0);
    }
    else if ( v9 == *(_QWORD *)(a1 + 672) )
    {
      sub_1400BF2F0(a1, 1);
    }
    else if ( v9 == *(_QWORD *)(a1 + 680) )
    {
      sub_1400B71B0(a1);
    }
    sub_14005D410((char **)&v21);
  }
  return sub_14005D410((char **)a2);
}
