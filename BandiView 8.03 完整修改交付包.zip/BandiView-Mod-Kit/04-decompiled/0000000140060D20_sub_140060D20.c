// EA 0x140060d20  name sub_140060D20  size 736
__int64 __fastcall sub_140060D20(unsigned __int64 *a1, __int64 a2, const void *a3)
{
  int v6; // ebp
  int v7; // r14d
  unsigned __int64 v8; // rbx
  int v9; // r12d
  unsigned __int64 v10; // rsi
  __int64 v11; // rax
  __int64 v12; // rdi
  int v13; // eax
  unsigned __int64 *v14; // r9
  __int64 v15; // rsi
  int v16; // ebx
  int v17; // edx
  char *v18; // rdi
  __int64 v19; // rcx
  char *v20; // rbx
  size_t v21; // r14
  int v22; // esi
  char *v23; // rdx
  int v24; // eax
  __int64 v26; // rcx
  int v27; // [rsp+20h] [rbp-58h]
  char *v28; // [rsp+28h] [rbp-50h]
  unsigned __int64 v29; // [rsp+30h] [rbp-48h]
  int v31; // [rsp+88h] [rbp+10h]
  int v32; // [rsp+98h] [rbp+20h]

  if ( a2 == 0 )
    return 0;
  v6 = sub_1404ADC20(a2);
  if ( v6 == 0 )
    return 0;
  if ( a3 != nullptr )
  {
    v7 = sub_1404ADC20(a3);
    v27 = v7;
  }
  else
  {
    v7 = 0;
    v27 = 0;
  }
  v8 = *a1;
  v9 = 0;
  v10 = v8 + 2LL * *(int *)(v8 - 16);
  if ( v8 < v10 )
  {
    do
    {
      v11 = sub_1404A27AC(v8, a2);
      if ( v11 != 0 )
      {
        v12 = 2LL * v6;
        do
        {
          v8 = v12 + v11;
          ++v9;
          v11 = sub_1404A27AC(v12 + v11, a2);
        }
        while ( v11 != 0 );
      }
      if ( v8 != 0 )
        v13 = sub_1404ADC20(v8);
      else
        v13 = 0;
      v8 += 2LL * (v13 + 1);
    }
    while ( v8 < v10 );
    if ( v9 > 0 )
    {
      v14 = a1;
      v15 = *(int *)(*a1 - 16);
      v16 = v15 + v9 * (v7 - v6);
      v31 = *(_DWORD *)(*a1 - 16);
      v32 = v16;
      v17 = v31;
      if ( v16 > (int)v15 )
        v17 = v15 + v9 * (v7 - v6);
      if ( v17 < 0 )
        goto LABEL_44;
      if ( ((*(_DWORD *)(*a1 - 12) - v17) | (1 - *(_DWORD *)(*a1 - 8))) < 0 )
      {
        sub_14005FC80(a1, v17);
        v14 = a1;
      }
      v28 = (char *)*v14;
      v18 = (char *)*v14;
      v29 = *v14 + 2 * v15;
      if ( *v14 < v29 )
      {
        while ( 1 )
        {
          v20 = (char *)sub_1404A27AC(v18, a2);
          if ( v20 == nullptr )
            goto LABEL_32;
          v21 = 2LL * v7;
          do
          {
            v18 = &v20[v21];
            v22 = v15 - ((v20 - v28) >> 1) - v6;
            if ( 2LL * v22 != 0 )
            {
              if ( v18 == nullptr || (v23 = &v20[2 * v6]) == nullptr )
              {
                *(_DWORD *)sub_1404A7740(v19) = 22;
                invalid_parameter_noinfo();
                goto LABEL_44;
              }
              memcpy(v18, v23, 2LL * v22);
            }
            if ( v21 != 0 )
            {
              if ( a3 == nullptr )
              {
                memset(v20, 0, v21);
                *(_DWORD *)sub_1404A7740(v26) = 22;
                invalid_parameter_noinfo();
                sub_14005FF30(0x80070057);
              }
              memcpy(v20, a3, v21);
            }
            *(_WORD *)&v20[2 * v22 + 2 * v27] = 0;
            LODWORD(v15) = v27 - v6 + v31;
            v31 = v15;
            v20 = (char *)sub_1404A27AC(&v20[v21], a2);
          }
          while ( v20 != nullptr );
          v7 = v27;
LABEL_32:
          if ( v18 != nullptr )
            v24 = sub_1404ADC20(v18);
          else
            v24 = 0;
          v18 += 2 * v24 + 2;
          if ( (unsigned __int64)v18 >= v29 )
          {
            v16 = v32;
            v14 = a1;
            break;
          }
        }
      }
      if ( v16 < 0 || v16 > *(_DWORD *)(*v14 - 12) )
LABEL_44:
        sub_14005FF30(0x80070057);
      *(_DWORD *)(*v14 - 16) = v16;
      *(_WORD *)(*v14 + 2LL * v16) = 0;
    }
  }
  return (unsigned int)v9;
}
