// EA 0x1404d8590  name sub_1404D8590  size 54
__int64 __fastcall sub_1404D8590(char *a1, char *a2)
{
  int v3; // ecx
  unsigned int v4; // eax
  signed __int64 v5; // r8

  v3 = *(unsigned __int16 *)a2;
  v4 = *(unsigned __int16 *)a1 - v3;
  if ( v4 == 0 )
  {
    v5 = a1 - a2;
    do
    {
      if ( (_WORD)v3 == 0 )
        break;
      v3 = *((unsigned __int16 *)a2 + 1);
      a2 += 2;
      v4 = *(unsigned __int16 *)&a2[v5] - v3;
    }
    while ( v4 == 0 );
  }
  return ((int)v4 > 0) - (v4 >> 31);
}
