// EA 0x140495ec0  name sub_140495EC0  size 157
void __fastcall sub_140495EC0(__int64 a1, __int64 a2, __int64 a3)
{
  char *v3; // rbx
  HANDLE CurrentProcess; // rax
  void (__fastcall *v8)(_QWORD, __int64, __int64); // rax

  if ( a1 != 0 )
  {
    v3 = *(char **)(a1 + 8);
    if ( v3 != nullptr )
    {
      if ( *(_DWORD *)a1 != 0 )
      {
        *(_WORD *)v3 = -18104;
        *(_QWORD *)(v3 + 2) = a3;
        *((_WORD *)v3 + 5) = -18360;
        *(_QWORD *)(v3 + 12) = a2;
        *((_WORD *)v3 + 10) = -7937;
        CurrentProcess = GetCurrentProcess();
        FlushInstructionCache(CurrentProcess, v3, 0x16u);
      }
      else
      {
        v8 = (void (__fastcall *)(_QWORD, __int64, __int64))sub_140495B38(&qword_1407065B0);
        if ( v8 != nullptr )
          v8(*(_QWORD *)(a1 + 8), a2, a3);
      }
    }
  }
}
