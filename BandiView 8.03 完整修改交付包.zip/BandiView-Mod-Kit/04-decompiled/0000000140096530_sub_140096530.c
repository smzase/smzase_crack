// EA 0x140096530  name sub_140096530  size 967
_QWORD *__fastcall sub_140096530(_QWORD *a1, _QWORD *a2)
{
  __int64 v4; // rax
  __int64 v5; // rbx
  __int128 v6; // xmm6
  __int64 *v7; // rax
  __int64 v8; // rcx
  _QWORD *v9; // r14
  __int64 *v10; // rax
  _QWORD *v11; // rbx
  __int64 v12; // rcx
  __int64 *v13; // rax
  int *v14; // rdx
  __int64 *v15; // rax
  _QWORD *v16; // rdx
  _QWORD *v17; // rdx
  _QWORD *v18; // rdx
  _QWORD *v19; // rdx
  volatile signed __int32 *v20; // rdx
  int **v22; // [rsp+50h] [rbp-39h] BYREF
  __int64 v23; // [rsp+58h] [rbp-31h] BYREF
  __int64 v24; // [rsp+60h] [rbp-29h] BYREF
  __int64 v25; // [rsp+68h] [rbp-21h] BYREF
  __int64 v26; // [rsp+70h] [rbp-19h] BYREF
  __int128 v27; // [rsp+80h] [rbp-9h] BYREF
  int **v28; // [rsp+90h] [rbp+7h]
  LPCWSTR *v29; // [rsp+98h] [rbp+Fh]
  int ***v30; // [rsp+A0h] [rbp+17h]
  int *v31; // [rsp+F0h] [rbp+67h] BYREF
  _QWORD *v32; // [rsp+F8h] [rbp+6Fh]
  int **v33; // [rsp+100h] [rbp+77h] BYREF
  int **v34; // [rsp+108h] [rbp+7Fh] BYREF

  v32 = a2;
  *a1 = 0;
  v4 = sub_1400A1680();
  sub_1400A2270(v4);
  v5 = sub_1400A1680();
  v6 = *(_OWORD *)(sub_1400A1680() + 48);
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  v26 = (*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24;
  v34 = (int **)&v33;
  sub_14007D5E0();
  v9 = sub_14007DE80(v8, &v33);
  v22 = &v31;
  v10 = sub_1400601C0();
  if ( v10 == nullptr )
    sub_14005FF30(0x80004005);
  v11 = (_QWORD *)(v5 + 8);
  v31 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24);
  if ( (unsigned __int8)sub_14005F980(&v31, (__int64)L"BandiView") == 0 )
    sub_14005FCF0(&v31, L"BandiView", 9);
  sub_1400C9530(&v25, &v31, v9);
  sub_14007E660(&v24);
  sub_14007D5E0();
  sub_14007DE80(v12, &v23);
  if ( *(_DWORD *)(*v11 - 16LL) != 0 )
  {
    v28 = &v31;
    v31 = (int *)(sub_14005F710((volatile signed __int32 *)(v23 - 24)) + 24);
    v29 = (LPCWSTR *)&v33;
    v33 = (int **)(sub_14005F710((volatile signed __int32 *)(v24 - 24)) + 24);
    v30 = &v34;
    v34 = (int **)(sub_14005F710((volatile signed __int32 *)(v25 - 24)) + 24);
    v22 = (int **)(sub_14005F710((volatile signed __int32 *)(*a2 - 24LL)) + 24);
    v27 = v6;
    sub_1400CADE0(
      1,
      (unsigned int)&v22,
      (unsigned int)&v34,
      (unsigned int)&v33,
      (__int64)&v31,
      (__int64)v11,
      (__int64)&v27,
      1,
      (__int64)&v26,
      (__int64)a1);
  }
  v34 = &v31;
  v13 = sub_1400601C0();
  if ( v13 == nullptr )
    sub_14005FF30(0x80004005);
  v31 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24);
  if ( (unsigned __int8)sub_14005F980(&v31, (__int64)L"SOFTWARE\\$app$\\l") == 0 )
    sub_14005FCF0(&v31, L"SOFTWARE\\$app$\\l", 16);
  v34 = &v31;
  sub_140060D20((unsigned __int64 *)&v31, (__int64)L"$app$", L"BandiView");
  v33 = (int **)(sub_14005F710(v31 - 6) + 24);
  v14 = v31 - 6;
  if ( _InterlockedExchangeAdd(v31 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v14 + 8LL))(*(_QWORD *)v14);
  sub_140082710(HKEY_LOCAL_MACHINE, (LPCWSTR *)&v33);
  v33 = &v31;
  v15 = sub_1400601C0();
  if ( v15 == nullptr )
    sub_14005FF30(0x80004005);
  v31 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
  if ( (unsigned __int8)sub_14005F980(&v31, (__int64)L"TRI") == 0 )
    sub_14005FCF0(&v31, L"TRI", 3);
  sub_1400A1530(1, &v31);
  PostMessageW(HWND_BROADCAST, dword_140709AB4, 0, 0);
  v16 = (_QWORD *)(v23 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v23 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v16 + 8LL))(*v16);
  v17 = (_QWORD *)(v24 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v24 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v17 + 8LL))(*v17);
  v18 = (_QWORD *)(v25 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v25 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v18 + 8LL))(*v18);
  v19 = (_QWORD *)(v26 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v26 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v19 + 8LL))(*v19);
  v20 = (volatile signed __int32 *)(*a2 - 24LL);
  if ( _InterlockedExchangeAdd(v20 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v20 + 8LL))(*(_QWORD *)v20);
  return a1;
}
