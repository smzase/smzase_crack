// EA 0x14008e580  name sub_14008E580  size 1214
__int64 __fastcall sub_14008E580(__int64 a1, int *a2)
{
  __int64 *v4; // rax
  int *v5; // rbx
  unsigned int v6; // edi
  __int64 v7; // rsi
  wchar_t *v8; // rdx
  wchar_t *v9; // rbx
  int v10; // eax
  volatile signed __int32 *v11; // rdi
  signed __int32 v12; // eax
  bool v13; // cc
  __int64 result; // rax
  volatile signed __int32 *v15; // rdx
  _QWORD *v16; // rax
  _QWORD *v17; // rax
  _QWORD *v18; // rax
  HKEY v19; // rcx
  HKEY v20; // rdx
  __int128 *v21; // rsi
  __int64 *v22; // rax
  __int64 v23; // rcx
  int v24; // eax
  HKEY hKey; // [rsp+50h] [rbp-89h] BYREF
  DWORD dwDisposition[2]; // [rsp+58h] [rbp-81h] BYREF
  DWORD cbData[2]; // [rsp+60h] [rbp-79h] BYREF
  void *p_hKey; // [rsp+68h] [rbp-71h]
  int *v29[4]; // [rsp+70h] [rbp-69h] BYREF
  __int64 Data; // [rsp+90h] [rbp-49h] BYREF
  __int128 v31; // [rsp+98h] [rbp-41h] BYREF
  __int128 v32; // [rsp+A8h] [rbp-31h]
  __int128 Src; // [rsp+B8h] [rbp-21h] BYREF
  __int128 v34; // [rsp+C8h] [rbp-11h]
  char *v35[4]; // [rsp+D8h] [rbp-1h] BYREF

  v29[1] = a2;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v5 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  v29[0] = v5;
  v6 = 0;
  while ( 1 )
  {
    v7 = 3LL * v6;
    v8 = off_1406DC940[v7];
    if ( v8 == nullptr )
      sub_14005FF30(0x80004005);
    if ( (unsigned int)sub_1404D8590(*(_QWORD *)a2, v8) == 0 )
      break;
    if ( (int)++v6 >= 25 )
      goto LABEL_11;
  }
  v9 = off_1406DC940[v7 + 1];
  if ( v9 != nullptr )
    v10 = sub_1404ADC20(off_1406DC940[v7 + 1]);
  else
    v10 = 0;
  sub_14005FCF0(v29, v9, v10);
  v5 = v29[0];
LABEL_11:
  v11 = v5 - 6;
  if ( *(v5 - 4) != 0 )
  {
    v16 = (_QWORD *)sub_140069AD0((__int64)v35);
    v17 = sub_14005ED20(v16, L"shell\\", 6u);
    Src = 0;
    v34 = 0;
    Src = *(_OWORD *)v17;
    v34 = *((_OWORD *)v17 + 1);
    v17[2] = 0;
    v17[3] = 7;
    *(_WORD *)v17 = 0;
    v18 = sub_14005ED20(&Src, L"bvshell.x64.dll", 0xFu);
    v31 = 0;
    v32 = 0;
    v31 = *(_OWORD *)v18;
    v32 = *((_OWORD *)v18 + 1);
    v18[2] = 0;
    v18[3] = 7;
    *(_WORD *)v18 = 0;
    sub_14005D410((char **)&Src);
    sub_14005D410(v35);
    hKey = (HKEY)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)a2 - 24LL)) + 24);
    if ( (unsigned __int8)sub_1400ACB10(a1, &hKey) == 0 )
    {
      hKey = (HKEY)(sub_14005F710(v11) + 24);
      sub_1400AC190(&hKey);
LABEL_44:
      SHChangeNotify(0x8000000, 0, nullptr, nullptr);
      sub_14008DEB0(a1);
      sub_14005D410((char **)&v31);
      goto LABEL_12;
    }
    hKey = nullptr;
    if ( RegOpenKeyExW(
           HKEY_CURRENT_USER,
           L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced",
           0,
           0x20019u,
           &hKey) == 0 )
    {
      if ( hKey != nullptr )
        RegCloseKey(hKey);
      hKey = nullptr;
      if ( RegOpenKeyExW(
             HKEY_CURRENT_USER,
             L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced",
             0,
             0x2001Fu,
             &hKey) == 0 )
        goto LABEL_50;
      if ( hKey != nullptr )
        RegCloseKey(hKey);
      hKey = nullptr;
      if ( RegCreateKeyExW(
             HKEY_CURRENT_USER,
             L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced",
             0,
             nullptr,
             0,
             0x2001Fu,
             nullptr,
             &hKey,
             dwDisposition) == 0 )
      {
LABEL_50:
        LODWORD(Data) = 0;
        cbData[0] = 4;
        dwDisposition[0] = 4;
        if ( RegQueryValueExW(hKey, L"IconsOnly", nullptr, dwDisposition, (LPBYTE)&Data, cbData) == 0 )
        {
          v19 = hKey;
          if ( (_DWORD)Data == 0 )
          {
LABEL_30:
            if ( v19 != nullptr )
              RegCloseKey(v19);
            v29[2] = (int *)cbData;
            *(_QWORD *)cbData = sub_14005F710(v11) + 24;
            v29[3] = (int *)&Data;
            hKey = (HKEY)(sub_14005F710(v11) + 24);
            p_hKey = &hKey;
            sub_1400609A0(&Data, L"BandiView.Thumbnail", (const void **)&hKey);
            v20 = hKey - 6;
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)hKey - 2, 0xFFFFFFFF) <= 1 )
              (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v20 + 8LL))(*(_QWORD *)v20);
            p_hKey = dwDisposition;
            v21 = &v31;
            if ( *((_QWORD *)&v32 + 1) > 7u )
              v21 = (__int128 *)v31;
            v22 = sub_1400601C0();
            if ( v22 == nullptr )
              sub_14005FF30(0x80004005);
            *(_QWORD *)dwDisposition = (*(__int64 (__fastcall **)(__int64 *))(*v22 + 24))(v22) + 24;
            if ( (unsigned __int8)sub_14005F980(dwDisposition, (__int64)v21) == 0 )
            {
              if ( v21 != nullptr )
                v24 = sub_1404ADC20(v21);
              else
                v24 = 0;
              sub_14005FCF0((int **)dwDisposition, v21, v24);
            }
            sub_1400AB880(v23, dwDisposition, &Data, cbData);
            goto LABEL_44;
          }
          dwDisposition[0] = 0;
          if ( RegSetValueExW(hKey, L"IconsOnly", 0, 4u, (const BYTE *)dwDisposition, 4u) == 0 )
            SHChangeNotify(0x8000000, 0, nullptr, nullptr);
        }
      }
    }
    v19 = hKey;
    goto LABEL_30;
  }
LABEL_12:
  v12 = _InterlockedExchangeAdd(v11 + 4, 0xFFFFFFFF);
  v13 = v12 <= 1;
  result = (unsigned int)(v12 - 1);
  if ( v13 )
    result = (*(__int64 (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v11 + 8LL))(
               *(_QWORD *)v11,
               v11);
  v15 = (volatile signed __int32 *)(*(_QWORD *)a2 - 24LL);
  if ( _InterlockedExchangeAdd(v15 + 4, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v15 + 8LL))(*(_QWORD *)v15);
  return result;
}
