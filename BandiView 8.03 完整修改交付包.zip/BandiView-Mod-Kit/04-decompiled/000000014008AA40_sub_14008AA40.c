// EA 0x14008aa40  name sub_14008AA40  size 619
int **__fastcall sub_14008AA40(int **a1)
{
  __int64 *v2; // rax
  __int64 *v3; // rax
  __int64 *v4; // rax
  __int64 *v5; // rax
  __int64 *v6; // rax
  __int64 *v7; // rax
  __int64 *v8; // rax
  __int64 *v9; // rax
  __int64 *v10; // rax

  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  a1[1] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  a1[2] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  a1[3] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  a1[4] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  a1[5] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  a1[6] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24);
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    sub_14005FF30(0x80004005);
  a1[7] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
  v10 = sub_1400601C0();
  if ( v10 == nullptr )
    sub_14005FF30(0x80004005);
  a1[8] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24);
  sub_14005FCF0(a1, L"OK", 2);
  sub_14005FCF0(a1 + 1, L"Cancel", 6);
  sub_14005FCF0(a1 + 2, L"Abort", 5);
  sub_14005FCF0(a1 + 3, L"Retry", 5);
  sub_14005FCF0(a1 + 4, L"Ignore", 6);
  sub_14005FCF0(a1 + 5, L"Yes", 3);
  sub_14005FCF0(a1 + 6, L"No", 2);
  sub_14005FCF0(a1 + 7, L"Continue", 8);
  sub_14005FCF0(a1 + 8, L"Do not show this message again", 30);
  return a1;
}
