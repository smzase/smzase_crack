// EA 0x1401ca3c0  name sub_1401CA3C0  size 380
__int64 __fastcall sub_1401CA3C0(int *a1, _QWORD *a2, __int64 a3)
{
  char *v6; // rbx
  int v7; // eax
  __int64 v8; // rax
  __int64 v9; // rsi
  __int64 v10; // rdi
  char *v11; // rax
  unsigned __int8 v12; // di
  char *v14; // [rsp+20h] [rbp-58h]
  void **v15; // [rsp+38h] [rbp-40h] BYREF
  HANDLE hObject; // [rsp+40h] [rbp-38h]
  void *Block; // [rsp+48h] [rbp-30h]
  void *v18; // [rsp+50h] [rbp-28h]
  void *v19; // [rsp+58h] [rbp-20h]
  __int64 v20; // [rsp+60h] [rbp-18h]
  __int16 v21; // [rsp+68h] [rbp-10h]
  int v22; // [rsp+6Ch] [rbp-Ch]
  __int64 v23; // [rsp+C8h] [rbp+50h] BYREF

  v15 = &XFileReadStream::`vftable';
  v22 = 0;
  Block = j__malloc_base(0x2000u);
  v19 = Block;
  v18 = Block;
  v20 = 0;
  hObject = (HANDLE)-1LL;
  v21 = 0;
  v6 = nullptr;
  if ( a2[3] > 7u )
    a2 = (_QWORD *)*a2;
  if ( (unsigned __int8)sub_1401CC050(&v15, a2) != 0 )
  {
    v8 = ((__int64 (__fastcall *)(void ***))v15[4])(&v15);
    v9 = v8;
    v10 = v8 + 2;
    if ( v8 == -2 )
    {
      v6 = nullptr;
      v14 = nullptr;
      v10 = 0;
    }
    else
    {
      v11 = (char *)j__realloc_base(nullptr, v8 + 2);
      if ( v11 == nullptr )
      {
LABEL_12:
        v7 = -1160249342;
        goto LABEL_13;
      }
      v6 = v11;
      v14 = v11;
    }
    ((void (__fastcall *)(void ***, _QWORD))v15[2])(&v15, 0);
    v23 = 0;
    if ( ((unsigned __int8 (__fastcall *)(void ***, char *, __int64, __int64 *, char *))v15[1])(&v15, v6, v9, &v23, v14) != 0
      && v9 == v23 )
    {
      *(_WORD *)&v6[v10 - 2] = 0;
      v12 = sub_1401CA540(a1, v6, v9, a3);
      goto LABEL_14;
    }
    goto LABEL_12;
  }
  v7 = -1160249343;
LABEL_13:
  a1[1] = 0;
  *a1 = v7;
  v12 = 0;
LABEL_14:
  if ( v6 != nullptr )
    j__free_base(v6);
  v15 = &XFileReadStream::`vftable';
  if ( HIBYTE(v21) != 0 && hObject != (HANDLE)-1LL )
  {
    CloseHandle(hObject);
    hObject = (HANDLE)-1LL;
  }
  j__free_base(Block);
  return v12;
}
