// EA 0x1400ace70  name sub_1400ACE70  size 187
__int64 __fastcall sub_1400ACE70(__int64 a1, _QWORD *a2, unsigned __int8 a3)
{
  unsigned int v3; // esi
  int v6; // eax
  __int64 v7; // rax
  __int64 v8; // rbx
  volatile signed __int32 *v9; // rdx
  signed __int32 v10; // eax
  bool v11; // cc
  __int64 result; // rax
  __int64 v13; // [rsp+40h] [rbp+8h] BYREF
  _QWORD *v14; // [rsp+48h] [rbp+10h]

  v14 = a2;
  v3 = a3;
  v13 = sub_14005F710((volatile signed __int32 *)(*a2 - 24LL)) + 24;
  v6 = sub_1401BE5D0(a1 + 728, &v13);
  v7 = sub_1404A362C(
         v6,
         0,
         (unsigned int)&AControlBase `RTTI Type Descriptor',
         (unsigned int)&XCheckBox `RTTI Type Descriptor',
         0);
  v8 = v7;
  if ( v7 != 0 )
  {
    if ( *(_DWORD *)(*(_QWORD *)(v7 + 1048) - 16LL) != 0 )
      sub_1401F6750(v7);
    sub_1401D8460(v8, v3);
  }
  v9 = (volatile signed __int32 *)(*a2 - 24LL);
  v10 = _InterlockedExchangeAdd(v9 + 4, 0xFFFFFFFF);
  v11 = v10 <= 1;
  result = (unsigned int)(v10 - 1);
  if ( v11 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v9 + 8LL))(*(_QWORD *)v9);
  return result;
}
