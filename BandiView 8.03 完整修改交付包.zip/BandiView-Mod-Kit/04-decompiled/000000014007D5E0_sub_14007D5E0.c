// EA 0x14007d5e0  name sub_14007D5E0  size 95
int *sub_14007D5E0()
{
  if ( dword_14070D22C > *(_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL) )
  {
    sub_140496500(&dword_14070D22C);
    if ( dword_14070D22C == -1 )
    {
      sub_14007D8A0();
      atexit(sub_1405928D0);
      Init_thread_footer(&dword_14070D22C);
    }
  }
  return &dword_14070D230;
}
