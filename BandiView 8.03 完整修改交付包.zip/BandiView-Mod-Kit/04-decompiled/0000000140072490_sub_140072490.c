// EA 0x140072490  name sub_140072490  size 117
_QWORD *sub_140072490(_QWORD *a1, __int64 a2, ...)
{
  __int64 *v3; // rax
  va_list va; // [rsp+50h] [rbp+18h] BYREF

  va_start(va, a2);
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  *a1 = (*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24;
  sub_14005EB80(a1, a2, (__int64 *)va);
  return a1;
}
