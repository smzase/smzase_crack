// EA 0x14005df70  name sub_14005DF70  size 2002
__int64 __fastcall sub_14005DF70(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // r8
  __int64 v9; // rcx
  __int64 v10; // r14
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rbx
  __int64 v14; // rcx
  __int64 v15; // r8
  _QWORD *v16; // rdx
  __int64 v17; // rax
  __int64 v18; // rdx
  __int64 v19; // rcx
  __int64 v20; // r8
  __int64 v21; // rax
  __int64 v22; // rdx
  __int64 v23; // rcx
  __int64 v24; // r8
  __int64 v25; // rax
  unsigned int v26; // r14d
  __int64 v27; // rax
  __int64 v28; // rdx
  __int64 v29; // rcx
  __int64 v30; // r8
  __int64 v31; // rax
  __int64 v32; // rdx
  __int64 v33; // rcx
  __int64 v34; // r8
  __int64 v35; // rax
  LPCWSTR v36; // rdx
  _QWORD *v37; // rdx
  _QWORD *v38; // rdx
  _QWORD *v39; // rdx
  volatile signed __int32 *v40; // rdx
  volatile signed __int32 *v41; // rdx
  __int64 v43; // rax
  _QWORD *v44; // rdx
  _QWORD *v45; // rdx
  _QWORD *v46; // rdx
  _QWORD *v47; // rdx
  volatile signed __int32 *v48; // rdx
  volatile signed __int32 *v49; // rdx
  __int64 v50; // [rsp+40h] [rbp-C0h] BYREF
  __int64 *v51; // [rsp+48h] [rbp-B8h] BYREF
  LPCWSTR *v52; // [rsp+50h] [rbp-B0h]
  LPCWSTR *p_lpText; // [rsp+58h] [rbp-A8h]
  _QWORD *v54; // [rsp+60h] [rbp-A0h]
  _QWORD *v55; // [rsp+68h] [rbp-98h]
  __int64 *v56; // [rsp+70h] [rbp-90h]
  LPCWSTR lpText; // [rsp+78h] [rbp-88h] BYREF
  __int64 v58; // [rsp+80h] [rbp-80h] BYREF
  _BYTE v59[72]; // [rsp+90h] [rbp-70h] BYREF
  __int64 v60; // [rsp+D8h] [rbp-28h]
  __int64 v61; // [rsp+E0h] [rbp-20h]
  int v62; // [rsp+ECh] [rbp-14h]
  int v63; // [rsp+F0h] [rbp-10h]
  __int64 v64; // [rsp+110h] [rbp+10h]

  v54 = a2;
  v55 = a3;
  sub_14005D490((__int64)v59, (__int64)a2, (__int64)a3);
  v63 = 1;
  v62 = 1;
  if ( *(_BYTE *)(a1 + 2088) != 0 )
  {
    v9 = *(_QWORD *)(a1 + 2064);
    if ( v9 != 0 )
    {
      v10 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v9 + 72LL))(v9);
    }
    else
    {
      v10 = *(_QWORD *)(a1 + 2072);
      if ( v10 != 0 )
        v10 = *(_QWORD *)(v10 + 8);
    }
    v51 = &v50;
    v11 = sub_1400601C0(v9, v6, v8);
    if ( v11 == 0 )
      sub_14005FF30(2147500037LL);
    v50 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v11 + 24LL))(v11) + 24;
    if ( (unsigned __int8)sub_14005F980(&v50, L"WINDOW_AD1") == 0 )
      sub_14005FCF0(&v50, L"WINDOW_AD1", 10);
  }
  else
  {
    if ( a1 == -2096 )
      v10 = 0;
    else
      v10 = *(_QWORD *)(a1 + 2104);
    v51 = &v50;
    v12 = sub_1400601C0(v7, v6, v8);
    if ( v12 == 0 )
      sub_14005FF30(2147500037LL);
    v50 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v12 + 24LL))(v12) + 24;
    if ( (unsigned __int8)sub_14005F980(&v50, L"WINDOW_AD1") == 0 )
      sub_14005FCF0(&v50, L"WINDOW_AD1", 10);
  }
  v51 = &v50;
  v13 = *(_QWORD *)(a1 + 1328);
  lpText = (LPCWSTR)(sub_14005F710(v50 - 24) + 24);
  sub_1401D3520(v13, &lpText, v10);
  v16 = (_QWORD *)(v50 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v50 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v16 + 8LL))(*v16);
  v51 = &v50;
  v17 = sub_1400601C0(v14, v16, v15);
  if ( v17 == 0 )
    sub_14005FF30(2147500037LL);
  v50 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v17 + 24LL))(v17) + 24;
  if ( (unsigned __int8)sub_14005F980(&v50, L"BTN_CLOSE") == 0 )
    sub_14005FCF0(&v50, L"BTN_CLOSE", 9);
  sub_1401BDF90(a1 + 88, &v50, 65000);
  v51 = &v50;
  v21 = sub_1400601C0(v19, v18, v20);
  if ( v21 == 0 )
    sub_14005FF30(2147500037LL);
  v50 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v21 + 24LL))(v21) + 24;
  if ( (unsigned __int8)sub_14005F980(&v50, L"BTN_HELP") == 0 )
    sub_14005FCF0(&v50, L"BTN_HELP", 8);
  sub_1401BDF90(a1 + 88, &v50, 65001);
  v56 = &v50;
  v25 = sub_1400601C0(v23, v22, v24);
  if ( v25 == 0 )
    sub_14005FF30(2147500037LL);
  v50 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v25 + 24LL))(v25) + 24;
  if ( (unsigned __int8)sub_14005F980(&v50, &Data) == 0 )
    sub_14005FCF0(&v50, &Data, 0);
  p_lpText = &lpText;
  lpText = (LPCWSTR)(sub_14005F710(*a3 - 24LL) + 24);
  v51 = (__int64 *)(sub_14005F710(*a2 - 24LL) + 24);
  v26 = sub_1401C0B50((int)a1 + 88, (__int64)&lpText, (__int64)&v50, (__int64)v59);
  sub_1401BAA20(a1 + 88);
  v27 = sub_140075FE0();
  if ( (unsigned int)sub_1404A6F80(*(_QWORD *)(v27 + 544), L"Korean") == 0 )
  {
    v52 = (LPCWSTR *)&v50;
    v31 = sub_1400601C0(v29, v28, v30);
    if ( v31 == 0 )
      sub_14005FF30(2147500037LL);
    v50 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v31 + 24LL))(v31) + 24;
    if ( (unsigned __int8)sub_14005F980(&v50, &unk_1405E6020) == 0 )
      sub_14005FCF0(&v50, &unk_1405E6020, 17);
    p_lpText = &lpText;
    v35 = sub_1400601C0(v33, v32, v34);
    if ( v35 == 0 )
      sub_14005FF30(2147500037LL);
    lpText = (LPCWSTR)((*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v35 + 24LL))(v35) + 24);
    if ( (unsigned __int8)sub_14005F980(&lpText, L"STATIC_TITLE") == 0 )
      sub_14005FCF0(&lpText, L"STATIC_TITLE", 12);
    sub_1401C5020(a1 + 88, &lpText, &v50);
  }
  if ( v26 != 0 )
  {
    v58 = 0;
    v52 = &lpText;
    v43 = sub_1400601C0(v29, v28, v30);
    if ( v43 == 0 )
      sub_14005FF30(2147500037LL);
    lpText = (LPCWSTR)((*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v43 + 24LL))(v43) + 24);
    if ( (unsigned __int8)sub_14005F980(&lpText, L"popup") == 0 )
      sub_14005FCF0(&lpText, L"popup", 5);
    sub_1400605C0(&v58, &lpText);
    if ( *(_BYTE *)(a1 + 2088) != 0 )
    {
      v51 = (__int64 *)(sub_14005F710(v58 - 24) + 24);
      sub_14006BD70(a1 + 2048, &v51);
    }
    else
    {
      sub_14006CFF0(a1 + 2096, v58);
    }
    v44 = (_QWORD *)(v58 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v58 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v44 + 8LL))(*v44);
    v45 = (_QWORD *)(v64 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v64 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v45 + 8LL))(*v45);
    v46 = (_QWORD *)(v61 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v61 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v46 + 8LL))(*v46);
    v47 = (_QWORD *)(v60 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v60 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v47 + 8LL))(*v47);
    v48 = (volatile signed __int32 *)(*a2 - 24LL);
    if ( _InterlockedExchangeAdd(v48 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v48 + 8LL))(*(_QWORD *)v48);
    v49 = (volatile signed __int32 *)(*a3 - 24LL);
    if ( _InterlockedExchangeAdd(v49 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v49 + 8LL))(*(_QWORD *)v49);
    return v26;
  }
  else
  {
    lpText = nullptr;
    sub_1401BA850(a1 + 88, &lpText);
    MessageBoxW(*(HWND *)(a1 + 8), lpText, &Data, 0);
    PostMessageW(*(HWND *)(a1 + 8), 0x10u, 0, 0);
    v36 = lpText - 12;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)lpText - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v36 + 8LL))(*(_QWORD *)v36);
    v37 = (_QWORD *)(v64 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v64 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v37 + 8LL))(*v37);
    v38 = (_QWORD *)(v61 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v61 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v38 + 8LL))(*v38);
    v39 = (_QWORD *)(v60 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v60 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v39 + 8LL))(*v39);
    v40 = (volatile signed __int32 *)(*a2 - 24LL);
    if ( _InterlockedExchangeAdd(v40 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v40 + 8LL))(*(_QWORD *)v40);
    v41 = (volatile signed __int32 *)(*a3 - 24LL);
    if ( _InterlockedExchangeAdd(v41 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v41 + 8LL))(*(_QWORD *)v41);
    return 0;
  }
}
