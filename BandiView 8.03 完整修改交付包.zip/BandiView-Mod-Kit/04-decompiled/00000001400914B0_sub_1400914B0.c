// EA 0x1400914b0  name sub_1400914B0  size 391
__int64 __fastcall sub_1400914B0(__int64 a1, int a2)
{
  int i; // ebp
  __int64 *v4; // rax
  __int64 *v5; // rax
  BOOL v6; // edi
  __int64 v7; // rbx
  BOOL v8; // edi
  __int64 v9; // r14
  __int64 result; // rax
  __int64 v11[7]; // [rsp+20h] [rbp-38h] BYREF
  __int64 v12; // [rsp+60h] [rbp+8h] BYREF
  __int64 v13; // [rsp+70h] [rbp+18h] BYREF
  __int64 v14; // [rsp+78h] [rbp+20h] BYREF

  *(_DWORD *)(a1 + 72) = a2;
  for ( i = 0; i < 11; ++i )
  {
    v4 = sub_1400601C0();
    if ( v4 == nullptr )
      sub_14005FF30(0x80004005);
    v12 = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24;
    v5 = sub_1400601C0();
    if ( v5 == nullptr )
      sub_14005FF30(0x80004005);
    v14 = (*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24;
    sub_14005EB50((__int64)&v12, (__int64)L"BTN_TAB_%d", (unsigned int)i);
    sub_14005EB50((__int64)&v14, (__int64)L"TAB_SETTGING_%d", (unsigned int)i);
    v6 = i == *(_DWORD *)(a1 + 72);
    v7 = v12;
    v13 = sub_14005F710((volatile signed __int32 *)(v12 - 24)) + 24;
    sub_1401C5270(a1 + 728, &v13, v6);
    v8 = i == *(_DWORD *)(a1 + 72);
    v9 = v14;
    v11[0] = sub_14005F710((volatile signed __int32 *)(v14 - 24)) + 24;
    sub_1401C4E90(a1 + 728, v11, v8);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v9 - 8), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD, __int64))(**(_QWORD **)(v9 - 24) + 8LL))(*(_QWORD *)(v9 - 24), v9 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v7 - 8), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD, __int64))(**(_QWORD **)(v7 - 24) + 8LL))(*(_QWORD *)(v7 - 24), v7 - 24);
  }
  result = *(unsigned int *)(a1 + 72);
  if ( (_DWORD)result == 10 )
    return sub_1400B5960(a1);
  if ( (_DWORD)result == 5 )
    return UnDecorator::getZName(a1);
  return result;
}
