// EA 0x14007cfa0  name sub_14007CFA0  size 125
__int64 sub_14007CFA0()
{
  __int64 *v0; // rax
  __int64 v1; // rax
  int *v3; // [rsp+38h] [rbp+10h] BYREF
  int **v4; // [rsp+40h] [rbp+18h]

  v4 = &v3;
  v0 = sub_1400601C0();
  if ( v0 == nullptr )
    sub_14005FF30(0x80004005);
  v3 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v0 + 24))(v0) + 24);
  if ( (unsigned __int8)sub_14005F980(&v3, (__int64)&Data) == 0 )
    sub_14005FCF0(&v3, &Data, 0);
  v1 = sub_14007D020(&v3);
  return (*(__int64 (__fastcall **)(_QWORD, __int64))(**(_QWORD **)(v1 + 16) + 104LL))(*(_QWORD *)(v1 + 16), 1);
}
