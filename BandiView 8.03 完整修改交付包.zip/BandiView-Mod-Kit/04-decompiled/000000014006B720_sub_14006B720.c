// EA 0x14006b720  name sub_14006B720  size 85
int sub_14006B720(wchar_t *Buffer, wchar_t *Format, ...)
{
  _QWORD *v4; // rax
  va_list va; // [rsp+60h] [rbp+18h] BYREF

  va_start(va, Format);
  v4 = (_QWORD *)sub_14006B710();
  return _stdio_common_vswscanf(*v4 | 1LL, Buffer, 0xFFFFFFFFFFFFFFFFuLL, Format, nullptr, va);
}
