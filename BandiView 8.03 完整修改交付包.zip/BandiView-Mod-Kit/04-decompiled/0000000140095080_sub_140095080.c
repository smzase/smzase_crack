// EA 0x140095080  name sub_140095080  size 1668
char __fastcall sub_140095080(HWND hWnd, _QWORD *a2, _QWORD *a3)
{
  unsigned int v6; // esi
  int v7; // edi
  _QWORD *v8; // rax
  _QWORD *v9; // rdx
  LPCWSTR *v10; // rax
  int *v11; // rdx
  int v12; // edi
  __int64 v13; // rax
  __int64 *v14; // rax
  __int64 *v15; // rax
  __int64 *v16; // rax
  HMODULE *v17; // rax
  _QWORD *v18; // rdx
  _QWORD *v19; // rdx
  void *v20; // rax
  int *v21; // rdx
  int *v22; // rdx
  volatile signed __int32 *v23; // rdx
  volatile signed __int32 *v24; // rdx
  __int64 v26; // rax
  _BYTE *v27; // rdi
  __int64 *v28; // rax
  int v29; // eax
  int *v30; // rdx
  int *v31; // rdx
  int *v32; // rdx
  volatile signed __int32 *v33; // rdx
  volatile signed __int32 *v34; // rdx
  DWORD Type[2]; // [rsp+30h] [rbp-D0h] BYREF
  DWORD cbData[2]; // [rsp+38h] [rbp-C8h] BYREF
  DWORD *v37; // [rsp+40h] [rbp-C0h] BYREF
  DWORD *v38; // [rsp+48h] [rbp-B8h]
  _QWORD *v39; // [rsp+50h] [rbp-B0h]
  _QWORD *v40; // [rsp+58h] [rbp-A8h]
  _QWORD v41[2]; // [rsp+60h] [rbp-A0h] BYREF
  _QWORD *v42; // [rsp+70h] [rbp-90h] BYREF
  DWORD CurrentThreadId; // [rsp+78h] [rbp-88h]
  __int64 v44; // [rsp+80h] [rbp-80h]
  LPVOID lpMem; // [rsp+88h] [rbp-78h]
  __int64 v46; // [rsp+90h] [rbp-70h]
  int v47; // [rsp+98h] [rbp-68h]
  _BYTE v48[160]; // [rsp+A0h] [rbp-60h] BYREF
  int *v49; // [rsp+140h] [rbp+40h] BYREF
  int *v50; // [rsp+148h] [rbp+48h] BYREF
  char v51; // [rsp+150h] [rbp+50h]
  HWND v52; // [rsp+158h] [rbp+58h]
  HKEY hKey; // [rsp+160h] [rbp+60h] BYREF
  char v54; // [rsp+168h] [rbp+68h] BYREF
  int v55; // [rsp+1E8h] [rbp+E8h]
  int *v56; // [rsp+200h] [rbp+100h] BYREF
  __int64 v57; // [rsp+208h] [rbp+108h]
  int v58; // [rsp+210h] [rbp+110h]
  int v59; // [rsp+214h] [rbp+114h]
  _BYTE v60[8]; // [rsp+218h] [rbp+118h] BYREF
  BYTE Data[64]; // [rsp+220h] [rbp+120h] BYREF

  v39 = a2;
  v40 = a3;
  sub_14009B190(&hKey, 0);
  v58 = 0;
  v6 = 1;
  v55 = 1;
  sub_14005FCF0(&v56, L"SOFTWARE\\BandiView", 18);
  v59 = 1;
  if ( hKey != nullptr )
    RegCloseKey(hKey);
  hKey = nullptr;
  if ( RegOpenKeyExW(HKEY_CURRENT_USER, L"SOFTWARE\\BandiView", 0, 0x20019u, &hKey) == 0 )
  {
    v7 = 0;
    *(_DWORD *)Data = 0;
    if ( v59 != 0 )
    {
      if ( v55 == 1 )
      {
        v10 = (LPCWSTR *)sub_140060B30(&v37, v60, L"darkModeOption");
        *(_DWORD *)Data = 0;
        cbData[0] = 4;
        Type[0] = 4;
        if ( RegQueryValueExW(hKey, *v10, nullptr, Type, Data, cbData) == 0 )
          v7 = *(_DWORD *)Data;
        v11 = (int *)(v37 - 6);
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)v37 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v11 + 8LL))(*(_QWORD *)v11);
      }
      else if ( v55 == 2 )
      {
        v8 = (_QWORD *)sub_140060B30(Type, v60, L"darkModeOption");
        sub_1401E9D20((unsigned int)&v54, v57, *v8, (unsigned int)Data, 0);
        v9 = (_QWORD *)(*(_QWORD *)Type - 24LL);
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)Type - 24LL + 16), 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v9 + 8LL))(*v9);
        v7 = *(_DWORD *)Data;
      }
    }
    if ( v7 != 0 )
    {
      v12 = v7 - 1;
      if ( v12 != 0 )
      {
        if ( v12 == 1 )
          v6 = 2;
      }
      else
      {
        v6 = 3;
      }
    }
    v13 = sub_1401D4680();
    sub_1401D4700(v13, v6);
    sub_14009B560(&hKey);
  }
  v41[1] = 0;
  lpMem = nullptr;
  v46 = 0;
  v47 = 0;
  v41[0] = &CRegisterDlg::`vftable';
  sub_140094680(v48);
  v14 = sub_1400601C0();
  if ( v14 == nullptr )
    sub_14005FF30(0x80004005);
  v49 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24);
  v15 = sub_1400601C0();
  if ( v15 == nullptr )
    sub_14005FF30(0x80004005);
  v50 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
  v52 = hWnd;
  v16 = sub_1400601C0();
  if ( v16 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)Type = (*(__int64 (__fastcall **)(__int64 *))(*v16 + 24))(v16) + 24;
  if ( (unsigned __int8)sub_14005F980(Type, (__int64)&::Data) == 0 )
    sub_14005FCF0((int **)Type, &::Data, 0);
  v17 = sub_14007D020(Type);
  (*(void (__fastcall **)(HMODULE))(*(_QWORD *)v17[2] + 24LL))(v17[2]);
  v51 = 0;
  v37 = cbData;
  *(_QWORD *)cbData = sub_14005F710((volatile signed __int32 *)(*a3 - 24LL)) + 24;
  *(_QWORD *)Data = cbData;
  *(_QWORD *)Type = sub_14005F710((volatile signed __int32 *)(*a2 - 24LL)) + 24;
  v38 = Type;
  sub_14006B500(&v49, (_BYTE **)Type);
  sub_14006B500(&v50, (_BYTE **)cbData);
  v18 = (_QWORD *)(*(_QWORD *)Type - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)Type - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v18 + 8LL))(*v18);
  v19 = (_QWORD *)(*(_QWORD *)cbData - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)cbData - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v19 + 8LL))(*v19);
  v20 = lpMem;
  if ( lpMem == nullptr )
  {
    v20 = (void *)sub_140495D90();
    lpMem = v20;
    if ( v20 == nullptr )
    {
      SetLastError(0xEu);
LABEL_32:
      v41[0] = &CRegisterDlg::`vftable';
      v21 = v50 - 6;
      if ( _InterlockedExchangeAdd(v50 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v21 + 8LL))(*(_QWORD *)v21);
      v22 = v49 - 6;
      if ( _InterlockedExchangeAdd(v49 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v22 + 8LL))(*(_QWORD *)v22);
      sub_140094790(v48);
      if ( lpMem != nullptr )
        sub_140495E60(lpMem);
      sub_14009B2F0(&hKey);
      v23 = (volatile signed __int32 *)(*a2 - 24LL);
      if ( _InterlockedExchangeAdd(v23 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v23 + 8LL))(*(_QWORD *)v23);
      v24 = (volatile signed __int32 *)(*a3 - 24LL);
      if ( _InterlockedExchangeAdd(v24 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v24 + 8LL))(*(_QWORD *)v24);
      return 0;
    }
  }
  sub_140495EC0(v20, 0, 0);
  v42 = v41;
  CurrentThreadId = GetCurrentThreadId();
  EnterCriticalSection(&CriticalSection);
  v44 = qword_1406FBC60;
  qword_1406FBC60 = (__int64)&v42;
  LeaveCriticalSection(&CriticalSection);
  if ( DialogBoxParamW(hInstance, (LPCWSTR)0x87, hWnd, DialogFunc, 0) != 1 )
    goto LABEL_32;
  PostMessageW(HWND_BROADCAST, dword_140709AB4, 0, 0);
  if ( hWnd != nullptr && v51 == 0 )
  {
    sub_14007D7F0((int **)&v37);
    v38 = Type;
    v26 = sub_1401C5640();
    v27 = (_BYTE *)sub_1401C81E0(v26, L"TEXT_REGISTRATION_SUCCEED", L"TEXT");
    v28 = sub_1400601C0();
    if ( v28 == nullptr )
      sub_14005FF30(0x80004005);
    *(_QWORD *)Type = (*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24;
    if ( (unsigned __int8)sub_14005F980(Type, (__int64)v27) == 0 )
    {
      if ( v27 != nullptr )
        v29 = sub_1404ADC20(v27);
      else
        v29 = 0;
      sub_14005FCF0((int **)Type, v27, v29);
    }
    sub_14008B0F0(hWnd, (_BYTE **)Type);
    v30 = (int *)(v37 - 6);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v37 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v30 + 8LL))(*(_QWORD *)v30);
  }
  v41[0] = &CRegisterDlg::`vftable';
  v31 = v50 - 6;
  if ( _InterlockedExchangeAdd(v50 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v31 + 8LL))(*(_QWORD *)v31);
  v32 = v49 - 6;
  if ( _InterlockedExchangeAdd(v49 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v32 + 8LL))(*(_QWORD *)v32);
  sub_140094790(v48);
  if ( lpMem != nullptr )
    sub_140495E60(lpMem);
  sub_14009B2F0(&hKey);
  v33 = (volatile signed __int32 *)(*a2 - 24LL);
  if ( _InterlockedExchangeAdd(v33 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v33 + 8LL))(*(_QWORD *)v33);
  v34 = (volatile signed __int32 *)(*a3 - 24LL);
  if ( _InterlockedExchangeAdd(v34 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v34 + 8LL))(*(_QWORD *)v34);
  return 1;
}
