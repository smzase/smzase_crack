// EA 0x14009f6b0  name sub_14009F6B0  size 547
_QWORD *__fastcall sub_14009F6B0(_QWORD *a1)
{
  __int64 *v2; // rax
  __int64 *v3; // rax
  int v4; // r8d
  wchar_t *v5; // rdx
  __int16 *v6; // rax
  int *v7; // rax
  int *v8; // rbx
  __int64 v9; // rdi
  int *v10; // rdi
  _QWORD *v11; // rdx
  int *v13; // [rsp+78h] [rbp+10h] BYREF
  int *v14; // [rsp+80h] [rbp+18h] BYREF
  __int64 v15; // [rsp+88h] [rbp+20h] BYREF

  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  *a1 = (*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24;
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  v13 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
  if ( *((_BYTE *)sub_140075FE0() + 181) != 0 )
  {
    sub_14005FCF0(&v13, L"https://www.bandisoft.com/bandiview/updateinfo.beta/", 52);
    if ( (__ROR4__(__ROR4__(dword_1406F8958, 3) + 1412567278, 5) ^ 0xABCDEF12) == 0xFF )
    {
      v4 = 56;
      v5 = L"https://www.bandisoft.com/bandiview/updateinfo.beta/pro/";
LABEL_8:
      sub_14005FCF0(&v13, v5, v4);
    }
  }
  else
  {
    sub_14005FCF0(&v13, L"https://www.bandisoft.com/bandiview/updateinfo/", 47);
    if ( (__ROR4__(__ROR4__(dword_1406F8958, 3) + 1412567278, 5) ^ 0xABCDEF12) == 0xFF )
    {
      v4 = 51;
      v5 = L"https://www.bandisoft.com/bandiview/updateinfo/pro/";
      goto LABEL_8;
    }
  }
  sub_14009F580(&v15);
  v6 = sub_140075FE0();
  v7 = (int *)sub_14005F710((volatile signed __int32 *)(*((_QWORD *)v6 + 68) - 24LL));
  v8 = v7 + 6;
  v14 = v7 + 6;
  v9 = v7[2];
  if ( (int)v9 >= 0 )
  {
    if ( (int)((v7[3] - v9) | (1 - v7[4])) < 0 )
    {
      sub_14005FC80(&v14, v9);
      v8 = v14;
    }
    sub_1404AE190(v8, (int)v9 + 1);
    if ( (int)v9 <= *(v8 - 3) )
    {
      *(v8 - 4) = v9;
      *((_WORD *)v8 + v9) = 0;
      v10 = v13;
      sub_14005EB50((__int64)a1, (__int64)L"%s?l=%s&v=%s", v13, v8, v15);
      if ( _InterlockedExchangeAdd(v8 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v8 - 3) + 8LL))(*((_QWORD *)v8 - 3));
      v11 = (_QWORD *)(v15 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v15 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v11 + 8LL))(*v11);
      if ( _InterlockedExchangeAdd(v10 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v10 - 3) + 8LL))(*((_QWORD *)v10 - 3));
      return a1;
    }
  }
  sub_14005FF30(0x80070057);
}
