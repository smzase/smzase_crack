// EA 0x1400cade0  name sub_1400CADE0  size 5754
char __fastcall sub_1400CADE0(
        int a1,
        _QWORD *a2,
        int *a3,
        _QWORD *a4,
        _QWORD *a5,
        const char *a6,
        __int64 a7,
        int a8,
        int **a9,
        __int64 a10)
{
  __int64 *v14; // rax
  __int64 *v15; // rax
  const wchar_t *v16; // r9
  __int64 *v17; // rax
  __int64 v18; // rdi
  const WCHAR *v19; // rbx
  __int64 *v20; // rax
  wchar_t *v21; // rbx
  __int64 *v22; // rax
  int v23; // eax
  __int64 *v24; // rax
  __int64 v25; // r13
  __int64 v26; // r12
  const char *v27; // rbx
  __int64 v28; // r15
  __int64 v29; // r14
  __int64 v30; // rsi
  __int64 v31; // rbx
  _QWORD *v32; // rax
  _QWORD *v33; // rdx
  _QWORD *v34; // rdx
  _QWORD *v35; // rdx
  _QWORD *v36; // rdx
  _QWORD *v37; // rdx
  _QWORD *v38; // rdx
  _QWORD *v39; // rdx
  _QWORD *v40; // rdx
  _QWORD *v41; // rdx
  __int64 v42; // rbx
  volatile signed __int32 *v43; // r14
  const WCHAR *v44; // rdi
  __int64 *v45; // rax
  __int64 *v46; // rax
  const char *v47; // rsi
  __int64 *v48; // rax
  LPSTR v49; // rdi
  unsigned int v50; // eax
  __int64 *v51; // rax
  const char *v52; // rsi
  __int64 v53; // r12
  int v54; // r15d
  _QWORD *v55; // rdx
  int *v56; // rdx
  int *v57; // rdx
  _QWORD *v58; // rdx
  _QWORD *v59; // rdx
  _QWORD *v60; // rdx
  volatile signed __int32 *v61; // rdx
  _QWORD *v62; // rdx
  _QWORD *v63; // rdx
  _QWORD *v64; // rdx
  volatile signed __int32 *v65; // rdx
  volatile signed __int32 *v66; // rdx
  volatile signed __int32 *v67; // rdx
  volatile signed __int32 *v68; // rdx
  __int64 v70; // r15
  int *v71; // r12
  _DWORD *v72; // rax
  _QWORD *v73; // rdx
  _QWORD *v74; // rdx
  int *v75; // rdx
  int *v76; // rdx
  _QWORD *v77; // rdx
  _QWORD *v78; // rdx
  _QWORD *v79; // rdx
  volatile signed __int32 *v80; // rdx
  _QWORD *v81; // rdx
  _QWORD *v82; // rdx
  _QWORD *v83; // rdx
  volatile signed __int32 *v84; // rdx
  __int64 v85; // rdx
  __int64 *v86; // rax
  int **v87; // r15
  _DWORD *v88; // rax
  _QWORD *v89; // rdx
  _QWORD *v90; // rdx
  int *v91; // rdx
  int *v92; // rdx
  _QWORD *v93; // rdx
  _QWORD *v94; // rdx
  _QWORD *v95; // rdx
  volatile signed __int32 *v96; // rdx
  _QWORD *v97; // rdx
  _QWORD *v98; // rdx
  _QWORD *v99; // rdx
  volatile signed __int32 *v100; // rdx
  int *v101; // rcx
  int v102; // edx
  _DWORD *v103; // rax
  _QWORD *v104; // rdx
  _QWORD *v105; // rdx
  int *v106; // rdx
  int *v107; // rdx
  _QWORD *v108; // rdx
  _QWORD *v109; // rdx
  _QWORD *v110; // rdx
  volatile signed __int32 *v111; // rdx
  _QWORD *v112; // rdx
  _QWORD *v113; // rdx
  _QWORD *v114; // rdx
  _QWORD *v115; // rdx
  _QWORD *v116; // rdx
  int *v117; // rdx
  int *v118; // rdx
  _QWORD *v119; // rdx
  _QWORD *v120; // rdx
  _QWORD *v121; // rdx
  volatile signed __int32 *v122; // rdx
  _QWORD *v123; // rdx
  _QWORD *v124; // rdx
  _QWORD *v125; // rdx
  volatile signed __int32 *v126; // rdx
  volatile signed __int32 *v127; // rdx
  volatile signed __int32 *v128; // rdx
  volatile signed __int32 *v129; // rdx
  _DWORD *v130; // rax
  int *v131; // rdx
  _QWORD *v132; // rdx
  _QWORD *v133; // rdx
  LPSTR v134; // rdx
  _QWORD *v135; // rdx
  _QWORD *v136; // rdx
  _QWORD *v137; // rdx
  _QWORD *v138; // rdx
  volatile signed __int32 *v139; // rdx
  volatile signed __int32 *v140; // rdx
  volatile signed __int32 *v141; // rdx
  volatile signed __int32 *v142; // rdx
  volatile signed __int32 *v143; // [rsp+60h] [rbp-A0h] BYREF
  int *v144; // [rsp+68h] [rbp-98h]
  __int64 v145; // [rsp+70h] [rbp-90h] BYREF
  int *v146; // [rsp+78h] [rbp-88h] BYREF
  __int64 v147; // [rsp+80h] [rbp-80h] BYREF
  __int64 v148; // [rsp+88h] [rbp-78h] BYREF
  __int64 v149; // [rsp+90h] [rbp-70h] BYREF
  __int64 v150; // [rsp+98h] [rbp-68h] BYREF
  const WCHAR *v151; // [rsp+A0h] [rbp-60h] BYREF
  __int64 v152; // [rsp+A8h] [rbp-58h]
  _QWORD *v153; // [rsp+B0h] [rbp-50h]
  _QWORD *v154; // [rsp+B8h] [rbp-48h]
  _QWORD *v155; // [rsp+C0h] [rbp-40h]
  LPSTR v156; // [rsp+C8h] [rbp-38h] BYREF
  __int64 v157; // [rsp+D0h] [rbp-30h] BYREF
  __int64 v158; // [rsp+D8h] [rbp-28h] BYREF
  const char *v159; // [rsp+E0h] [rbp-20h] BYREF
  int **v160; // [rsp+E8h] [rbp-18h] BYREF
  __int64 v161; // [rsp+F0h] [rbp-10h]
  volatile signed __int32 *v162; // [rsp+F8h] [rbp-8h] BYREF
  __int64 v163; // [rsp+100h] [rbp+0h] BYREF
  int *v164; // [rsp+108h] [rbp+8h] BYREF
  __int64 v165; // [rsp+110h] [rbp+10h] BYREF
  __int64 v166; // [rsp+118h] [rbp+18h] BYREF
  __int64 v167; // [rsp+120h] [rbp+20h] BYREF
  __int64 v168; // [rsp+128h] [rbp+28h] BYREF
  __int64 v169; // [rsp+130h] [rbp+30h]
  __int64 v170; // [rsp+138h] [rbp+38h] BYREF
  __int64 v171; // [rsp+140h] [rbp+40h] BYREF
  __int64 v172; // [rsp+148h] [rbp+48h] BYREF
  __int64 v173; // [rsp+150h] [rbp+50h] BYREF
  __int64 v174; // [rsp+158h] [rbp+58h] BYREF
  __int64 v175; // [rsp+160h] [rbp+60h] BYREF
  __int64 v176; // [rsp+168h] [rbp+68h] BYREF
  __int64 v177; // [rsp+170h] [rbp+70h] BYREF
  __int64 v178; // [rsp+178h] [rbp+78h]
  __int64 v179; // [rsp+180h] [rbp+80h] BYREF
  int **v180; // [rsp+188h] [rbp+88h]
  __int64 v181; // [rsp+190h] [rbp+90h] BYREF
  _QWORD v182[5]; // [rsp+1A0h] [rbp+A0h] BYREF
  __int64 v183; // [rsp+1C8h] [rbp+C8h]
  _BYTE v184[128]; // [rsp+1F0h] [rbp+F0h] BYREF
  __int64 v185; // [rsp+270h] [rbp+170h]
  int v186; // [rsp+278h] [rbp+178h]
  int v187; // [rsp+27Ch] [rbp+17Ch]
  __int64 v188; // [rsp+288h] [rbp+188h]
  void *v189; // [rsp+290h] [rbp+190h]
  int v190; // [rsp+298h] [rbp+198h]
  __int64 v191; // [rsp+2A0h] [rbp+1A0h]
  __int64 v192; // [rsp+2A8h] [rbp+1A8h]
  int v193; // [rsp+2B0h] [rbp+1B0h]
  _QWORD *v194; // [rsp+2C0h] [rbp+1C0h]
  int *v195; // [rsp+2C8h] [rbp+1C8h]
  _QWORD *v196; // [rsp+2D0h] [rbp+1D0h]
  __int64 v197; // [rsp+2D8h] [rbp+1D8h]
  _QWORD *v198; // [rsp+2E0h] [rbp+1E0h]
  void *Block; // [rsp+2F0h] [rbp+1F0h] BYREF
  _BYTE v200[136]; // [rsp+2F8h] [rbp+1F8h] BYREF

  v154 = a4;
  v146 = a3;
  v153 = a2;
  v161 = a10;
  v159 = a6;
  v194 = a2;
  v195 = a3;
  v196 = a4;
  v155 = a5;
  v198 = a5;
  v163 = a7;
  v180 = a9;
  sub_14007A820(v182);
  v14 = sub_1400601C0();
  if ( v14 == nullptr )
    sub_14005FF30(0x80004005);
  v152 = (*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14);
  v197 = v152 + 24;
  v15 = sub_1400601C0();
  if ( v15 == nullptr )
    sub_14005FF30(0x80004005);
  v165 = (*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24;
  if ( a1 == 1 )
  {
    v16 = L"bandiview";
  }
  else if ( a1 == 2 )
  {
    v16 = L"bandizip";
  }
  else
  {
    v16 = L"honeycam";
    if ( a1 != 3 )
      v16 = L"APPID_ERR";
  }
  sub_14005EB50(
    (__int64)&v165,
    (__int64)L"%s?appid=%s",
    L"https://secure.bandisoft.com/uni.app/checkValidGUID.php",
    v16);
  v17 = sub_1400601C0();
  if ( v17 == nullptr )
    sub_14005FF30(0x80004005);
  v18 = (*(__int64 (__fastcall **)(__int64 *))(*v17 + 24))(v17) + 24;
  v148 = v18;
  v19 = *(const WCHAR **)a3;
  v20 = sub_1400601C0();
  if ( v20 == nullptr )
    sub_14005FF30(0x80004005);
  v162 = (volatile signed __int32 *)((*(__int64 (__fastcall **)(__int64 *))(*v20 + 24))(v20) + 24);
  if ( (unsigned __int8)sub_140073860((LPSTR *)&v162, (__int64)v19) == 0 )
    sub_140097550((LPSTR *)&v162, v19);
  sub_1400C8D10(&v150, v163);
  sub_14005FCF0(a9, L"ok", 2);
  sub_1400CD060(&v149);
  if ( a8 != 0 )
  {
    v21 = (wchar_t *)&Data;
    if ( a8 == 1 )
      v21 = L"remove";
  }
  else
  {
    v21 = (wchar_t *)L"check";
  }
  v22 = sub_1400601C0();
  if ( v22 == nullptr )
    sub_14005FF30(0x80004005);
  v164 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v22 + 24))(v22) + 24);
  if ( (unsigned __int8)sub_14005F980(&v164, (__int64)v21) == 0 )
  {
    v23 = sub_1404ADC20(v21);
    sub_14005FCF0(&v164, v21, v23);
  }
  sub_140060CB0(a2);
  v24 = sub_1400601C0();
  if ( v24 == nullptr )
    sub_14005FF30(0x80004005);
  v163 = (*(__int64 (__fastcall **)(__int64 *))(*v24 + 24))(v24) + 24;
  v156 = (LPSTR)(sub_14005F710((volatile signed __int32 *)(*a5 - 24LL)) + 24);
  v178 = *(_QWORD *)sub_1400CAC00(&v157, &v156);
  v143 = (volatile signed __int32 *)(sub_14005F710((volatile signed __int32 *)(*a4 - 24LL)) + 24);
  v169 = *(_QWORD *)sub_1400CAC00(&v166, &v143);
  v145 = sub_14005F710((volatile signed __int32 *)(*a2 - 24LL)) + 24;
  v25 = *(_QWORD *)sub_1400CAC00(&v177, &v145);
  v172 = sub_14005F710((volatile signed __int32 *)(v149 - 24)) + 24;
  v26 = *(_QWORD *)sub_1400CAC00(&v176, &v172);
  v27 = v159;
  v167 = sub_14005F710((volatile signed __int32 *)(*((_QWORD *)v159 + 3) - 24LL)) + 24;
  v28 = *(_QWORD *)sub_1400CAC00(&v175, &v167);
  v168 = sub_14005F710((volatile signed __int32 *)(*((_QWORD *)v27 + 2) - 24LL)) + 24;
  v29 = *(_QWORD *)sub_1400CAC00(&v174, &v168);
  v170 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)v27 - 24LL)) + 24;
  v30 = *(_QWORD *)sub_1400CAC00(&v173, &v170);
  v144 = v164 - 6;
  v171 = sub_14005F710(v164 - 6) + 24;
  v31 = *(_QWORD *)sub_1400CAC00(&v181, &v171);
  v147 = sub_14005F710((volatile signed __int32 *)(v150 - 24)) + 24;
  v32 = (_QWORD *)sub_1400CAC00(&v179, &v147);
  sub_14005EB50(
    (__int64)&v163,
    (__int64)L"<post><data guid=%s action=%s email=%s maskedProductKey=%s keyHash=%s hid=%s lang=%s computerName=%s version=%s /></post>",
    *v32,
    v31,
    v30,
    v29,
    v28,
    v26,
    v25,
    v169,
    v178);
  v33 = (_QWORD *)(v179 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v179 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v33 + 8LL))(*v33);
  v34 = (_QWORD *)(v181 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v181 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v34 + 8LL))(*v34);
  v35 = (_QWORD *)(v173 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v173 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v35 + 8LL))(*v35);
  v36 = (_QWORD *)(v174 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v174 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v36 + 8LL))(*v36);
  v37 = (_QWORD *)(v175 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v175 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v37 + 8LL))(*v37);
  v38 = (_QWORD *)(v176 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v176 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v38 + 8LL))(*v38);
  v39 = (_QWORD *)(v177 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v177 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v39 + 8LL))(*v39);
  v40 = (_QWORD *)(v166 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v166 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v40 + 8LL))(*v40);
  v41 = (_QWORD *)(v157 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v157 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v41 + 8LL))(*v41);
  Block = v200;
  v42 = v163;
  sub_140075800(&Block, v163, 65001);
  if ( *(_DWORD *)(*(_QWORD *)v159 - 16LL) == 0 || *(_DWORD *)(*((_QWORD *)v159 + 2) - 16LL) == 0 )
  {
    v130 = (_DWORD *)v161;
    *(_DWORD *)(v161 + 4) = 0;
    *v130 = -1159778027;
    if ( Block != v200 )
      j__free_base(Block);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v42 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v42 - 24) + 8LL))(*(_QWORD *)(v42 - 24));
    v131 = v144;
    if ( _InterlockedExchangeAdd(v144 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v131 + 8LL))(*(_QWORD *)v131);
    v132 = (_QWORD *)(v149 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v149 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v132 + 8LL))(*v132);
    v133 = (_QWORD *)(v150 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v150 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v133 + 8LL))(*v133);
    v134 = (LPSTR)(v162 - 6);
    if ( _InterlockedExchangeAdd(v162 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v134 + 8LL))(*(_QWORD *)v134);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v18 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v18 - 24) + 8LL))(*(_QWORD *)(v18 - 24));
    v135 = (_QWORD *)(v165 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v165 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v135 + 8LL))(*v135);
    v136 = (_QWORD *)v152;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v152 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v136 + 8LL))(*v136);
    v137 = (_QWORD *)(v183 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v183 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v137 + 8LL))(*v137);
    v138 = (_QWORD *)(v182[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v182[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v138 + 8LL))(*v138);
    v139 = (volatile signed __int32 *)(*v153 - 24LL);
    if ( _InterlockedExchangeAdd(v139 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v139 + 8LL))(*(_QWORD *)v139);
    v85 = *(_QWORD *)v146;
    goto LABEL_279;
  }
  v43 = v162;
  sub_140096900((int **)&v151, (__int64)v162);
  v44 = v151;
  v45 = sub_1400601C0();
  if ( v45 == nullptr )
    sub_14005FF30(0x80004005);
  v156 = (LPSTR)((*(__int64 (__fastcall **)(__int64 *))(*v45 + 24))(v45) + 24);
  if ( (unsigned __int8)sub_140073860(&v156, (__int64)v44) == 0 )
    sub_140097550(&v156, v44);
  v46 = sub_1400601C0();
  if ( v46 == nullptr )
    sub_14005FF30(0x80004005);
  v159 = (const char *)((*(__int64 (__fastcall **)(__int64 *))(*v46 + 24))(v46) + 24);
  v160 = (int **)&v143;
  v47 = (const char *)Block;
  v48 = sub_1400601C0();
  if ( v48 == nullptr )
    sub_14005FF30(0x80004005);
  v49 = v156;
  v143 = (volatile signed __int32 *)((*(__int64 (__fastcall **)(__int64 *))(*v48 + 24))(v48) + 24);
  if ( (unsigned __int8)sub_140073860((LPSTR *)&v143, (__int64)v47) == 0 )
  {
    if ( v47 != nullptr )
      v50 = strlen(v47);
    else
      v50 = 0;
    sub_140073B10(&v143, v47, v50);
  }
  sub_1400CE520(&v143, v49, &v159);
  v51 = sub_1400601C0();
  if ( v51 == nullptr )
    sub_14005FF30(0x80004005);
  v145 = (*(__int64 (__fastcall **)(__int64 *))(*v51 + 24))(v51) + 24;
  v52 = v159;
  sub_14007CDD0(&v145, "post=%s", v159);
  v53 = *(_QWORD *)v146;
  v160 = (int **)&v157;
  v54 = sub_1400C9B00(&v157, &v145);
  v143 = (volatile signed __int32 *)(v165 - 24);
  v147 = sub_14005F710((volatile signed __int32 *)(v165 - 24)) + 24;
  if ( (unsigned int)sub_14007B8E0((unsigned int)&v147, v54, (unsigned int)&v148, v53, (__int64)v182, (__int64)&v160) == 0 )
  {
    v55 = (_QWORD *)(v145 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v145 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v55 + 8LL))(*v55);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v52 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v52 - 3) + 8LL))(*((_QWORD *)v52 - 3));
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v49 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v49 - 3) + 8LL))(*((_QWORD *)v49 - 3));
    v56 = (int *)(v151 - 12);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v151 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v56 + 8LL))(*(_QWORD *)v56);
    if ( Block != v200 )
      j__free_base(Block);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v42 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v42 - 24) + 8LL))(*(_QWORD *)(v42 - 24));
    v57 = v144;
    if ( _InterlockedExchangeAdd(v144 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v57 + 8LL))(*(_QWORD *)v57);
    v58 = (_QWORD *)(v149 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v149 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v58 + 8LL))(*v58);
    v59 = (_QWORD *)(v150 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v150 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v59 + 8LL))(*v59);
    if ( _InterlockedExchangeAdd(v43 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v43 - 3) + 8LL))(*((_QWORD *)v43 - 3));
    v60 = (_QWORD *)(v148 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v148 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v60 + 8LL))(*v60);
    v61 = v143;
    if ( _InterlockedExchangeAdd(v143 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v61 + 8LL))(*(_QWORD *)v61);
    v62 = (_QWORD *)v152;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v152 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v62 + 8LL))(*v62);
    v63 = (_QWORD *)(v183 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v183 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v63 + 8LL))(*v63);
    v64 = (_QWORD *)(v182[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v182[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v64 + 8LL))(*v64);
    v65 = (volatile signed __int32 *)(*v153 - 24LL);
    if ( _InterlockedExchangeAdd(v65 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v65 + 8LL))(*(_QWORD *)v65);
    v66 = (volatile signed __int32 *)(*(_QWORD *)v146 - 24LL);
    if ( _InterlockedExchangeAdd(v66 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v66 + 8LL))(*(_QWORD *)v66);
    v67 = (volatile signed __int32 *)(*v154 - 24LL);
    if ( _InterlockedExchangeAdd(v67 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v67 + 8LL))(*(_QWORD *)v67);
    v68 = (volatile signed __int32 *)(*v155 - 24LL);
    if ( _InterlockedExchangeAdd(v68 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v68 + 8LL))(*(_QWORD *)v68);
    return 1;
  }
  v160 = (int **)&v157;
  v70 = sub_1400C9B00(&v157, &v148);
  v71 = v146;
  v147 = sub_14005F710((volatile signed __int32 *)(*(_QWORD *)v146 - 24LL)) + 24;
  sub_1400C9840(&v158, &v147, v70);
  sub_1401FC5F0(v184);
  v189 = nullptr;
  v187 = 4;
  v185 = 0;
  v188 = 0;
  v186 = 1;
  v190 = 0;
  sub_1401FC770(v184);
  if ( v189 != nullptr )
    j__free_base(v189);
  v189 = nullptr;
  v191 = 0;
  v192 = 0;
  v193 = 0;
  if ( (unsigned int)sub_1401FCDB0(v184, v158) == 0 )
  {
    v72 = (_DWORD *)v161;
    *(_DWORD *)(v161 + 4) = 0;
    *v72 = -1159778029;
    if ( v189 != nullptr )
      j__free_base(v189);
    v189 = nullptr;
    sub_1401FC700(v184);
    v73 = (_QWORD *)(v158 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v158 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v73 + 8LL))(*v73);
    v74 = (_QWORD *)(v145 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v145 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v74 + 8LL))(*v74);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v52 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v52 - 3) + 8LL))(*((_QWORD *)v52 - 3));
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v49 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v49 - 3) + 8LL))(*((_QWORD *)v49 - 3));
    v75 = (int *)(v151 - 12);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v151 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v75 + 8LL))(*(_QWORD *)v75);
    if ( Block != v200 )
      j__free_base(Block);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v42 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v42 - 24) + 8LL))(*(_QWORD *)(v42 - 24));
    v76 = v144;
    if ( _InterlockedExchangeAdd(v144 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v76 + 8LL))(*(_QWORD *)v76);
    v77 = (_QWORD *)(v149 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v149 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v77 + 8LL))(*v77);
    v78 = (_QWORD *)(v150 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v150 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v78 + 8LL))(*v78);
    if ( _InterlockedExchangeAdd(v43 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v43 - 3) + 8LL))(*((_QWORD *)v43 - 3));
    v79 = (_QWORD *)(v148 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v148 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v79 + 8LL))(*v79);
    v80 = v143;
    if ( _InterlockedExchangeAdd(v143 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v80 + 8LL))(*(_QWORD *)v80);
    v81 = (_QWORD *)v152;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v152 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v81 + 8LL))(*v81);
    v82 = (_QWORD *)(v183 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v183 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v82 + 8LL))(*v82);
    v83 = (_QWORD *)(v182[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v182[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v83 + 8LL))(*v83);
    v84 = (volatile signed __int32 *)(*v153 - 24LL);
    if ( _InterlockedExchangeAdd(v84 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v84 + 8LL))(*(_QWORD *)v84);
LABEL_131:
    v85 = *(_QWORD *)v71;
LABEL_279:
    v140 = (volatile signed __int32 *)(v85 - 24);
    if ( _InterlockedExchangeAdd(v140 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v140 + 8LL))(*(_QWORD *)v140);
    v141 = (volatile signed __int32 *)(*v154 - 24LL);
    if ( _InterlockedExchangeAdd(v141 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v141 + 8LL))(*(_QWORD *)v141);
    v142 = (volatile signed __int32 *)(*v155 - 24LL);
    if ( _InterlockedExchangeAdd(v142 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v142 + 8LL))(*(_QWORD *)v142);
    return 0;
  }
  v160 = &v146;
  v86 = sub_1400601C0();
  if ( v86 == nullptr )
    sub_14005FF30(0x80004005);
  v146 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v86 + 24))(v86) + 24);
  if ( (unsigned __int8)sub_14005F980(&v146, (__int64)L"result") == 0 )
    sub_14005FCF0(&v146, L"result", 6);
  v87 = v180;
  if ( (unsigned int)sub_1400C9F50(v184, &v146, v180) == 0 )
  {
    v88 = (_DWORD *)v161;
    *(_DWORD *)(v161 + 4) = 0;
    *v88 = -1159778028;
    if ( v189 != nullptr )
      j__free_base(v189);
    v189 = nullptr;
    sub_1401FC700(v184);
    v89 = (_QWORD *)(v158 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v158 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v89 + 8LL))(*v89);
    v90 = (_QWORD *)(v145 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v145 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v90 + 8LL))(*v90);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v52 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v52 - 3) + 8LL))(*((_QWORD *)v52 - 3));
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v49 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v49 - 3) + 8LL))(*((_QWORD *)v49 - 3));
    v91 = (int *)(v151 - 12);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v151 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v91 + 8LL))(*(_QWORD *)v91);
    if ( Block != v200 )
      j__free_base(Block);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v42 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v42 - 24) + 8LL))(*(_QWORD *)(v42 - 24));
    v92 = v144;
    if ( _InterlockedExchangeAdd(v144 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v92 + 8LL))(*(_QWORD *)v92);
    v93 = (_QWORD *)(v149 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v149 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v93 + 8LL))(*v93);
    v94 = (_QWORD *)(v150 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v150 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v94 + 8LL))(*v94);
    if ( _InterlockedExchangeAdd(v43 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v43 - 3) + 8LL))(*((_QWORD *)v43 - 3));
    v95 = (_QWORD *)(v148 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v148 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v95 + 8LL))(*v95);
    v96 = v143;
    if ( _InterlockedExchangeAdd(v143 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v96 + 8LL))(*(_QWORD *)v96);
    v97 = (_QWORD *)v152;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v152 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v97 + 8LL))(*v97);
    v98 = (_QWORD *)(v183 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v183 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v98 + 8LL))(*v98);
    v99 = (_QWORD *)(v182[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v182[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v99 + 8LL))(*v99);
    v100 = (volatile signed __int32 *)(*v153 - 24LL);
    if ( _InterlockedExchangeAdd(v100 + 4, 0xFFFFFFFF) > 1 )
      goto LABEL_131;
LABEL_171:
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v100 + 8LL))(*(_QWORD *)v100);
    v85 = *(_QWORD *)v71;
    goto LABEL_279;
  }
  v101 = *v87;
  v102 = *(unsigned __int16 *)*v87 - 111;
  if ( *(_WORD *)*v87 == 111 )
  {
    v102 = *((unsigned __int16 *)v101 + 1) - 107;
    if ( *((_WORD *)v101 + 1) == 107 )
      v102 = *((unsigned __int16 *)v101 + 2);
  }
  if ( v102 != 0 )
  {
    v103 = (_DWORD *)v161;
    *(_DWORD *)(v161 + 4) = 0;
    *v103 = -1159777532;
    if ( v189 != nullptr )
      j__free_base(v189);
    v189 = nullptr;
    sub_1401FC700(v184);
    v104 = (_QWORD *)(v158 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v158 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v104 + 8LL))(*v104);
    v105 = (_QWORD *)(v145 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v145 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v105 + 8LL))(*v105);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v52 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v52 - 3) + 8LL))(*((_QWORD *)v52 - 3));
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v49 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v49 - 3) + 8LL))(*((_QWORD *)v49 - 3));
    v106 = (int *)(v151 - 12);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)v151 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v106 + 8LL))(*(_QWORD *)v106);
    if ( Block != v200 )
      j__free_base(Block);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v42 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v42 - 24) + 8LL))(*(_QWORD *)(v42 - 24));
    v107 = v144;
    if ( _InterlockedExchangeAdd(v144 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v107 + 8LL))(*(_QWORD *)v107);
    v108 = (_QWORD *)(v149 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v149 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v108 + 8LL))(*v108);
    v109 = (_QWORD *)(v150 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v150 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v109 + 8LL))(*v109);
    if ( _InterlockedExchangeAdd(v43 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v43 - 3) + 8LL))(*((_QWORD *)v43 - 3));
    v110 = (_QWORD *)(v148 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v148 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v110 + 8LL))(*v110);
    v111 = v143;
    if ( _InterlockedExchangeAdd(v143 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v111 + 8LL))(*(_QWORD *)v111);
    v112 = (_QWORD *)v152;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v152 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v112 + 8LL))(*v112);
    v113 = (_QWORD *)(v183 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v183 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v113 + 8LL))(*v113);
    v114 = (_QWORD *)(v182[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v182[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v114 + 8LL))(*v114);
    v100 = (volatile signed __int32 *)(*v153 - 24LL);
    if ( _InterlockedExchangeAdd(v100 + 4, 0xFFFFFFFF) > 1 )
      goto LABEL_131;
    goto LABEL_171;
  }
  if ( v189 != nullptr )
    j__free_base(v189);
  v189 = nullptr;
  sub_1401FC700(v184);
  v115 = (_QWORD *)(v158 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v158 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v115 + 8LL))(*v115);
  v116 = (_QWORD *)(v145 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v145 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v116 + 8LL))(*v116);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v52 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v52 - 3) + 8LL))(*((_QWORD *)v52 - 3));
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v49 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v49 - 3) + 8LL))(*((_QWORD *)v49 - 3));
  v117 = (int *)(v151 - 12);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v151 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v117 + 8LL))(*(_QWORD *)v117);
  if ( Block != v200 )
    j__free_base(Block);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v42 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v42 - 24) + 8LL))(*(_QWORD *)(v42 - 24));
  v118 = v144;
  if ( _InterlockedExchangeAdd(v144 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v118 + 8LL))(*(_QWORD *)v118);
  v119 = (_QWORD *)(v149 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v149 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v119 + 8LL))(*v119);
  v120 = (_QWORD *)(v150 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v150 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v120 + 8LL))(*v120);
  if ( _InterlockedExchangeAdd(v43 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v43 - 3) + 8LL))(*((_QWORD *)v43 - 3));
  v121 = (_QWORD *)(v148 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v148 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v121 + 8LL))(*v121);
  v122 = v143;
  if ( _InterlockedExchangeAdd(v143 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v122 + 8LL))(*(_QWORD *)v122);
  v123 = (_QWORD *)v152;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v152 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v123 + 8LL))(*v123);
  v124 = (_QWORD *)(v183 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v183 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v124 + 8LL))(*v124);
  v125 = (_QWORD *)(v182[0] - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v182[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v125 + 8LL))(*v125);
  v126 = (volatile signed __int32 *)(*v153 - 24LL);
  if ( _InterlockedExchangeAdd(v126 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v126 + 8LL))(*(_QWORD *)v126);
  v127 = (volatile signed __int32 *)(*(_QWORD *)v71 - 24LL);
  if ( _InterlockedExchangeAdd(v127 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v127 + 8LL))(*(_QWORD *)v127);
  v128 = (volatile signed __int32 *)(*v154 - 24LL);
  if ( _InterlockedExchangeAdd(v128 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v128 + 8LL))(*(_QWORD *)v128);
  v129 = (volatile signed __int32 *)(*v155 - 24LL);
  if ( _InterlockedExchangeAdd(v129 + 4, 0xFFFFFFFF) > 1 )
    return 1;
  (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v129 + 8LL))(*(_QWORD *)v129);
  return 1;
}
