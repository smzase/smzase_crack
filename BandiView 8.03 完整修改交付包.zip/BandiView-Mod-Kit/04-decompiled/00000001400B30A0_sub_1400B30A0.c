// EA 0x1400b30a0  name sub_1400B30A0  size 585
__int64 __fastcall sub_1400B30A0(__int64 a1, __m128i *a2)
{
  int v4; // r14d
  const __m128i *v5; // rcx
  const __m128i *v6; // rcx
  const __m128i *v7; // rcx
  BOOL v8; // edi
  __int64 *v9; // rax
  BOOL v10; // edi
  __int64 *v11; // rax
  int *v13; // [rsp+20h] [rbp-38h] BYREF
  int **v14; // [rsp+28h] [rbp-30h]
  __m128i *v15; // [rsp+30h] [rbp-28h]

  v15 = a2;
  v4 = *((_DWORD *)sub_140075FE0() + 50);
  v5 = a2;
  if ( a2[1].m128i_i64[1] > 7uLL )
    v5 = (const __m128i *)a2->m128i_i64[0];
  if ( a2[1].m128i_i64[0] != 15 || (unsigned int)sub_140074220(v5, (const __m128i *)L"CHK_BG_CLR_BLUR", 0xFu) != 0 )
  {
    v6 = a2;
    if ( a2[1].m128i_i64[1] > 7uLL )
      v6 = (const __m128i *)a2->m128i_i64[0];
    if ( a2[1].m128i_i64[0] != 15 || (unsigned int)sub_140074220(v6, (const __m128i *)L"CHK_BG_CLR_AUTO", 0xFu) != 0 )
    {
      if ( a2[1].m128i_i64[1] <= 7uLL )
        v7 = a2;
      else
        v7 = (const __m128i *)a2->m128i_i64[0];
      if ( a2[1].m128i_i64[0] == 17
        && (unsigned int)sub_140074220(v7, (const __m128i *)L"CHK_BG_CLR_CUSTOM", 0x11u) == 0 )
      {
        *((_DWORD *)sub_140075FE0() + 50) = 0;
      }
    }
    else
    {
      *((_DWORD *)sub_140075FE0() + 50) = 1;
    }
  }
  else
  {
    *((_DWORD *)sub_140075FE0() + 50) = 2;
  }
  v8 = *((_DWORD *)sub_140075FE0() + 50) == 0;
  v14 = &v13;
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    sub_14005FF30(0x80004005);
  v13 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
  if ( (unsigned __int8)sub_14005F980(&v13, (__int64)L"STATIC_BKGND_CLR_CUSTOM_PALETTE") == 0 )
    sub_14005FCF0(&v13, L"STATIC_BKGND_CLR_CUSTOM_PALETTE", 31);
  sub_1401C4E90(a1 + 728, &v13, v8);
  v10 = *((_DWORD *)sub_140075FE0() + 50) != 0;
  v14 = &v13;
  v11 = sub_1400601C0();
  if ( v11 == nullptr )
    sub_14005FF30(0x80004005);
  v13 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24);
  if ( (unsigned __int8)sub_14005F980(&v13, (__int64)L"STATIC_BKGNDCOLOR_INFO") == 0 )
    sub_14005FCF0(&v13, L"STATIC_BKGNDCOLOR_INFO", 22);
  sub_1401C4E90(a1 + 728, &v13, v10);
  if ( v4 != *((_DWORD *)sub_140075FE0() + 50) )
    PostMessageW(*(HWND *)(a1 + 616), 0x111u, 0x8267u, 0);
  return sub_14005D410((char **)a2);
}
