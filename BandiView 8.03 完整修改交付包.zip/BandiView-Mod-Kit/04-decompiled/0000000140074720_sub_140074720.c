// EA 0x140074720  name sub_140074720  size 87
__int64 sub_140074720()
{
  struct tm v1; // [rsp+28h] [rbp-40h] BYREF

  unknown_libname_553(0);
  common_localtime_s<__int64>(&v1);
  return (unsigned int)(v1.tm_mday + 100 * (v1.tm_mon + 190001 + 100 * v1.tm_year));
}
