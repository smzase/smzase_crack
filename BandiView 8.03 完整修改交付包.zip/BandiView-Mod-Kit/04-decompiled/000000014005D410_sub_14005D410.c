// EA 0x14005d410  name sub_14005D410  size 104
__int64 __fastcall sub_14005D410(char **a1)
{
  unsigned __int64 v1; // rdx
  char *v3; // rax
  char *v4; // rcx

  v1 = (unsigned __int64)a1[3];
  if ( v1 > 7 )
  {
    v3 = *a1;
    if ( 2 * v1 + 2 < 0x1000 )
    {
      v4 = *a1;
    }
    else
    {
      v4 = *((char **)v3 - 1);
      if ( (unsigned __int64)(v3 - v4 - 8) > 0x1F )
        __fastfail(5u);
    }
    j_j_j__free_base(v4);
  }
  a1[2] = nullptr;
  *(_WORD *)a1 = 0;
  a1[3] = (char *)7;
  return 0;
}
