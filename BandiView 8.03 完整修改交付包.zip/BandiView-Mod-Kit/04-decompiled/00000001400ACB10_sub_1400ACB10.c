// EA 0x1400acb10  name sub_1400ACB10  size 167
_BOOL8 __fastcall sub_1400ACB10(__int64 a1, _QWORD *a2)
{
  bool v4; // di
  int v5; // eax
  __int64 v6; // rax
  volatile signed __int32 *v7; // rdx
  __int64 v9; // [rsp+40h] [rbp+8h] BYREF
  _QWORD *v10; // [rsp+48h] [rbp+10h]

  v10 = a2;
  v4 = false;
  v9 = sub_14005F710((volatile signed __int32 *)(*a2 - 24LL)) + 24;
  v5 = sub_1401BE5D0(a1 + 728, &v9);
  v6 = sub_1404A362C(
         v5,
         0,
         (unsigned int)&AControlBase `RTTI Type Descriptor',
         (unsigned int)&XCheckBox `RTTI Type Descriptor',
         0);
  if ( v6 != 0 )
    v4 = *(_DWORD *)(v6 + 728) != 0;
  v7 = (volatile signed __int32 *)(*a2 - 24LL);
  if ( _InterlockedExchangeAdd(v7 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v7 + 8LL))(*(_QWORD *)v7);
  return v4;
}
