// EA 0x140097550  name sub_140097550  size 316
LPSTR *__fastcall sub_140097550(LPSTR *a1, const WCHAR *a2)
{
  int v4; // eax
  __int64 v5; // r14
  int cbMultiByte; // esi
  LPSTR v8; // rcx
  volatile signed __int32 *v9; // rdx
  __int64 v10; // rsi

  if ( a2 != nullptr
    && (v4 = WideCharToMultiByte(3u, 0, a2, -1, nullptr, 0, nullptr, nullptr), v5 = v4, cbMultiByte = v4 - 1, v4 - 1 > 0) )
  {
    if ( ((*((_DWORD *)*a1 - 3) - cbMultiByte) | (1 - *((_DWORD *)*a1 - 2))) < 0 )
      sub_140073A50(a1, (unsigned int)cbMultiByte);
    WideCharToMultiByte(3u, 0, a2, -1, *a1, cbMultiByte, nullptr, nullptr);
    if ( cbMultiByte > *((_DWORD *)*a1 - 3) )
      sub_14005FF30(0x80070057);
    *((_DWORD *)*a1 - 4) = cbMultiByte;
    (*a1)[v5 - 1] = 0;
    return a1;
  }
  else
  {
    v8 = *a1;
    v9 = (volatile signed __int32 *)(*a1 - 24);
    if ( *((_DWORD *)v9 + 2) != 0 )
    {
      if ( *((int *)v9 + 4) >= 0 )
      {
        v10 = *(_QWORD *)v9;
        if ( _InterlockedExchangeAdd(v9 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v9 + 8LL))(*(_QWORD *)v9);
        *a1 = (LPSTR)((*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v10 + 24LL))(v10) + 24);
      }
      else
      {
        if ( *((int *)v8 - 3) < 0 )
          sub_14005FF30(0x80070057);
        *((_DWORD *)v8 - 4) = 0;
        **a1 = 0;
      }
    }
    return a1;
  }
}
