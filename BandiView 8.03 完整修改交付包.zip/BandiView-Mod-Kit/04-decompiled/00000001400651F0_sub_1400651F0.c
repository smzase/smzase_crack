// EA 0x1400651f0  name sub_1400651F0  size 21
__int64 sub_1400651F0()
{
  return sub_140064EC0();
}
