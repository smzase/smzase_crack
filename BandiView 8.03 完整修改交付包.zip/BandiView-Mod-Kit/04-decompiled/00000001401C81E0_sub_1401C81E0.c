// EA 0x1401c81e0  name sub_1401C81E0  size 2622
const wchar_t *__fastcall sub_1401C81E0(__int64 a1, const WCHAR *a2, const WCHAR *a3)
{
  const WCHAR *v6; // rbx
  unsigned __int64 v7; // rax
  const WCHAR *v8; // rbx
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rcx
  __int128 *v11; // r14
  char *v12; // rbx
  __int64 v13; // rax
  __int64 v14; // rdi
  int v15; // eax
  unsigned __int64 v16; // r8
  __int128 *v17; // rdx
  __int128 *v18; // rdx
  int v19; // r8d
  int v20; // ecx
  const WCHAR *v21; // rdx
  unsigned __int64 v22; // r8
  int v23; // edx
  __int64 v24; // rcx
  unsigned __int64 v25; // rdx
  __int128 *v26; // rax
  __int128 *v27; // rdx
  __int128 *v28; // r9
  __int128 *v29; // r8
  _WORD *v30; // r14
  _QWORD *v31; // r13
  unsigned int v32; // edi
  unsigned __int16 v33; // ax
  _WORD *v34; // rcx
  __int64 v35; // rbx
  unsigned int v36; // edi
  char v37; // bl
  int v38; // eax
  unsigned __int64 v39; // r8
  __int128 *v40; // rdx
  const __m128i *v41; // rcx
  int v42; // eax
  const WCHAR *v43; // rdx
  unsigned __int64 v44; // r8
  __int64 v45; // rcx
  int v46; // edx
  __int128 *v47; // rdx
  __int128 *v48; // rdx
  bool v49; // bl
  __int128 *v50; // rdx
  __int128 *v51; // r8
  __int64 v52; // rcx
  __int16 v53; // ax
  const WCHAR *v54; // rsi
  __int64 v55; // rcx
  __int16 v56; // ax
  const void *v57; // rbx
  unsigned __int64 v58; // rax
  const void *v59; // rbx
  unsigned __int64 v60; // rax
  __int128 *p_Src; // rcx
  __int64 v62; // r8
  _WORD *v63; // r14
  unsigned __int16 v64; // ax
  _WORD *v65; // rcx
  __int64 v66; // rdx
  unsigned int v67; // r13d
  __int64 v68; // rax
  __int64 v69; // r15
  __int64 v70; // rbx
  __int64 v71; // [rsp+40h] [rbp-99h]
  _WORD *v72; // [rsp+48h] [rbp-91h] BYREF
  __int128 v73; // [rsp+50h] [rbp-89h] BYREF
  __int128 v74; // [rsp+60h] [rbp-79h]
  __int128 v75; // [rsp+70h] [rbp-69h] BYREF
  __m128i v76; // [rsp+80h] [rbp-59h]
  __int128 v77; // [rsp+90h] [rbp-49h] BYREF
  __m128i si128; // [rsp+A0h] [rbp-39h]
  __int128 v79; // [rsp+B0h] [rbp-29h] BYREF
  __m128i v80; // [rsp+C0h] [rbp-19h]
  __int128 Src; // [rsp+D0h] [rbp-9h] BYREF
  __int64 v82; // [rsp+E0h] [rbp+7h]
  unsigned __int64 v83; // [rsp+E8h] [rbp+Fh]

  if ( *(_DWORD *)(a1 + 296) == 0 )
    return L"Unable to load the language file.";
  v77 = 0;
  si128 = _mm_load_si128((const __m128i *)&xmmword_140662F90);
  LOWORD(v77) = 0;
  v6 = &Data;
  if ( a2 != nullptr )
    v6 = a2;
  v7 = sub_1404ADC20(v6);
  sub_140069540((void **)&v77, v6, v7);
  v79 = 0;
  v80 = _mm_load_si128((const __m128i *)&xmmword_140662F90);
  LOWORD(v79) = 0;
  v8 = &Data;
  if ( a3 != nullptr )
    v8 = a3;
  v9 = sub_1404ADC20(v8);
  sub_140069540((void **)&v79, v8, v9);
  v10 = si128.m128i_i64[0];
  v11 = &v77;
  if ( si128.m128i_i64[1] > 7uLL )
    v11 = (__int128 *)v77;
  if ( si128.m128i_i64[0] == 0
    || (v12 = (char *)v11 + 2 * si128.m128i_i64[0],
        v13 = sub_1404DF4D0(v11, v12, 124),
        v10 = si128.m128i_i64[0],
        (char *)v13 == v12) )
  {
    v14 = -1;
  }
  else
  {
    v14 = (v13 - (__int64)v11) >> 1;
  }
  if ( v14 == -1 )
    LODWORD(v14) = -1;
  if ( (int)v14 > 0 )
  {
    v73 = 0;
    v74 = 0;
    v15 = v14;
    if ( (int)v10 < (int)v14 )
      v15 = v10;
    v16 = v15;
    if ( v10 < v15 )
      v16 = v10;
    v17 = &v77;
    if ( si128.m128i_i64[1] > 7uLL )
      v17 = (__int128 *)v77;
    sub_140061270((char **)&v73, v17, v16);
    v18 = &v73;
    if ( *((_QWORD *)&v74 + 1) > 7u )
      v18 = (__int128 *)v73;
    sub_140069540((void **)&v79, v18, v74);
    sub_14005D410((char **)&v73);
    v19 = v14 + 1;
    v20 = v14 + 1;
    if ( (int)v14 + 1 < 0 )
      v20 = 0;
    if ( si128.m128i_i32[0] < v20 )
      v20 = si128.m128i_i32[0];
    v73 = 0;
    v74 = 0;
    if ( v20 == v19 )
    {
      v23 = si128.m128i_i32[0] - v19;
      v24 = (unsigned int)(si128.m128i_i32[0] - v19);
      if ( si128.m128i_i32[0] - v19 < 0 )
        v24 = 0;
      if ( v23 < (int)v24 )
        v24 = (unsigned int)v23;
      v25 = (int)v14 + 1LL;
      if ( si128.m128i_i64[0] < v25 )
        unknown_libname_8(v24);
      v22 = (int)v24;
      if ( si128.m128i_i64[0] - v25 < (int)v24 )
        v22 = si128.m128i_i64[0] - v25;
      v26 = &v77;
      if ( si128.m128i_i64[1] > 7uLL )
        v26 = (__int128 *)v77;
      v21 = (const WCHAR *)v26 + v25;
    }
    else
    {
      v21 = &Data;
      v22 = 0;
    }
    sub_140061270((char **)&v73, v21, v22);
    v27 = &v73;
    if ( *((_QWORD *)&v74 + 1) > 7u )
      v27 = (__int128 *)v73;
    sub_140069540((void **)&v77, v27, v74);
    sub_14005D410((char **)&v73);
  }
  v28 = &v79;
  if ( v80.m128i_i64[1] > 7uLL )
    v28 = (__int128 *)v79;
  v29 = &v77;
  if ( si128.m128i_i64[1] > 7uLL )
    v29 = (__int128 *)v77;
  sub_1401C80E0(v10, &v72, v29, v28);
  v30 = v72;
  if ( v72 == nullptr )
    sub_14005FF30(0x80004005);
  v31 = (_QWORD *)(a1 + 72);
  v71 = a1 + 72;
  v32 = 0;
  v33 = *v72;
  if ( *v72 != 0 )
  {
    v34 = v72;
    do
    {
      v32 = v33 + 33 * v32;
      v33 = *++v34;
    }
    while ( *v34 != 0 );
  }
  if ( *v31 != 0 && (v35 = *(_QWORD *)(*v31 + 8LL * (v32 % *(_DWORD *)(a1 + 88)))) != 0 )
  {
    while ( *(_DWORD *)(v35 + 24) != v32 || (unsigned int)sub_1404D8590(*(_QWORD *)v35, v30) != 0 )
    {
      v35 = *(_QWORD *)(v35 + 16);
      if ( v35 == 0 )
        goto LABEL_56;
    }
    v36 = 0;
  }
  else
  {
LABEL_56:
    v36 = 0;
    v35 = 0;
  }
  if ( v35 == 0 )
  {
    Src = 0;
    v82 = 0;
    v83 = 7;
    LOWORD(Src) = 0;
    v75 = 0;
    v76 = 0;
    sub_140061270((char **)&v75, &Data, 0);
    if ( (unsigned __int8)sub_1401D2200(
                            (int)a1 + 200,
                            (unsigned int)&v79,
                            (unsigned int)&v77,
                            (unsigned int)&Src,
                            (__int64)&v75) == 0
      || v82 == 0 )
    {
      LOBYTE(v35) = 1;
    }
    sub_14005D410((char **)&v75);
    if ( (_BYTE)v35 == 0 )
      goto LABEL_118;
    v75 = 0;
    v76 = 0;
    sub_140061270((char **)&v75, &Data, 0);
    v37 = sub_1401D2200((int)a1 + 248, (unsigned int)&v79, (unsigned int)&v77, (unsigned int)&Src, (__int64)&v75);
    sub_14005D410((char **)&v75);
    if ( v37 == 0 )
    {
      v73 = 0;
      v74 = 0;
      v38 = 1;
      if ( v80.m128i_i32[0] < 1 )
        v38 = v80.m128i_i32[0];
      v39 = v38;
      if ( v80.m128i_i64[0] < (unsigned __int64)v38 )
        v39 = v80.m128i_i64[0];
      v40 = &v79;
      if ( v80.m128i_i64[1] > 7uLL )
        v40 = (__int128 *)v79;
      sub_140061270((char **)&v73, v40, v39);
      v41 = (const __m128i *)&v73;
      if ( *((_QWORD *)&v74 + 1) > 7u )
        v41 = (const __m128i *)v73;
      if ( (_QWORD)v74 == 1 )
        v37 = (unsigned int)sub_140074220(v41, (const __m128i *)L"$", 1u) == 0;
      sub_14005D410((char **)&v73);
      if ( v37 != 0 )
      {
        v42 = 1;
        if ( v80.m128i_i32[0] < 1 )
          v42 = v80.m128i_i32[0];
        v73 = 0;
        v74 = 0;
        if ( v42 == 1 )
        {
          v45 = (unsigned int)(v80.m128i_i32[0] - 1);
          v46 = v45;
          if ( (int)v45 < 0 )
            v46 = 0;
          if ( (int)v45 < v46 )
            v46 = v80.m128i_i32[0] - 1;
          if ( v80.m128i_i64[0] == 0 )
            unknown_libname_8(v45);
          v44 = v46;
          if ( v80.m128i_i64[0] - 1 < (unsigned __int64)v46 )
            v44 = v80.m128i_i64[0] - 1;
          v47 = &v79;
          if ( v80.m128i_i64[1] > 7uLL )
            v47 = (__int128 *)v79;
          v43 = (const WCHAR *)v47 + 1;
        }
        else
        {
          v43 = &Data;
          v44 = 0;
        }
        sub_140061270((char **)&v73, v43, v44);
        v75 = 0;
        v76 = _mm_load_si128((const __m128i *)&xmmword_140662F90);
        LOWORD(v75) = 0;
        v48 = &v73;
        if ( *((_QWORD *)&v74 + 1) > 7u )
          v48 = (__int128 *)v73;
        sub_140069540((void **)&v75, v48, v74);
        sub_14005D410((char **)&v73);
        v73 = 0;
        v74 = 0;
        sub_140061270((char **)&v73, &Data, 0);
        v49 = (unsigned __int8)sub_1401D2200(
                                 (int)a1 + 200,
                                 (unsigned int)&v75,
                                 (unsigned int)&v77,
                                 (unsigned int)&Src,
                                 (__int64)&v73) == 0
           || v82 == 0;
        sub_14005D410((char **)&v73);
        if ( v49 )
        {
          v73 = 0;
          v74 = 0;
          sub_140061270((char **)&v73, &Data, 0);
          sub_1401D2200(a1 + 248, (unsigned int)&v75, (unsigned int)&v77, (unsigned int)&Src, (__int64)&v73);
          sub_14005D410((char **)&v73);
        }
        sub_14005D410((char **)&v75);
      }
      if ( v82 == 0 )
      {
        v50 = (__int128 *)v79;
        if ( v80.m128i_i64[1] <= 7uLL )
        {
          v51 = &v79;
        }
        else
        {
          if ( (_QWORD)v79 == 0 )
          {
            v36 = 0;
            goto LABEL_110;
          }
          v51 = (__int128 *)v79;
        }
        v36 = 0;
        v52 = 0;
        while ( 1 )
        {
          v53 = *((_WORD *)v51 + v52++);
          if ( v53 != aMenu[v52 - 1] )
            break;
          if ( v52 == 5 )
          {
            v54 = nullptr;
            goto LABEL_143;
          }
        }
        if ( v80.m128i_i64[1] <= 7uLL )
        {
          v50 = &v79;
LABEL_113:
          v55 = 0;
          while ( 1 )
          {
            v56 = *((_WORD *)v50 + v55++);
            if ( v56 != aCmd[v55 - 1] )
              break;
            if ( v55 == 4 )
            {
              v54 = nullptr;
              goto LABEL_143;
            }
          }
LABEL_118:
          v75 = 0;
          v76 = 0u;
          sub_140061270((char **)&v75, L"\n", 1u);
          v73 = 0;
          v74 = 0u;
          sub_140061270((char **)&v73, L"\\n", 2u);
          sub_1401CAFA0(&Src);
          v75 = 0;
          v76 = 0u;
          sub_140061270((char **)&v75, L"\r", 1u);
          v73 = 0;
          v74 = 0u;
          sub_140061270((char **)&v73, L"\\r", 2u);
          sub_1401CAFA0(&Src);
          if ( *(_DWORD *)(a1 + 316) != 0 )
          {
            v75 = 0;
            v76 = 0u;
            sub_140061270((char **)&v75, L"\n", 1u);
            v73 = 0;
            v74 = 0u;
            sub_140061270((char **)&v73, L"[br]", 4u);
            sub_1401CAFA0(&Src);
          }
          v57 = *(const void **)(a1 + 320);
          if ( *((_DWORD *)v57 - 4) != 0 )
          {
            v75 = 0;
            v76 = 0u;
            v58 = sub_1404ADC20(v57);
            sub_140061270((char **)&v75, v57, v58);
            v73 = 0;
            v74 = 0u;
            sub_140061270((char **)&v73, L"${APPNAME}", 0xAu);
            sub_1401CAFA0(&Src);
          }
          v59 = *(const void **)(a1 + 328);
          if ( *((_DWORD *)v59 - 4) != 0 )
          {
            v75 = 0;
            v76 = 0u;
            v60 = sub_1404ADC20(v59);
            sub_140061270((char **)&v75, v59, v60);
            v73 = 0;
            v74 = 0u;
            sub_140061270((char **)&v73, L"${APPVERSION}", 0xDu);
            sub_1401CAFA0(&Src);
          }
          p_Src = &Src;
          if ( v83 > 7 )
            p_Src = (__int128 *)Src;
          v54 = (const WCHAR *)sub_1404BCF60(p_Src);
          v63 = v72;
          if ( v72 == nullptr )
            sub_14005FF30(0x80004005);
          v64 = *v72;
          if ( *v72 != 0 )
          {
            v65 = v72;
            do
            {
              v36 = v64 + 33 * v36;
              v64 = *++v65;
            }
            while ( *v65 != 0 );
          }
          v66 = v36 % *(_DWORD *)(a1 + 88);
          v67 = v66;
          v68 = a1 + 72;
          v69 = *(_QWORD *)(a1 + 72);
          if ( v69 != 0 )
          {
            v70 = *(_QWORD *)(v69 + 8 * v66);
            if ( v70 != 0 )
            {
              while ( *(_DWORD *)(v70 + 24) != v36 || (unsigned int)sub_1404D8590(*(_QWORD *)v70, v63) != 0 )
              {
                v70 = *(_QWORD *)(v70 + 16);
                if ( v70 == 0 )
                  goto LABEL_135;
              }
              v68 = v71;
LABEL_137:
              if ( v70 == 0 )
              {
                if ( v69 == 0 )
                {
                  LOBYTE(v62) = 1;
                  if ( (unsigned __int8)sub_1400918F0(v68, *(unsigned int *)(v68 + 16), v62) == 0 )
                    sub_14005FF30(0x8007000E);
                }
                v70 = sub_1400C3150(v71, v63, v67, v36);
              }
              *(_QWORD *)(v70 + 8) = v54;
              if ( v54 == nullptr )
                v54 = &Data;
LABEL_143:
              sub_14005D410((char **)&Src);
              v30 = v72;
              goto LABEL_147;
            }
LABEL_135:
            v68 = v71;
          }
          v70 = 0;
          goto LABEL_137;
        }
LABEL_110:
        if ( (_QWORD)v79 == 0 )
          goto LABEL_118;
        goto LABEL_113;
      }
    }
    v36 = 0;
    goto LABEL_118;
  }
  v54 = *(const WCHAR **)(v35 + 8);
  if ( v54 == nullptr )
    v54 = &Data;
LABEL_147:
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v30 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v30 - 3) + 8LL))(*((_QWORD *)v30 - 3));
  sub_14005D410((char **)&v79);
  sub_14005D410((char **)&v77);
  return v54;
}
