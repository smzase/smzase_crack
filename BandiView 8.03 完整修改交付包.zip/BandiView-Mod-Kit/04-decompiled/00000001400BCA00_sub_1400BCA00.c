// EA 0x1400bca00  name sub_1400BCA00  size 832
__int16 *__fastcall sub_1400BCA00(__int64 a1)
{
  int v2; // esi
  __int64 *v3; // rax
  __int64 v4; // rdi
  __int64 *v5; // rax
  __int64 *v6; // rax
  __int64 *v7; // rax
  __int64 *v8; // rax
  __int64 v9; // rbx
  int v10; // ecx
  __int64 v11; // rcx
  __int64 *v12; // rax
  __int64 v13; // rbx
  __int16 *result; // rax
  int v15; // ecx
  __int64 v16; // rcx
  int *v17; // [rsp+40h] [rbp+20h] BYREF
  int **v18; // [rsp+48h] [rbp+28h]

  v2 = *((_DWORD *)sub_140075FE0() + 61);
  v18 = &v17;
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  v4 = a1 + 728;
  v17 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
  if ( (unsigned __int8)sub_14005F980(&v17, (__int64)L"STATIC_BKGND_COLOR_GRID1") == 0 )
    sub_14005FCF0(&v17, L"STATIC_BKGND_COLOR_GRID1", 24);
  sub_1401C4E90(v4, &v17, v2 == 0);
  v18 = &v17;
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  v17 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
  if ( (unsigned __int8)sub_14005F980(&v17, (__int64)L"BTN_BKGND_COLOR_GRID1") == 0 )
    sub_14005FCF0(&v17, L"BTN_BKGND_COLOR_GRID1", 21);
  sub_1401C4E90(v4, &v17, v2 == 0);
  v18 = &v17;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  v17 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  if ( (unsigned __int8)sub_14005F980(&v17, (__int64)L"STATIC_BKGND_COLOR_GRID2") == 0 )
    sub_14005FCF0(&v17, L"STATIC_BKGND_COLOR_GRID2", 24);
  sub_1401C4E90(v4, &v17, v2 == 0);
  v18 = &v17;
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  v17 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
  if ( (unsigned __int8)sub_14005F980(&v17, (__int64)L"BTN_BKGND_COLOR_GRID2") == 0 )
    sub_14005FCF0(&v17, L"BTN_BKGND_COLOR_GRID2", 21);
  sub_1401C4E90(v4, &v17, v2 == 0);
  v18 = &v17;
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  v17 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24);
  if ( (unsigned __int8)sub_14005F980(&v17, (__int64)L"STATIC_BKGND_COLOR_GRID1") == 0 )
    sub_14005FCF0(&v17, L"STATIC_BKGND_COLOR_GRID1", 24);
  v9 = sub_1401BE5D0(v4, &v17);
  v10 = *((_DWORD *)sub_140075FE0() + 62);
  if ( *(_DWORD *)(v9 + 544) != v10 )
  {
    *(_DWORD *)(v9 + 544) = v10;
    (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v9 + 224LL))(v9, 0);
    v11 = *(_QWORD *)(v9 + 528);
    if ( v11 != 0 )
      sub_1401BC8D0(v11, v9 + 264);
  }
  v18 = &v17;
  v12 = sub_1400601C0();
  if ( v12 == nullptr )
    sub_14005FF30(0x80004005);
  v17 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24);
  if ( (unsigned __int8)sub_14005F980(&v17, (__int64)L"STATIC_BKGND_COLOR_GRID2") == 0 )
    sub_14005FCF0(&v17, L"STATIC_BKGND_COLOR_GRID2", 24);
  v13 = sub_1401BE5D0(v4, &v17);
  result = sub_140075FE0();
  v15 = *((_DWORD *)result + 63);
  if ( *(_DWORD *)(v13 + 544) != v15 )
  {
    *(_DWORD *)(v13 + 544) = v15;
    result = (__int16 *)(*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v13 + 224LL))(v13, 0);
    v16 = *(_QWORD *)(v13 + 528);
    if ( v16 != 0 )
      return (__int16 *)sub_1401BC8D0(v16, v13 + 264);
  }
  return result;
}
