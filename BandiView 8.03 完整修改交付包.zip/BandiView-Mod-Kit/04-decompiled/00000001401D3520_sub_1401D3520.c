// EA 0x1401d3520  name sub_1401D3520  size 410
__int64 __fastcall sub_1401D3520(__int64 a1, _QWORD *a2, __int64 a3)
{
  __int64 *v6; // rax
  int *v7; // rbx
  int *v8; // rdx
  __int64 v9; // r8
  __int64 v10; // rdx
  volatile signed __int32 *v11; // rdx
  volatile signed __int32 *v13; // rdx
  int *v14; // [rsp+20h] [rbp-38h] BYREF
  _BYTE v15[48]; // [rsp+28h] [rbp-30h] BYREF
  __int64 v16; // [rsp+70h] [rbp+18h] BYREF
  __int64 v17; // [rsp+78h] [rbp+20h] BYREF

  v16 = a3;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  v7 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  v14 = v7;
  if ( a3 == 0 )
  {
    sub_14018C080(a1 + 216, *a2, &v16);
LABEL_12:
    if ( _InterlockedExchangeAdd(v7 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v7 - 3) + 8LL))(*((_QWORD *)v7 - 3));
    v11 = (volatile signed __int32 *)(*a2 - 24LL);
    if ( _InterlockedExchangeAdd(v11 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v11 + 8LL))(*(_QWORD *)v11);
    return 1;
  }
  v17 = sub_14005F710((volatile signed __int32 *)(*a2 - 24LL)) + 24;
  if ( (unsigned int)sub_1401D3730(a1, &v17, v15) != 0 )
  {
    v8 = v7 - 6;
  }
  else
  {
    v9 = *(_QWORD *)(a1 + 288);
    if ( v9 == 0 || (v10 = *(_QWORD *)(v9 + 8LL * ((unsigned int)a3 % *(_DWORD *)(a1 + 304)))) == 0 )
    {
LABEL_11:
      sub_14018C080(a1 + 216, *a2, &v16);
      sub_1401D3E80(a1 + 288, &v16, *a2);
      goto LABEL_12;
    }
    while ( *(_DWORD *)(v10 + 24) != (_DWORD)a3 || *(_QWORD *)v10 != a3 )
    {
      v10 = *(_QWORD *)(v10 + 16);
      if ( v10 == 0 )
        goto LABEL_11;
    }
    sub_14006B500(&v14, (_BYTE **)(v10 + 8));
    v8 = v14 - 6;
  }
  if ( _InterlockedExchangeAdd(v8 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v8 + 8LL))(*(_QWORD *)v8);
  v13 = (volatile signed __int32 *)(*a2 - 24LL);
  if ( _InterlockedExchangeAdd(v13 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v13 + 8LL))(*(_QWORD *)v13);
  return 0;
}
