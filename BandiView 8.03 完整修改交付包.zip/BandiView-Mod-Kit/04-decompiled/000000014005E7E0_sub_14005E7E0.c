// EA 0x14005e7e0  name sub_14005E7E0  size 746
__int64 __fastcall sub_14005E7E0(__int64 a1, __int64 a2, __int64 a3)
{
  HWND v4; // rcx
  __int64 v6; // rbx
  __int64 v7; // rax
  int v8; // eax
  __int64 v9; // rcx
  __int64 v10; // rax
  HWND v11; // rax
  int v12; // r8d
  int nHeight; // eax
  int v14; // edx
  int v15; // r9d
  HWND v16; // rcx
  struct tagPOINT Point; // [rsp+48h] [rbp-30h] BYREF
  struct tagRECT Rect; // [rsp+50h] [rbp-28h] BYREF

  if ( a3 == 10 )
  {
    Point = 0;
    GetCursorPos(&Point);
    v4 = *(HWND *)(a1 + 8);
    Rect = 0;
    GetWindowRect(v4, &Rect);
    if ( !PtInRect(&Rect, Point) && (*(_DWORD *)(a1 + 2340))-- == 1 )
    {
      KillTimer(*(HWND *)(a1 + 8), 1u);
      SetTimer(*(HWND *)(a1 + 8), 2u, 0xAu, nullptr);
      GetWindowRect(*(HWND *)(a1 + 8), (LPRECT)(a1 + 2024));
    }
    return 0;
  }
  if ( a3 != 9 )
  {
    if ( a3 != 1 )
    {
      if ( a3 != 2 )
        return 0;
      *(_DWORD *)(a1 + 2028) += *(_DWORD *)(a1 + 2040);
      v12 = *(_DWORD *)(a1 + 2028);
      nHeight = *(_DWORD *)(a1 + 2036) - v12;
      if ( nHeight <= 0 )
      {
        KillTimer(*(HWND *)(a1 + 8), 2u);
        PostMessageW(*(HWND *)(a1 + 8), 0x10u, 0, 0);
        return 0;
      }
      v14 = *(_DWORD *)(a1 + 2024);
      v15 = *(_DWORD *)(a1 + 2032);
      v16 = *(HWND *)(a1 + 8);
LABEL_28:
      MoveWindow(v16, v14, v12, v15 - v14, nHeight, true);
      return 0;
    }
    *(_DWORD *)(a1 + 2028) -= *(_DWORD *)(a1 + 2040);
    v8 = *(_DWORD *)(a1 + 2012);
    if ( *(_DWORD *)(a1 + 2028) > v8 )
    {
LABEL_20:
      v12 = *(_DWORD *)(a1 + 2028);
      nHeight = *(_DWORD *)(a1 + 2036) - v12;
      v14 = *(_DWORD *)(a1 + 2024);
      v15 = *(_DWORD *)(a1 + 2032);
      v16 = *(HWND *)(a1 + 8);
      goto LABEL_28;
    }
    *(_DWORD *)(a1 + 2028) = v8;
    KillTimer(*(HWND *)(a1 + 8), 1u);
    if ( *(_BYTE *)(a1 + 2088) != 0 )
    {
      v9 = *(_QWORD *)(a1 + 2064);
      if ( v9 != 0 )
      {
        v11 = (HWND)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v9 + 72LL))(v9);
        goto LABEL_19;
      }
      v10 = *(_QWORD *)(a1 + 2072);
      if ( v10 == 0 )
      {
LABEL_18:
        v11 = nullptr;
LABEL_19:
        InvalidateRect(v11, nullptr, true);
        goto LABEL_20;
      }
    }
    else
    {
      v10 = a1 + 2096;
      if ( a1 == -2096 )
        goto LABEL_18;
    }
    v11 = *(HWND *)(v10 + 8);
    goto LABEL_19;
  }
  if ( *(_BYTE *)(a1 + 2320) != 0 || *(_BYTE *)(a1 + 2321) != 0 )
  {
    KillTimer(*(HWND *)(a1 + 8), 9u);
    MoveWindow(
      *(HWND *)(a1 + 8),
      *(_DWORD *)(a1 + 2024),
      *(_DWORD *)(a1 + 2028),
      *(_DWORD *)(a1 + 2032) - *(_DWORD *)(a1 + 2024),
      *(_DWORD *)(a1 + 2036) - *(_DWORD *)(a1 + 2028),
      true);
    SetTimer(*(HWND *)(a1 + 8), 1u, 0xAu, nullptr);
    if ( *(_BYTE *)(a1 + 80) == 0 )
      SetWindowPos(*(HWND *)(a1 + 8), nullptr, 0, 0, 0, 0, 0x57u);
  }
  else
  {
    v6 = *(_QWORD *)(a1 + 2328);
    v7 = GetTickCount64() - v6;
    if ( v7 <= 20000 )
    {
      sub_14006DB60(L"Wating AD... %dms", (unsigned int)v7);
    }
    else
    {
      PostMessageW(*(HWND *)(a1 + 8), 0x10u, 0, 0);
      sub_14006DB60(L"Wating AD - WM_CLOSE");
    }
  }
  return 0;
}
