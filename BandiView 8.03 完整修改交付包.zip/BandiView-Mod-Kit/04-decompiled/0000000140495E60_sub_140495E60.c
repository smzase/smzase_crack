// EA 0x140495e60  name sub_140495E60  size 95
void __fastcall sub_140495E60(_QWORD *lpMem)
{
  struct _SLIST_ENTRY *v1; // rdx
  void (__fastcall *v3)(_QWORD); // rax
  HANDLE ProcessHeap; // rax

  if ( lpMem != nullptr )
  {
    v1 = (struct _SLIST_ENTRY *)lpMem[1];
    if ( v1 != nullptr )
    {
      if ( *(_DWORD *)lpMem != 0 )
      {
        InterlockedPushEntrySList(qword_1407065A0, v1);
      }
      else
      {
        v3 = (void (__fastcall *)(_QWORD))sub_140495B38(&qword_1407065C0);
        if ( v3 != nullptr )
          v3(lpMem[1]);
      }
    }
    ProcessHeap = GetProcessHeap();
    HeapFree(ProcessHeap, 0, lpMem);
  }
}
