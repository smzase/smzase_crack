// EA 0x14007d7f0  name sub_14007D7F0  size 171
int **__fastcall sub_14007D7F0(int **a1)
{
  __int64 *v2; // rax
  int v3; // r8d
  WCHAR *v4; // rdx
  __int64 *v5; // rax

  if ( *((_BYTE *)sub_14007D5E0() + 56) != 0 )
  {
    v2 = sub_1400601C0();
    if ( v2 != nullptr )
    {
      *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
      if ( (unsigned __int8)sub_14005F980(a1, (__int64)&unk_140627008) == 0 )
      {
        v3 = 3;
        v4 = (WCHAR *)&unk_140627008;
LABEL_8:
        sub_14005FCF0(a1, v4, v3);
        return a1;
      }
      return a1;
    }
LABEL_10:
    sub_14005FF30(0x80004005);
  }
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    goto LABEL_10;
  *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
  if ( (unsigned __int8)sub_14005F980(a1, (__int64)L"BandiView") == 0 )
  {
    v3 = 9;
    v4 = (WCHAR *)L"BandiView";
    goto LABEL_8;
  }
  return a1;
}
