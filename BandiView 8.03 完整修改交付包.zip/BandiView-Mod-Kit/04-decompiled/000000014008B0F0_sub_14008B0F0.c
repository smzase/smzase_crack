// EA 0x14008b0f0  name sub_14008B0F0  size 257
__int64 __fastcall sub_14008B0F0(HWND hWnd, _BYTE **a2)
{
  volatile signed __int32 *v4; // rcx
  int *v5; // rbx
  __int64 v6; // rsi
  unsigned int v7; // ebx
  volatile signed __int32 *v8; // rdx
  LPARAM dwInitParam; // [rsp+20h] [rbp-E8h] BYREF
  int *v11[23]; // [rsp+28h] [rbp-E0h] BYREF

  sub_14008B4B0(&dwInitParam);
  v4 = (volatile signed __int32 *)(*a2 - 24);
  v5 = v11[0] - 6;
  if ( v4 != v11[0] - 6 )
  {
    if ( v5[4] >= 0 && *(_QWORD *)v4 == *(_QWORD *)v5 )
    {
      v6 = sub_14005F710(v4);
      if ( _InterlockedExchangeAdd(v5 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD, int *))(**(_QWORD **)v5 + 8LL))(*(_QWORD *)v5, v5);
      v11[0] = (int *)(v6 + 24);
    }
    else
    {
      sub_14005FCF0(v11, *a2, *((_DWORD *)*a2 - 4));
    }
  }
  v11[1] = (int *)(sub_14008ADD0() + 40);
  v7 = sub_14008B6C0((LPARAM)&dwInitParam, hWnd);
  sub_14008B5E0(&dwInitParam);
  v8 = (volatile signed __int32 *)(*a2 - 24);
  if ( _InterlockedExchangeAdd(v8 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v8 + 8LL))(*(_QWORD *)v8);
  return v7;
}
