// EA 0x140121bd0  name sub_140121BD0  size 114
int **__fastcall sub_140121BD0(__int64 a1, int **a2)
{
  __int64 *v4; // rax

  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  *a2 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( *(_QWORD *)(a1 + 112) != 0 )
    sub_14006B500(a2, (_BYTE **)(**(_QWORD **)(a1 + 104) + 16LL));
  return a2;
}
