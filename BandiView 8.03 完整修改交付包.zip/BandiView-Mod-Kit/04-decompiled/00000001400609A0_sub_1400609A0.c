// EA 0x1400609a0  name sub_1400609A0  size 388
__int64 *__fastcall sub_1400609A0(__int64 *a1, const void *a2, const void **a3)
{
  __int64 v6; // rcx
  __int64 v7; // rcx
  __int64 *v8; // rax
  __int64 v9; // r14
  const void *v10; // r13
  __int64 v11; // r12
  int v12; // ebp
  int v13; // edi
  __int64 v14; // rcx
  char *v15; // rsi
  __int64 v16; // r14
  size_t v17; // r8
  void *v18; // rcx
  size_t v19; // r8
  char *v20; // rcx

  *a1 = 0;
  v6 = *((_QWORD *)*a3 - 3);
  if ( v6 == 0 || (v7 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v6 + 32LL))(v6)) == 0 )
  {
    v8 = sub_1400601C0();
    v7 = (*(__int64 (__fastcall **)(__int64 *))(*v8 + 32))(v8);
  }
  if ( v7 == 0 )
    sub_14005FF30(0x80004005);
  v9 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v7 + 24LL))(v7) + 24;
  *a1 = v9;
  v10 = *a3;
  v11 = *((int *)*a3 - 4);
  if ( a2 != nullptr )
    v12 = sub_1404ADC20(a2);
  else
    v12 = 0;
  v13 = v11 + v12;
  if ( (int)v11 + v12 < 0 )
LABEL_26:
    sub_14005FF30(0x80070057);
  v14 = (unsigned int)(*(_DWORD *)(v9 - 12) - v13);
  if ( (int)(v14 | (1 - *(_DWORD *)(v9 - 8))) < 0 )
    sub_14005FC80(a1, v13);
  v15 = (char *)*a1;
  v16 = 2LL * v12;
  if ( v16 != 0 )
  {
    if ( v15 != nullptr )
    {
      v17 = 2LL * v12;
      v18 = (void *)*a1;
      if ( a2 != nullptr )
      {
        memcpy(v18, a2, v17);
        goto LABEL_17;
      }
      memset(v18, 0, v17);
    }
    *(_DWORD *)sub_1404A7740(v14) = 22;
    invalid_parameter_noinfo();
  }
LABEL_17:
  v19 = 2 * v11;
  if ( 2 * v11 != 0 )
  {
    v20 = &v15[v16];
    if ( &v15[v16] != nullptr )
    {
      if ( v10 != nullptr )
      {
        memcpy(v20, v10, v19);
        goto LABEL_23;
      }
      memset(v20, 0, v19);
    }
    *(_DWORD *)sub_1404A7740(v20) = 22;
    invalid_parameter_noinfo();
  }
LABEL_23:
  if ( v13 > *(_DWORD *)(*a1 - 12) )
    goto LABEL_26;
  *(_DWORD *)(*a1 - 16) = v13;
  *(_WORD *)(*a1 + 2LL * v13) = 0;
  return a1;
}
