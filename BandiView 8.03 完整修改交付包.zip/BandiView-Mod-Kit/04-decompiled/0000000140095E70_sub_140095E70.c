// EA 0x140095e70  name sub_140095E70  size 859
__int64 sub_140095E70(__int64 a1, __int64 a2, __int64 a3, ...)
{
  __int64 *v4; // rax
  __int64 *v5; // rax
  HWND *v6; // r12
  __int16 *v7; // rax
  __int64 v8; // rdi
  volatile signed __int32 *v9; // r15
  __int64 v10; // rbx
  volatile signed __int32 *v11; // r14
  __int64 v12; // rax
  char v13; // di
  __int64 v14; // rax
  __int64 v15; // rax
  _BYTE *v16; // rbx
  __int64 v17; // rax
  __int64 v18; // rax
  _BYTE *v19; // rbx
  int *v20; // rbx
  __int64 v21; // rax
  const void *v22; // rax
  __int64 *v23; // rax
  int v24; // ebx
  int *v25; // rdx
  const WCHAR *v26; // r8
  volatile signed __int32 *v27; // rdx
  volatile signed __int32 *v29; // [rsp+30h] [rbp-61h] BYREF
  int *v30; // [rsp+38h] [rbp-59h] BYREF
  __int64 v31; // [rsp+40h] [rbp-51h] BYREF
  _QWORD v32[5]; // [rsp+48h] [rbp-49h] BYREF
  __int64 v33; // [rsp+70h] [rbp-21h] BYREF
  int *v34; // [rsp+78h] [rbp-19h] BYREF
  __int64 v36; // [rsp+108h] [rbp+77h] BYREF
  va_list va; // [rsp+108h] [rbp+77h]
  __int64 v38; // [rsp+110h] [rbp+7Fh] BYREF
  va_list va1; // [rsp+110h] [rbp+7Fh]
  va_list va2; // [rsp+118h] [rbp+87h] BYREF

  va_start(va2, a3);
  va_start(va1, a3);
  va_start(va, a3);
  v36 = va_arg(va1, _QWORD);
  va_copy(va2, va1);
  v38 = va_arg(va2, _QWORD);
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v32[0] = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24;
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  v38 = (*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24;
  v6 = (HWND *)(a1 + 8);
  sub_140096450(a1 + 8, 1319, v32);
  sub_140096450(a1 + 8, 1320, (__int64 *)va1);
  v36 = 0;
  v32[2] = &v30;
  v7 = sub_140075FE0();
  v30 = (int *)(sub_14005F710((volatile signed __int32 *)(*((_QWORD *)v7 + 68) - 24LL)) + 24);
  v32[3] = &v31;
  v8 = v38;
  v9 = (volatile signed __int32 *)(v38 - 24);
  v31 = sub_14005F710((volatile signed __int32 *)(v38 - 24)) + 24;
  v10 = v32[0];
  v11 = (volatile signed __int32 *)(v32[0] - 24LL);
  v29 = (volatile signed __int32 *)(sub_14005F710((volatile signed __int32 *)(v32[0] - 24LL)) + 24);
  if ( (unsigned __int8)sub_1400969B0(&v29, &v31, &v30, (__int64 *)va) != 0 )
  {
    EndDialog(*v6, 1);
  }
  else
  {
    if ( *(_DWORD *)(v8 - 16) != 38
      || *(int *)(v10 - 16) < 0
      || (v12 = sub_1404A27AC(v10, L"@")) == 0
      || (v13 = 1, (int)((v12 - v10) >> 1) <= 0) )
    {
      v13 = 0;
    }
    sub_140072490(&v29, (__int64)L"\n\n(License Error Code: 0x%x-%u)", (unsigned int)v36, HIDWORD(v36));
    sub_14008AA40((int **)&v33);
    v14 = sub_1401C5640();
    v15 = sub_1401C81E0(v14, L"TEXT_MESSAGEBOX_OK", L"TEXT");
    v16 = (_BYTE *)v15;
    if ( v15 != 0 )
      LODWORD(v15) = sub_1404ADC20(v15);
    sub_14005FCF0((int **)&v33, v16, v15);
    v17 = sub_1401C5640();
    v18 = sub_1401C81E0(v17, L"TEXT_MESSAGEBOX_HELP", L"TEXT");
    v19 = (_BYTE *)v18;
    if ( v18 != 0 )
      LODWORD(v18) = sub_1404ADC20(v18);
    sub_14005FCF0(&v34, v19, v18);
    v20 = *sub_14007D7F0(&v30);
    v21 = sub_1401C5640();
    v22 = (const void *)sub_1401C81E0(v21, L"TEXT_REGISTRATION_FAILED", L"TEXT");
    v23 = sub_1400609A0(&v31, v22, (const void **)&v29);
    v24 = sub_14008B200(*v6, (_BYTE **)v23, (__int64)v20, 1, (int *)&v33);
    v25 = v30 - 6;
    if ( _InterlockedExchangeAdd(v30 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v25 + 8LL))(*(_QWORD *)v25);
    if ( v24 == 2 )
    {
      v26 = L"https://www.bandisoft.com/kb/xx-12157/";
      if ( HIDWORD(v36) != 12157 )
        v26 = L"https://www.bandisoft.com/bandiview/help/registration-failed/";
      ShellExecuteW(nullptr, L"open", v26, nullptr, nullptr, 1);
    }
    if ( v13 != 0 )
      EndDialog(*v6, 2);
    if ( *(_BYTE *)(a1 + 240) != 0 )
      EndDialog(*v6, 2);
    sub_14008ACB0(&v33);
    v27 = v29 - 6;
    if ( _InterlockedExchangeAdd(v29 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v27 + 8LL))(*(_QWORD *)v27);
  }
  if ( _InterlockedExchangeAdd(v9 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v9 + 8LL))(*(_QWORD *)v9, v9);
  if ( _InterlockedExchangeAdd(v11 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v11 + 8LL))(*(_QWORD *)v11, v11);
  return 0;
}
