// EA 0x140065730  name sub_140065730  size 952
__int64 __fastcall sub_140065730(__int64 a1, const WCHAR *a2)
{
  unsigned int v4; // esi
  __int64 v5; // r8
  __int64 v6; // rax
  __int64 v7; // rax
  __int64 v8; // rbx
  __int64 *v9; // rax
  __int64 *v10; // rax
  __int64 v11; // rax
  LPCWSTR *v12; // rax
  int *v13; // rdx
  __int64 v14; // rbx
  __int64 *v15; // rax
  __int64 v16; // rax
  __int64 v17; // rbx
  __int64 v18; // rcx
  _QWORD *v19; // rdx
  _QWORD *v20; // rdx
  __int64 v21; // rcx
  int *v22; // [rsp+30h] [rbp-D0h] BYREF
  int **v23; // [rsp+38h] [rbp-C8h]
  int v24; // [rsp+40h] [rbp-C0h] BYREF
  char *v25; // [rsp+48h] [rbp-B8h] BYREF
  char *v26; // [rsp+68h] [rbp-98h] BYREF
  char *v27; // [rsp+88h] [rbp-78h] BYREF
  _BYTE v28[16]; // [rsp+A8h] [rbp-58h] BYREF
  void *Block; // [rsp+B8h] [rbp-48h]
  _BYTE v30[24]; // [rsp+C8h] [rbp-38h] BYREF
  __int64 v31; // [rsp+E0h] [rbp-20h]
  __int64 v32; // [rsp+E8h] [rbp-18h]

  if ( (unsigned int)sub_140066F10() == 0 )
    return 10;
  sub_140065490((__int64)&v24);
  sub_1400869A0(a2, &v24);
  v4 = sub_140067D60(&v24);
  if ( v4 == 999999 )
  {
    if ( v24 == 17 )
    {
      v4 = sub_1400651F0();
LABEL_26:
      sub_14019BB00();
      v17 = sub_140075FE0();
      sub_140065D40(v18, *(_QWORD *)(v17 + 56));
      **(_QWORD **)(v17 + 56) = *(_QWORD *)(v17 + 56);
      *(_QWORD *)(*(_QWORD *)(v17 + 56) + 8LL) = *(_QWORD *)(v17 + 56);
      *(_QWORD *)(v17 + 64) = 0;
      sub_14007A100(v17 + 280);
      goto LABEL_27;
    }
    if ( v24 == 3 )
    {
      v4 = sub_14019B780(0, &v24);
LABEL_25:
      v16 = sub_14019BB00();
      sub_14019C680(v16);
      goto LABEL_26;
    }
    sub_140065210((__int64)a2, &v24, v5);
    v4 = sub_140089C30(a2);
    if ( *(_BYTE *)(sub_14007D5E0() + 112) != 0 )
    {
      if ( *(_BYTE *)(sub_14007D5E0() + 112) != 0 )
      {
        v6 = sub_140075FE0();
        sub_140076800(v6);
        v7 = sub_14019BB00();
        sub_14019BC50(v7);
      }
      v8 = sub_140075FE0();
      v23 = &v22;
      v9 = sub_1400601C0();
      if ( v9 == nullptr )
        sub_14005FF30(0x80004005);
      v22 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
      if ( (unsigned __int8)sub_14005F980(&v22, (__int64)&Data) == 0 )
        sub_14005FCF0(&v22, &Data, 0);
    }
    else
    {
      if ( *(_BYTE *)(sub_14007D5E0() + 113) == 0 )
      {
        v14 = sub_140075FE0();
        v23 = &v22;
        v15 = sub_1400601C0();
        if ( v15 == nullptr )
          sub_14005FF30(0x80004005);
        v22 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
        if ( (unsigned __int8)sub_14005F980(&v22, (__int64)&Data) == 0 )
          sub_14005FCF0(&v22, &Data, 0);
        sub_140076F50(v14, 1, &v22);
        goto LABEL_25;
      }
      v8 = sub_140075FE0();
      v23 = &v22;
      v10 = sub_1400601C0();
      if ( v10 == nullptr )
        sub_14005FF30(0x80004005);
      v22 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24);
      if ( (unsigned __int8)sub_14005F980(&v22, (__int64)&Data) == 0 )
        sub_14005FCF0(&v22, &Data, 0);
    }
    sub_140076F50(v8, 1, &v22);
    v11 = sub_14019BB00();
    sub_14019C680(v11);
    v12 = (LPCWSTR *)sub_14006EAE0(&v22);
    ShellExecuteW(nullptr, L"Open", *v12, nullptr, nullptr, 5);
    v13 = v22 - 6;
    if ( _InterlockedExchangeAdd(v22 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v13 + 8LL))(*(_QWORD *)v13);
    goto LABEL_26;
  }
LABEL_27:
  v19 = (_QWORD *)(v32 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v32 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v19 + 8LL))(*v19);
  v20 = (_QWORD *)(v31 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v31 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v20 + 8LL))(*v20);
  sub_140065BD0(v30);
  sub_140065D40(v21, Block);
  j_j_j__free_base(Block);
  sub_140065CE0(v28);
  sub_14005D410(&v27);
  sub_14005D410(&v26);
  sub_14005D410(&v25);
  return v4;
}
