// EA 0x140065bd0  name sub_140065BD0  size 109
void __fastcall sub_140065BD0(void **a1)
{
  _QWORD **v2; // rcx
  _QWORD *v3; // rdi
  _QWORD *v4; // rbx

  v2 = (_QWORD **)*a1;
  *v2[1] = 0;
  v3 = *v2;
  if ( *v2 != nullptr )
  {
    do
    {
      v4 = (_QWORD *)*v3;
      sub_140065CE0(v3 + 2);
      j_j_j__free_base(v3);
      v3 = v4;
    }
    while ( v4 != nullptr );
  }
  j_j_j__free_base(*a1);
}
