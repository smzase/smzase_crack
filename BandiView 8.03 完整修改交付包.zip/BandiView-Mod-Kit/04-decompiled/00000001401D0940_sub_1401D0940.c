// EA 0x1401d0940  name sub_1401D0940  size 311
void __fastcall sub_1401D0940(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *i; // rbx
  __int64 v4; // rbp
  _QWORD *v5; // rdi
  __int64 **v6; // rcx
  __int64 j; // rax
  __int64 *k; // rcx

  v1 = *(_QWORD *)(a1 + 32);
  for ( i = *(_QWORD **)v1; i != (_QWORD *)v1; v1 = *(_QWORD *)(a1 + 32) )
  {
    v4 = i[8];
    if ( v4 != 0 )
    {
      v5 = *(_QWORD **)(v4 + 32);
      sub_1401D24B0(v4 + 32, v4 + 32, v5[1]);
      v5[1] = v5;
      *v5 = v5;
      v5[2] = v5;
      *(_QWORD *)(v4 + 40) = 0;
      sub_1401D24B0(v4 + 32, v4 + 32, *(_QWORD *)(*(_QWORD *)(v4 + 32) + 8LL));
      j_j_j__free_base(*(void **)(v4 + 32));
      sub_14007F110(v4);
      j_j_j__free_base((void *)v4);
    }
    v6 = (__int64 **)i[2];
    if ( *((_BYTE *)v6 + 25) != 0 )
    {
      for ( j = i[1]; *(_BYTE *)(j + 25) == 0; j = *(_QWORD *)(j + 8) )
      {
        if ( i != *(_QWORD **)(j + 16) )
          break;
        i = (_QWORD *)j;
      }
      i = (_QWORD *)j;
    }
    else
    {
      i = (_QWORD *)i[2];
      for ( k = *v6; *((_BYTE *)k + 25) == 0; k = (__int64 *)*k )
        i = k;
    }
  }
  sub_1401067C0(a1 + 32, a1 + 32, *(char **)(v1 + 8));
  *(_QWORD *)(v1 + 8) = v1;
  *(_QWORD *)v1 = v1;
  *(_QWORD *)(v1 + 16) = v1;
  *(_QWORD *)(a1 + 40) = 0;
  *(_BYTE *)(a1 + 2) = 0;
}
