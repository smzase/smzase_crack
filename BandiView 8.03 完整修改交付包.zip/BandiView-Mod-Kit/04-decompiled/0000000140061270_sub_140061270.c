// EA 0x140061270  name sub_140061270  size 219
__int64 __fastcall sub_140061270(char **a1, const void *a2, unsigned __int64 a3)
{
  __int64 v3; // rsi
  __int64 v7; // rbx
  __int64 v9; // rcx
  char *v10; // rax
  size_t v11; // rbx
  char *v12; // rdi

  v3 = 0x7FFFFFFFFFFFFFFELL;
  if ( a3 > 0x7FFFFFFFFFFFFFFELL )
    unknown_libname_3();
  if ( a3 > 7 )
  {
    if ( (a3 | 7) <= 0x7FFFFFFFFFFFFFFELL )
    {
      v3 = a3 | 7;
      if ( (a3 | 7) < 0xA )
        v3 = 10;
      v9 = v3 + 1;
      if ( (unsigned __int64)(v3 + 1) > 0x7FFFFFFFFFFFFFFFLL )
      {
        sub_14005D3C0();
        JUMPOUT(0x14006134ALL);
      }
    }
    else
    {
      v9 = 0x7FFFFFFFFFFFFFFFLL;
    }
    v10 = (char *)sub_14005D1E0(2 * v9);
    a1[2] = (char *)a3;
    v11 = 2 * a3;
    *a1 = v10;
    a1[3] = (char *)v3;
    v12 = v10;
    memcpy(v10, a2, v11);
    *(_WORD *)&v12[v11] = 0;
    return 0;
  }
  else
  {
    a1[2] = (char *)a3;
    v7 = 2 * a3;
    a1[3] = (char *)7;
    memcpy(a1, a2, 2 * a3);
    *(_WORD *)((char *)a1 + v7) = 0;
    return 0;
  }
}
