// EA 0x140098660  name sub_140098660  size 170
__int64 __fastcall sub_140098660(__int64 a1, int a2)
{
  void *v4; // rax

  *(_QWORD *)(a1 + 8) = 0;
  *(_QWORD *)(a1 + 40) = 0;
  *(_QWORD *)(a1 + 48) = 0;
  *(_DWORD *)(a1 + 56) = 0;
  *(_QWORD *)a1 = &CLicenseGuideDlg::`vftable';
  *(_QWORD *)(a1 + 64) = &CLicenseGuideDlg::`vftable';
  *(_QWORD *)(a1 + 88) = 0;
  *(_QWORD *)(a1 + 120) = 0;
  *(_QWORD *)(a1 + 128) = 0;
  *(_DWORD *)(a1 + 136) = 0;
  *(_QWORD *)(a1 + 144) = DefWindowProcW;
  *(_QWORD *)(a1 + 80) = &CSkinnedWindow::`vftable';
  *(_DWORD *)(a1 + 172) = 0;
  *(_QWORD *)(a1 + 152) = 0;
  v4 = operator new(0x780u);
  *(_QWORD *)(a1 + 160) = sub_1401B9500(v4);
  *(_DWORD *)(a1 + 168) = 0;
  *(_DWORD *)(a1 + 72) = a2;
  return a1;
}
