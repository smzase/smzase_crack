// EA 0x1400ca010  name sub_1400CA010  size 3049
char __fastcall sub_1400CA010(int a1, int **a2, __int64 *a3, _QWORD *a4, _DWORD *a5, int **a6)
{
  unsigned int v9; // ebx
  __int64 *v10; // rax
  __int64 *v11; // rax
  __int64 v12; // rdi
  __int64 v13; // rsi
  __int64 v14; // rbx
  _QWORD *v15; // rax
  int **v16; // rdx
  int *v17; // rdx
  int **v18; // rdi
  __int64 v19; // rbx
  __int64 *v20; // rax
  const WCHAR *v21; // r15
  _DWORD *v22; // rcx
  __int64 v23; // rbx
  __int64 *v24; // rax
  __int64 *v25; // rax
  __int64 v26; // rbx
  _DWORD *v27; // rax
  __int64 *v28; // rax
  __int64 *v29; // rax
  _DWORD *v30; // rax
  LPSTR v31; // rdx
  volatile signed __int32 *v32; // rbx
  int v33; // edx
  _DWORD *v34; // rax
  __int64 *v35; // rax
  __int64 *v36; // rax
  __int64 *v37; // rax
  int **v38; // r12
  __int64 v39; // r14
  int **v40; // r15
  __int64 *v41; // rax
  __int64 v42; // r15
  int **v43; // rdi
  __int64 v44; // rax
  int *v45; // rdx
  _QWORD *v46; // rdx
  _QWORD *v47; // rdx
  _QWORD *v48; // rdx
  _QWORD *v49; // rdx
  _QWORD *v50; // rdx
  volatile signed __int32 *v51; // rdx
  volatile signed __int32 *v52; // rdx
  volatile signed __int32 *v53; // rdx
  _DWORD *v55; // rax
  _QWORD *v56; // rdx
  _QWORD *v57; // rdx
  _QWORD *v58; // rdx
  _QWORD *v59; // rdx
  _QWORD *v60; // rdx
  __int64 v61; // rdx
  _DWORD *v62; // rax
  int **v63; // rdx
  _QWORD *v64; // rdx
  _QWORD *v65; // rdx
  _QWORD *v66; // rdx
  _QWORD *v67; // rdx
  _QWORD *v68; // rdx
  volatile signed __int32 *v69; // rdx
  volatile signed __int32 *v70; // rdx
  volatile signed __int32 *v71; // rdx
  int **v72; // [rsp+40h] [rbp-C0h] BYREF
  int *v73; // [rsp+48h] [rbp-B8h] BYREF
  volatile signed __int32 *v74; // [rsp+50h] [rbp-B0h] BYREF
  int **v75; // [rsp+58h] [rbp-A8h] BYREF
  __int64 v76; // [rsp+60h] [rbp-A0h] BYREF
  __int64 v77; // [rsp+68h] [rbp-98h] BYREF
  __int64 v78; // [rsp+70h] [rbp-90h] BYREF
  int **v79; // [rsp+78h] [rbp-88h]
  __int64 v80; // [rsp+80h] [rbp-80h] BYREF
  _QWORD v81[5]; // [rsp+90h] [rbp-70h] BYREF
  __int64 v82; // [rsp+B8h] [rbp-48h]
  _BYTE v83[128]; // [rsp+E0h] [rbp-20h] BYREF
  __int64 v84; // [rsp+160h] [rbp+60h]
  int v85; // [rsp+168h] [rbp+68h]
  int v86; // [rsp+16Ch] [rbp+6Ch]
  __int64 v87; // [rsp+178h] [rbp+78h]
  void *Block; // [rsp+180h] [rbp+80h]
  int v89; // [rsp+188h] [rbp+88h]
  __int64 v90; // [rsp+190h] [rbp+90h]
  __int64 v91; // [rsp+198h] [rbp+98h]
  int v92; // [rsp+1A0h] [rbp+A0h]
  int v93; // [rsp+200h] [rbp+100h] BYREF
  int **v94; // [rsp+208h] [rbp+108h]
  __int64 *v95; // [rsp+210h] [rbp+110h]
  _QWORD *v96; // [rsp+218h] [rbp+118h]

  v96 = a4;
  v95 = a3;
  v94 = a2;
  v93 = a1;
  v9 = sub_1400CCC00();
  sub_14007A820(v81);
  v74 = nullptr;
  v10 = sub_1400601C0();
  if ( v10 == nullptr )
    sub_14005FF30(0x80004005);
  v80 = (*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24;
  sub_140072490(&v77, (__int64)L"%08x", v9);
  v11 = sub_1400601C0();
  if ( v11 == nullptr )
    sub_14005FF30(0x80004005);
  v76 = (*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24;
  sub_140060CB0(a3);
  v12 = *a3;
  v13 = v77;
  v14 = *(_QWORD *)sub_1400723B0(&v72, a2[1]);
  v15 = (_QWORD *)sub_1400723B0(&v75, *a2);
  sub_14005EB50(
    (__int64)&v80,
    (__int64)L"email=%s&productKey=%s&hid=%s&lang=%s&appid=%s",
    *v15,
    v14,
    v13,
    v12,
    L"bandiview");
  v16 = v75 - 3;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v75 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(int *))(*(_QWORD *)*v16 + 8LL))(*v16);
  v17 = (int *)(v72 - 3);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v72 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v17 + 8LL))(*(_QWORD *)v17);
  v18 = a6;
  if ( *(*a6 - 4) == 0 )
    sub_14005FCF0(a6, L"https://secure.bandisoft.com/uni.app/checkProductKey.php", 56);
  v19 = *a4;
  v72 = &v73;
  v20 = sub_1400601C0();
  if ( v20 == nullptr )
    sub_14005FF30(0x80004005);
  v21 = (const WCHAR *)v80;
  v73 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v20 + 24))(v20) + 24);
  if ( (unsigned __int8)sub_140073860((LPSTR *)&v73, (__int64)v21) == 0 )
    sub_140097550((LPSTR *)&v73, v21);
  v75 = (int **)(sub_14005F710(*v18 - 6) + 24);
  if ( (unsigned int)sub_14007B8E0(
                       (unsigned int)&v75,
                       (unsigned int)&v73,
                       (unsigned int)&v76,
                       v19,
                       (__int64)v81,
                       (__int64)&v74) == 0 )
  {
    if ( HIDWORD(v74) == 12157 )
    {
      v22 = a5;
      *a5 = (_DWORD)v74;
      v22[1] = 12157;
LABEL_116:
      v65 = (_QWORD *)(v76 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v76 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v65 + 8LL))(*v65);
      v66 = (_QWORD *)(v77 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v77 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v66 + 8LL))(*v66);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)v21 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v21 - 3) + 8LL))(*((_QWORD *)v21 - 3));
      v67 = (_QWORD *)(v82 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v82 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v67 + 8LL))(*v67);
      v68 = (_QWORD *)(v81[0] - 24LL);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v81[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v68 + 8LL))(*v68);
      v61 = *a3;
LABEL_127:
      v69 = (volatile signed __int32 *)(v61 - 24);
      if ( _InterlockedExchangeAdd(v69 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v69 + 8LL))(*(_QWORD *)v69);
      v70 = (volatile signed __int32 *)(*a4 - 24LL);
      if ( _InterlockedExchangeAdd(v70 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v70 + 8LL))(*(_QWORD *)v70);
      v71 = *v18 - 6;
      if ( _InterlockedExchangeAdd(v71 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v71 + 8LL))(*(_QWORD *)v71);
      return 0;
    }
    v72 = nullptr;
    v23 = *a4;
    v79 = (int **)&v74;
    v24 = sub_1400601C0();
    if ( v24 == nullptr )
      sub_14005FF30(0x80004005);
    v74 = (volatile signed __int32 *)((*(__int64 (__fastcall **)(__int64 *))(*v24 + 24))(v24) + 24);
    if ( (unsigned __int8)sub_140073860((LPSTR *)&v74, (__int64)v21) == 0 )
      sub_140097550((LPSTR *)&v74, v21);
    v75 = &v73;
    v25 = sub_1400601C0();
    if ( v25 == nullptr )
      sub_14005FF30(0x80004005);
    v73 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v25 + 24))(v25) + 24);
    if ( (unsigned __int8)sub_14005F980(
                            &v73,
                            (__int64)L"https://secure-backup.bandisoft.com/uni.app/checkProductKey.php") == 0 )
      sub_14005FCF0(&v73, L"https://secure-backup.bandisoft.com/uni.app/checkProductKey.php", 63);
    if ( (unsigned int)sub_14007B8E0(
                         (unsigned int)&v73,
                         (unsigned int)&v74,
                         (unsigned int)&v76,
                         v23,
                         (__int64)v81,
                         (__int64)&v72) == 0 )
    {
      *(_QWORD *)a5 = v72;
      goto LABEL_116;
    }
  }
  v79 = (int **)&v72;
  v26 = sub_1400C9B00(&v72, &v76);
  v75 = (int **)(sub_14005F710((volatile signed __int32 *)(*a4 - 24LL)) + 24);
  sub_1400C9840(&v78, &v75, v26);
  sub_1401FC5F0(v83);
  Block = nullptr;
  v86 = 4;
  v84 = 0;
  v87 = 0;
  v85 = 1;
  v89 = 0;
  sub_1401FC770(v83);
  if ( Block != nullptr )
    j__free_base(Block);
  Block = nullptr;
  v90 = 0;
  v91 = 0;
  v92 = 0;
  if ( (unsigned int)sub_1401FCDB0(v83, v78) == 0 )
  {
    v27 = a5;
    a5[1] = 0;
    *v27 = -1159778029;
LABEL_27:
    if ( Block != nullptr )
      j__free_base(Block);
    Block = nullptr;
LABEL_114:
    sub_1401FC700(v83);
    v64 = (_QWORD *)(v78 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v78 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v64 + 8LL))(*v64);
    goto LABEL_116;
  }
  v28 = sub_1400601C0();
  if ( v28 == nullptr )
    sub_14005FF30(0x80004005);
  v74 = (volatile signed __int32 *)((*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24);
  v79 = (int **)&v72;
  v29 = sub_1400601C0();
  if ( v29 == nullptr )
    sub_14005FF30(0x80004005);
  v72 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v29 + 24))(v29) + 24);
  if ( (unsigned __int8)sub_14005F980(&v72, (__int64)L"result") == 0 )
    sub_14005FCF0((int **)&v72, L"result", 6);
  if ( (unsigned int)sub_1400C9F50(v83, &v72, &v74) == 0 )
  {
    v30 = a5;
    a5[1] = 0;
    *v30 = -1159778028;
    v31 = (LPSTR)(v74 - 6);
    if ( _InterlockedExchangeAdd(v74 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v31 + 8LL))(*(_QWORD *)v31);
    goto LABEL_27;
  }
  v32 = v74;
  v33 = *(unsigned __int16 *)v74 - 111;
  if ( *(_WORD *)v74 == 111 )
  {
    v33 = *((unsigned __int16 *)v74 + 1) - 107;
    if ( *((_WORD *)v74 + 1) == 107 )
      v33 = *((unsigned __int16 *)v74 + 2);
  }
  if ( v33 != 0 )
  {
    v34 = a5;
    a5[1] = 0;
    *v34 = -1159777532;
    if ( _InterlockedExchangeAdd(v32 - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v32 - 3) + 8LL))(*((_QWORD *)v32 - 3));
    if ( Block != nullptr )
      j__free_base(Block);
    Block = nullptr;
    goto LABEL_114;
  }
  v35 = sub_1400601C0();
  if ( v35 == nullptr )
    sub_14005FF30(0x80004005);
  v75 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v35 + 24))(v35) + 24);
  v79 = (int **)&v72;
  v36 = sub_1400601C0();
  if ( v36 == nullptr )
    sub_14005FF30(0x80004005);
  v72 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v36 + 24))(v36) + 24);
  if ( (unsigned __int8)sub_14005F980(&v72, (__int64)L"guid") == 0 )
    sub_14005FCF0((int **)&v72, L"guid", 4);
  if ( (unsigned int)sub_1400C9F50(v83, &v72, &v75) != 0 )
  {
    v79 = (int **)&v72;
    v37 = sub_1400601C0();
    if ( v37 == nullptr )
      sub_14005FF30(0x80004005);
    v72 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v37 + 24))(v37) + 24);
    if ( (unsigned __int8)sub_14005F980(&v72, (__int64)L"productID") == 0 )
      sub_14005FCF0((int **)&v72, L"productID", 9);
    if ( (unsigned int)sub_1400C9F50(v83, &v72, a2 + 4) != 0 )
    {
      v38 = v75;
      if ( (unsigned int)(*((_DWORD *)v75 - 4) - 32) >= 2 )
      {
        v55 = a5;
        a5[1] = 0;
        *v55 = -1159778028;
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)v38 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*(v38 - 3) + 8LL))(*(v38 - 3));
        if ( _InterlockedExchangeAdd(v32 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v32 - 3) + 8LL))(*((_QWORD *)v32 - 3));
        if ( Block != nullptr )
          j__free_base(Block);
        Block = nullptr;
        sub_1401FC700(v83);
        v56 = (_QWORD *)(v78 - 24);
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v78 - 24 + 16), 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v56 + 8LL))(*v56);
        v57 = (_QWORD *)(v76 - 24);
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v76 - 24 + 16), 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v57 + 8LL))(*v57);
        v58 = (_QWORD *)(v77 - 24);
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v77 - 24 + 16), 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v58 + 8LL))(*v58);
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)v21 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v21 - 3) + 8LL))(*((_QWORD *)v21 - 3));
        v59 = (_QWORD *)(v82 - 24);
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v82 - 24 + 16), 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v59 + 8LL))(*v59);
        v60 = (_QWORD *)(v81[0] - 24LL);
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v81[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v60 + 8LL))(*v60);
        v61 = *v95;
        goto LABEL_127;
      }
      v39 = 0;
      v40 = v94;
      do
      {
        sub_14006B720((wchar_t *)v38 + 2 * v39, (wchar_t *)L"%02x", &v93);
        *((_BYTE *)v40 + v39 + 40) = v93;
        v39 = (unsigned int)(v39 + 1);
      }
      while ( (int)v39 < 16 );
      v79 = &v73;
      v41 = sub_1400601C0();
      v42 = v80;
      if ( v41 == nullptr )
        sub_14005FF30(0x80004005);
      v73 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v41 + 24))(v41) + 24);
      if ( (unsigned __int8)sub_14005F980(&v73, (__int64)L"ONLINE") == 0 )
        sub_14005FCF0(&v73, L"ONLINE", 6);
      v79 = &v73;
      v43 = v94;
      sub_14006B500(v94 + 7, (_BYTE **)&v73);
      v44 = unknown_libname_553(0);
      sub_14005EB50((__int64)(v43 + 8), (__int64)L"%I64d", v44);
      v45 = v73 - 6;
      if ( _InterlockedExchangeAdd(v73 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v45 + 8LL))(*(_QWORD *)v45);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)v38 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*(v38 - 3) + 8LL))(*(v38 - 3));
      if ( _InterlockedExchangeAdd(v32 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v32 - 3) + 8LL))(*((_QWORD *)v32 - 3));
      if ( Block != nullptr )
        j__free_base(Block);
      Block = nullptr;
      sub_1401FC700(v83);
      v46 = (_QWORD *)(v78 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v78 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v46 + 8LL))(*v46);
      v47 = (_QWORD *)(v76 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v76 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v47 + 8LL))(*v47);
      v48 = (_QWORD *)(v77 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v77 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v48 + 8LL))(*v48);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v42 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v42 - 24) + 8LL))(*(_QWORD *)(v42 - 24));
      v49 = (_QWORD *)(v82 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v82 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v49 + 8LL))(*v49);
      v50 = (_QWORD *)(v81[0] - 24LL);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v81[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v50 + 8LL))(*v50);
      v51 = (volatile signed __int32 *)(*v95 - 24);
      if ( _InterlockedExchangeAdd(v51 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v51 + 8LL))(*(_QWORD *)v51);
      v52 = (volatile signed __int32 *)(*a4 - 24LL);
      if ( _InterlockedExchangeAdd(v52 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v52 + 8LL))(*(_QWORD *)v52);
      v53 = *a6 - 6;
      if ( _InterlockedExchangeAdd(v53 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v53 + 8LL))(*(_QWORD *)v53);
      return 1;
    }
  }
  v62 = a5;
  a5[1] = 0;
  *v62 = -1159778028;
  v63 = v75 - 3;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)v75 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(int *))(*(_QWORD *)*v63 + 8LL))(*v63);
  if ( _InterlockedExchangeAdd(v32 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v32 - 3) + 8LL))(*((_QWORD *)v32 - 3));
  if ( Block != nullptr )
    j__free_base(Block);
  Block = nullptr;
  goto LABEL_114;
}
