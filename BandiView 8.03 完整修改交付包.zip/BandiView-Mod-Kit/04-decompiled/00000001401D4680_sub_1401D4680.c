// EA 0x1401d4680  name sub_1401D4680  size 116
int *sub_1401D4680()
{
  if ( dword_14071EF70 > *(_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL) )
  {
    sub_140496500(&dword_14071EF70);
    if ( dword_14071EF70 == -1 )
    {
      dword_14071EF78 = 0;
      dword_14071EF7C = -1;
      byte_14071EF80 = 0;
      atexit(nullsub_5);
      Init_thread_footer(&dword_14071EF70);
    }
  }
  return &dword_14071EF78;
}
