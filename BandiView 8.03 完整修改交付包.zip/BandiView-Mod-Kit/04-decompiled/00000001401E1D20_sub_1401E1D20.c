// EA 0x1401e1d20  name sub_1401E1D20  size 108
__int64 __fastcall sub_1401E1D20(__int64 a1)
{
  void *v3; // [rsp+38h] [rbp+10h]

  *(_QWORD *)(a1 + 8) = 0;
  *(_QWORD *)(a1 + 40) = 0;
  *(_QWORD *)(a1 + 48) = 0;
  *(_DWORD *)(a1 + 56) = 0;
  *(_QWORD *)(a1 + 64) = DefWindowProcW;
  *(_QWORD *)a1 = &CSkinnedWindow::`vftable';
  *(_DWORD *)(a1 + 92) = 0;
  *(_QWORD *)(a1 + 72) = 0;
  v3 = operator new(0x780u);
  *(_QWORD *)(a1 + 80) = sub_1401B9500((__int64)v3);
  *(_DWORD *)(a1 + 88) = 0;
  return a1;
}
