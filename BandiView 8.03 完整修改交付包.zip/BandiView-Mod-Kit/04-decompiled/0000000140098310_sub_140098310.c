// EA 0x140098310  name sub_140098310  size 180
_BOOL8 __fastcall sub_140098310(__int64 a1, const WCHAR *a2)
{
  HANDLE v4; // rax
  DWORD v5; // eax
  LPVOID v7; // rax
  DWORD LastError; // ebx

  ((void (*)(void))sub_1400983D0)();
  v4 = OpenFileMappingW(0xF001Fu, false, a2);
  *(_QWORD *)(a1 + 8) = v4;
  if ( v4 != nullptr )
  {
    v7 = MapViewOfFile(v4, 0xF001Fu, 0, 0, 0);
    *(_QWORD *)(a1 + 24) = v7;
    if ( v7 != nullptr )
    {
      return (unsigned __int8)sub_140098430(a1) != 0;
    }
    else
    {
      LastError = GetLastError();
      sub_1400983D0(a1);
      *(_DWORD *)(a1 + 32) = -1160183805;
      *(_DWORD *)(a1 + 36) = LastError;
      return false;
    }
  }
  else
  {
    v5 = GetLastError();
    *(_DWORD *)(a1 + 32) = -1160183806;
    *(_DWORD *)(a1 + 36) = v5;
    return false;
  }
}
