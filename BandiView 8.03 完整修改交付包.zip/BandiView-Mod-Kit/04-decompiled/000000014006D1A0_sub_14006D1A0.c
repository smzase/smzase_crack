// EA 0x14006d1a0  name sub_14006D1A0  size 235
__int64 __fastcall sub_14006D1A0(__int64 a1)
{
  __int64 result; // rax
  int (__fastcall ***v3)(_QWORD, void *, __int64 *); // rcx
  __int64 v4; // rsi
  _QWORD *v5; // rbx
  _QWORD *v6; // rax
  unsigned int v7; // edi
  __int64 v8; // [rsp+40h] [rbp+8h] BYREF
  __int64 v9; // [rsp+48h] [rbp+10h] BYREF
  int (__fastcall ***v10)(_QWORD, void *, __int64 *); // [rsp+50h] [rbp+18h] BYREF

  v10 = nullptr;
  result = (*(__int64 (__fastcall **)(_QWORD, int (__fastcall ****)(_QWORD, void *, __int64 *)))(**(_QWORD **)(a1 + 32)
                                                                                               + 144LL))(
             *(_QWORD *)(a1 + 32),
             &v10);
  v3 = v10;
  if ( v10 != nullptr )
  {
    v4 = a1 + 64;
    v5 = *(_QWORD **)(a1 + 64);
    while ( v5 != nullptr )
    {
      v6 = v5;
      v5 = (_QWORD *)*v5;
      if ( v3 != nullptr )
      {
        v7 = *((_DWORD *)v6 + 4);
        v9 = 0;
        v8 = 0;
        if ( (**v3)(v3, &unk_1405E7518, &v9) >= 0
          && (*(int (__fastcall **)(__int64, __int64 *, __int64 *))(*(_QWORD *)v9 + 32LL))(v9, &qword_1405C3390, &v8) >= 0 )
        {
          (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v8 + 48LL))(v8, v7);
        }
        if ( v8 != 0 )
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 16LL))(v8);
        if ( v9 != 0 )
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v9 + 16LL))(v9);
        v3 = v10;
      }
    }
    return sub_14006D9B0(v4);
  }
  return result;
}
