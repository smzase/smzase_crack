// EA 0x1401067c0  name sub_1401067C0  size 94
void __fastcall sub_1401067C0(__int64 a1, __int64 a2, char *a3)
{
  char *v3; // rbx
  char *v6; // rdi

  v3 = a3;
  while ( v3[25] == 0 )
  {
    sub_1401067C0(a1, a2, *((_QWORD *)v3 + 2));
    v6 = v3;
    v3 = *(char **)v3;
    sub_14007F110(v6 + 32);
    j_j_j__free_base(v6);
  }
}
