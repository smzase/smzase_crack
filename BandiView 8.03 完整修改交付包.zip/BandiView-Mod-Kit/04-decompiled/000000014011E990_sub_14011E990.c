// EA 0x14011e990  name sub_14011E990  size 819
__int64 __fastcall sub_14011E990(__int64 a1, __int64 *a2)
{
  __int64 *v4; // rax
  int *v5; // rbx
  __int64 v6; // r8
  __int64 v7; // rcx
  int v8; // edx
  __int64 *v9; // rax
  _BYTE *v10; // rdx
  volatile signed __int32 *v11; // rcx
  volatile signed __int32 *v12; // rsi
  __int64 v13; // rbx
  __int64 v14; // rcx
  int v15; // edx
  __int64 *v16; // rax
  _BYTE *v17; // rdx
  volatile signed __int32 *v18; // rcx
  volatile signed __int32 *v19; // rsi
  __int64 v20; // rbx
  _QWORD *v21; // rdx
  signed __int32 v22; // eax
  bool v23; // cc
  __int64 result; // rax
  __int64 v25; // rcx
  int *v26; // rdx
  signed __int32 v27; // eax
  volatile signed __int32 *v28; // rdx
  __int64 v29; // [rsp+30h] [rbp-10h] BYREF
  int **v30; // [rsp+38h] [rbp-8h]
  int *v31; // [rsp+80h] [rbp+40h] BYREF
  int *v32; // [rsp+88h] [rbp+48h] BYREF

  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v5 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  v31 = v5;
  v6 = *a2;
  v7 = -1;
  do
  {
    v8 = *(unsigned __int16 *)(v6 + 2 * v7 + 2) - aBtnOpenPhotoFo[v7 + 1];
    if ( v8 != 0 )
      break;
    v7 += 2;
    if ( v7 == 23 )
      break;
    v8 = *(unsigned __int16 *)(v6 + 2 * v7) - aBtnOpenPhotoFo[v7];
  }
  while ( v8 == 0 );
  if ( v8 != 0 )
  {
    v14 = -1;
    do
    {
      v15 = *(unsigned __int16 *)(v6 + 2 * v14 + 2) - aBtnOpenPhotoFo_0[v14 + 1];
      if ( v15 != 0 )
        break;
      v14 += 2;
      if ( v14 == 23 )
        break;
      v15 = *(unsigned __int16 *)(v6 + 2 * v14) - aBtnOpenPhotoFo_0[v14];
    }
    while ( v15 == 0 );
    if ( v15 != 0 )
    {
      v26 = v5 - 6;
      v27 = _InterlockedExchangeAdd(v5 - 2, 0xFFFFFFFF);
      v23 = v27 <= 1;
      result = (unsigned int)(v27 - 1);
      if ( !v23 )
        goto LABEL_45;
      v25 = *(_QWORD *)v26;
      goto LABEL_44;
    }
    v30 = &v32;
    v16 = sub_1400601C0();
    if ( v16 == nullptr )
      sub_14005FF30(0x80004005);
    v32 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v16 + 24))(v16) + 24);
    if ( (unsigned __int8)sub_14005F980(&v32, (__int64)L"EDIT_PHOTO_FOLDER2") == 0 )
      sub_14005FCF0(&v32, L"EDIT_PHOTO_FOLDER2", 18);
    v17 = *(_BYTE **)sub_1400ACCC0(a1, &v29, &v32);
    v18 = (volatile signed __int32 *)(v17 - 24);
    v19 = v5 - 6;
    if ( v17 - 24 != (_BYTE *)(v5 - 6) )
    {
      if ( *((int *)v19 + 4) >= 0 && *(_QWORD *)v18 == *(_QWORD *)v19 )
      {
        v20 = sub_14005F710(v18);
        if ( _InterlockedExchangeAdd(v19 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v19 + 8LL))(*(_QWORD *)v19, v19);
        v5 = (int *)(v20 + 24);
        v31 = v5;
      }
      else
      {
        sub_14005FCF0(&v31, v17, *((_DWORD *)v17 - 4));
        v5 = v31;
      }
    }
  }
  else
  {
    v30 = &v32;
    v9 = sub_1400601C0();
    if ( v9 == nullptr )
      sub_14005FF30(0x80004005);
    v32 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
    if ( (unsigned __int8)sub_14005F980(&v32, (__int64)L"EDIT_PHOTO_FOLDER1") == 0 )
      sub_14005FCF0(&v32, L"EDIT_PHOTO_FOLDER1", 18);
    v10 = *(_BYTE **)sub_1400ACCC0(a1, &v29, &v32);
    v11 = (volatile signed __int32 *)(v10 - 24);
    v12 = v5 - 6;
    if ( v10 - 24 != (_BYTE *)(v5 - 6) )
    {
      if ( *((int *)v12 + 4) >= 0 && *(_QWORD *)v11 == *(_QWORD *)v12 )
      {
        v13 = sub_14005F710(v11);
        if ( _InterlockedExchangeAdd(v12 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v12 + 8LL))(*(_QWORD *)v12, v12);
        v5 = (int *)(v13 + 24);
        v31 = v5;
      }
      else
      {
        sub_14005FCF0(&v31, v10, *((_DWORD *)v10 - 4));
        v5 = v31;
      }
    }
  }
  v21 = (_QWORD *)(v29 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v29 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v21 + 8LL))(*v21);
  if ( *(v5 - 4) != 0 && (unsigned int)sub_14006FD90((LPCWSTR)v5) == 0 )
  {
    v32 = (int *)(sub_14005F710(v5 - 6) + 24);
    sub_140070190(&v32);
  }
  if ( (unsigned int)sub_14006FD90((LPCWSTR)v5) != 0 )
    ShellExecuteW(nullptr, L"open", (LPCWSTR)v5, nullptr, nullptr, 1);
  v22 = _InterlockedExchangeAdd(v5 - 2, 0xFFFFFFFF);
  v23 = v22 <= 1;
  result = (unsigned int)(v22 - 1);
  if ( v23 )
  {
    v25 = *((_QWORD *)v5 - 3);
    v26 = v5 - 6;
LABEL_44:
    result = (*(__int64 (__fastcall **)(__int64, int *))(*(_QWORD *)v25 + 8LL))(v25, v26);
  }
LABEL_45:
  v28 = (volatile signed __int32 *)(*a2 - 24);
  if ( _InterlockedExchangeAdd(v28 + 4, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v28 + 8LL))(*(_QWORD *)v28);
  return result;
}
