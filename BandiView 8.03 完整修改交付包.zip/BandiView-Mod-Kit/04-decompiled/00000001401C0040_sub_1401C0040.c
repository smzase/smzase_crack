// EA 0x1401c0040  name sub_1401C0040  size 192
int *sub_1401C0040()
{
  if ( dword_14071ED28 > *(_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL) )
  {
    sub_140496500(&dword_14071ED28);
    if ( dword_14071ED28 == -1 )
    {
      qword_14071ED70 = 0;
      xmmword_14071ED80 = 0;
      dword_14071ED30 = 96;
      qword_14071ED38 = 0;
      qword_14071ED40 = 0;
      qword_14071ED48 = 0;
      qword_14071ED50 = 0;
      qword_14071ED58 = 0;
      qword_14071ED60 = 0;
      qword_14071ED68 = 0;
      qword_14071ED78 = 0;
      Init_thread_footer(&dword_14071ED28);
    }
  }
  if ( dword_1406FADC8 != 0 )
  {
    dword_1406FADC8 = 0;
    atexit(sub_1401C0100);
  }
  return &dword_14071ED30;
}
