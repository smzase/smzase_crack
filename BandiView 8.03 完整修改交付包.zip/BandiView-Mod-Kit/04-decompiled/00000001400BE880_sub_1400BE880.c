// EA 0x1400be880  name sub_1400BE880  size 1252
__int64 __fastcall sub_1400BE880(__int64 a1)
{
  __int64 *v2; // rax
  BOOL v3; // ebx
  __int64 *v4; // rax
  __int64 *v5; // rax
  __int64 *v6; // rax
  __int64 v7; // rax
  __int64 *v8; // rax
  BOOL v9; // ebx
  __int64 *v10; // rax
  __int64 *v11; // rax
  __int64 v12; // rax
  __int64 *v13; // rax
  BOOL v14; // ebx
  __int64 *v15; // rax
  __int64 *v16; // rax
  __int64 *v17; // rax
  __int64 v18; // rax
  int *v20; // [rsp+48h] [rbp+28h] BYREF
  int **v21; // [rsp+50h] [rbp+30h]

  v21 = &v20;
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  if ( (unsigned __int8)sub_14005F980(&v20, (__int64)L"CHK_SET_TEMP_FOLDER") == 0 )
    sub_14005FCF0(&v20, L"CHK_SET_TEMP_FOLDER", 19);
  v3 = sub_1400ACB10(a1, &v20);
  v21 = &v20;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( (unsigned __int8)sub_14005F980(&v20, (__int64)L"EDIT_TEMP_FOLDER") == 0 )
    sub_14005FCF0(&v20, L"EDIT_TEMP_FOLDER", 16);
  sub_1401C4F90(a1 + 728, &v20, v3);
  v21 = &v20;
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
  if ( (unsigned __int8)sub_14005F980(&v20, (__int64)L"BTN_SET_TEMP_FOLDER") == 0 )
    sub_14005FCF0(&v20, L"BTN_SET_TEMP_FOLDER", 19);
  sub_1401C4F90(a1 + 728, &v20, v3);
  v21 = &v20;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  if ( (unsigned __int8)sub_14005F980(&v20, (__int64)L"STATIC_TEMP_FOLDER_BG") == 0 )
    sub_14005FCF0(&v20, L"STATIC_TEMP_FOLDER_BG", 21);
  v7 = sub_1401BE5D0(a1 + 728, &v20);
  sub_1401DACD0(v7, !v3);
  v21 = &v20;
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24);
  if ( (unsigned __int8)sub_14005F980(&v20, (__int64)L"CHK_USER_DEFINE_IMAGE_EXT") == 0 )
    sub_14005FCF0(&v20, L"CHK_USER_DEFINE_IMAGE_EXT", 25);
  v9 = sub_1400ACB10(a1, &v20);
  v21 = &v20;
  v10 = sub_1400601C0();
  if ( v10 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24);
  if ( (unsigned __int8)sub_14005F980(&v20, (__int64)L"IDC_EDIT_USER_DEFINE_IMAGE_EXT") == 0 )
    sub_14005FCF0(&v20, L"IDC_EDIT_USER_DEFINE_IMAGE_EXT", 30);
  sub_1401C4F90(a1 + 728, &v20, v9);
  v21 = &v20;
  v11 = sub_1400601C0();
  if ( v11 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24);
  if ( (unsigned __int8)sub_14005F980(&v20, (__int64)L"STATIC_USER_DEFINE_IMAGE_EXT_BG") == 0 )
    sub_14005FCF0(&v20, L"STATIC_USER_DEFINE_IMAGE_EXT_BG", 31);
  v12 = sub_1401BE5D0(a1 + 728, &v20);
  sub_1401DACD0(v12, !v9);
  v21 = &v20;
  v13 = sub_1400601C0();
  if ( v13 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24);
  if ( (unsigned __int8)sub_14005F980(&v20, (__int64)L"CHK_USER_DEFINE_IGNORE_IMAGE_EXT") == 0 )
    sub_14005FCF0(&v20, L"CHK_USER_DEFINE_IGNORE_IMAGE_EXT", 32);
  v14 = sub_1400ACB10(a1, &v20);
  v21 = &v20;
  v15 = sub_1400601C0();
  if ( v15 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
  if ( (unsigned __int8)sub_14005F980(&v20, (__int64)L"IDC_CB_USER_DEFINE_IGNORE_IMAGE_EXT") == 0 )
    sub_14005FCF0(&v20, L"IDC_CB_USER_DEFINE_IGNORE_IMAGE_EXT", 35);
  sub_1401C4F90(a1 + 728, &v20, v14);
  v21 = &v20;
  v16 = sub_1400601C0();
  if ( v16 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v16 + 24))(v16) + 24);
  if ( (unsigned __int8)sub_14005F980(&v20, (__int64)L"EDIT_USER_DEFINE_IGNORE_IMAGE_EXT") == 0 )
    sub_14005FCF0(&v20, L"EDIT_USER_DEFINE_IGNORE_IMAGE_EXT", 33);
  sub_1401C4F90(a1 + 728, &v20, v14);
  v21 = &v20;
  v17 = sub_1400601C0();
  if ( v17 == nullptr )
    sub_14005FF30(0x80004005);
  v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v17 + 24))(v17) + 24);
  if ( (unsigned __int8)sub_14005F980(&v20, (__int64)L"STATIC_USER_DEFINE_IGNORE_IMAGE_EXT_BG") == 0 )
    sub_14005FCF0(&v20, L"STATIC_USER_DEFINE_IGNORE_IMAGE_EXT_BG", 38);
  v18 = sub_1401BE5D0(a1 + 728, &v20);
  return sub_1401DACD0(v18, !v14);
}
