// EA 0x14006caf0  name sub_14006CAF0  size 254
__int64 __fastcall sub_14006CAF0(__int64 a1)
{
  __int64 v2; // rcx
  __int64 v3; // rcx
  __int64 v4; // rcx
  __int64 v5; // rcx
  __int64 result; // rax
  __int64 v7; // rcx
  __int64 v8; // rcx
  __int64 v9; // rcx
  __int64 v10; // rcx

  v2 = *(_QWORD *)(a1 + 32);
  if ( v2 != 0 )
  {
    sub_14006DAB0(v2, &qword_1405C3350, *(unsigned int *)(a1 + 112));
    sub_14006D1A0(a1);
    v3 = *(_QWORD *)(a1 + 32);
    if ( v3 != 0 )
    {
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 16LL))(v3);
      *(_QWORD *)(a1 + 32) = 0;
    }
    v4 = *(_QWORD *)(a1 + 40);
    if ( v4 != 0 )
    {
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 16LL))(v4);
      *(_QWORD *)(a1 + 40) = 0;
    }
    v5 = *(_QWORD *)(a1 + 48);
    if ( v5 != 0 )
    {
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 16LL))(v5);
      *(_QWORD *)(a1 + 48) = 0;
    }
    result = (*(__int64 (__fastcall **)(_QWORD, __int64))(**(_QWORD **)(a1 + 56) + 48LL))(*(_QWORD *)(a1 + 56), 1);
    v7 = *(_QWORD *)(a1 + 56);
    if ( v7 != 0 )
    {
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v7 + 16LL))(v7);
      *(_QWORD *)(a1 + 56) = 0;
    }
  }
  v8 = *(_QWORD *)(a1 + 136);
  if ( v8 != 0 )
    result = (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v8 + 120LL))(v8, 1);
  *(_QWORD *)(a1 + 136) = 0;
  v9 = *(_QWORD *)(a1 + 144);
  if ( v9 != 0 )
    result = (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v9 + 72LL))(v9, 1);
  *(_QWORD *)(a1 + 144) = 0;
  v10 = *(_QWORD *)(a1 + 152);
  if ( v10 != 0 )
    result = (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v10 + 144LL))(v10, 1);
  *(_QWORD *)(a1 + 152) = 0;
  return result;
}
