// EA 0x14006db60  name sub_14006DB60  size 245
__int64 sub_14006DB60(__int64 a1, ...)
{
  __int64 result; // rax
  HWND v2; // rdi
  __int64 *v3; // rax
  __int64 v4; // rbx
  signed __int32 v5; // eax
  bool v6; // cc
  _QWORD v7[2]; // [rsp+20h] [rbp-48h] BYREF
  LPARAM lParam; // [rsp+30h] [rbp-38h] BYREF
  int v9; // [rsp+38h] [rbp-30h]
  __int64 v10; // [rsp+40h] [rbp-28h]
  va_list va; // [rsp+78h] [rbp+10h] BYREF

  va_start(va, a1);
  result = (__int64)FindWindowW(L"#32770", L"XRecv");
  v2 = (HWND)result;
  if ( result != 0 )
  {
    v3 = sub_1400601C0();
    if ( v3 == nullptr )
      sub_14005FF30(0x80004005);
    v7[0] = (*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24;
    v7[1] = 0;
    sub_14005EB80(v7, a1, (__int64 *)va);
    lParam = 1;
    v4 = v7[0];
    v9 = 2 * *(_DWORD *)(v7[0] - 16LL) + 2;
    if ( *(int *)(v7[0] - 8LL) > 1 )
    {
      sub_14005FB40(v7, *(unsigned int *)(v7[0] - 16LL));
      v4 = v7[0];
    }
    v10 = v4;
    SendMessageW(v2, 0x4Au, 0, (LPARAM)&lParam);
    v5 = _InterlockedExchangeAdd((volatile signed __int32 *)(v4 - 24 + 16), 0xFFFFFFFF);
    v6 = v5 <= 1;
    result = (unsigned int)(v5 - 1);
    if ( v6 )
      return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(v4 - 24) + 8LL))(*(_QWORD *)(v4 - 24));
  }
  return result;
}
