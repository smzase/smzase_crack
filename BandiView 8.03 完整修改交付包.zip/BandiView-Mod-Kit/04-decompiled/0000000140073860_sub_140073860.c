// EA 0x140073860  name sub_140073860  size 285
__int64 __fastcall sub_140073860(LPSTR *a1, __int64 a2)
{
  unsigned __int8 v2; // r8
  unsigned int v4; // ebx
  HMODULE v5; // rax
  HMODULE v6; // rsi
  HRSRC ResourceW; // rax
  unsigned __int16 *v8; // rax
  unsigned __int16 *v9; // rsi
  int v10; // eax
  __int64 cbMultiByte; // rbx

  v2 = 0;
  if ( (unsigned __int64)(a2 - 1) <= 0xFFFE )
  {
    v4 = (unsigned __int16)a2;
    v5 = (HMODULE)sub_14005F870((unsigned __int16)a2);
    v6 = v5;
    if ( v5 != nullptr )
    {
      ResourceW = FindResourceW(v5, (LPCWSTR)(((unsigned __int64)v4 >> 4) + 1), (LPCWSTR)6);
      if ( ResourceW != nullptr )
      {
        v8 = (unsigned __int16 *)sub_14005F900(v6, ResourceW);
        v9 = v8;
        if ( v8 != nullptr )
        {
          v10 = WideCharToMultiByte(3u, 0, v8 + 1, *v8, nullptr, 0, nullptr, nullptr);
          cbMultiByte = v10;
          if ( v10 < 0 )
            goto LABEL_12;
          if ( ((*((_DWORD *)*a1 - 3) - v10) | (1 - *((_DWORD *)*a1 - 2))) < 0 )
            sub_140073A50(a1, (unsigned int)v10);
          WideCharToMultiByte(3u, 0, v9 + 1, *v9, *a1, cbMultiByte, nullptr, nullptr);
          if ( (int)cbMultiByte > *((_DWORD *)*a1 - 3) )
LABEL_12:
            sub_14005FF30(0x80070057);
          *((_DWORD *)*a1 - 4) = cbMultiByte;
          (*a1)[cbMultiByte] = 0;
        }
      }
    }
    return 1;
  }
  return v2;
}
