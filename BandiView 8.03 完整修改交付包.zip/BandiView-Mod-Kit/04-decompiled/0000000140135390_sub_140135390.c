// EA 0x140135390  name sub_140135390  size 1377
__int64 __fastcall sub_140135390(_QWORD *a1)
{
  HWND *v2; // rsi
  HICON IconW; // rax
  __int64 v4; // rax
  __int64 v5; // r12
  HICON v6; // rax
  __int64 v7; // rax
  LPARAM v8; // rax
  void *v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  __int64 v14; // rbx
  unsigned int v15; // eax
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // r8
  __int128 *v19; // rbx
  __int64 v20; // rax
  unsigned int v21; // eax
  __int64 v22; // rax
  __int64 v23; // rdx
  __int64 v24; // r8
  __int64 v25; // rcx
  __int64 v26; // r15
  __int64 v27; // r15
  __int64 v28; // rax
  _QWORD *v29; // r14
  __int64 v30; // rbx
  _QWORD *v31; // rdx
  __int64 v32; // rbx
  __int64 v33; // rdx
  __int64 v34; // rcx
  __int64 v35; // r8
  __int64 v36; // rax
  LPCWSTR v37; // rdx
  HWND v38; // rbx
  __int64 v39; // rax
  _QWORD *v40; // rdx
  _QWORD *v41; // rdx
  _QWORD *v42; // rdx
  __int64 v44; // [rsp+40h] [rbp-C0h] BYREF
  LPCWSTR lpText; // [rsp+48h] [rbp-B8h] BYREF
  _QWORD v46[4]; // [rsp+50h] [rbp-B0h] BYREF
  _BYTE v47[64]; // [rsp+70h] [rbp-90h] BYREF
  _QWORD *v48; // [rsp+B0h] [rbp-50h]
  __int64 v49; // [rsp+B8h] [rbp-48h]
  _QWORD v50[4]; // [rsp+C0h] [rbp-40h] BYREF
  int v51; // [rsp+E0h] [rbp-20h]
  __int64 v52; // [rsp+F0h] [rbp-10h]
  HWND v53; // [rsp+100h] [rbp+0h] BYREF
  __m128i si128; // [rsp+108h] [rbp+8h]
  char v55; // [rsp+118h] [rbp+18h]
  __int16 v56; // [rsp+119h] [rbp+19h]
  char v57; // [rsp+11Bh] [rbp+1Bh]
  __int64 v58; // [rsp+120h] [rbp+20h]
  int v59; // [rsp+128h] [rbp+28h]
  char v60; // [rsp+12Ch] [rbp+2Ch]
  __int128 v61; // [rsp+130h] [rbp+30h] BYREF
  __int128 v62; // [rsp+140h] [rbp+40h]
  __int128 Src; // [rsp+150h] [rbp+50h] BYREF
  __int128 v64; // [rsp+160h] [rbp+60h]
  _BYTE v65[32]; // [rsp+170h] [rbp+70h] BYREF

  v2 = (HWND *)(a1 + 1);
  IconW = (HICON)lParam;
  if ( lParam == 0 )
  {
    v4 = sub_14007D5E0();
    IconW = LoadIconW(hModule, *(LPCWSTR *)(v4 + 32));
    lParam = (LPARAM)IconW;
  }
  v5 = 1;
  SendMessageW(*v2, 0x80u, 1u, (LPARAM)IconW);
  v6 = (HICON)qword_140709240;
  if ( qword_140709240 == 0 )
  {
    v7 = sub_14007D5E0();
    v6 = LoadIconW(hModule, *(LPCWSTR *)(v7 + 32));
    qword_140709240 = (LPARAM)v6;
  }
  SendMessageW(*v2, 0x80u, 0, (LPARAM)v6);
  sub_140091E20(v2, 0);
  v8 = sub_1401C5640();
  sub_1401C7E40(v8, *v2);
  v9 = (void *)sub_140069AD0(v65);
  v10 = sub_14005ED20(v9);
  Src = 0;
  v64 = 0;
  Src = *(_OWORD *)v10;
  v64 = *(_OWORD *)(v10 + 16);
  *(_QWORD *)(v10 + 16) = 0;
  *(_QWORD *)(v10 + 24) = 7;
  *(_WORD *)v10 = 0;
  v11 = sub_14005ED20(&Src);
  v61 = 0;
  v62 = 0;
  v61 = *(_OWORD *)v11;
  v62 = *(_OWORD *)(v11 + 16);
  *(_QWORD *)(v11 + 16) = 0;
  *(_QWORD *)(v11 + 24) = 7;
  *(_WORD *)v11 = 0;
  sub_14005D410(&Src);
  sub_14005D410(v65);
  v56 = 0;
  v57 = 0;
  v58 = 0;
  v59 = 257;
  v60 = 0;
  v53 = *v2;
  si128 = _mm_load_si128((const __m128i *)&xmmword_140663300);
  v55 = 1;
  v12 = sub_1401C5640();
  v13 = sub_1401C81E0(v12, L"TEXT_ASK_WEBVIEW_HELP", L"TEXT");
  v14 = v13;
  if ( v13 != 0 )
    v15 = sub_1404ADC20(v13);
  else
    v15 = 0;
  sub_14005FCF0(a1 + 296, v14, v15);
  v46[0] = &v44;
  v19 = &v61;
  if ( *((_QWORD *)&v62 + 1) > 7u )
    v19 = (__int128 *)v61;
  v20 = sub_1400601C0(v17, v16, v18);
  if ( v20 == 0 )
    sub_14005FF30(2147500037LL);
  v44 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v20 + 24LL))(v20) + 24;
  if ( (unsigned __int8)sub_14005F980(&v44, v19) == 0 )
  {
    if ( v19 != nullptr )
      v21 = sub_1404ADC20(v19);
    else
      v21 = 0;
    sub_14005FCF0(&v44, v19, v21);
  }
  sub_14006B990(a1 + 292, &v44, &v53, 0);
  v22 = sub_14009F6B0(&lpText);
  sub_14006BD70(a1 + 292, v22);
  sub_14005D490(v47);
  sub_14005FCF0(v50, L"IDD_UPDATE", 10);
  v48 = a1 + 8;
  v51 = 2;
  v47[21] = *(_DWORD *)(sub_1401D4680() + 4) == 1;
  v25 = a1[294];
  if ( v25 != 0 )
  {
    v27 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v25 + 72LL))(v25);
  }
  else
  {
    v26 = a1[295];
    if ( v26 != 0 )
      v27 = *(_QWORD *)(v26 + 8);
    else
      v27 = 0;
  }
  v46[0] = &v44;
  v28 = sub_1400601C0(v25, v23, v24);
  if ( v28 == 0 )
    sub_14005FF30(2147500037LL);
  v29 = a1 + 42;
  v44 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v28 + 24LL))(v28) + 24;
  if ( (unsigned __int8)sub_14005F980(&v44, L"WINDOW_WEB64") == 0 )
    sub_14005FCF0(&v44, L"WINDOW_WEB64", 12);
  v46[0] = &v44;
  v30 = a1[197];
  lpText = (LPCWSTR)(sub_14005F710(v44 - 24) + 24);
  sub_1401D3520(v30, &lpText, v27);
  v31 = (_QWORD *)(v44 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v44 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v31 + 8LL))(*v31);
  v46[1] = &lpText;
  v32 = sub_1400699F0(&lpText);
  v46[2] = &v44;
  v36 = sub_1400601C0(v34, v33, v35);
  if ( v36 == 0 )
    sub_14005FF30(2147500037LL);
  v44 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v36 + 24LL))(v36) + 24;
  if ( (unsigned __int8)sub_14005F980(&v44, L"skin_update_dlg.xml") == 0 )
    sub_14005FCF0(&v44, L"skin_update_dlg.xml", 19);
  sub_1400697A0(v46);
  if ( (unsigned int)sub_1401C0B50((_DWORD)v29, (__int64)&v44, v32, (__int64)v47) != 0 )
  {
    sub_1401BAA20(v29);
    v38 = *v2;
    v39 = sub_1401D4680();
    sub_1401D47B0(v39, v38);
  }
  else
  {
    sub_1401BA850(v29, &lpText);
    MessageBoxW(*v2, lpText, &Data, 0);
    v37 = lpText - 12;
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)lpText - 2, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v37 + 8LL))(*(_QWORD *)v37);
    v5 = 0;
  }
  v40 = (_QWORD *)(v52 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v52 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v40 + 8LL))(*v40);
  v41 = (_QWORD *)(v50[0] - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v50[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v41 + 8LL))(*v41);
  v42 = (_QWORD *)(v49 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v49 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v42 + 8LL))(*v42);
  sub_14005D410(&v61);
  return v5;
}
