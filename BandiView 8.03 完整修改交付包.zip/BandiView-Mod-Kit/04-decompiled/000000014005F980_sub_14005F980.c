// EA 0x14005f980  name sub_14005F980  size 259
__int64 __fastcall sub_14005F980(_QWORD *a1, __int64 a2)
{
  unsigned __int8 v3; // cl
  unsigned int v4; // ebx
  HMODULE v5; // rax
  HMODULE v6; // rsi
  HRSRC ResourceW; // rax
  unsigned __int16 *v8; // rax
  unsigned __int16 *v9; // rsi
  __int64 v10; // rbx
  int v11; // eax

  v3 = 0;
  if ( (unsigned __int64)(a2 - 1) <= 0xFFFE )
  {
    v4 = (unsigned __int16)a2;
    v5 = (HMODULE)sub_14005F870((unsigned __int16)a2);
    v6 = v5;
    if ( v5 == nullptr )
      return 1;
    ResourceW = FindResourceW(v5, (LPCWSTR)(((unsigned __int64)v4 >> 4) + 1), (LPCWSTR)6);
    if ( ResourceW == nullptr )
      return 1;
    v8 = (unsigned __int16 *)sub_14005F900(v6, ResourceW);
    v9 = v8;
    if ( v8 == nullptr )
      return 1;
    v10 = *v8;
    if ( (int)((*(_DWORD *)(*a1 - 12LL) - v10) | (1 - *(_DWORD *)(*a1 - 8LL))) < 0 )
      sub_14005FC80(a1, *v8);
    v11 = sub_1404A7770(*a1, v10, v9 + 1, *v9);
    if ( v11 != 0 )
    {
      if ( v11 == 12 )
        sub_14005FF30(2147942414LL);
      if ( v11 == 22 || v11 == 34 )
        goto LABEL_17;
      if ( v11 != 80 )
        sub_14005FF30(2147500037LL);
    }
    if ( (int)v10 <= *(_DWORD *)(*a1 - 12LL) )
    {
      *(_DWORD *)(*a1 - 16LL) = v10;
      *(_WORD *)(*a1 + 2 * v10) = 0;
      return 1;
    }
LABEL_17:
    sub_14005FF30(2147942487LL);
  }
  return v3;
}
