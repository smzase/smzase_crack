// EA 0x140090520  name sub_140090520  size 628
void **__fastcall sub_140090520(__int64 a1)
{
  volatile signed __int32 *v2; // rdx
  volatile signed __int32 *v3; // rdi
  __int64 v4; // rcx
  __int64 v5; // rax
  void *v6; // rcx
  __int64 v7; // rbp
  unsigned __int64 v8; // rdi
  unsigned __int64 v9; // r14
  const WCHAR *v10; // rcx
  HWND v11; // rcx
  volatile signed __int32 *v12; // rdx
  void *v13; // rcx
  __int64 v14; // rcx
  void *v15; // rcx
  volatile signed __int32 *v16; // rdx
  void **result; // rax
  void *v18; // rcx

  *(_QWORD *)a1 = &SettingDlg::`vftable';
  *(_QWORD *)(a1 + 64) = &SettingDlg::`vftable';
  sub_140091640(a1 + 2656);
  sub_1401B9CE0(a1 + 728);
  sub_140091650(a1 + 576);
  v2 = (volatile signed __int32 *)(*(_QWORD *)(a1 + 552) - 24LL);
  if ( _InterlockedExchangeAdd(v2 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v2 + 8LL))(*(_QWORD *)v2);
  v3 = *(volatile signed __int32 **)(a1 + 528);
  if ( v3 != nullptr && _InterlockedExchangeAdd(v3 + 2, 0xFFFFFFFF) == 1 )
  {
    (**(void (__fastcall ***)(volatile signed __int32 *))v3)(v3);
    if ( _InterlockedExchangeAdd(v3 + 3, 0xFFFFFFFF) == 1 )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 8LL))(v3);
  }
  v4 = *(_QWORD *)(a1 + 496);
  if ( v4 != 0 )
  {
    sub_140091870(v4, *(_QWORD *)(a1 + 504));
    v5 = *(_QWORD *)(a1 + 496);
    if ( ((*(_QWORD *)(a1 + 512) - v5) & 0xFFFFFFFFFFFFFFF0uLL) < 0x1000 )
    {
      v6 = *(void **)(a1 + 496);
    }
    else
    {
      v6 = *(void **)(v5 - 8);
      if ( (unsigned __int64)(v5 - (_QWORD)v6 - 8) > 0x1F )
        __fastfail(5u);
    }
    j_j_j__free_base(v6);
    *(_QWORD *)(a1 + 496) = 0;
    *(_QWORD *)(a1 + 504) = 0;
    *(_QWORD *)(a1 + 512) = 0;
  }
  sub_14007A160(a1 + 456);
  v7 = *(_QWORD *)(a1 + 416);
  if ( v7 != 0 )
  {
    v8 = 0;
    v9 = *(_QWORD *)(a1 + 424);
    if ( v9 != 0 )
    {
      do
        sub_14008A870((void *)(v7 + 32 * v8++));
      while ( v8 < v9 );
    }
    j__free_base(*(void **)(a1 + 416));
  }
  v10 = *(const WCHAR **)(a1 + 400);
  if ( *((_DWORD *)v10 - 4) != 0 )
  {
    DeleteFileW(v10);
    sub_14005FA90((int **)(a1 + 400));
  }
  v11 = *(HWND *)(a1 + 408);
  if ( v11 != nullptr )
  {
    PostMessageW(v11, 0x10u, 0, 0);
    *(_QWORD *)(a1 + 408) = 0;
  }
  v12 = (volatile signed __int32 *)(*(_QWORD *)(a1 + 400) - 24LL);
  if ( _InterlockedExchangeAdd(v12 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v12 + 8LL))(*(_QWORD *)v12);
  *(_QWORD *)(a1 + 320) = &XGroupListCtrl::`vftable';
  v13 = *(void **)(a1 + 360);
  if ( v13 != nullptr )
    sub_140495E60(v13);
  v14 = *(_QWORD *)(a1 + 256);
  *(_QWORD *)(a1 + 112) = &EditControl4Number::`vftable';
  if ( v14 != 0 )
    (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v14 + 8LL))(v14, 1);
  v15 = *(void **)(a1 + 152);
  if ( v15 != nullptr )
    sub_140495E60(v15);
  v16 = (volatile signed __int32 *)(*(_QWORD *)(a1 + 88) - 24LL);
  if ( _InterlockedExchangeAdd(v16 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v16 + 8LL))(*(_QWORD *)v16);
  result = &IXSkinCallback::`vftable';
  *(_QWORD *)(a1 + 64) = &IXSkinCallback::`vftable';
  v18 = *(void **)(a1 + 40);
  if ( v18 != nullptr )
    return (void **)sub_140495E60(v18);
  return result;
}
