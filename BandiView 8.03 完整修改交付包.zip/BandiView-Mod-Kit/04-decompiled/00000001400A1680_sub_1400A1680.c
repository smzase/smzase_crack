// EA 0x1400a1680  name sub_1400A1680  size 337
int *sub_1400A1680()
{
  __int64 *v0; // rax
  __int64 *v1; // rax
  __int64 *v2; // rax
  __int64 *v3; // rax
  __int64 *v4; // rax

  if ( dword_14071E900 > *(_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL) )
  {
    sub_140496500(&dword_14071E900);
    if ( dword_14071E900 == -1 )
    {
      dword_14071E910 = 1;
      sub_1400A13F0((__int64)&unk_14071E918);
      v0 = sub_1400601C0();
      if ( v0 == nullptr )
        sub_14005FF30(0x80004005);
      qword_14071E960 = (*(__int64 (__fastcall **)(__int64 *))(*v0 + 24))(v0) + 24;
      v1 = sub_1400601C0();
      if ( v1 == nullptr )
        sub_14005FF30(0x80004005);
      qword_14071E968 = (*(__int64 (__fastcall **)(__int64 *))(*v1 + 24))(v1) + 24;
      v2 = sub_1400601C0();
      if ( v2 == nullptr )
        sub_14005FF30(0x80004005);
      qword_14071E970 = (*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24;
      v3 = sub_1400601C0();
      if ( v3 == nullptr )
        sub_14005FF30(0x80004005);
      qword_14071E978 = (*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24;
      v4 = sub_1400601C0();
      if ( v4 == nullptr )
        sub_14005FF30(0x80004005);
      qword_14071E980 = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24;
      atexit(sub_140592BF0);
      Init_thread_footer(&dword_14071E900);
    }
  }
  return &dword_14071E910;
}
