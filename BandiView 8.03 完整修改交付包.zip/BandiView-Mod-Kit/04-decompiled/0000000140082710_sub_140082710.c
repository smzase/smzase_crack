// EA 0x140082710  name sub_140082710  size 512
__int64 __fastcall sub_140082710(HKEY a1, LPCWSTR *a2)
{
  unsigned int v4; // ebp
  DWORD v5; // eax
  __int64 v6; // rax
  __int64 v7; // rax
  int v8; // edi
  _QWORD *v9; // rdx
  bool v10; // zf
  volatile signed __int32 *v11; // rdx
  DWORD cSubKeys; // [rsp+60h] [rbp-278h] BYREF
  DWORD cchName; // [rsp+64h] [rbp-274h] BYREF
  HKEY hKey; // [rsp+68h] [rbp-270h] BYREF
  _BYTE v16[8]; // [rsp+78h] [rbp-260h] BYREF
  _QWORD v17[2]; // [rsp+80h] [rbp-258h] BYREF
  WCHAR Name[264]; // [rsp+90h] [rbp-248h] BYREF

  v17[1] = a2;
  hKey = nullptr;
  cchName = 260;
  cSubKeys = 0;
  memset(Name, 0, 0x208u);
  v4 = 0;
  if ( RegOpenKeyExW(a1, *a2, 0, 9u, &hKey) == 0
    && RegQueryInfoKeyW(
         hKey,
         nullptr,
         nullptr,
         nullptr,
         &cSubKeys,
         nullptr,
         nullptr,
         nullptr,
         nullptr,
         nullptr,
         nullptr,
         nullptr) == 0 )
  {
    v5 = cSubKeys;
    if ( cSubKeys != 0 )
    {
      while ( 1 )
      {
        cchName = 260;
        if ( RegEnumKeyExW(hKey, v5 - 1, Name, &cchName, nullptr, nullptr, nullptr, nullptr) != 0 || cchName == 0 )
          break;
        v6 = sub_140060B30(v17, a2, L"\\");
        v7 = sub_140060B30(v16, v6, Name);
        v8 = sub_140082710(a1, v7);
        v9 = (_QWORD *)(v17[0] - 24LL);
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v17[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v9 + 8LL))(*v9);
        if ( v8 == 0 )
          break;
        v10 = cSubKeys == 1;
        v5 = --cSubKeys;
        if ( v10 )
          goto LABEL_10;
      }
    }
    else
    {
LABEL_10:
      v4 = 1;
    }
  }
  if ( hKey != nullptr )
    RegCloseKey(hKey);
  if ( v4 != 0 )
    RegDeleteKeyW(a1, *a2);
  v11 = (volatile signed __int32 *)(*a2 - 12);
  if ( _InterlockedExchangeAdd(v11 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v11 + 8LL))(*(_QWORD *)v11);
  return v4;
}
