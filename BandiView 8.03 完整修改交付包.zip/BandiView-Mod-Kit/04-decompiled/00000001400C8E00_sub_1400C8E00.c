// EA 0x1400c8e00  name sub_1400C8E00  size 926
int **__fastcall sub_1400C8E00(int **a1, _QWORD *a2, __int64 a3, unsigned int a4)
{
  __int64 v6; // rdx
  __int64 *v7; // rax
  int v8; // eax
  signed int v9; // r15d
  unsigned __int8 *v10; // rax
  unsigned __int8 *v11; // r14
  __int64 *v12; // rax
  volatile signed __int32 *v13; // rdx
  __int64 *v14; // rax
  __int64 *v15; // rax
  int v16; // edi
  int v17; // ebx
  int v18; // ecx
  unsigned int i; // edi
  __int64 v20; // rbx
  __int64 j; // rdi
  __int64 v22; // rdi
  volatile signed __int32 *v23; // rdx
  __int64 v25; // [rsp+20h] [rbp-E0h] BYREF
  __int64 v26; // [rsp+28h] [rbp-D8h] BYREF
  unsigned int v27; // [rsp+30h] [rbp-D0h]
  _DWORD v28[6]; // [rsp+38h] [rbp-C8h] BYREF
  __int64 v29; // [rsp+50h] [rbp-B0h]
  _QWORD *v30; // [rsp+58h] [rbp-A8h]
  void **v31; // [rsp+60h] [rbp-A0h]
  unsigned __int8 *v32; // [rsp+68h] [rbp-98h]
  __int64 v33; // [rsp+70h] [rbp-90h]
  void *Block; // [rsp+80h] [rbp-80h] BYREF
  _BYTE v35[136]; // [rsp+88h] [rbp-78h] BYREF

  v27 = a4;
  v29 = a3;
  v26 = (__int64)a1;
  v30 = a2;
  v6 = *a2;
  if ( *(_DWORD *)(v6 - 16) == 0 )
  {
    v7 = sub_1400601C0();
    if ( v7 == nullptr )
      sub_14005FF30(0x80004005);
    *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
    if ( (unsigned __int8)sub_14005F980(a1, (__int64)&Data) == 0 )
      sub_14005FCF0(a1, &Data, 0);
LABEL_12:
    v13 = (volatile signed __int32 *)(*a2 - 24LL);
    if ( _InterlockedExchangeAdd(v13 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v13 + 8LL))(*(_QWORD *)v13);
    return a1;
  }
  Block = v35;
  sub_140075800(&Block, v6, 65001);
  v31 = &XAutoByte::`vftable';
  v8 = strlen((const char *)Block);
  v9 = ((((v8 + 8) >> 31) & 7) + v8 + 8) & 0xFFFFFFF8;
  v10 = (unsigned __int8 *)j__calloc_base(v9, 1u);
  v11 = v10;
  v32 = v10;
  v33 = v9;
  if ( v10 == nullptr )
  {
    v12 = sub_1400601C0();
    if ( v12 == nullptr )
      sub_14005FF30(0x80004005);
    *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24);
    if ( (unsigned __int8)sub_14005F980(a1, (__int64)&Data) == 0 )
      sub_14005FCF0(a1, &Data, 0);
    if ( Block != v35 )
      j__free_base(Block);
    goto LABEL_12;
  }
  sub_1400C9E30(v10, v9, Block);
  v14 = sub_1400601C0();
  if ( v14 == nullptr )
    sub_14005FF30(0x80004005);
  v26 = (*(__int64 (__fastcall **)(__int64 *))(*v14 + 24))(v14) + 24;
  v15 = sub_1400601C0();
  if ( v15 == nullptr )
    sub_14005FF30(0x80004005);
  v25 = (*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24;
  v28[1] = 1;
  v28[2] = strlen((const char *)Block);
  v28[3] = sub_14009A4C0(0, Block);
  v16 = rand();
  v17 = rand();
  v18 = v16 + ((v17 + (rand() << 15)) << 15);
  if ( v18 == -1 )
    v18 = -2;
  v28[0] = v18;
  sub_1400CE240(v11, v9, v29, v27);
  sub_1400CE240(v28, 16, v29, v27);
  for ( i = 0; i < 0x10; ++i )
  {
    sub_14005EB50((__int64)&v25, (__int64)L"%02x", *((unsigned __int8 *)v28 + (int)i));
    v20 = v25;
    sub_140069690(&v26, v25, *(unsigned int *)(v25 - 16));
  }
  for ( j = 0; (int)j < v9; j = (unsigned int)(j + 1) )
  {
    sub_14005EB50((__int64)&v25, (__int64)L"%02x", v11[j]);
    v20 = v25;
    sub_140069690(&v26, v25, *(unsigned int *)(v25 - 16));
  }
  v22 = v26;
  *a1 = (int *)(sub_14005F710((volatile signed __int32 *)(v26 - 24)) + 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v20 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v20 - 24) + 8LL))(*(_QWORD *)(v20 - 24));
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v22 - 8), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD, __int64))(**(_QWORD **)(v22 - 24) + 8LL))(*(_QWORD *)(v22 - 24), v22 - 24);
  if ( v11 != nullptr )
    j__free_base(v11);
  if ( Block != v35 )
    j__free_base(Block);
  v23 = (volatile signed __int32 *)(*a2 - 24LL);
  if ( _InterlockedExchangeAdd(v23 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v23 + 8LL))(*(_QWORD *)v23);
  return a1;
}
