// EA 0x14011e4a0  name sub_14011E4A0  size 1264
__int64 __fastcall sub_14011E4A0(__int64 a1, __int64 *a2)
{
  __int64 *v4; // rax
  int *v5; // rbx
  __int64 *v6; // rax
  int *v7; // r9
  __int64 v8; // r8
  __int64 i; // rcx
  int v10; // edx
  wchar_t *v11; // rdx
  __int64 j; // rcx
  int v13; // edx
  int *v14; // r15
  _BYTE *v15; // rdx
  volatile signed __int32 *v16; // rcx
  volatile signed __int32 *v17; // rsi
  __int64 v18; // rbx
  _QWORD *v19; // rdx
  _BYTE *v20; // rdx
  volatile signed __int32 *v21; // rcx
  volatile signed __int32 *v22; // rsi
  __int64 v23; // rbx
  _QWORD *v24; // rdx
  int k; // r14d
  volatile signed __int32 *v26; // rcx
  _BYTE *v27; // rdx
  volatile signed __int32 *v28; // rsi
  __int64 v29; // rbx
  signed __int32 v30; // ecx
  bool v31; // cc
  _QWORD *v32; // rdx
  __int64 v33; // rax
  __int64 v34; // rax
  __int64 v35; // rcx
  __int64 v36; // rcx
  __int64 *v37; // rax
  __int64 v38; // rsi
  int v39; // r14d
  _QWORD *v40; // rdx
  __int64 v41; // rcx
  int *v42; // rdx
  _QWORD *v43; // rdx
  signed __int32 v44; // eax
  __int64 result; // rax
  volatile signed __int32 *v46; // rdx
  __int64 v47; // [rsp+30h] [rbp-30h] BYREF
  int *v48; // [rsp+38h] [rbp-28h] BYREF
  __int64 v49[4]; // [rsp+40h] [rbp-20h] BYREF
  int *v50; // [rsp+B0h] [rbp+50h] BYREF
  __int64 v51; // [rsp+B8h] [rbp+58h] BYREF

  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v5 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  v50 = v5;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  v7 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  v48 = v7;
  v8 = *a2;
  for ( i = 0; i != 22; i += 2 )
  {
    v10 = *(unsigned __int16 *)(v8 + 2 * i) - aBtnSetPhotoFol[i];
    if ( v10 != 0 )
      break;
    v10 = *(unsigned __int16 *)(v8 + 2 * i + 2) - aBtnSetPhotoFol[i + 1];
    if ( v10 != 0 )
      break;
  }
  if ( v10 != 0 )
  {
    for ( j = 0; j != 22; j += 2 )
    {
      v13 = *(unsigned __int16 *)(v8 + 2 * j) - aBtnSetPhotoFol_0[j];
      if ( v13 != 0 )
        break;
      v13 = *(unsigned __int16 *)(v8 + 2 * j + 2) - aBtnSetPhotoFol_0[j + 1];
      if ( v13 != 0 )
        break;
    }
    if ( v13 != 0 )
    {
      v42 = v7 - 6;
      if ( _InterlockedExchangeAdd(v7 - 2, 0xFFFFFFFF) > 1 )
        goto LABEL_66;
      v41 = *(_QWORD *)v42;
      goto LABEL_65;
    }
    v11 = L"EDIT_PHOTO_FOLDER2";
  }
  else
  {
    v11 = L"EDIT_PHOTO_FOLDER1";
  }
  sub_14005FCF0(&v48, v11, 18);
  v14 = v48 - 6;
  v47 = sub_14005F710(v48 - 6) + 24;
  v15 = *(_BYTE **)sub_1400ACCC0(a1, v49, &v47);
  v16 = (volatile signed __int32 *)(v15 - 24);
  v17 = v5 - 6;
  if ( v15 - 24 != (_BYTE *)(v5 - 6) )
  {
    if ( *((int *)v17 + 4) >= 0 && *(_QWORD *)v16 == *(_QWORD *)v17 )
    {
      v18 = sub_14005F710(v16);
      if ( _InterlockedExchangeAdd(v17 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v17 + 8LL))(*(_QWORD *)v17, v17);
      v5 = (int *)(v18 + 24);
      v50 = v5;
    }
    else
    {
      sub_14005FCF0(&v50, v15, *((_DWORD *)v15 - 4));
      v5 = v50;
    }
  }
  v19 = (_QWORD *)(v49[0] - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v49[0] - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v19 + 8LL))(*v19);
  if ( *(v5 - 4) == 0 )
  {
    v20 = (_BYTE *)*sub_14009ACB0(v49);
    v21 = (volatile signed __int32 *)(v20 - 24);
    v22 = v5 - 6;
    if ( v20 - 24 != (_BYTE *)(v5 - 6) )
    {
      if ( *((int *)v22 + 4) >= 0 && *(_QWORD *)v21 == *(_QWORD *)v22 )
      {
        v23 = sub_14005F710(v21);
        if ( _InterlockedExchangeAdd(v22 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v22 + 8LL))(*(_QWORD *)v22, v22);
        v5 = (int *)(v23 + 24);
        v50 = v5;
      }
      else
      {
        sub_14005FCF0(&v50, v20, *((_DWORD *)v20 - 4));
        v5 = v50;
      }
    }
    v24 = (_QWORD *)(v49[0] - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v49[0] - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v24 + 8LL))(*v24);
  }
  for ( k = 0; k < 3; ++k )
  {
    if ( (unsigned int)sub_14006FD90((LPCWSTR)v5) != 0 )
      break;
    v27 = *(_BYTE **)sub_14006EE60(v49, &v50);
    v26 = (volatile signed __int32 *)(v27 - 24);
    v28 = v5 - 6;
    if ( v27 - 24 != (_BYTE *)(v5 - 6) )
    {
      if ( *((int *)v28 + 4) >= 0 && *(_QWORD *)v26 == *(_QWORD *)v28 )
      {
        v29 = sub_14005F710(v26);
        v30 = _InterlockedExchangeAdd(v28 + 4, 0xFFFFFFFF);
        v31 = v30 <= 1;
        v26 = (volatile signed __int32 *)(unsigned int)(v30 - 1);
        if ( v31 )
          (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v28 + 8LL))(*(_QWORD *)v28, v28);
        v5 = (int *)(v29 + 24);
        v50 = v5;
      }
      else
      {
        sub_14005FCF0(&v50, v27, *((_DWORD *)v27 - 4));
        v5 = v50;
      }
    }
    v32 = (_QWORD *)(v49[0] - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v49[0] - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v32 + 8LL))(*v32);
  }
  v33 = sub_1401C5640(v26);
  v34 = sub_1401C81E0(v33, L"TEXT_SELECT_FOLDER", L"TEXT");
  sub_1400703B0(&v51, *(_QWORD *)(a1 + 8), v5, v34);
  v35 = *(_QWORD *)(v51 - 24);
  if ( v35 == 0 || (v36 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v35 + 32LL))(v35)) == 0 )
  {
    v37 = sub_1400601C0();
    v36 = (*(__int64 (__fastcall **)(__int64 *))(*v37 + 32))(v37);
    if ( v36 == 0 )
      sub_14005FF30(0x80004005);
  }
  v47 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v36 + 24LL))(v36) + 24;
  if ( (unsigned __int8)sub_14005F980(&v47, (__int64)&Locale) == 0 )
    sub_140073980(&v47, &Locale);
  v38 = v47;
  if ( v47 == 0 )
    sub_14005FF30(0x80004005);
  v39 = sub_1404D8590(v51, v47);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v38 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v38 - 24) + 8LL))(*(_QWORD *)(v38 - 24));
  if ( v39 != 0 )
  {
    v49[1] = (__int64)&v47;
    v47 = sub_14005F710((volatile signed __int32 *)(v51 - 24)) + 24;
    v49[0] = sub_14005F710(v14) + 24;
    sub_1401C5020(a1 + 728, v49, &v47);
    v43 = (_QWORD *)(v51 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v51 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v43 + 8LL))(*v43);
    if ( _InterlockedExchangeAdd(v14 + 4, 0xFFFFFFFF) <= 1 )
    {
      v41 = *(_QWORD *)v14;
      v42 = v14;
      goto LABEL_65;
    }
  }
  else
  {
    v40 = (_QWORD *)(v51 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v51 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v40 + 8LL))(*v40);
    if ( _InterlockedExchangeAdd(v14 + 4, 0xFFFFFFFF) <= 1 )
    {
      v41 = *(_QWORD *)v14;
      v42 = v14;
LABEL_65:
      (*(void (__fastcall **)(__int64, int *))(*(_QWORD *)v41 + 8LL))(v41, v42);
    }
  }
LABEL_66:
  v44 = _InterlockedExchangeAdd(v5 - 2, 0xFFFFFFFF);
  v31 = v44 <= 1;
  result = (unsigned int)(v44 - 1);
  if ( v31 )
    result = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v5 - 3) + 8LL))(*((_QWORD *)v5 - 3));
  v46 = (volatile signed __int32 *)(*a2 - 24);
  if ( _InterlockedExchangeAdd(v46 + 4, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v46 + 8LL))(*(_QWORD *)v46);
  return result;
}
