// EA 0x140073d60  name sub_140073D60  size 1205
void __fastcall sub_140073D60(__int64 a1)
{
  _QWORD *v2; // rax
  __int64 v3; // rdx
  __int64 v4; // r8
  _QWORD *v5; // r9
  char v6; // bl
  __int64 v7; // r8
  unsigned __int64 v8; // rax
  _QWORD *v9; // rcx
  _QWORD *v10; // rdx
  _QWORD *v11; // rcx
  _QWORD *v12; // rcx
  __int64 v13; // rax
  _QWORD *v14; // r8
  LPCWSTR v15; // rbx
  unsigned int v16; // eax
  LPCWSTR lpText; // [rsp+40h] [rbp-C0h] BYREF
  char v18; // [rsp+48h] [rbp-B8h] BYREF
  __int16 v19; // [rsp+49h] [rbp-B7h]
  __int64 v20; // [rsp+50h] [rbp-B0h]
  __int64 v21; // [rsp+58h] [rbp-A8h]
  __int64 v22; // [rsp+60h] [rbp-A0h]
  void *Block[2]; // [rsp+68h] [rbp-98h] BYREF
  __int128 v24; // [rsp+78h] [rbp-88h] BYREF
  __int64 v25; // [rsp+88h] [rbp-78h]
  __int64 v26; // [rsp+90h] [rbp-70h]
  __int128 v27; // [rsp+98h] [rbp-68h] BYREF
  __int64 v28; // [rsp+A8h] [rbp-58h]
  __int64 v29; // [rsp+B0h] [rbp-50h]
  _QWORD v30[2]; // [rsp+B8h] [rbp-48h] BYREF
  __int64 v31; // [rsp+C8h] [rbp-38h]
  unsigned __int64 v32; // [rsp+D0h] [rbp-30h]
  __int128 v33; // [rsp+D8h] [rbp-28h] BYREF
  __int64 v34; // [rsp+E8h] [rbp-18h]
  __int64 v35; // [rsp+F0h] [rbp-10h]
  __int128 v36; // [rsp+F8h] [rbp-8h] BYREF
  __int64 v37; // [rsp+108h] [rbp+8h]
  __int64 v38; // [rsp+110h] [rbp+10h]
  __int128 v39; // [rsp+118h] [rbp+18h] BYREF
  __int64 v40; // [rsp+128h] [rbp+28h]
  __int64 v41; // [rsp+130h] [rbp+30h]
  _QWORD v42[2]; // [rsp+138h] [rbp+38h] BYREF
  __int64 v43; // [rsp+148h] [rbp+48h]
  unsigned __int64 v44; // [rsp+150h] [rbp+50h]

  Block[1] = nullptr;
  v2 = operator new(0x48u);
  *v2 = v2;
  v2[1] = v2;
  v2[2] = v2;
  *((_WORD *)v2 + 12) = 257;
  Block[0] = v2;
  v19 = 0;
  v20 = 0;
  v21 = 0;
  v22 = 0;
  v18 = 0;
  sub_140069AD0(v42);
  if ( (unsigned __int64)(0x7FFFFFFFFFFFFFFELL - v43) < 0xA )
    unknown_libname_3();
  v5 = v42;
  if ( v44 > 7 )
    v5 = (_QWORD *)v42[0];
  sub_14005D0A0(&v24, v3, v4, v5, v43, L"config.ini", 10);
  v6 = sub_1401D0A80(&v18, &v24);
  sub_14005D410(&v24);
  if ( v6 != 0 )
  {
    v39 = 0;
    v40 = 0;
    v41 = 0;
    sub_140061270(&v39, L"--", 2);
    v36 = 0;
    v37 = 0;
    v38 = 0;
    sub_140061270(&v36, L"config_id", 9);
    v33 = 0;
    v34 = 0;
    v35 = 0;
    sub_140061270(&v33, L"setting", 7);
    sub_1401D1BB0(&v18, v30, &v33, &v36, &v39);
    sub_14005D410(&v33);
    sub_14005D410(&v36);
    sub_14005D410(&v39);
    v7 = v31;
    v8 = v32;
    v9 = v30;
    v10 = (_QWORD *)v30[0];
    if ( v32 > 7 )
      v9 = (_QWORD *)v30[0];
    if ( v31 == 4 )
    {
      if ( (unsigned int)sub_140074220(v9, L"appx") == 0 )
      {
        *(_DWORD *)a1 = 2;
        *(_BYTE *)(a1 + 5) = 1;
LABEL_27:
        v24 = 0;
        v25 = 0;
        v26 = 0;
        sub_140061270(&v24, L"beta_version", 12);
        v27 = 0;
        v28 = 0;
        v29 = 0;
        sub_140061270(&v27, L"setting", 7);
        *(_DWORD *)(a1 + 12) = sub_1401D18C0(&v18, &v27, &v24, 0);
        sub_14005D410(&v27);
        sub_14005D410(&v24);
        v16 = sub_14006E550();
        *(_BYTE *)(a1 + 7) = v16 >= 0x11;
        *(_BYTE *)(a1 + 8) = v16 >= 0x12;
        v27 = 0;
        v28 = 0;
        v29 = 0;
        sub_140061270(&v27, L"popup_ad_wnd_w", 14);
        v24 = 0;
        v25 = 0;
        v26 = 0;
        sub_140061270(&v24, L"setting", 7);
        *(_DWORD *)(a1 + 24) = sub_1401D18C0(&v18, &v24, &v27, 0);
        sub_14005D410(&v24);
        sub_14005D410(&v27);
        v27 = 0;
        v28 = 0;
        v29 = 0;
        sub_140061270(&v27, L"popup_ad_wnd_h", 14);
        v24 = 0;
        v25 = 0;
        v26 = 0;
        sub_140061270(&v24, L"setting", 7);
        *(_DWORD *)(a1 + 28) = sub_1401D18C0(&v18, &v24, &v27, 0);
        sub_14005D410(&v24);
        sub_14005D410(&v27);
        *(_BYTE *)(a1 + 9) = 0;
        sub_14005D410(v30);
        goto LABEL_28;
      }
      v8 = v32;
      v7 = v31;
      v10 = (_QWORD *)v30[0];
    }
    v11 = v30;
    if ( v8 > 7 )
      v11 = v10;
    if ( v7 == 3 )
    {
      if ( (unsigned int)sub_140074220(v11, L"std") == 0 )
      {
        *(_DWORD *)a1 = 1;
        goto LABEL_27;
      }
      v8 = v32;
      v7 = v31;
      v10 = (_QWORD *)v30[0];
    }
    v12 = v30;
    if ( v8 > 7 )
      v12 = v10;
    if ( v7 != 4 || (unsigned int)sub_140074220(v12, L"test") != 0 )
    {
      v13 = sub_1400601C0(v12, v10, v7);
      if ( v13 == 0 )
        sub_14005FF30(2147500037LL);
      lpText = (LPCWSTR)((*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v13 + 24LL))(v13) + 24);
      v14 = v30;
      if ( v32 > 7 )
        v14 = (_QWORD *)v30[0];
      sub_14005EB50(&lpText, L"Error at config_id: [%ls]!!", v14);
      v15 = lpText;
      MessageBoxW(nullptr, lpText, L"BandiView", 0x30u);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)v15 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v15 - 3) + 8LL))(*((_QWORD *)v15 - 3));
    }
    else
    {
      *(_DWORD *)a1 = 1;
      *(_BYTE *)(a1 + 4) = 1;
    }
    goto LABEL_27;
  }
LABEL_28:
  sub_14005D410(v42);
  sub_1401D0940(&v18);
  sub_1401067C0(Block, Block, *((_QWORD *)Block[0] + 1));
  j_j_j__free_base(Block[0]);
}
