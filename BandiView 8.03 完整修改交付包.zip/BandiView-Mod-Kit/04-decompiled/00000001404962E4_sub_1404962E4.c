// EA 0x1404962e4  name sub_1404962E4  size 35
void __fastcall __noreturn sub_1404962E4(__int64 a1)
{
  _BYTE v1[40]; // [rsp+20h] [rbp-28h] BYREF

  sub_140495FF0(v1, a1);
  sub_1404A2BE0(v1, &_TI3_AVlength_error_std__);
  JUMPOUT(0x140496306LL);
}
