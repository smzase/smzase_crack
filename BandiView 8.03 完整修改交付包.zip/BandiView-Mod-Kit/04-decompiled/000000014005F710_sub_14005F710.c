// EA 0x14005f710  name sub_14005F710  size 290
__int64 __fastcall sub_14005F710(volatile signed __int32 *a1)
{
  __int64 (__fastcall ***v2)(_QWORD, _QWORD, __int64); // rax
  __int64 v4; // rax
  __int64 v5; // rsi
  int v6; // edx
  size_t v7; // rdi
  void *v8; // rcx
  const void *v9; // rbp
  unsigned __int64 v10; // rbx

  v2 = (__int64 (__fastcall ***)(_QWORD, _QWORD, __int64))(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)a1 + 32LL))(*(_QWORD *)a1);
  if ( *((int *)a1 + 4) >= 0 && v2 == *(__int64 (__fastcall ****)(_QWORD, _QWORD, __int64))a1 )
  {
    _InterlockedIncrement(a1 + 4);
    return (__int64)a1;
  }
  v4 = (**v2)(v2, *((unsigned int *)a1 + 2), 2);
  v5 = v4;
  if ( v4 == 0 )
    sub_14005FC20();
  v6 = *((_DWORD *)a1 + 2);
  *(_DWORD *)(v4 + 8) = v6;
  v7 = 2LL * (*((_DWORD *)a1 + 2) + 1);
  if ( v7 == 0 )
    return v5;
  v8 = (void *)(v4 + 24);
  if ( v4 == -24 )
  {
    *(_DWORD *)sub_1404A7740() = 22;
    invalid_parameter_noinfo();
    return -24;
  }
  v9 = (const void *)(a1 + 6);
  v10 = 2LL * (v6 + 1);
  if ( v9 == nullptr || v10 < v7 )
  {
    memset(v8, 0, 2LL * (v6 + 1));
    if ( v9 != nullptr )
    {
      if ( v10 >= v7 )
        return v5;
      *(_DWORD *)sub_1404A7740() = 34;
    }
    else
    {
      *(_DWORD *)sub_1404A7740() = 22;
    }
    invalid_parameter_noinfo();
    return v5;
  }
  memcpy(v8, v9, v7);
  return v5;
}
