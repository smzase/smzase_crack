// EA 0x14009be90  name sub_14009BE90  size 302
void __fastcall sub_14009BE90(__int64 a1, char a2, __int64 a3, bool *a4)
{
  BOOL v6; // esi
  int v7; // ecx
  _QWORD *v8; // rax
  __int64 v9; // rdx
  LPCWSTR *v10; // rax
  int v11; // ebx
  volatile signed __int32 *v12; // rdx
  DWORD cbData; // [rsp+30h] [rbp-38h] BYREF
  DWORD Type[2]; // [rsp+38h] [rbp-30h] BYREF
  __int64 v15; // [rsp+40h] [rbp-28h] BYREF
  BYTE Data[32]; // [rsp+48h] [rbp-20h] BYREF

  v6 = *a4;
  if ( a2 != 0 )
  {
    if ( *(_DWORD *)(a1 + 180) == 0 )
      return;
    v7 = *(_DWORD *)(a1 + 136) - 1;
    if ( v7 != 0 )
    {
      if ( v7 != 1 )
        return;
      v8 = (_QWORD *)sub_140060B30(Type, a1 + 184, a3);
      sub_1401E9EB0(a1 + 8, *(_QWORD *)(a1 + 168), *v8, (_DWORD)a4, v6);
      v9 = *(_QWORD *)Type;
    }
    else
    {
      v10 = (LPCWSTR *)sub_140060B30(&v15, a1 + 184, a3);
      *(_DWORD *)Data = 0;
      cbData = 4;
      Type[0] = 4;
      v11 = v6;
      if ( RegQueryValueExW(*(HKEY *)a1, *v10, nullptr, Type, Data, &cbData) == 0 )
        v11 = *(_DWORD *)Data;
      *a4 = v11 != 0;
      v9 = v15;
    }
    v12 = (volatile signed __int32 *)(v9 - 24);
    if ( _InterlockedExchangeAdd(v12 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v12 + 8LL))(*(_QWORD *)v12);
  }
  else
  {
    sub_14009B970(a1, a3, *a4);
  }
}
