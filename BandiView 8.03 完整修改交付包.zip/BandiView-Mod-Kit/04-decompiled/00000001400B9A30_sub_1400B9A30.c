// EA 0x1400b9a30  name sub_1400B9A30  size 2910
__int64 __fastcall sub_1400B9A30(__int64 a1)
{
  __int64 *v2; // rax
  __int64 *v3; // rax
  __int64 *v4; // rax
  __int64 *v5; // rax
  __int64 *v6; // rax
  bool v7; // al
  __int64 *v8; // rax
  int v9; // eax
  _QWORD *v10; // rdi
  __int64 v11; // rcx
  __int64 *v12; // rax
  __int64 *v13; // rax
  __int64 v14; // r8
  __int64 *v15; // rax
  bool v16; // al
  __int64 *v17; // rax
  int v18; // eax
  _QWORD *v19; // rsi
  __int64 v20; // rcx
  __int64 *v21; // rax
  __int64 *v22; // rax
  __int64 *v23; // rax
  __int64 *v24; // rax
  __int64 *v25; // rax
  __int64 *v26; // rax
  __int64 *v27; // rax
  __int64 *v28; // rax
  __int64 *v29; // rax
  __int64 *v30; // rax
  __int64 *v31; // rax
  __int64 *v32; // rax
  __int64 *v33; // rax
  __int64 *v34; // rax
  __int64 *v35; // rax
  __int64 *v36; // rax
  int *v38; // [rsp+68h] [rbp+28h] BYREF
  int **v39; // [rsp+70h] [rbp+30h] BYREF
  int **v40; // [rsp+78h] [rbp+38h]

  v40 = &v38;
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_LBUTTON") == 0 )
    sub_14005FCF0(&v38, L"CHK_CUSTOM_LBUTTON", 18);
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"IDC_CB_CUSTOM_LBUTTON") == 0 )
    sub_14005FCF0((int **)&v39, L"IDC_CB_CUSTOM_LBUTTON", 21);
  sub_1400AD000(a1, &v39, &v38);
  v40 = &v38;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_LBTNDBL") == 0 )
    sub_14005FCF0(&v38, L"CHK_CUSTOM_LBTNDBL", 18);
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"IDC_CB_CUSTOM_LBTNDBL") == 0 )
    sub_14005FCF0((int **)&v39, L"IDC_CB_CUSTOM_LBTNDBL", 21);
  sub_1400AD000(a1, &v39, &v38);
  v39 = &v38;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_LBUTTON") == 0 )
    sub_14005FCF0(&v38, L"CHK_CUSTOM_LBUTTON", 18);
  v7 = sub_1400ACB10(a1, &v38);
  v39 = &v38;
  if ( v7 )
  {
    v8 = sub_1400601C0();
    if ( v8 == nullptr )
      sub_14005FF30(0x80004005);
    v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24);
    if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"IDC_CB_CUSTOM_LBTNDBL") == 0 )
      sub_14005FCF0(&v38, L"IDC_CB_CUSTOM_LBTNDBL", 21);
    v9 = sub_1401BE5D0(a1 + 728, &v38);
    v10 = (_QWORD *)sub_1404A362C(
                      v9,
                      0,
                      (unsigned int)&AControlBase `RTTI Type Descriptor',
                      (unsigned int)&BvComboBox `RTTI Type Descriptor',
                      0);
    *((_BYTE *)v10 + 520) = 0;
    (*(void (__fastcall **)(_QWORD *))(*v10 + 264LL))(v10);
    (*(void (__fastcall **)(_QWORD *, _QWORD))(*v10 + 224LL))(v10, 0);
    v11 = v10[66];
    if ( v11 != 0 )
      sub_1401BC8D0(v11, v10 + 33);
    v39 = &v38;
    v12 = sub_1400601C0();
    if ( v12 == nullptr )
      sub_14005FF30(0x80004005);
    v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24);
    if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_LBTNDBL") == 0 )
      sub_14005FCF0(&v38, L"CHK_CUSTOM_LBTNDBL", 18);
    sub_1401C4F90(a1 + 728, &v38, 0);
    v39 = &v38;
    v13 = sub_1400601C0();
    if ( v13 == nullptr )
      sub_14005FF30(0x80004005);
    v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24);
    if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CLICK2PAGETURN") == 0 )
      sub_14005FCF0(&v38, L"CHK_CLICK2PAGETURN", 18);
    v14 = 0;
  }
  else
  {
    v15 = sub_1400601C0();
    if ( v15 == nullptr )
      sub_14005FF30(0x80004005);
    v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
    if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CLICK2PAGETURN") == 0 )
      sub_14005FCF0(&v38, L"CHK_CLICK2PAGETURN", 18);
    v16 = sub_1400ACB10(a1, &v38);
    v39 = &v38;
    if ( v16 )
    {
      v17 = sub_1400601C0();
      if ( v17 == nullptr )
        sub_14005FF30(0x80004005);
      v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v17 + 24))(v17) + 24);
      if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"IDC_CB_CUSTOM_LBTNDBL") == 0 )
        sub_14005FCF0(&v38, L"IDC_CB_CUSTOM_LBTNDBL", 21);
      v18 = sub_1401BE5D0(a1 + 728, &v38);
      v19 = (_QWORD *)sub_1404A362C(
                        v18,
                        0,
                        (unsigned int)&AControlBase `RTTI Type Descriptor',
                        (unsigned int)&BvComboBox `RTTI Type Descriptor',
                        0);
      *((_BYTE *)v19 + 520) = 0;
      (*(void (__fastcall **)(_QWORD *))(*v19 + 264LL))(v19);
      (*(void (__fastcall **)(_QWORD *, _QWORD))(*v19 + 224LL))(v19, 0);
      v20 = v19[66];
      if ( v20 != 0 )
        sub_1401BC8D0(v20, v19 + 33);
      v39 = &v38;
      v21 = sub_1400601C0();
      if ( v21 == nullptr )
        sub_14005FF30(0x80004005);
      v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v21 + 24))(v21) + 24);
      if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_LBTNDBL") == 0 )
        sub_14005FCF0(&v38, L"CHK_CUSTOM_LBTNDBL", 18);
      sub_1401C4F90(a1 + 728, &v38, 0);
      v39 = &v38;
      v22 = sub_1400601C0();
      if ( v22 == nullptr )
        sub_14005FF30(0x80004005);
      v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v22 + 24))(v22) + 24);
      if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CLICK2PAGETURN") == 0 )
        sub_14005FCF0(&v38, L"CHK_CLICK2PAGETURN", 18);
    }
    else
    {
      v23 = sub_1400601C0();
      if ( v23 == nullptr )
        sub_14005FF30(0x80004005);
      v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v23 + 24))(v23) + 24);
      if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_LBTNDBL") == 0 )
        sub_14005FCF0(&v38, L"CHK_CUSTOM_LBTNDBL", 18);
      sub_1401C4F90(a1 + 728, &v38, 1);
      v39 = &v38;
      v24 = sub_1400601C0();
      if ( v24 == nullptr )
        sub_14005FF30(0x80004005);
      v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v24 + 24))(v24) + 24);
      if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CLICK2PAGETURN") == 0 )
        sub_14005FCF0(&v38, L"CHK_CLICK2PAGETURN", 18);
    }
    v14 = 1;
  }
  sub_1401C4F90(a1 + 728, &v38, v14);
  v40 = &v38;
  v25 = sub_1400601C0();
  if ( v25 == nullptr )
    sub_14005FF30(0x80004005);
  v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v25 + 24))(v25) + 24);
  if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_MBUTTON") == 0 )
    sub_14005FCF0(&v38, L"CHK_CUSTOM_MBUTTON", 18);
  v26 = sub_1400601C0();
  if ( v26 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v26 + 24))(v26) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"IDC_CB_CUSTOM_MBUTTON") == 0 )
    sub_14005FCF0((int **)&v39, L"IDC_CB_CUSTOM_MBUTTON", 21);
  sub_1400AD000(a1, &v39, &v38);
  v40 = &v38;
  v27 = sub_1400601C0();
  if ( v27 == nullptr )
    sub_14005FF30(0x80004005);
  v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v27 + 24))(v27) + 24);
  if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_RBUTTON") == 0 )
    sub_14005FCF0(&v38, L"CHK_CUSTOM_RBUTTON", 18);
  v28 = sub_1400601C0();
  if ( v28 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"IDC_CB_CUSTOM_RBUTTON") == 0 )
    sub_14005FCF0((int **)&v39, L"IDC_CB_CUSTOM_RBUTTON", 21);
  sub_1400AD000(a1, &v39, &v38);
  v40 = &v38;
  v29 = sub_1400601C0();
  if ( v29 == nullptr )
    sub_14005FF30(0x80004005);
  v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v29 + 24))(v29) + 24);
  if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_XBUTTON") == 0 )
    sub_14005FCF0(&v38, L"CHK_CUSTOM_XBUTTON", 18);
  v30 = sub_1400601C0();
  if ( v30 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v30 + 24))(v30) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"IDC_CB_CUSTOM_XBUTTON") == 0 )
    sub_14005FCF0((int **)&v39, L"IDC_CB_CUSTOM_XBUTTON", 21);
  sub_1400AD000(a1, &v39, &v38);
  v40 = &v38;
  v31 = sub_1400601C0();
  if ( v31 == nullptr )
    sub_14005FF30(0x80004005);
  v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v31 + 24))(v31) + 24);
  if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_YBUTTON") == 0 )
    sub_14005FCF0(&v38, L"CHK_CUSTOM_YBUTTON", 18);
  v32 = sub_1400601C0();
  if ( v32 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v32 + 24))(v32) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"IDC_CB_CUSTOM_YBUTTON") == 0 )
    sub_14005FCF0((int **)&v39, L"IDC_CB_CUSTOM_YBUTTON", 21);
  sub_1400AD000(a1, &v39, &v38);
  v40 = &v38;
  v33 = sub_1400601C0();
  if ( v33 == nullptr )
    sub_14005FF30(0x80004005);
  v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v33 + 24))(v33) + 24);
  if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_WHEELUP") == 0 )
    sub_14005FCF0(&v38, L"CHK_CUSTOM_WHEELUP", 18);
  v34 = sub_1400601C0();
  if ( v34 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v34 + 24))(v34) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"IDC_CB_CUSTOM_WHEELUP") == 0 )
    sub_14005FCF0((int **)&v39, L"IDC_CB_CUSTOM_WHEELUP", 21);
  sub_1400AD000(a1, &v39, &v38);
  v40 = &v38;
  v35 = sub_1400601C0();
  if ( v35 == nullptr )
    sub_14005FF30(0x80004005);
  v38 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v35 + 24))(v35) + 24);
  if ( (unsigned __int8)sub_14005F980(&v38, (__int64)L"CHK_CUSTOM_WHEELDN") == 0 )
    sub_14005FCF0(&v38, L"CHK_CUSTOM_WHEELDN", 18);
  v36 = sub_1400601C0();
  if ( v36 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int **)((*(__int64 (__fastcall **)(__int64 *))(*v36 + 24))(v36) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"IDC_CB_CUSTOM_WHEELDN") == 0 )
    sub_14005FCF0((int **)&v39, L"IDC_CB_CUSTOM_WHEELDN", 21);
  return sub_1400AD000(a1, &v39, &v38);
}
