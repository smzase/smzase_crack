// EA 0x140067d60  name sub_140067D60  size 3964
__int64 __fastcall sub_140067D60(__int64 a1)
{
  __int64 v2; // r8
  __int64 v3; // r8
  int i; // edi
  wchar_t *v6; // rbx
  __int64 *v7; // rax
  int v8; // eax
  unsigned int v9; // ebx
  HWND ActiveWindow; // rbx
  void *v11; // rax
  __int64 v12; // rdi
  __int64 *v13; // rax
  _BYTE *v14; // rbx
  __int64 *v15; // rax
  int v16; // eax
  _BYTE *v17; // rbx
  __int64 *v18; // rax
  int v19; // eax
  __int64 v20; // rsi
  __int64 *v21; // rax
  int v22; // eax
  HWND v23; // rbx
  wchar_t *v24; // rax
  __int64 v25; // rax
  __int64 v26; // rax
  _BYTE *v27; // rbx
  __int64 *v28; // rax
  int v29; // eax
  __int64 v30; // rsi
  __int64 *v31; // rax
  int v32; // eax
  HWND v33; // rbx
  void *v34; // rax
  __int64 v35; // rdx
  __int64 v36; // r8
  void **v37; // r9
  const WCHAR *v38; // r9
  int **EventW; // rdi
  void **v40; // rdx
  _QWORD *v41; // rax
  void **v42; // r8
  int *v43; // rdx
  _QWORD *v44; // rax
  void **v45; // r8
  wchar_t **v46; // rdx
  __int64 *v47; // rax
  __int64 v48; // r8
  int *v49; // rdx
  int *v50; // rdx
  wchar_t *v51; // rdx
  HANDLE v52; // rbx
  __int64 *v53; // rax
  _BYTE *v54; // r14
  int v55; // eax
  int *v56; // rbx
  HANDLE v57; // rbx
  _QWORD *v58; // rdi
  _QWORD *v59; // rbx
  unsigned __int64 v60; // rax
  char v61; // bl
  __int64 *v62; // rax
  wchar_t **v63; // rdi
  wchar_t **v64; // rdx
  WCHAR *v65; // rbx
  __int64 *v66; // rax
  int v67; // eax
  int *v68; // rbx
  HWND v69; // rbx
  void *v70; // rax
  wchar_t **v71; // [rsp+40h] [rbp-C0h] BYREF
  wchar_t **p_Buffer; // [rsp+48h] [rbp-B8h] BYREF
  int **v73; // [rsp+50h] [rbp-B0h]
  HANDLE hObject[2]; // [rsp+58h] [rbp-A8h] BYREF
  LPCVOID lpBaseAddress[2]; // [rsp+68h] [rbp-98h]
  wchar_t **v76; // [rsp+78h] [rbp-88h]
  __int128 v77; // [rsp+80h] [rbp-80h] BYREF
  int **v78; // [rsp+90h] [rbp-70h]
  int *v79; // [rsp+98h] [rbp-68h] BYREF
  wchar_t *Buffer; // [rsp+A0h] [rbp-60h] BYREF
  int *v81; // [rsp+A8h] [rbp-58h] BYREF
  void *Block[2]; // [rsp+B0h] [rbp-50h] BYREF
  __int128 v83; // [rsp+C0h] [rbp-40h]
  LPCWSTR lpName[2]; // [rsp+D0h] [rbp-30h] BYREF
  __int128 v85; // [rsp+E0h] [rbp-20h]
  LPVOID v86[342]; // [rsp+F0h] [rbp-10h] BYREF

  switch ( *(_DWORD *)a1 )
  {
    case 4:
      v9 = sub_14007CFA0();
      memset(v86, 0, 0xAA8u);
      v77 = 0;
      sub_140090170(v86, 0, &v77, v9);
      ActiveWindow = GetActiveWindow();
      v11 = v86[5];
      if ( v86[5] != nullptr || (v11 = (void *)sub_140495D90(), v86[5] = v11, v11 != nullptr) )
      {
        sub_140495EC0(v11, 0, 0);
        v86[2] = v86;
        LODWORD(v86[3]) = GetCurrentThreadId();
        EnterCriticalSection(&CriticalSection);
        v86[4] = (LPVOID)qword_1406FBC60;
        qword_1406FBC60 = (__int64)&v86[2];
        LeaveCriticalSection(&CriticalSection);
        DialogBoxParamW(hInstance, (LPCWSTR)LOWORD(v86[90]), ActiveWindow, DialogFunc, 0);
      }
      else
      {
        SetLastError(0xEu);
      }
      sub_140090520(v86);
      v12 = sub_140075FE0();
      p_Buffer = &Buffer;
      v13 = sub_1400601C0();
      if ( v13 == nullptr )
        sub_14005FF30(0x80004005);
      Buffer = (wchar_t *)((*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24);
      if ( (unsigned __int8)sub_14005F980(&Buffer, (__int64)&Data) == 0 )
        sub_14005FCF0((int **)&Buffer, &Data, 0);
      sub_140076F50(v12, 1, &Buffer);
      return 0;
    case 5:
      *(_BYTE *)(sub_14007D5E0() + 97) = 1;
      v86[1] = nullptr;
      memset(&v86[5], 0, 20);
      v86[0] = &RegDlg::`vftable';
      v86[9] = nullptr;
      memset(&v86[13], 0, 20);
      v86[16] = DefWindowProcW;
      v86[8] = &XGroupCheckListCtrl::`vftable';
      *(_OWORD *)&v86[17] = 0u;
      v33 = GetActiveWindow();
      v34 = (void *)sub_140495D90();
      v86[5] = v34;
      if ( v34 != nullptr )
      {
        sub_140495EC0(v34, 0, 0);
        v86[2] = v86;
        LODWORD(v86[3]) = GetCurrentThreadId();
        EnterCriticalSection(&CriticalSection);
        v86[4] = (LPVOID)qword_1406FBC60;
        qword_1406FBC60 = (__int64)&v86[2];
        LeaveCriticalSection(&CriticalSection);
        DialogBoxParamW(hInstance, (LPCWSTR)0x8F, v33, DialogFunc, 0);
      }
      else
      {
        SetLastError(0xEu);
      }
      v86[0] = &RegDlg::`vftable';
      v86[8] = &XGroupCheckListCtrl::`vftable';
      if ( v86[13] != nullptr )
        sub_140495E60(v86[13]);
      goto LABEL_165;
    case 6:
      sub_1400930D0(1);
      sub_1400930D0(0);
      sub_140093CE0();
      for ( i = 0; i < 25; ++i )
      {
        p_Buffer = &Buffer;
        v6 = (&off_1406DC948)[3 * (unsigned int)i];
        v7 = sub_1400601C0();
        if ( v7 == nullptr )
          sub_14005FF30(0x80004005);
        Buffer = (wchar_t *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
        if ( (unsigned __int8)sub_14005F980(&Buffer, (__int64)v6) == 0 )
        {
          if ( v6 != nullptr )
            v8 = sub_1404ADC20(v6);
          else
            v8 = 0;
          sub_14005FCF0((int **)&Buffer, v6, v8);
        }
        sub_1400AC190(&Buffer);
      }
      return 0;
    case 7:
      *(_BYTE *)(sub_14007D5E0() + 97) = 1;
      LOBYTE(v2) = 1;
      sub_1400922F0(1, 1, v2, 100);
      LOBYTE(v3) = 1;
      sub_1400922F0(0, 1, v3, 100);
      return 0;
    case 8:
      *(_BYTE *)(sub_14007D5E0() + 97) = 1;
      sub_140093680();
      return 0;
    case 0xB:
      *(_BYTE *)(sub_14007D5E0() + 97) = 1;
      p_Buffer = (wchar_t **)&v81;
      v14 = (_BYTE *)(a1 + 72);
      if ( *(_QWORD *)(a1 + 96) > 7u )
        v14 = *(_BYTE **)v14;
      v15 = sub_1400601C0();
      if ( v15 == nullptr )
        sub_14005FF30(0x80004005);
      v81 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
      if ( (unsigned __int8)sub_14005F980(&v81, (__int64)v14) == 0 )
      {
        if ( v14 != nullptr )
          v16 = sub_1404ADC20(v14);
        else
          v16 = 0;
        sub_14005FCF0(&v81, v14, v16);
      }
      v73 = &v79;
      v17 = (_BYTE *)(a1 + 40);
      if ( *(_QWORD *)(a1 + 64) > 7u )
        v17 = *(_BYTE **)v17;
      v18 = sub_1400601C0();
      if ( v18 == nullptr )
        sub_14005FF30(0x80004005);
      v79 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v18 + 24))(v18) + 24);
      if ( (unsigned __int8)sub_14005F980(&v79, (__int64)v17) == 0 )
      {
        if ( v17 != nullptr )
          v19 = sub_1404ADC20(v17);
        else
          v19 = 0;
        sub_14005FCF0(&v79, v17, v19);
      }
      v71 = &Buffer;
      v20 = a1 + 8;
      if ( *(_QWORD *)(v20 + 24) > 7u )
        v20 = *(_QWORD *)v20;
      v21 = sub_1400601C0();
      if ( v21 == nullptr )
        sub_14005FF30(0x80004005);
      Buffer = (wchar_t *)((*(__int64 (__fastcall **)(__int64 *))(*v21 + 24))(v21) + 24);
      if ( (unsigned __int8)sub_14005F980(&Buffer, v20) == 0 )
      {
        if ( v20 != 0 )
          v22 = sub_1404ADC20(v20);
        else
          v22 = 0;
        sub_14005FCF0((int **)&Buffer, (_BYTE *)v20, v22);
      }
      v23 = nullptr;
      v71 = nullptr;
      v24 = Buffer;
      if ( *((_DWORD *)Buffer - 4) != 0 )
      {
        sub_14006B720(Buffer, (wchar_t *)L"%p");
        v24 = Buffer;
        v23 = (HWND)v71;
      }
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)v24 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v24 - 3) + 8LL))(*((_QWORD *)v24 - 3));
      sub_140095080(v23);
      return 0;
    case 0xC:
      *(_BYTE *)(sub_14007D5E0() + 97) = 1;
      v25 = sub_140075FE0();
      v71 = (wchar_t **)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(v25 + 544) - 24LL)) + 24);
      sub_140096530(&v79, &v71);
      return (unsigned int)v79;
    case 0xD:
      *(_BYTE *)(sub_14007D5E0() + 97) = 1;
      p_Buffer = (wchar_t **)&v71;
      v26 = sub_140075FE0();
      v71 = (wchar_t **)(sub_14005F710((volatile signed __int32 *)(*(_QWORD *)(v26 + 544) - 24LL)) + 24);
      v73 = &v79;
      v27 = (_BYTE *)(a1 + 40);
      if ( *(_QWORD *)(a1 + 64) > 7u )
        v27 = *(_BYTE **)v27;
      v28 = sub_1400601C0();
      if ( v28 == nullptr )
        sub_14005FF30(0x80004005);
      v79 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24);
      if ( (unsigned __int8)sub_14005F980(&v79, (__int64)v27) == 0 )
      {
        if ( v27 != nullptr )
          v29 = sub_1404ADC20(v27);
        else
          v29 = 0;
        sub_14005FCF0(&v79, v27, v29);
      }
      Buffer = (wchar_t *)&v81;
      v30 = a1 + 8;
      if ( *(_QWORD *)(v30 + 24) > 7u )
        v30 = *(_QWORD *)v30;
      v31 = sub_1400601C0();
      if ( v31 == nullptr )
        sub_14005FF30(0x80004005);
      v81 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v31 + 24))(v31) + 24);
      if ( (unsigned __int8)sub_14005F980(&v81, v30) == 0 )
      {
        if ( v30 != 0 )
          v32 = sub_1404ADC20(v30);
        else
          v32 = 0;
        sub_14005FCF0(&v81, (_BYTE *)v30, v32);
      }
      return sub_140097230(&v81, &v79, &v71);
    case 0x14:
      sub_1400693B0(Block, a1 + 8);
      v76 = nullptr;
      hObject[1] = nullptr;
      hObject[0] = nullptr;
      lpBaseAddress[1] = nullptr;
      lpBaseAddress[0] = nullptr;
      v73 = nullptr;
      if ( (unsigned __int64)(0x7FFFFFFFFFFFFFFELL - v83) < 6 )
        unknown_libname_3();
      v37 = Block;
      if ( *((_QWORD *)&v83 + 1) > 7u )
        v37 = (void **)Block[0];
      sub_14005D0A0((char *)lpName, v35, v36, v37, v83, L"_event", 6);
      v38 = (const WCHAR *)lpName;
      if ( *((_QWORD *)&v85 + 1) > 7u )
        v38 = lpName[0];
      EventW = (int **)CreateEventW(nullptr, true, false, v38);
      v73 = EventW;
      v40 = Block;
      if ( *((_QWORD *)&v83 + 1) > 7u )
        v40 = (void **)Block[0];
      if ( (unsigned int)sub_140098310(hObject, v40) == 0 )
      {
        v71 = v76;
        Buffer = nullptr;
        v41 = (_QWORD *)sub_1401C0850(&v79, &v71);
        v42 = Block;
        if ( *((_QWORD *)&v83 + 1) > 7u )
          v42 = (void **)Block[0];
        sub_140072490(&Buffer, L"%s, err:%s", v42, *v41);
        v43 = v79 - 6;
        if ( _InterlockedExchangeAdd(v79 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v43 + 8LL))(*(_QWORD *)v43);
        v81 = nullptr;
        v44 = (_QWORD *)sub_1401C0850(&p_Buffer, &v71);
        v45 = Block;
        if ( *((_QWORD *)&v83 + 1) > 7u )
          v45 = (void **)Block[0];
        sub_140072490(&v81, L"error at mmf.OpenExisting() - %s, err:%s", v45, *v44);
        v46 = p_Buffer - 3;
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)p_Buffer - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(wchar_t *))(*(_QWORD *)*v46 + 8LL))(*v46);
        v78 = &v79;
        v47 = sub_1400601C0();
        if ( v47 == nullptr )
          sub_14005FF30(0x80004005);
        v79 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v47 + 24))(v47) + 24);
        if ( (unsigned __int8)sub_14005F980(&v79, (__int64)L"error") == 0 )
          sub_14005FCF0(&v79, L"error", 5);
        v71 = (wchar_t **)(sub_14005F710(v81 - 6) + 24);
        LOBYTE(v48) = 1;
        sub_140074840(&v71, &v79, v48);
        sub_14007D7F0(&v79);
        sub_1401C56D0(&v71, L"TEXT_ERR_AT_CANT_OPEN_MMF", Buffer, L"TEXT");
        sub_14008B0F0(nullptr);
        v49 = v79 - 6;
        if ( _InterlockedExchangeAdd(v79 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v49 + 8LL))(*(_QWORD *)v49);
        v50 = v81 - 6;
        if ( _InterlockedExchangeAdd(v81 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v50 + 8LL))(*(_QWORD *)v50);
        v51 = Buffer - 12;
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)Buffer - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v51 + 8LL))(*(_QWORD *)v51);
        sub_14005D410((char **)lpName);
        if ( EventW != nullptr )
          CloseHandle(EventW);
        v52 = hObject[1];
        if ( hObject[1] != nullptr )
        {
          if ( lpBaseAddress[1] != nullptr )
            UnmapViewOfFile(lpBaseAddress[1]);
          CloseHandle(v52);
          if ( hObject[0] != nullptr )
            CloseHandle(hObject[0]);
        }
        sub_14005D410((char **)Block);
        return 102;
      }
      v53 = sub_1400601C0();
      if ( v53 == nullptr )
        sub_14005FF30(0x80004005);
      v54 = lpBaseAddress[1];
      v79 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v53 + 24))(v53) + 24);
      if ( (unsigned __int8)sub_14005F980(&v79, (__int64)v54) == 0 )
      {
        if ( v54 != nullptr )
          v55 = sub_1404ADC20(v54);
        else
          v55 = 0;
        sub_14005FCF0(&v79, v54, v55);
      }
      v56 = v79;
      sub_1400869A0(v79, a1);
      SetEvent(EventW);
      if ( _InterlockedExchangeAdd(v56 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v56 - 3) + 8LL))(*((_QWORD *)v56 - 3));
      sub_14005D410((char **)lpName);
      if ( EventW != nullptr )
        CloseHandle(EventW);
      v57 = hObject[1];
      if ( hObject[1] != nullptr )
      {
        if ( v54 != nullptr )
          UnmapViewOfFile(v54);
        CloseHandle(v57);
        if ( hObject[0] != nullptr )
          CloseHandle(hObject[0]);
      }
      sub_14005D410((char **)Block);
      return 999999;
    case 0x16:
      v58 = (_QWORD *)(a1 + 8);
      Block[0] = nullptr;
      Block[1] = nullptr;
      v83 = 0u;
      v59 = (_QWORD *)(a1 + 8);
      if ( *(_QWORD *)(a1 + 32) > 7u )
        v59 = (_QWORD *)*v58;
      LOBYTE(Buffer) = 0;
      WORD1(Buffer) = 0;
      if ( v59 == nullptr )
      {
        Block[0] = (void *)3134259209LL;
LABEL_129:
        v62 = sub_1400601C0();
        if ( v62 == nullptr )
          sub_14005FF30(0x80004005);
        v71 = (wchar_t **)((*(__int64 (__fastcall **)(__int64 *))(*v62 + 24))(v62) + 24);
        if ( v58[3] > 7u )
          v58 = (_QWORD *)*v58;
        sub_14005EB50((__int64)&v71, (__int64)L"Error: Cannot open %ls", v58);
        sub_14007D7F0(&p_Buffer);
        v63 = v71;
        v79 = (int *)(sub_14005F710((volatile signed __int32 *)v71 - 6) + 24);
        sub_14008B0F0(nullptr);
        v64 = p_Buffer - 3;
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)p_Buffer - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(wchar_t *))(*(_QWORD *)*v64 + 8LL))(*v64);
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)v63 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD, wchar_t **))(*(_QWORD *)*(v63 - 3) + 8LL))(*(v63 - 3), v63 - 3);
        if ( Block[1] != nullptr )
        {
          j__free_base(Block[1]);
          Block[1] = nullptr;
        }
        DWORD1(v83) = 0;
        if ( *((_QWORD *)&v83 + 1) != 0 )
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v83 + 1) + 16LL))(*((_QWORD *)&v83 + 1));
        return 104;
      }
      *(_OWORD *)lpName = 0;
      v85 = 0;
      v60 = sub_1404ADC20(v59);
      sub_140061270((char **)lpName, v59, v60);
      v61 = sub_1401CA3C0(Block, lpName, &Buffer);
      sub_14005D410((char **)lpName);
      if ( v61 == 0 )
        goto LABEL_129;
      v65 = (WCHAR *)&Data;
      if ( Block[1] != nullptr )
        v65 = (WCHAR *)Block[1];
      v66 = sub_1400601C0();
      if ( v66 == nullptr )
        sub_14005FF30(0x80004005);
      v79 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v66 + 24))(v66) + 24);
      if ( (unsigned __int8)sub_14005F980(&v79, (__int64)v65) == 0 )
      {
        if ( v65 != nullptr )
          v67 = sub_1404ADC20(v65);
        else
          v67 = 0;
        sub_14005FCF0(&v79, v65, v67);
      }
      v68 = v79;
      sub_1400869A0(v79, a1);
      if ( _InterlockedExchangeAdd(v68 - 2, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v68 - 3) + 8LL))(*((_QWORD *)v68 - 3));
      if ( Block[1] != nullptr )
      {
        j__free_base(Block[1]);
        Block[1] = nullptr;
      }
      DWORD1(v83) = 0;
      if ( *((_QWORD *)&v83 + 1) != 0 )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v83 + 1) + 16LL))(*((_QWORD *)&v83 + 1));
      return 999999;
    case 0x18:
      memset(&v86[9], 0, 104);
      memset(&v86[1], 0, 56);
      v86[0] = &CLicenseGuideDlg::`vftable';
      v86[8] = &CLicenseGuideDlg::`vftable';
      sub_1401E1D20(&v86[10]);
      LODWORD(v86[9]) = 1;
      v69 = GetActiveWindow();
      v70 = (void *)sub_140495D90();
      v86[5] = v70;
      if ( v70 != nullptr )
      {
        sub_140495EC0(v70, 0, 0);
        v86[2] = v86;
        LODWORD(v86[3]) = GetCurrentThreadId();
        EnterCriticalSection(&CriticalSection);
        v86[4] = (LPVOID)qword_1406FBC60;
        qword_1406FBC60 = (__int64)&v86[2];
        LeaveCriticalSection(&CriticalSection);
        DialogBoxParamW(hInstance, (LPCWSTR)0x88, v69, DialogFunc, 0);
      }
      else
      {
        SetLastError(0xEu);
      }
      v86[0] = &CLicenseGuideDlg::`vftable';
      v86[8] = &CLicenseGuideDlg::`vftable';
      v86[10] = &CSkinnedWindow::`vftable';
      if ( v86[20] != nullptr )
        (*(void (__fastcall **)(LPVOID, __int64))(*(_QWORD *)v86[20] + 32LL))(v86[20], 1);
      if ( v86[15] != nullptr )
        sub_140495E60(v86[15]);
      v86[8] = &IXSkinCallback::`vftable';
LABEL_165:
      if ( v86[5] != nullptr )
        sub_140495E60(v86[5]);
      return 0;
    default:
      return 999999;
  }
}
