// EA 0x140495d90  name sub_140495D90  size 122
_QWORD *sub_140495D90()
{
  HANDLE ProcessHeap; // rax
  _QWORD *v1; // rbx
  __int64 (*v3)(void); // rax
  __int64 v4; // rax
  HANDLE v5; // rax

  ProcessHeap = GetProcessHeap();
  v1 = HeapAlloc(ProcessHeap, 8u, 0x10u);
  if ( v1 == nullptr )
    return nullptr;
  v3 = (__int64 (*)(void))sub_140495B38(&qword_1407065A8);
  *(_DWORD *)v1 = v3 == nullptr;
  if ( v3 != nullptr )
    v4 = v3();
  else
    v4 = sub_140495C38();
  v1[1] = v4;
  if ( v4 == 0 )
  {
    v5 = GetProcessHeap();
    HeapFree(v5, 0, v1);
    return nullptr;
  }
  return v1;
}
