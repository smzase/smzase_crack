// EA 0x140096900  name sub_140096900  size 160
int **__fastcall sub_140096900(int **a1, __int64 a2)
{
  __int64 *v3; // rax
  int v4; // eax
  _BYTE v6[80]; // [rsp+30h] [rbp-68h] BYREF

  sub_1400AE080(a2, v6);
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
  if ( (unsigned __int8)sub_14005F980(a1, (__int64)v6) == 0 )
  {
    v4 = sub_1404ADC20(v6);
    sub_14005FCF0(a1, v6, v4);
  }
  return a1;
}
