// EA 0x140074220  name sub_140074220  size 384
__int64 __fastcall sub_140074220(const __m128i *a1, const __m128i *a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // rax
  const __m128i *v7; // r10
  unsigned int v11; // ecx
  __int64 v12; // r9
  unsigned int v13; // r8d
  unsigned __int64 v14; // rdx
  __int64 result; // rax
  unsigned int v16; // r8d
  unsigned int v17; // edx
  unsigned int v18; // r8d
  unsigned __int16 v19; // cx
  bool v20; // cf

  v3 = 0;
  _R9 = a1;
  v7 = a2;
  if ( dword_140709230 != 0 && a3 >= 0x10 )
  {
    while ( 1 )
    {
      __asm
      {
        vmovdqu ymm1, ymmword ptr [r9]
        vpcmpeqw ymm1, ymm1, ymmword ptr [r10]
        vpmovmskb ecx, ymm1
      }
      if ( _ECX != -1 )
        break;
      v3 += 16LL;
      _R9 += 2;
      v7 += 2;
      if ( v3 + 16 > a3 )
      {
        __asm { vzeroupper }
        goto LABEL_6;
      }
    }
    v16 = 1;
    _BitScanForward(&v17, ~_ECX);
    if ( a1->m128i_i16[((unsigned __int64)v17 >> 1) + v3] < (unsigned int)a2->m128i_i16[((unsigned __int64)v17 >> 1)
                                                                                      + v3] )
      v16 = -1;
    __asm { vzeroupper }
    return v16;
  }
  else
  {
LABEL_6:
    if ( v3 + 8 > a3 )
    {
LABEL_9:
      if ( v3 + 4 <= a3 )
      {
        v12 = _R9->m128i_i64[0];
        if ( v12 != v7->m128i_i64[0] )
        {
          v13 = 1;
          _BitScanForward64(&v14, v12 ^ v7->m128i_i64[0]);
          if ( a1->m128i_i16[(v14 >> 4) + v3] < (unsigned int)a2->m128i_i16[(v14 >> 4) + v3] )
            return (unsigned int)-1;
          return v13;
        }
        v3 += 4LL;
      }
      if ( v3 >= a3 )
      {
        return 0;
      }
      else
      {
        while ( 1 )
        {
          v19 = a1->m128i_u16[v3];
          v20 = v19 < (unsigned int)a2->m128i_i16[v3];
          if ( v19 != a2->m128i_i16[v3] )
            break;
          if ( ++v3 >= a3 )
            return 0;
        }
        result = 1;
        if ( v20 )
          return 0xFFFFFFFFLL;
      }
    }
    else
    {
      while ( 1 )
      {
        LOWORD(v11) = _mm_movemask_epi8(_mm_cmpeq_epi16(_mm_loadu_si128(v7), _mm_loadu_si128(_R9)));
        if ( (_WORD)v11 != 0xFFFF )
          break;
        v3 += 8LL;
        ++_R9;
        ++v7;
        if ( v3 + 8 > a3 )
          goto LABEL_9;
      }
      v18 = 1;
      _BitScanForward(&v11, ~(unsigned __int16)v11);
      if ( a1->m128i_i16[((unsigned __int64)v11 >> 1) + v3] < (unsigned int)a2->m128i_i16[((unsigned __int64)v11 >> 1)
                                                                                        + v3] )
        return (unsigned int)-1;
      return v18;
    }
  }
  return result;
}
