// EA 0x14009bbc0  name sub_14009BBC0  size 711
__int64 __fastcall sub_14009BBC0(__int64 a1, __int64 a2, const WCHAR **a3)
{
  volatile signed __int32 *v5; // rdx
  int v7; // ecx
  int v8; // ecx
  const WCHAR *v9; // rbx
  __int64 v10; // rbp
  __int64 *v11; // rax
  __int64 v12; // rcx
  __int64 v13; // rcx
  __int64 v14; // rbx
  unsigned int v15; // ebp
  _QWORD *v16; // rdx
  _QWORD *v17; // rdx
  _QWORD *v18; // rdx
  volatile signed __int32 *v19; // rdx
  const WCHAR *v20; // rbx
  _QWORD *v21; // rax
  unsigned int v22; // ebx
  _QWORD *v23; // rdx
  volatile signed __int32 *v24; // rdx
  const WCHAR *lpData; // rbp
  const WCHAR **v26; // rax
  const WCHAR *v27; // rbx
  int v28; // eax
  _QWORD *v29; // rdx
  volatile signed __int32 *v30; // rdx
  __int64 v31; // [rsp+30h] [rbp-28h] BYREF
  _QWORD v32[4]; // [rsp+38h] [rbp-20h] BYREF
  __int64 v33; // [rsp+60h] [rbp+8h] BYREF
  const WCHAR **v34; // [rsp+70h] [rbp+18h]
  __int64 v35; // [rsp+78h] [rbp+20h] BYREF

  v34 = a3;
  if ( *(_DWORD *)(a1 + 180) == 0 )
  {
LABEL_2:
    v5 = (volatile signed __int32 *)(*a3 - 12);
    if ( _InterlockedExchangeAdd(v5 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v5 + 8LL))(*(_QWORD *)v5);
    return 0;
  }
  v7 = *(_DWORD *)(a1 + 136) - 1;
  if ( v7 == 0 )
  {
    lpData = *a3;
    v26 = (const WCHAR **)sub_140060B30(&v33, a1 + 184, a2);
    if ( *(_QWORD *)a1 != 0 && lpData != nullptr )
    {
      v27 = *v26;
      v28 = lstrlenW(lpData);
      v22 = RegSetValueExW(*(HKEY *)a1, v27, 0, 1u, (const BYTE *)lpData, 2 * v28) == 0;
    }
    else
    {
      v22 = 0;
    }
    v29 = (_QWORD *)(v33 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v33 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v29 + 8LL))(*v29);
    v30 = (volatile signed __int32 *)(*a3 - 12);
    if ( _InterlockedExchangeAdd(v30 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v30 + 8LL))(*(_QWORD *)v30);
    return v22;
  }
  v8 = v7 - 1;
  if ( v8 == 0 )
  {
    v20 = *a3;
    v21 = (_QWORD *)sub_140060B30(&v33, a1 + 184, a2);
    v22 = sub_1401EA270(a1 + 8, *(_QWORD *)(a1 + 168), *v21, v20);
    v23 = (_QWORD *)(v33 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v33 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v23 + 8LL))(*v23);
    v24 = (volatile signed __int32 *)(*a3 - 12);
    if ( _InterlockedExchangeAdd(v24 + 4, 0xFFFFFFFF) <= 1 )
    {
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v24 + 8LL))(*(_QWORD *)v24);
      return v22;
    }
    return v22;
  }
  if ( v8 != 1 )
    goto LABEL_2;
  v9 = *a3;
  v10 = *(_QWORD *)sub_140060B30(v32, a1 + 184, a2);
  v11 = sub_1400601C0();
  if ( v11 == nullptr )
    sub_14005FF30(0x80004005);
  v33 = (*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24;
  sub_14009B0E0(v12, &v31, v9);
  sub_14009B0E0(v13, &v35, v10);
  sub_14005EB50((__int64)&v33, (__int64)L"\"%s\"=\"%s\"", v35, v31);
  v14 = v33;
  v15 = sub_14009B050(a1 + 128, v33);
  v16 = (_QWORD *)(v35 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v35 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v16 + 8LL))(*v16);
  v17 = (_QWORD *)(v31 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v31 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v17 + 8LL))(*v17);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v14 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v14 - 24) + 8LL))(*(_QWORD *)(v14 - 24));
  v18 = (_QWORD *)(v32[0] - 24LL);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v32[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v18 + 8LL))(*v18);
  v19 = (volatile signed __int32 *)(*a3 - 12);
  if ( _InterlockedExchangeAdd(v19 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v19 + 8LL))(*(_QWORD *)v19);
  return v15;
}
