// EA 0x14005ff30  name sub_14005FF30  size 34
void __fastcall __noreturn sub_14005FF30(unsigned int a1)
{
  char v1; // [rsp+38h] [rbp+10h] BYREF

  sub_14005FF20(&v1, a1);
  sub_1404A2BE0(&v1, &_TI1_AVCAtlException_ATL__);
  JUMPOUT(0x14005FF51LL);
}
