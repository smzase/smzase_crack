// EA 0x14005fa90  name sub_14005FA90  size 149
void __fastcall sub_14005FA90(int **a1)
{
  int *v2; // r8
  volatile signed __int32 *v3; // rdx
  __int64 v4; // rdi

  v2 = *a1;
  v3 = *a1 - 6;
  if ( *((_DWORD *)v3 + 2) != 0 )
  {
    if ( *((int *)v3 + 4) >= 0 )
    {
      v4 = *(_QWORD *)v3;
      if ( _InterlockedExchangeAdd(v3 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v3 + 8LL))(*(_QWORD *)v3);
      *a1 = (int *)((*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4) + 24);
    }
    else
    {
      if ( *(v2 - 3) < 0 )
        sub_14005FF30(2147942487LL);
      *(v2 - 4) = 0;
      *(_WORD *)*a1 = 0;
    }
  }
}
