// EA 0x14056f480  name memset  size 904
void *__cdecl memset(void *a1, int Val, size_t Size)
{
  void *result; // rax
  __int64 v6; // r11
  char *v8; // rcx
  __m128i v9; // xmm0
  __int64 v11; // r9
  __int64 v16; // r9
  __m128i *v17; // rcx
  unsigned __int64 v18; // r8
  unsigned __int64 v19; // r9

  result = a1;
  v6 = 0x101010101010101LL * (unsigned __int8)Val;
  v8 = (char *)a1 + Size;
  switch ( Size )
  {
    case 0uLL:
      return result;
    case 1uLL:
      goto LABEL_5;
    case 2uLL:
      goto LABEL_8;
    case 3uLL:
      goto LABEL_4;
    case 4uLL:
      goto LABEL_12;
    case 5uLL:
      goto LABEL_10;
    case 6uLL:
      goto LABEL_7;
    case 7uLL:
      goto LABEL_3;
    case 8uLL:
      *((_QWORD *)v8 - 1) = v6;
      return result;
    case 9uLL:
      *(_QWORD *)(v8 - 9) = v6;
      *(v8 - 1) = Val;
      return result;
    case 0xAuLL:
      *(_QWORD *)(v8 - 10) = v6;
      *((_WORD *)v8 - 1) = v6;
      return result;
    case 0xBuLL:
      *(_QWORD *)(v8 - 11) = v6;
      *(_WORD *)(v8 - 3) = v6;
      *(v8 - 1) = Val;
      return result;
    case 0xCuLL:
      *(_QWORD *)(v8 - 12) = v6;
LABEL_12:
      *((_DWORD *)v8 - 1) = v6;
      return result;
    case 0xDuLL:
      *(_QWORD *)(v8 - 13) = v6;
LABEL_10:
      *(_DWORD *)(v8 - 5) = v6;
      *(v8 - 1) = Val;
      return result;
    case 0xEuLL:
      *(_QWORD *)(v8 - 14) = v6;
LABEL_7:
      *(_DWORD *)(v8 - 6) = v6;
LABEL_8:
      *((_WORD *)v8 - 1) = v6;
      return result;
    case 0xFuLL:
      *(_QWORD *)(v8 - 15) = v6;
LABEL_3:
      *(_DWORD *)(v8 - 7) = v6;
LABEL_4:
      *(_WORD *)(v8 - 3) = v6;
LABEL_5:
      *(v8 - 1) = Val;
      return result;
    default:
      v9 = _mm_unpacklo_epi64((__m128i)(unsigned __int64)v6, (__m128i)(unsigned __int64)v6);
      if ( Size <= 0x20 )
      {
        *(__m128i *)a1 = v9;
        *(__m128i *)((char *)a1 + Size - 16) = v9;
        return result;
      }
      if ( (unsigned int)dword_1406DA088 < 3 )
      {
        if ( Size <= qword_1406DA090 || (dword_14070662C & 2) == 0 )
        {
          v16 = ((unsigned __int8)a1 & 0xF) - 16LL;
          v17 = (__m128i *)((char *)a1 - v16);
          v18 = v16 + Size;
          if ( v18 > 0x80 )
          {
            do
            {
              *v17 = v9;
              v17[1] = v9;
              v17[2] = v9;
              v17[3] = v9;
              v17[4] = v9;
              v17[5] = v9;
              v17[6] = v9;
              v17[7] = v9;
              v17 += 8;
              v18 -= 128LL;
            }
            while ( v18 >= 0x80 );
          }
          v19 = (v18 + 15) & 0xFFFFFFFFFFFFFFF0uLL;
          switch ( v19 >> 4 )
          {
            case 0uLL:
              goto LABEL_60;
            case 1uLL:
              goto LABEL_59;
            case 2uLL:
              goto LABEL_58;
            case 3uLL:
              goto LABEL_57;
            case 4uLL:
              goto LABEL_56;
            case 5uLL:
              goto LABEL_55;
            case 6uLL:
              goto LABEL_54;
            case 7uLL:
              goto LABEL_53;
            case 8uLL:
              *(__m128i *)((char *)v17 + v19 - 128) = v9;
LABEL_53:
              *(__m128i *)((char *)v17 + v19 - 112) = v9;
LABEL_54:
              *(__m128i *)((char *)v17 + v19 - 96) = v9;
LABEL_55:
              *(__m128i *)((char *)v17 + v19 - 80) = v9;
LABEL_56:
              *(__m128i *)((char *)v17 + v19 - 64) = v9;
LABEL_57:
              *(__m128i *)((char *)v17 + v19 - 48) = v9;
LABEL_58:
              *(__m128i *)((char *)v17 + v19 - 32) = v9;
LABEL_59:
              *(__m128i *)((char *)v17 + v18 - 16) = v9;
LABEL_60:
              *(__m128i *)result = v9;
              break;
          }
          return result;
        }
        return memset_repstos(a1, (unsigned __int8)Val, Size, a1);
      }
      if ( Size > qword_1406DA090 && Size <= qword_1406DA098 && (dword_14070662C & 2) != 0 )
        return memset_repstos(a1, (unsigned __int8)Val, Size, a1);
      __asm { vinsertf128 ymm0, ymm0, xmm0, 1 }
      v11 = ((unsigned __int8)a1 & 0x1F) - 32LL;
      _RCX = (char *)a1 - v11;
      _R8 = v11 + Size;
      if ( _R8 <= 0x100 )
        goto LABEL_26;
      if ( _R8 <= qword_1406DA098 )
      {
        do
        {
          __asm
          {
            vmovdqa ymmword ptr [rcx], ymm0
            vmovdqa ymmword ptr [rcx+20h], ymm0
            vmovdqa ymmword ptr [rcx+40h], ymm0
            vmovdqa ymmword ptr [rcx+60h], ymm0
            vmovdqa ymmword ptr [rcx+80h], ymm0
            vmovdqa ymmword ptr [rcx+0A0h], ymm0
            vmovdqa ymmword ptr [rcx+0C0h], ymm0
            vmovdqa ymmword ptr [rcx+0E0h], ymm0
          }
          _RCX += 256;
          _R8 -= 256LL;
        }
        while ( _R8 >= 0x100 );
LABEL_26:
        _R9 = (_R8 + 31) & 0xFFFFFFFFFFFFFFE0uLL;
        switch ( _R9 >> 5 )
        {
          case 0uLL:
            goto LABEL_35;
          case 1uLL:
            goto LABEL_34;
          case 2uLL:
            goto LABEL_33;
          case 3uLL:
            goto LABEL_32;
          case 4uLL:
            goto LABEL_31;
          case 5uLL:
            goto LABEL_30;
          case 6uLL:
            goto LABEL_29;
          case 7uLL:
            goto LABEL_28;
          case 8uLL:
            __asm { vmovdqu ymmword ptr [rcx+r9-100h], ymm0; jumptable 000000014056F614 case 8 }
LABEL_28:
            __asm { vmovdqu ymmword ptr [rcx+r9-0E0h], ymm0; jumptable 000000014056F614 case 7 }
LABEL_29:
            __asm { vmovdqu ymmword ptr [rcx+r9-0C0h], ymm0; jumptable 000000014056F614 case 6 }
LABEL_30:
            __asm { vmovdqu ymmword ptr [rcx+r9-0A0h], ymm0; jumptable 000000014056F614 case 5 }
LABEL_31:
            __asm { vmovdqu ymmword ptr [rcx+r9-80h], ymm0; jumptable 000000014056F614 case 4 }
LABEL_32:
            __asm { vmovdqu ymmword ptr [rcx+r9-60h], ymm0; jumptable 000000014056F614 case 3 }
LABEL_33:
            __asm { vmovdqu ymmword ptr [rcx+r9-40h], ymm0; jumptable 000000014056F614 case 2 }
LABEL_34:
            __asm { vmovdqu ymmword ptr [rcx+r8-20h], ymm0; jumptable 000000014056F614 case 1 }
LABEL_35:
            __asm
            {
              vmovdqu ymmword ptr [rax], ymm0; jumptable 000000014056F614 case 0
              vzeroupper
            }
            break;
        }
        return result;
      }
      do
      {
        __asm
        {
          vmovntdq ymmword ptr [rcx], ymm0
          vmovntdq ymmword ptr [rcx+20h], ymm0
          vmovntdq ymmword ptr [rcx+40h], ymm0
          vmovntdq ymmword ptr [rcx+60h], ymm0
          vmovntdq ymmword ptr [rcx+80h], ymm0
          vmovntdq ymmword ptr [rcx+0A0h], ymm0
          vmovntdq ymmword ptr [rcx+0C0h], ymm0
          vmovntdq ymmword ptr [rcx+0E0h], ymm0
        }
        _RCX += 256;
        _R8 -= 256LL;
      }
      while ( _R8 >= 0x100 );
      _R9 = (_R8 + 31) & 0xFFFFFFFFFFFFFFE0uLL;
      switch ( _R9 >> 5 )
      {
        case 0uLL:
          goto LABEL_46;
        case 1uLL:
          goto LABEL_45;
        case 2uLL:
          goto LABEL_44;
        case 3uLL:
          goto LABEL_43;
        case 4uLL:
          goto LABEL_42;
        case 5uLL:
          goto LABEL_41;
        case 6uLL:
          goto LABEL_40;
        case 7uLL:
          goto LABEL_39;
        case 8uLL:
          __asm { vmovntdq ymmword ptr [rcx+r9-100h], ymm0; jumptable 000000014056F6D4 case 8 }
LABEL_39:
          __asm { vmovntdq ymmword ptr [rcx+r9-0E0h], ymm0; jumptable 000000014056F6D4 case 7 }
LABEL_40:
          __asm { vmovntdq ymmword ptr [rcx+r9-0C0h], ymm0; jumptable 000000014056F6D4 case 6 }
LABEL_41:
          __asm { vmovntdq ymmword ptr [rcx+r9-0A0h], ymm0; jumptable 000000014056F6D4 case 5 }
LABEL_42:
          __asm { vmovntdq ymmword ptr [rcx+r9-80h], ymm0; jumptable 000000014056F6D4 case 4 }
LABEL_43:
          __asm { vmovntdq ymmword ptr [rcx+r9-60h], ymm0; jumptable 000000014056F6D4 case 3 }
LABEL_44:
          __asm { vmovntdq ymmword ptr [rcx+r9-40h], ymm0; jumptable 000000014056F6D4 case 2 }
LABEL_45:
          __asm { vmovdqu ymmword ptr [rcx+r8-20h], ymm0; jumptable 000000014056F6D4 case 1 }
LABEL_46:
          __asm { vmovdqu ymmword ptr [rax], ymm0; jumptable 000000014056F6D4 case 0 }
          _mm_sfence();
          __asm { vzeroupper }
          break;
      }
      return result;
  }
}
