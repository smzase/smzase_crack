// EA 0x140121b00  name sub_140121B00  size 205
_BOOL8 __fastcall sub_140121B00(__int64 a1)
{
  IID *v2; // rax
  HRESULT v3; // ebx
  BOOL v4; // ebx
  LPVOID ppv; // [rsp+30h] [rbp-28h] BYREF
  IID rclsid; // [rsp+38h] [rbp-20h] BYREF

  *(_DWORD *)(a1 + 96) = 0;
  sub_140065D40(a1, *(_QWORD ***)(a1 + 104));
  **(_QWORD **)(a1 + 104) = *(_QWORD *)(a1 + 104);
  *(_QWORD *)(*(_QWORD *)(a1 + 104) + 8LL) = *(_QWORD *)(a1 + 104);
  *(_QWORD *)(a1 + 112) = 0;
  ppv = nullptr;
  v2 = (IID *)&unk_1405C3490;
  if ( *(_BYTE *)a1 != 0 )
    v2 = (IID *)&unk_1405C3480;
  rclsid = *v2;
  v3 = CoCreateInstance(&rclsid, nullptr, 1u, &stru_140636DF0, &ppv);
  *(_DWORD *)(a1 + 96) = v3;
  if ( v3 >= 0 )
  {
    v3 = sub_140121610(a1, ppv);
    *(_DWORD *)(a1 + 96) = v3;
  }
  v4 = v3 >= 0;
  if ( ppv != nullptr )
    (*(void (__fastcall **)(LPVOID))(*(_QWORD *)ppv + 16LL))(ppv);
  return v4;
}
