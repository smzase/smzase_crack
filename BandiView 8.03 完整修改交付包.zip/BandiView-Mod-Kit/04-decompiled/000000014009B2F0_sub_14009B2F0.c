// EA 0x14009b2f0  name sub_14009B2F0  size 232
LSTATUS __fastcall sub_14009B2F0(__int64 a1)
{
  volatile signed __int32 *v2; // rdx
  volatile signed __int32 *v3; // rdx
  volatile signed __int32 *v4; // rdx
  volatile signed __int32 *v5; // rdx
  void (__fastcall ***v6)(_QWORD, __int64); // rcx
  LSTATUS result; // eax

  if ( *(_DWORD *)(a1 + 180) != 0 )
    sub_14009B560(a1);
  v2 = (volatile signed __int32 *)(*(_QWORD *)(a1 + 184) - 24LL);
  if ( _InterlockedExchangeAdd(v2 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v2 + 8LL))(*(_QWORD *)v2);
  v3 = (volatile signed __int32 *)(*(_QWORD *)(a1 + 168) - 24LL);
  if ( _InterlockedExchangeAdd(v3 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v3 + 8LL))(*(_QWORD *)v3);
  v4 = (volatile signed __int32 *)(*(_QWORD *)(a1 + 160) - 24LL);
  if ( _InterlockedExchangeAdd(v4 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v4 + 8LL))(*(_QWORD *)v4);
  v5 = (volatile signed __int32 *)(*(_QWORD *)(a1 + 144) - 24LL);
  if ( _InterlockedExchangeAdd(v5 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v5 + 8LL))(*(_QWORD *)v5);
  v6 = *(void (__fastcall ****)(_QWORD, __int64))(a1 + 128);
  if ( v6 != nullptr )
    (**v6)(v6, 1);
  sub_1401E9AE0(a1 + 8);
  result = sub_1400732F0(a1 + 8);
  if ( *(_QWORD *)a1 != 0 )
    result = RegCloseKey(*(HKEY *)a1);
  *(_QWORD *)a1 = 0;
  return result;
}
