// EA 0x140065210  name sub_140065210  size 602
__int64 __fastcall sub_140065210(__int64 a1, _DWORD *a2, __int64 a3)
{
  __int64 v5; // rax
  __int64 v6; // rax
  __int64 result; // rax
  int v8; // ebx
  __int64 v9; // rbx
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // r8
  __int64 v13; // rax
  __int64 v14; // rdx
  __int64 v15; // rcx
  __int64 v16; // r8
  __int64 v17; // rax
  LPCWSTR v18; // rbx
  signed __int32 v19; // eax
  bool v20; // cc
  LPCWSTR v21; // rdx
  LPCWSTR lpParameters; // [rsp+30h] [rbp-28h] BYREF
  LPCWSTR lpFile; // [rsp+38h] [rbp-20h] BYREF
  LPCWSTR *p_lpParameters; // [rsp+40h] [rbp-18h]

  p_lpParameters = &lpParameters;
  v5 = sub_1400601C0(a1, a2, a3);
  if ( v5 == 0 )
    sub_14005FF30(2147500037LL);
  lpParameters = (LPCWSTR)((*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v5 + 24LL))(v5) + 24);
  if ( (unsigned __int8)sub_14005F980(&lpParameters, &Data) == 0 )
    sub_14005FCF0(&lpParameters, &Data, 0);
  v6 = sub_14007D020(&lpParameters);
  result = (*(__int64 (__fastcall **)(_QWORD, int *, __int64))(**(_QWORD **)(v6 + 16) + 112LL))(
             *(_QWORD *)(v6 + 16),
             &dword_1406F8958,
             4);
  if ( (_DWORD)result == 0 )
  {
    v8 = sub_140074720();
    result = sub_140075FE0();
    if ( v8 != *(_DWORD *)(result + 44) && (*a2 <= 2u || *a2 == 14) )
    {
      sub_14006DB60(L"@@rLaunchPopupAdWindow() - param:%s", a1);
      *(_DWORD *)(sub_140075FE0() + 44) = v8;
      v9 = sub_140075FE0();
      p_lpParameters = &lpParameters;
      v13 = sub_1400601C0(v11, v10, v12);
      if ( v13 == 0 )
        sub_14005FF30(2147500037LL);
      lpParameters = (LPCWSTR)((*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v13 + 24LL))(v13) + 24);
      if ( (unsigned __int8)sub_14005F980(&lpParameters, &Data) == 0 )
        sub_14005FCF0(&lpParameters, &Data, 0);
      sub_140076F50(v9, 1, &lpParameters);
      lpFile = nullptr;
      sub_14006EAE0(&lpFile);
      v17 = sub_1400601C0(v15, v14, v16);
      if ( v17 == 0 )
        sub_14005FF30(2147500037LL);
      lpParameters = (LPCWSTR)((*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v17 + 24LL))(v17) + 24);
      if ( (unsigned __int8)sub_14005F980(&lpParameters, L"/ad") == 0 )
        sub_14005FCF0(&lpParameters, L"/ad", 3);
      v18 = lpParameters;
      ShellExecuteW(nullptr, L"open", lpFile, lpParameters, nullptr, 5);
      v19 = _InterlockedExchangeAdd((volatile signed __int32 *)v18 - 2, 0xFFFFFFFF);
      v20 = v19 <= 1;
      result = (unsigned int)(v19 - 1);
      if ( v20 )
        result = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v18 - 3) + 8LL))(*((_QWORD *)v18 - 3));
      v21 = lpFile - 12;
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)lpFile - 2, 0xFFFFFFFF) <= 1 )
        return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v21 + 8LL))(*(_QWORD *)v21);
    }
  }
  return result;
}
