// EA 0x1400b2070  name sub_1400B2070  size 978
__int64 __fastcall sub_1400B2070(__int64 a1)
{
  int v2; // edi
  const void **v3; // r15
  __int64 v4; // r14
  unsigned __int64 v5; // rax
  __int64 *v6; // rax
  __int64 *v7; // rax
  unsigned int v8; // ebx
  __int64 *v9; // rax
  __int128 *v10; // rbx
  __int64 *v11; // rax
  int v12; // eax
  __int64 *v13; // rax
  int *v15; // [rsp+20h] [rbp-79h] BYREF
  int **v16; // [rsp+28h] [rbp-71h]
  struct tagCHOOSECOLORW v17; // [rsp+30h] [rbp-69h] BYREF
  __int128 v18; // [rsp+80h] [rbp-19h] BYREF
  __int64 v19; // [rsp+90h] [rbp-9h]
  unsigned __int64 v20; // [rsp+98h] [rbp-1h]

  *(_QWORD *)&v17.lStructSize = 72;
  memset(&v17.hInstance, 0, 56);
  v17.hwndOwner = *(HWND *)(a1 + 8);
  v17.lpCustColors = (COLORREF *)(sub_140075FE0() + 422);
  v17.rgbResult = *(_DWORD *)(a1 + 604);
  v17.Flags = 3;
  v18 = 0;
  v19 = 0;
  v20 = 0;
  sub_140061270((char **)&v18, &Data, 0);
  v2 = 0;
  while ( 1 )
  {
    v3 = (const void **)&qword_140709E40[3 * v2];
    v15 = (int *)(sub_14005F710((volatile signed __int32 *)*v3 - 6) + 24);
    v4 = sub_1401BE5D0(a1 + 728, &v15);
    if ( *(_DWORD *)(a1 + 608) == *((_DWORD *)v3 + 4) )
      break;
    if ( (unsigned int)++v2 >= 0x15 )
      goto LABEL_8;
  }
  v5 = sub_1404ADC20(*v3);
  sub_140069540((void **)&v18, *v3, v5);
  if ( *(_DWORD *)(*(_QWORD *)(v4 + 1048) - 16LL) != 0 )
    sub_1401F6750(v4);
  sub_1401D8460(v4, 0);
LABEL_8:
  v16 = &v15;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  v15 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
  if ( (unsigned __int8)sub_14005F980(&v15, (__int64)L"BTN_BKGND_CLR") == 0 )
    sub_14005FCF0(&v15, L"BTN_BKGND_CLR", 13);
  sub_1400ACE70(a1, &v15, 1u);
  if ( ChooseColorW(&v17) )
  {
    *(_DWORD *)(a1 + 608) = v17.rgbResult;
    sub_1400B24E0(a1);
    sub_1400B2450(a1);
  }
  else
  {
    v16 = &v15;
    if ( v19 != 0 )
    {
      v10 = &v18;
      if ( v20 > 7 )
        v10 = (__int128 *)v18;
      v11 = sub_1400601C0();
      if ( v11 == nullptr )
        sub_14005FF30(0x80004005);
      v15 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v11 + 24))(v11) + 24);
      if ( (unsigned __int8)sub_14005F980(&v15, (__int64)v10) == 0 )
      {
        if ( v10 != nullptr )
          v12 = sub_1404ADC20(v10);
        else
          v12 = 0;
        sub_14005FCF0(&v15, v10, v12);
      }
      sub_1400ACE70(a1, &v15, 1u);
      v16 = &v15;
      v13 = sub_1400601C0();
      if ( v13 == nullptr )
        sub_14005FF30(0x80004005);
      v15 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24);
      if ( (unsigned __int8)sub_14005F980(&v15, (__int64)L"BTN_BORDER_CLR") == 0 )
        sub_14005FCF0(&v15, L"BTN_BORDER_CLR", 14);
      sub_1400ACE70(a1, &v15, 0);
    }
    else
    {
      v7 = sub_1400601C0();
      if ( v7 == nullptr )
        sub_14005FF30(0x80004005);
      v15 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
      if ( (unsigned __int8)sub_14005F980(&v15, (__int64)L"BTN_BORDER_CLR") == 0 )
        sub_14005FCF0(&v15, L"BTN_BORDER_CLR", 14);
      sub_1400ACE70(a1, &v15, 1u);
      v8 = *(_DWORD *)(a1 + 604);
      v16 = &v15;
      v9 = sub_1400601C0();
      if ( v9 == nullptr )
        sub_14005FF30(0x80004005);
      v15 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
      if ( (unsigned __int8)sub_14005F980(&v15, (__int64)L"STATIC_BORDER_CLR") == 0 )
        sub_14005FCF0(&v15, L"STATIC_BORDER_CLR", 17);
      sub_1400ACF30(a1, &v15, v8);
    }
  }
  return sub_14005D410((char **)&v18);
}
