// EA 0x140089c30  name sub_140089C30  size 581
__int64 __fastcall sub_140089C30(LPCWSTR lpString, _DWORD *a2)
{
  int v4; // ebp
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // rax
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // rax
  HANDLE MutexW; // r13
  int v17; // edi
  __int64 v18; // rdx
  __int64 v19; // rcx
  HWND WindowW; // rbx
  _DWORD *v21; // r15
  void (__fastcall ***v22)(_QWORD); // rbx
  void *v23; // rax
  __int64 v24; // rax
  _BYTE *v25; // rsi
  unsigned int v26; // r14d
  char v27; // di
  LPARAM lParam[2]; // [rsp+20h] [rbp-68h] BYREF
  LPCWSTR v30; // [rsp+30h] [rbp-58h]

  v4 = 1;
  if ( *(_BYTE *)(sub_140060320() + 4) != 0 )
    goto LABEL_4;
  LODWORD(lParam[1]) = 0;
  _RAX = 1;
  __asm { cpuid }
  lParam[0] = __PAIR64__(_RBX, _RAX);
  HIDWORD(lParam[1]) = _RDX;
  if ( (_RCX & 0x800000) == 0 || *((_BYTE *)sub_14007D5E0() + 40) != 0 )
LABEL_4:
    *((_BYTE *)sub_140075FE0() + 552) = 1;
  v12 = sub_14007E720(v11, v10);
  sub_14007EE10(v12, &Data);
  v15 = sub_14007E720(v14, v13);
  sub_14007EE10(v15, L"@@<ViewerMain()@@> ");
  MutexW = CreateMutexW(nullptr, false, L"BandiView");
  lParam[0] = (LPARAM)MutexW;
  if ( MutexW != nullptr && GetLastError() == 183 )
  {
    v17 = 0;
    LODWORD(lParam[1]) = 0;
  }
  else
  {
    v17 = 1;
    LODWORD(lParam[1]) = 1;
  }
  *((_BYTE *)sub_14007D5E0() + 114) = v17 != 0;
  if ( *((_BYTE *)sub_140075FE0() + 165) == 0 || v17 != 0 )
  {
    if ( *a2 == 19 )
      *((_DWORD *)sub_140075FE0() + 128) = 1;
    v21 = (_DWORD *)(*(_QWORD *)NtCurrentTeb()->ThreadLocalStoragePointer + 8LL);
    while ( 1 )
    {
      v22 = nullptr;
      if ( dword_14070CE60 > *v21 )
      {
        sub_140496500(&dword_14070CE60);
        if ( dword_14070CE60 == -1 )
        {
          sub_140076040();
          atexit(sub_140592850);
          Init_thread_footer(&dword_14070CE60);
        }
      }
      if ( dword_14070D070 != 1 && byte_14070D098 == 0 )
      {
        v22 = (void (__fastcall ***)(_QWORD))sub_140089E80(v19, v18);
        if ( v22 == nullptr )
        {
          v4 = 2;
          goto LABEL_29;
        }
      }
      v23 = operator new(0x1588u);
      v24 = sub_1400A5A70(v23, v22);
      v25 = (_BYTE *)v24;
      if ( v24 == 0 )
        break;
      v26 = sub_140089780(v24, a2);
      v27 = v25[209];
      (*(void (__fastcall **)(_BYTE *, __int64))(*(_QWORD *)v25 + 8LL))(v25, 1);
      if ( v27 == 0 )
        goto LABEL_30;
    }
    if ( v22 != nullptr )
      (**v22)(v22);
    v4 = 4;
  }
  else
  {
    WindowW = FindWindowW(L"BandiViewClass", nullptr);
    if ( WindowW != nullptr )
    {
      lParam[0] = 539101445;
      LODWORD(lParam[1]) = 2 * lstrlenW(lpString) + 2;
      v30 = lpString;
      SendMessageW(WindowW, 0x4Au, 0, (LPARAM)lParam);
      v4 = 0;
    }
  }
LABEL_29:
  v26 = v4;
LABEL_30:
  if ( MutexW != nullptr )
    CloseHandle(MutexW);
  return v26;
}
