// EA 0x1400cc810  name sub_1400CC810  size 231
_QWORD *__fastcall sub_1400CC810(_QWORD *a1, __int64 *a2, int a3)
{
  __int64 v6; // rdi
  __int64 v7; // rcx
  __int64 v8; // rbx
  volatile signed __int32 *v9; // rdx

  v6 = (unsigned int)(*(_DWORD *)(*a2 - 16) - 1);
  if ( (int)v6 >= 0 )
  {
    while ( 1 )
    {
      v7 = *a2;
      v8 = *(int *)(*a2 - 16);
      if ( (int)v6 > (int)v8 )
        break;
      if ( *(_WORD *)(2 * v6 + v7) != 45 )
      {
        if ( (int)v6 >= (int)v8 )
          break;
        if ( *(int *)(v7 - 8) > 1 )
          sub_14005FB40(a2, (unsigned int)v8);
        *(_WORD *)(2 * v6 + *a2) = 42;
        if ( (int)v8 < 0 || (int)v8 > *(_DWORD *)(*a2 - 12) )
          break;
        *(_DWORD *)(*a2 - 16) = v8;
        *(_WORD *)(*a2 + 2 * v8) = 0;
        --a3;
      }
      if ( a3 != 0 )
      {
        v6 = (unsigned int)(v6 - 1);
        if ( (int)v6 >= 0 )
          continue;
      }
      goto LABEL_12;
    }
    sub_14005FF30(0x80070057);
  }
LABEL_12:
  *a1 = sub_14005F710((volatile signed __int32 *)(*a2 - 24)) + 24;
  v9 = (volatile signed __int32 *)(*a2 - 24);
  if ( _InterlockedExchangeAdd(v9 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v9 + 8LL))(*(_QWORD *)v9);
  return a1;
}
