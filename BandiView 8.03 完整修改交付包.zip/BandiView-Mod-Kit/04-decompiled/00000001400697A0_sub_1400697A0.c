// EA 0x1400697a0  name sub_1400697A0  size 578
_QWORD *__fastcall sub_1400697A0(_QWORD *a1)
{
  _BYTE *v2; // rbx
  __int64 *v3; // rax
  int v4; // eax
  __int64 v5; // rax
  __int64 v6; // rax
  _QWORD *v7; // rdx
  _QWORD *v8; // rdx
  __int64 v9; // rax
  _BYTE *v10; // rdx
  volatile signed __int32 *v11; // rcx
  volatile signed __int32 *v12; // rdi
  __int64 v13; // rbp
  _QWORD *v14; // rdx
  _QWORD *v15; // rdx
  LPCWSTR v16; // rdx
  int *v17; // rdx
  __int64 v19; // [rsp+28h] [rbp-30h] BYREF
  __int64 v20; // [rsp+30h] [rbp-28h] BYREF
  _QWORD v21[4]; // [rsp+38h] [rbp-20h] BYREF
  LPCWSTR pszPath; // [rsp+68h] [rbp+10h] BYREF
  int *v23; // [rsp+70h] [rbp+18h] BYREF
  __int64 v24; // [rsp+78h] [rbp+20h] BYREF

  v2 = (_BYTE *)sub_14007CF20(4);
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  v23 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
  if ( (unsigned __int8)sub_14005F980(&v23, (__int64)v2) == 0 )
  {
    if ( v2 != nullptr )
      v4 = sub_1404ADC20(v2);
    else
      v4 = 0;
    sub_14005FCF0(&v23, v2, v4);
  }
  v5 = sub_14006EA30(&v19);
  v6 = sub_140060B30(&v24, v5, L"data\\");
  sub_14006AFD0(&pszPath, v6, &v23);
  v7 = (_QWORD *)(v24 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v24 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v7 + 8LL))(*v7);
  v8 = (_QWORD *)(v19 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v19 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v8 + 8LL))(*v8);
  if ( *(_BYTE *)(sub_14007D5E0() + 4) != 0 )
  {
    v9 = sub_14006EA30(v21);
    v10 = *(_BYTE **)sub_140060B30(&v20, v9, L"..\\bin\\data\\skin");
    v11 = (volatile signed __int32 *)(v10 - 24);
    v12 = (volatile signed __int32 *)(pszPath - 12);
    if ( v10 - 24 != (_BYTE *)(pszPath - 12) )
    {
      if ( *((int *)v12 + 4) >= 0 && *(_QWORD *)v11 == *(_QWORD *)v12 )
      {
        v13 = sub_14005F710(v11);
        if ( _InterlockedExchangeAdd(v12 + 4, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD, volatile signed __int32 *))(**(_QWORD **)v12 + 8LL))(*(_QWORD *)v12, v12);
        pszPath = (LPCWSTR)(v13 + 24);
      }
      else
      {
        sub_14005FCF0((int **)&pszPath, v10, *((_DWORD *)v10 - 4));
      }
    }
    v14 = (_QWORD *)(v20 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v20 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v14 + 8LL))(*v14);
    v15 = (_QWORD *)(v21[0] - 24LL);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v21[0] - 24LL + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v15 + 8LL))(*v15);
  }
  if ( (unsigned int)sub_14006FD90(pszPath) != 0 )
    *a1 = sub_14005F710((volatile signed __int32 *)pszPath - 6) + 24;
  else
    sub_140060B30(a1, &pszPath, L".data");
  v16 = pszPath - 12;
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)pszPath - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v16 + 8LL))(*(_QWORD *)v16);
  v17 = v23 - 6;
  if ( _InterlockedExchangeAdd(v23 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v17 + 8LL))(*(_QWORD *)v17);
  return a1;
}
