// EA 0x14009f020  name sub_14009F020  size 626
__int64 sub_14009F020()
{
  __int64 result; // rax
  _QWORD *v1; // rax
  __m128i *v2; // rax
  __m128i *v3; // xmm1_8
  __m128i v4; // xmm0
  __m128i *v5; // rbx
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax
  __int128 *v8; // rdx
  char v9; // [rsp+20h] [rbp-89h] BYREF
  __int16 v10; // [rsp+21h] [rbp-88h]
  __int64 v11; // [rsp+28h] [rbp-81h]
  __int64 v12; // [rsp+30h] [rbp-79h]
  __int64 v13; // [rsp+38h] [rbp-71h]
  void *v14[3]; // [rsp+40h] [rbp-69h] BYREF
  HANDLE hObject[2]; // [rsp+58h] [rbp-51h] BYREF
  void *Block; // [rsp+68h] [rbp-41h]
  void *v17; // [rsp+70h] [rbp-39h]
  void *v18; // [rsp+78h] [rbp-31h]
  __int64 v19; // [rsp+80h] [rbp-29h]
  __int16 v20; // [rsp+88h] [rbp-21h]
  int v21; // [rsp+8Ch] [rbp-1Dh]
  __m128i v22; // [rsp+90h] [rbp-19h] BYREF
  __m128i v23; // [rsp+A0h] [rbp-9h]
  __int128 v24; // [rsp+B0h] [rbp+7h] BYREF
  __int64 v25; // [rsp+C0h] [rbp+17h]
  unsigned __int64 v26; // [rsp+C8h] [rbp+1Fh]
  char *v27[4]; // [rsp+D0h] [rbp+27h] BYREF

  result = (unsigned int)dword_14070C2DC;
  if ( dword_14070C2DC == 0 )
  {
    v1 = (_QWORD *)sub_140069AD0((__int64)v27);
    v2 = (__m128i *)sub_14005ED20(v1, L"version.ini", 0xBu);
    v22 = *v2;
    v3 = (__m128i *)v22.m128i_i64[0];
    v23 = v2[1];
    v4 = v23;
    v2[1].m128i_i64[0] = 0;
    v2[1].m128i_i64[1] = 7;
    v2->m128i_i16[0] = 0;
    v5 = &v22;
    if ( _mm_srli_si128(v4, 8).m128i_u64[0] > 7 )
      v5 = v3;
    v24 = 0;
    v25 = 0;
    v26 = 0;
    v6 = sub_1404ADC20(v5);
    sub_140061270((char **)&v24, v5, v6);
    v14[1] = nullptr;
    v7 = operator new(0x48u);
    *v7 = v7;
    v7[1] = v7;
    v7[2] = v7;
    *((_WORD *)v7 + 12) = 257;
    v14[0] = v7;
    v10 = 0;
    v11 = 0;
    v12 = 0;
    v13 = 0;
    v9 = 0;
    sub_1401D0940(&v9);
    hObject[0] = &XFileReadStream::`vftable';
    v21 = 0;
    Block = j__malloc_base(0x2000u);
    v18 = Block;
    v17 = Block;
    v19 = 0;
    hObject[1] = (HANDLE)-1LL;
    v20 = 0;
    v8 = &v24;
    if ( v26 > 7 )
      v8 = (__int128 *)v24;
    if ( (unsigned __int8)sub_1401CC050(hObject, v8) != 0 )
      sub_1401D0B60(&v9, hObject);
    hObject[0] = &XFileReadStream::`vftable';
    if ( HIBYTE(v20) != 0 && hObject[1] != (HANDLE)-1LL )
    {
      CloseHandle(hObject[1]);
      hObject[1] = (HANDLE)-1LL;
    }
    j__free_base(Block);
    sub_14005D410((char **)&v24);
    sub_14005D410((char **)&v22);
    sub_14005D410(v27);
    v22 = 0;
    v23 = 0u;
    sub_140061270((char **)&v22, L"BuildNo", 7u);
    *(_OWORD *)hObject = 0;
    Block = nullptr;
    v17 = nullptr;
    sub_140061270((char **)hObject, L"Version", 7u);
    dword_14070C2DC = sub_1401D18C0(&v9, hObject, &v22, 0);
    sub_14005D410((char **)hObject);
    sub_14005D410((char **)&v22);
    sub_1401D0940(&v9);
    sub_1401067C0(v14, v14, *((_QWORD *)v14[0] + 1));
    j_j_j__free_base(v14[0]);
    return (unsigned int)dword_14070C2DC;
  }
  return result;
}
