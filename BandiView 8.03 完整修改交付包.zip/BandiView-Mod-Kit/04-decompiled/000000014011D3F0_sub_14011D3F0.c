// EA 0x14011d3f0  name sub_14011D3F0  size 745
__int64 __fastcall sub_14011D3F0(__int64 a1, __int64 *a2)
{
  __int64 v4; // r9
  __int64 v5; // r8
  int v6; // ecx
  __int64 *v7; // rax
  bool v8; // r14
  __int64 *v9; // rax
  HMODULE *v10; // rax
  int v11; // eax
  __int64 *v12; // rax
  __int64 *v13; // rax
  __int64 result; // rax
  volatile signed __int32 *v15; // rdx
  _QWORD v16[5]; // [rsp+20h] [rbp-79h] BYREF
  LPVOID v17; // [rsp+48h] [rbp-51h]
  void **v18; // [rsp+60h] [rbp-39h]
  void **v19; // [rsp+70h] [rbp-29h]
  LPVOID lpMem; // [rsp+98h] [rbp-1h]
  __int64 v21; // [rsp+C0h] [rbp+27h]
  int *v22; // [rsp+110h] [rbp+77h] BYREF
  int **v23; // [rsp+118h] [rbp+7Fh]

  v4 = *a2;
  v5 = -1;
  do
  {
    v6 = *(unsigned __int16 *)(v4 + 2 * v5 + 2) - aChkUpdate0[v5 + 1];
    if ( v6 != 0 )
      break;
    v5 += 2;
    if ( v5 == 13 )
      break;
    v6 = *(unsigned __int16 *)(v4 + 2 * v5) - aChkUpdate0[v5];
  }
  while ( v6 == 0 );
  if ( v6 != 0 )
  {
    sub_140073530(a2, (__int64)"CHK_UPDATE_1");
  }
  else
  {
    v23 = &v22;
    v7 = sub_1400601C0();
    if ( v7 == nullptr )
      sub_14005FF30(0x80004005);
    v22 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24);
    if ( (unsigned __int8)sub_14005F980(&v22, (__int64)L"CHK_UPDATE_0") == 0 )
      sub_14005FCF0(&v22, L"CHK_UPDATE_0", 12);
    v8 = sub_1400ACB10(a1, &v22);
    v23 = &v22;
    v9 = sub_1400601C0();
    if ( v9 == nullptr )
      sub_14005FF30(0x80004005);
    v22 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
    if ( (unsigned __int8)sub_14005F980(&v22, (__int64)&Data) == 0 )
      sub_14005FCF0(&v22, &Data, 0);
    v10 = sub_14007D020(&v22);
    v11 = (*(__int64 (__fastcall **)(HMODULE, int *, __int64))(*(_QWORD *)v10[2] + 112LL))(v10[2], &dword_1406F8958, 4);
    if ( !v8 && v11 == 0 )
    {
      v23 = &v22;
      v12 = sub_1400601C0();
      if ( v12 == nullptr )
        sub_14005FF30(0x80004005);
      v22 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v12 + 24))(v12) + 24);
      if ( (unsigned __int8)sub_14005F980(&v22, (__int64)&Data) == 0 )
        sub_14005FCF0(&v22, &Data, 0);
      sub_14007D020(&v22);
      sub_140098660((__int64)v16, 1);
      sub_1400692C0((__int64)v16, *(HWND *)(a1 + 8));
      v16[0] = &CLicenseGuideDlg::`vftable';
      v18 = &CLicenseGuideDlg::`vftable';
      v19 = &CSkinnedWindow::`vftable';
      if ( v21 != 0 )
        (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v21 + 32LL))(v21, 1);
      if ( lpMem != nullptr )
        sub_140495E60(lpMem);
      v18 = &IXSkinCallback::`vftable';
      if ( v17 != nullptr )
        sub_140495E60(v17);
      v23 = &v22;
      v13 = sub_1400601C0();
      if ( v13 == nullptr )
        sub_14005FF30(0x80004005);
      v22 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24);
      if ( (unsigned __int8)sub_14005F980(&v22, (__int64)L"CHK_UPDATE_0") == 0 )
        sub_14005FCF0(&v22, L"CHK_UPDATE_0", 12);
      sub_1400ACE70(a1, &v22, 1u);
    }
  }
  result = sub_14011D6E0(a1);
  v15 = (volatile signed __int32 *)(*a2 - 24);
  if ( _InterlockedExchangeAdd(v15 + 4, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)v15 + 8LL))(*(_QWORD *)v15);
  return result;
}
