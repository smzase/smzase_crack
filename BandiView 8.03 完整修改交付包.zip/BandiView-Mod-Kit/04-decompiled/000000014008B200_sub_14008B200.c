// EA 0x14008b200  name sub_14008B200  size 256
__int64 __fastcall sub_14008B200(HWND hWnd, _BYTE **a2, __int64 a3, __int64 a4, int *a5)
{
  volatile signed __int32 *v7; // rcx
  int *v8; // rbx
  __int64 v9; // rsi
  unsigned int v10; // ebx
  volatile signed __int32 *v11; // rdx
  LPARAM dwInitParam; // [rsp+20h] [rbp-E8h] BYREF
  int *v14[23]; // [rsp+28h] [rbp-E0h] BYREF

  sub_14008B4B0(&dwInitParam);
  v7 = (volatile signed __int32 *)(*a2 - 24);
  v8 = v14[0] - 6;
  if ( v7 != v14[0] - 6 )
  {
    if ( v8[4] >= 0 && *(_QWORD *)v7 == *(_QWORD *)v8 )
    {
      v9 = sub_14005F710(v7);
      if ( _InterlockedExchangeAdd(v8 + 4, 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD, int *))(**(_QWORD **)v8 + 8LL))(*(_QWORD *)v8, v8);
      v14[0] = (int *)(v9 + 24);
    }
    else
    {
      sub_14005FCF0(v14, *a2, *((_DWORD *)*a2 - 4));
    }
  }
  v14[1] = a5;
  v10 = sub_14008B6C0((LPARAM)&dwInitParam, hWnd);
  sub_14008B5E0(&dwInitParam);
  v11 = (volatile signed __int32 *)(*a2 - 24);
  if ( _InterlockedExchangeAdd(v11 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v11 + 8LL))(*(_QWORD *)v11);
  return v10;
}
