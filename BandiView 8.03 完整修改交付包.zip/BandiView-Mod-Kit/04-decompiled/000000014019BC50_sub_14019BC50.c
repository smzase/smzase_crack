// EA 0x14019bc50  name sub_14019BC50  size 242
__int64 __fastcall sub_14019BC50(__int64 a1)
{
  __int64 v2; // rbx
  int *v3; // rax
  int v4; // r11d
  int v5; // r9d
  int v6; // r8d
  int v7; // r10d
  __int64 v8; // rdx
  __int64 v9; // kr00_8
  __int64 result; // rax
  __int128 pvParam; // [rsp+20h] [rbp-48h] BYREF

  pvParam = 0;
  SystemParametersInfoW(0x30u, 0, &pvParam, 0);
  v2 = 1500LL * *(int *)sub_1401C0040() / 96;
  v3 = (int *)sub_1401C0040();
  v4 = pvParam;
  v5 = HIDWORD(pvParam);
  v6 = DWORD1(pvParam);
  v7 = (DWORD2(pvParam) - (int)v2 - (int)pvParam) / 2;
  v8 = (unsigned __int128)(900LL * *v3 * (__int128)0x2AAAAAAAAAAAAAABLL) >> 64;
  LODWORD(v3) = HIDWORD(pvParam);
  *(_DWORD *)(a1 + 8) = DWORD2(pvParam) - v7;
  *(_DWORD *)a1 = v7 + v4;
  v9 = (int)((_DWORD)v3 - (((unsigned __int64)v8 >> 63) + (v8 >> 4)) - v6);
  result = (unsigned int)(((int)v9 - HIDWORD(v9)) >> 1);
  *(_DWORD *)(a1 + 12) = v5 - result;
  *(_DWORD *)(a1 + 4) = result + v6;
  *(_BYTE *)(a1 + 312) = 0;
  return result;
}
