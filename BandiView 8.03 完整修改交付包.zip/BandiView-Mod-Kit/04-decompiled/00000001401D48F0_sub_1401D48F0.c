// EA 0x1401d48f0  name sub_1401D48F0  size 146
BOOL __fastcall sub_1401D48F0(DWORD_PTR a1, HWND a2)
{
  BOOL result; // eax
  _QWORD *v4; // rbx
  void *v5; // rcx
  DWORD_PTR pdwRefData; // [rsp+30h] [rbp+8h] BYREF

  pdwRefData = a1;
  sub_1402B7EC0(a2);
  pdwRefData = 0;
  result = GetWindowSubclass(a2, sub_1402C0150, 0x3Du, &pdwRefData);
  if ( result )
  {
    v4 = (_QWORD *)pdwRefData;
    if ( pdwRefData != 0 )
    {
      v5 = *(void **)(pdwRefData + 64);
      if ( v5 != nullptr )
      {
        CloseThemeData(v5);
        v4[8] = 0;
      }
      j_j_j__free_base(v4);
    }
    return RemoveWindowSubclass(a2, sub_1402C0150, 0x3Du);
  }
  return result;
}
