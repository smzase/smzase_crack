// EA 0x1400bbea0  name sub_1400BBEA0  size 1962
__int16 *__fastcall sub_1400BBEA0(__int64 a1)
{
  __int64 *v2; // rax
  bool v3; // bl
  __int64 *v4; // rax
  bool v5; // bl
  int v6; // ebx
  int *v7; // rdx
  int v8; // ebx
  int v9; // edi
  int v10; // eax
  int v11; // eax
  int v12; // eax
  __int64 *v13; // rax
  bool v14; // bl
  __int64 *v15; // rax
  bool v16; // bl
  __int64 *v17; // rax
  bool v18; // bl
  int v19; // ebx
  __int64 *v20; // rax
  bool v21; // bl
  __int64 *v22; // rax
  int v23; // ebx
  int v24; // edi
  int v25; // ebx
  __int64 *v26; // rax
  bool v27; // bl
  __int64 *v28; // rax
  int v29; // ebx
  __int64 *v30; // rax
  bool v31; // bl
  __int64 *v32; // rax
  bool v33; // bl
  __int64 *v34; // rax
  bool v35; // bl
  __int64 *v36; // rax
  bool v37; // bl
  __int16 *result; // rax
  int *v39; // [rsp+48h] [rbp+28h] BYREF
  int **v40; // [rsp+50h] [rbp+30h]

  v40 = &v39;
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"CHK_EXIFROTATION") == 0 )
    sub_14005FCF0(&v39, L"CHK_EXIFROTATION", 16);
  v3 = sub_1400ACB10(a1, &v39);
  *((_BYTE *)sub_140075FE0() + 232) = v3;
  v40 = &v39;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"CHK_CACHE_IMAGE") == 0 )
    sub_14005FCF0(&v39, L"CHK_CACHE_IMAGE", 15);
  v5 = sub_1400ACB10(a1, &v39);
  *((_BYTE *)sub_140075FE0() + 233) = v5;
  sub_1400AED30(a1 + 112, &v39);
  v6 = sub_1404BF238(v39);
  v7 = v39 - 6;
  if ( _InterlockedExchangeAdd(v39 - 2, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v7 + 8LL))(*(_QWORD *)v7);
  *((_DWORD *)sub_140075FE0() + 59) = v6;
  v8 = 30;
  if ( *((int *)sub_140075FE0() + 59) <= 30 )
    v9 = 30;
  else
    v9 = *((_DWORD *)sub_140075FE0() + 59);
  v10 = sub_1401605D0();
  v11 = MulDiv(v10, 80, 100);
  if ( v11 < 10000 )
    v11 = 10000;
  if ( v9 >= v11 )
  {
    v12 = sub_1401605D0();
    v8 = MulDiv(v12, 80, 100);
    if ( v8 < 10000 )
      v8 = 10000;
  }
  else if ( *((int *)sub_140075FE0() + 59) > 30 )
  {
    v8 = *((_DWORD *)sub_140075FE0() + 59);
  }
  *((_DWORD *)sub_140075FE0() + 59) = v8;
  v40 = &v39;
  v13 = sub_1400601C0();
  if ( v13 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v13 + 24))(v13) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"CHK_USE_PREVIEW_MODE") == 0 )
    sub_14005FCF0(&v39, L"CHK_USE_PREVIEW_MODE", 20);
  v14 = sub_1400ACB10(a1, &v39);
  *((_BYTE *)sub_140075FE0() + 240) = v14;
  v40 = &v39;
  v15 = sub_1400601C0();
  if ( v15 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v15 + 24))(v15) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"CHK_USE_IMAGE_ICC") == 0 )
    sub_14005FCF0(&v39, L"CHK_USE_IMAGE_ICC", 17);
  v16 = sub_1400ACB10(a1, &v39);
  *((_BYTE *)sub_140075FE0() + 241) = v16;
  v40 = &v39;
  v17 = sub_1400601C0();
  if ( v17 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v17 + 24))(v17) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"CHK_USE_MONITOR_ICC") == 0 )
    sub_14005FCF0(&v39, L"CHK_USE_MONITOR_ICC", 19);
  v18 = sub_1400ACB10(a1, &v39);
  *((_BYTE *)sub_140075FE0() + 242) = v18;
  v19 = *(_DWORD *)(*(_QWORD *)(a1 + 656) + 1076LL);
  *((_DWORD *)sub_140075FE0() + 61) = v19;
  v40 = &v39;
  v20 = sub_1400601C0();
  if ( v20 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v20 + 24))(v20) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"CHK_WEBTOON_SPACE") == 0 )
    sub_14005FCF0(&v39, L"CHK_WEBTOON_SPACE", 17);
  v21 = sub_1400ACB10(a1, &v39);
  *((_BYTE *)sub_140075FE0() + 256) = v21;
  v40 = &v39;
  v22 = sub_1400601C0();
  if ( v22 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v22 + 24))(v22) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"IDC_EDIT_WEBTOON_SPACE") == 0 )
    sub_14005FCF0(&v39, L"IDC_EDIT_WEBTOON_SPACE", 22);
  v23 = sub_1400ACBC0(a1, &v39);
  *((_DWORD *)sub_140075FE0() + 65) = v23;
  v24 = 1000;
  if ( *((int *)sub_140075FE0() + 65) >= 1000 || *((int *)sub_140075FE0() + 65) >= 0 )
  {
    if ( *((int *)sub_140075FE0() + 65) >= 1000 )
      v25 = 1000;
    else
      v25 = *((_DWORD *)sub_140075FE0() + 65);
  }
  else
  {
    v25 = 0;
  }
  *((_DWORD *)sub_140075FE0() + 65) = v25;
  v40 = &v39;
  v26 = sub_1400601C0();
  if ( v26 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v26 + 24))(v26) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"CHK_2PAGE_SPACE") == 0 )
    sub_14005FCF0(&v39, L"CHK_2PAGE_SPACE", 15);
  v27 = sub_1400ACB10(a1, &v39);
  *((_BYTE *)sub_140075FE0() + 264) = v27;
  v40 = &v39;
  v28 = sub_1400601C0();
  if ( v28 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v28 + 24))(v28) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"IDC_EDIT_2PAGE_SPACE") == 0 )
    sub_14005FCF0(&v39, L"IDC_EDIT_2PAGE_SPACE", 20);
  v29 = sub_1400ACBC0(a1, &v39);
  *((_DWORD *)sub_140075FE0() + 67) = v29;
  if ( *((int *)sub_140075FE0() + 67) >= 1000 || *((int *)sub_140075FE0() + 67) >= 0 )
  {
    if ( *((int *)sub_140075FE0() + 67) < 1000 )
      v24 = *((_DWORD *)sub_140075FE0() + 67);
  }
  else
  {
    v24 = 0;
  }
  *((_DWORD *)sub_140075FE0() + 67) = v24;
  v40 = &v39;
  v30 = sub_1400601C0();
  if ( v30 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v30 + 24))(v30) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"CHK_SEPARATE_COVER") == 0 )
    sub_14005FCF0(&v39, L"CHK_SEPARATE_COVER", 18);
  v31 = sub_1400ACB10(a1, &v39);
  *((_BYTE *)sub_140075FE0() + 272) = v31;
  v40 = &v39;
  v32 = sub_1400601C0();
  if ( v32 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v32 + 24))(v32) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"CHK_CLIP_ADVANCED") == 0 )
    sub_14005FCF0(&v39, L"CHK_CLIP_ADVANCED", 17);
  v33 = sub_1400ACB10(a1, &v39);
  *((_BYTE *)sub_140075FE0() + 273) = v33;
  v40 = &v39;
  v34 = sub_1400601C0();
  if ( v34 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v34 + 24))(v34) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"CHK_RAWFILE_JPEGTHUMBNAIL") == 0 )
    sub_14005FCF0(&v39, L"CHK_RAWFILE_JPEGTHUMBNAIL", 25);
  v35 = sub_1400ACB10(a1, &v39);
  *((_BYTE *)sub_140075FE0() + 274) = v35;
  v40 = &v39;
  v36 = sub_1400601C0();
  if ( v36 == nullptr )
    sub_14005FF30(0x80004005);
  v39 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v36 + 24))(v36) + 24);
  if ( (unsigned __int8)sub_14005F980(&v39, (__int64)L"CHK_CENTERIMAGE_LARGERTHAN") == 0 )
    sub_14005FCF0(&v39, L"CHK_CENTERIMAGE_LARGERTHAN", 26);
  v37 = sub_1400ACB10(a1, &v39);
  result = sub_140075FE0();
  *((_BYTE *)result + 275) = v37;
  return result;
}
