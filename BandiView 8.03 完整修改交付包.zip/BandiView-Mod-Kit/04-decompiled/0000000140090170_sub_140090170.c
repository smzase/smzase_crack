// EA 0x140090170  name sub_140090170  size 849
__int64 __fastcall sub_140090170(__int64 a1, __int64 a2, _QWORD *a3, int a4)
{
  __int64 *v8; // rax
  __int64 *v9; // rax
  __int64 *v10; // rax
  __int64 v11; // rax
  __int64 v12; // rcx
  volatile signed __int32 *v13; // rdi
  volatile signed __int32 *v14; // rdi

  *(_QWORD *)(a1 + 8) = 0;
  *(_QWORD *)(a1 + 40) = 0;
  *(_QWORD *)(a1 + 48) = 0;
  *(_DWORD *)(a1 + 56) = 0;
  *(_QWORD *)a1 = &SettingDlg::`vftable';
  *(_QWORD *)(a1 + 64) = &SettingDlg::`vftable';
  *(_DWORD *)(a1 + 72) = 0;
  *(_WORD *)(a1 + 76) = 0;
  *(_QWORD *)(a1 + 80) = 0;
  v8 = sub_1400601C0();
  if ( v8 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 88) = (*(__int64 (__fastcall **)(__int64 *))(*v8 + 24))(v8) + 24;
  *(_QWORD *)(a1 + 96) = 0;
  *(_QWORD *)(a1 + 104) = 0;
  sub_1400AE8D0((void *)(a1 + 112));
  *(_DWORD *)(a1 + 264) = 0;
  *(_BYTE *)(a1 + 268) = 0;
  *(_DWORD *)(a1 + 272) = 0;
  *(_DWORD *)(a1 + 276) = 100;
  *(_DWORD *)(a1 + 280) = 1;
  *(_QWORD *)(a1 + 288) = 0;
  *(_QWORD *)(a1 + 296) = 0x4059000000000000LL;
  *(_QWORD *)(a1 + 304) = 0x3FB999999999999ALL;
  *(_WORD *)(a1 + 312) = 0;
  *(_BYTE *)(a1 + 314) = 0;
  *(_QWORD *)(a1 + 328) = 0;
  *(_QWORD *)(a1 + 360) = 0;
  *(_QWORD *)(a1 + 368) = 0;
  *(_DWORD *)(a1 + 376) = 0;
  *(_QWORD *)(a1 + 384) = DefWindowProcW;
  *(_QWORD *)(a1 + 320) = &XGroupListCtrl::`vftable';
  *(_BYTE *)(a1 + 392) = 1;
  *(_DWORD *)(a1 + 396) = 0;
  v9 = sub_1400601C0();
  if ( v9 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 400) = (*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24;
  *(_QWORD *)(a1 + 408) = 0;
  *(_QWORD *)(a1 + 416) = 0;
  *(_QWORD *)(a1 + 424) = 0;
  *(_QWORD *)(a1 + 432) = 0;
  *(_DWORD *)(a1 + 440) = 0;
  *(_QWORD *)(a1 + 448) = 0;
  *(_QWORD *)(a1 + 456) = 0;
  *(_QWORD *)(a1 + 464) = 0;
  *(_QWORD *)(a1 + 472) = 0;
  *(_BYTE *)(a1 + 480) = 0;
  *(_QWORD *)(a1 + 488) = 0;
  *(_QWORD *)(a1 + 496) = 0;
  *(_QWORD *)(a1 + 504) = 0;
  *(_QWORD *)(a1 + 512) = 0;
  *(_QWORD *)(a1 + 520) = 0;
  *(_QWORD *)(a1 + 528) = 0;
  *(_QWORD *)(a1 + 536) = 0;
  *(_QWORD *)(a1 + 544) = 0;
  v10 = sub_1400601C0();
  if ( v10 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 552) = (*(__int64 (__fastcall **)(__int64 *))(*v10 + 24))(v10) + 24;
  *(_DWORD *)(a1 + 560) = 1024;
  *(_BYTE *)(a1 + 564) = 0;
  *(_QWORD *)(a1 + 568) = 0;
  *(_QWORD *)(a1 + 576) = 0;
  *(_QWORD *)(a1 + 584) = 0;
  *(_QWORD *)(a1 + 592) = 0;
  *(_BYTE *)(a1 + 600) = 0;
  *(_QWORD *)(a1 + 604) = 0;
  *(_QWORD *)(a1 + 616) = 0;
  *(_BYTE *)(a1 + 624) = 0;
  *(_QWORD *)(a1 + 632) = 0;
  *(_QWORD *)(a1 + 640) = 0;
  *(_QWORD *)(a1 + 648) = 0;
  *(_QWORD *)(a1 + 656) = 0;
  *(_QWORD *)(a1 + 664) = 0;
  *(_QWORD *)(a1 + 672) = 0;
  *(_QWORD *)(a1 + 680) = 0;
  *(_QWORD *)(a1 + 688) = 0;
  *(_QWORD *)(a1 + 696) = 0;
  *(_QWORD *)(a1 + 704) = 0;
  *(_QWORD *)(a1 + 712) = 0;
  *(_DWORD *)(a1 + 720) = a4;
  sub_1401B9500(a1 + 728);
  sub_14008F930(a1 + 2648);
  *(_QWORD *)(a1 + 616) = a2;
  v11 = a3[1];
  if ( v11 != 0 )
    _InterlockedIncrement((volatile signed __int32 *)(v11 + 8));
  v12 = a3[1];
  *(_QWORD *)(a1 + 520) = *a3;
  v13 = *(volatile signed __int32 **)(a1 + 528);
  *(_QWORD *)(a1 + 528) = v12;
  if ( v13 != nullptr && _InterlockedExchangeAdd(v13 + 2, 0xFFFFFFFF) == 1 )
  {
    (**(void (__fastcall ***)(volatile signed __int32 *))v13)(v13);
    if ( _InterlockedExchangeAdd(v13 + 3, 0xFFFFFFFF) == 1 )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 8LL))(v13);
  }
  v14 = (volatile signed __int32 *)a3[1];
  if ( v14 != nullptr && _InterlockedExchangeAdd(v14 + 2, 0xFFFFFFFF) == 1 )
  {
    (**(void (__fastcall ***)(volatile signed __int32 *))v14)(v14);
    if ( _InterlockedExchangeAdd(v14 + 3, 0xFFFFFFFF) == 1 )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 8LL))(v14);
  }
  return a1;
}
