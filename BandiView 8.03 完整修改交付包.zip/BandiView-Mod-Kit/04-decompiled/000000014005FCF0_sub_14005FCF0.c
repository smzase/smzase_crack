// EA 0x14005fcf0  name sub_14005FCF0  size 316
void __fastcall sub_14005FCF0(int **a1, _BYTE *a2, int a3)
{
  __int64 v3; // rbx
  int *v6; // rbp
  unsigned __int64 v7; // r15
  unsigned __int64 v8; // rsi
  int *v9; // rcx
  unsigned __int64 v10; // rdx
  char *v11; // rdx
  size_t v12; // r8

  v3 = a3;
  if ( a3 == 0 )
  {
    sub_14005FA90(a1);
    return;
  }
  if ( a2 == nullptr || a3 < 0 )
LABEL_23:
    sub_14005FF30(2147942487LL);
  v6 = *a1;
  v7 = (unsigned int)*(*a1 - 4);
  if ( ((*(*a1 - 3) - a3) | (1 - *(*a1 - 2))) < 0 )
    sub_14005FC80(a1, a3);
  v8 = 2 * v3;
  if ( 2 * v3 != 0 )
  {
    v9 = *a1;
    v10 = (a2 - (_BYTE *)v6) >> 1;
    if ( v10 > v7 )
    {
      if ( v9 != nullptr )
      {
        v12 = 2LL * *(v9 - 3);
        if ( v12 >= v8 )
        {
          memcpy(v9, a2, 2 * v3);
          goto LABEL_21;
        }
        memset(v9, 0, v12);
        goto LABEL_19;
      }
    }
    else if ( v9 != nullptr )
    {
      v11 = (char *)v9 + 2 * v10;
      if ( v11 != nullptr )
      {
        if ( 2LL * *(v9 - 3) >= v8 )
        {
          memcpy(v9, v11, 2 * v3);
          goto LABEL_21;
        }
LABEL_19:
        *(_DWORD *)sub_1404A7740() = 34;
        goto LABEL_20;
      }
    }
    *(_DWORD *)sub_1404A7740() = 22;
LABEL_20:
    invalid_parameter_noinfo();
  }
LABEL_21:
  if ( (int)v3 > *(*a1 - 3) )
    goto LABEL_23;
  *(*a1 - 4) = v3;
  *(_WORD *)((char *)*a1 + v8) = 0;
}
