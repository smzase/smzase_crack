// EA 0x1400a2270  name sub_1400A2270  size 366
void __fastcall sub_1400A2270(unsigned int *a1)
{
  __int64 v2; // rdx
  __int64 v3; // r14
  int v4; // eax
  int v5; // ebx
  __int64 v6; // rdi
  __int64 v7; // rdx
  _QWORD v8[2]; // [rsp+20h] [rbp-48h] BYREF
  _QWORD v9[2]; // [rsp+30h] [rbp-38h] BYREF

  v8[0] = 0;
  if ( (unsigned __int8)sub_1400A2540(a1, v8) == 0 )
    goto LABEL_10;
  v2 = *a1;
  *(_OWORD *)v9 = *((_OWORD *)a1 + 3);
  sub_1400A2F20(a1 + 20, v2, v9, v8);
  v3 = *((_QWORD *)a1 + 10);
  v4 = *(_DWORD *)(v3 - 16);
  if ( v4 == 0 )
  {
    if ( *(_DWORD *)(*((_QWORD *)a1 + 11) - 16LL) == 0 && *(_DWORD *)(*((_QWORD *)a1 + 12) - 16LL) == 0 )
      return;
LABEL_10:
    v8[0] = 0;
    sub_14005FA90((int **)a1 + 10);
    sub_14005FA90((int **)a1 + 11);
    sub_14005FA90((int **)a1 + 12);
    v7 = *a1;
    *(_OWORD *)v9 = *((_OWORD *)a1 + 3);
    sub_1400A36B0(a1 + 20, v7, v9, v8);
    sub_14005FA90((int **)a1 + 1);
    sub_14005FA90((int **)a1 + 2);
    sub_14005FA90((int **)a1 + 4);
    sub_14005FA90((int **)a1 + 5);
    sub_14005FA90((int **)a1 + 8);
    sub_14005FA90((int **)a1 + 9);
    *((_OWORD *)a1 + 3) = 0;
    return;
  }
  if ( (unsigned int)(v4 - 32) >= 2 )
    goto LABEL_10;
  v5 = 0;
  do
  {
    v6 = (unsigned int)v5;
    sub_14006B720((wchar_t *)(v3 + 4LL * (unsigned int)v5++), (wchar_t *)L"%02x", v8);
    *((_BYTE *)v9 + v6) = v8[0];
  }
  while ( v5 < 16 );
  if ( *((_OWORD *)a1 + 3) != *(_OWORD *)v9 )
    goto LABEL_10;
}
