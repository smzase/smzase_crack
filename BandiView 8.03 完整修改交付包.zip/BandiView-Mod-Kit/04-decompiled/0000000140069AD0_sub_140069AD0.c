// EA 0x140069ad0  name sub_140069AD0  size 249
__int64 __fastcall sub_140069AD0(__int64 a1)
{
  __int64 v2; // rax
  const void *v3; // rbx
  unsigned __int64 v4; // rax
  _QWORD *v5; // rdx
  __int64 v6; // rdx
  const void *v7; // rbx
  unsigned __int64 v8; // rax
  volatile signed __int32 *v9; // rdx
  __int64 v11; // [rsp+48h] [rbp+10h] BYREF
  __int64 v12; // [rsp+50h] [rbp+18h] BYREF

  if ( *(_BYTE *)(sub_14007D5E0() + 4) != 0 )
  {
    v2 = sub_14006EA30(&v12);
    v3 = *(const void **)sub_140060B30(&v11, v2, L"..\\bin\\");
    *(_OWORD *)a1 = 0;
    *(_QWORD *)(a1 + 16) = 0;
    *(_QWORD *)(a1 + 24) = 0;
    v4 = sub_1404ADC20(v3);
    sub_140061270((char **)a1, v3, v4);
    v5 = (_QWORD *)(v11 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v11 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v5 + 8LL))(*v5);
    v6 = v12;
  }
  else
  {
    v7 = *(const void **)sub_14006EA30(&v11);
    *(_OWORD *)a1 = 0;
    *(_QWORD *)(a1 + 16) = 0;
    *(_QWORD *)(a1 + 24) = 0;
    v8 = sub_1404ADC20(v7);
    sub_140061270((char **)a1, v7, v8);
    v6 = v11;
  }
  v9 = (volatile signed __int32 *)(v6 - 24);
  if ( _InterlockedExchangeAdd(v9 + 4, 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v9 + 8LL))(*(_QWORD *)v9);
  return a1;
}
