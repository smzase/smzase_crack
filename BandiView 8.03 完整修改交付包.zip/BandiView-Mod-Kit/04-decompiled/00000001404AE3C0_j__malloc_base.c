// EA 0x1404ae3c0  name j__malloc_base  size 5
// attributes: thunk
void *__cdecl j__malloc_base(size_t Size)
{
  return malloc_base(Size);
}
