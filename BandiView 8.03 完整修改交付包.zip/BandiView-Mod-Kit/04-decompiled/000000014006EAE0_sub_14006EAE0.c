// EA 0x14006eae0  name sub_14006EAE0  size 163
int **__fastcall sub_14006EAE0(int **a1)
{
  __int64 *v2; // rax
  int v3; // eax
  WCHAR Filename[1040]; // [rsp+30h] [rbp-838h] BYREF

  GetModuleFileNameW(nullptr, Filename, 0x410u);
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  *a1 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24);
  if ( (unsigned __int8)sub_14005F980(a1, (__int64)Filename) == 0 )
  {
    v3 = sub_1404ADC20(Filename);
    sub_14005FCF0(a1, Filename, v3);
  }
  return a1;
}
