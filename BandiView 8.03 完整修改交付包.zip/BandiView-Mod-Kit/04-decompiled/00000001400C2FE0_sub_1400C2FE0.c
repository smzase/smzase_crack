// EA 0x1400c2fe0  name sub_1400C2FE0  size 256
__int64 __fastcall sub_1400C2FE0(__int64 *a1, unsigned __int16 *a2, __int64 a3)
{
  int v3; // r12d
  unsigned int v6; // edi
  unsigned __int16 v7; // ax
  unsigned __int16 *v8; // rcx
  unsigned int v9; // r13d
  __int64 v10; // r15
  __int64 v11; // rbx

  v3 = a3;
  if ( a2 == nullptr )
    sub_14005FF30(0x80004005);
  v6 = 0;
  v7 = *a2;
  if ( *a2 != 0 )
  {
    v8 = a2;
    do
    {
      v6 = v7 + 33 * v6;
      v7 = *++v8;
    }
    while ( *v8 != 0 );
  }
  v9 = v6 % *((_DWORD *)a1 + 4);
  v10 = *a1;
  if ( *a1 != 0 && (v11 = *(_QWORD *)(v10 + 8LL * (v6 % *((_DWORD *)a1 + 4)))) != 0 )
  {
    while ( *(_DWORD *)(v11 + 24) != v6 || (unsigned int)sub_1404D8590(*(_QWORD *)v11, a2) != 0 )
    {
      v11 = *(_QWORD *)(v11 + 16);
      if ( v11 == 0 )
        goto LABEL_10;
    }
  }
  else
  {
LABEL_10:
    v11 = 0;
  }
  if ( v11 != 0 )
  {
    *(_DWORD *)(v11 + 8) = v3;
  }
  else
  {
    if ( v10 == 0 )
    {
      LOBYTE(a3) = 1;
      if ( (unsigned __int8)sub_1400918F0(a1, *((unsigned int *)a1 + 4), a3) == 0 )
        sub_14005FF30(0x8007000E);
    }
    v11 = sub_1400C3150(a1, a2, v9, v6);
    *(_DWORD *)(v11 + 8) = v3;
  }
  return v11;
}
