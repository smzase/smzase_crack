// EA 0x1400bf940  name sub_1400BF940  size 399
__int64 __fastcall sub_1400BF940(__int64 *a1)
{
  __int64 v2; // rcx
  __int64 v3; // rsi
  __int64 v4; // r8
  __int128 *v5; // rdi
  __int64 *v6; // rax
  int v7; // eax
  __int64 *v9; // rax
  int *v10[2]; // [rsp+20h] [rbp-48h] BYREF
  __int128 v11; // [rsp+30h] [rbp-38h] BYREF
  __m128i si128; // [rsp+40h] [rbp-28h]

  v2 = *((int *)a1 + 269);
  v3 = *a1;
  v10[1] = (int *)v10;
  if ( (int)v2 < 0 )
  {
    v9 = sub_1400601C0();
    if ( v9 == nullptr )
      sub_14005FF30(0x80004005);
    v10[0] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24);
    if ( (unsigned __int8)sub_14005F980(v10, (__int64)&Data) == 0 )
      sub_14005FCF0(v10, &Data, 0);
    return (*(__int64 (__fastcall **)(__int64 *, int **))(v3 + 40))(a1, v10);
  }
  else
  {
    v4 = a1[131];
    if ( (int)v2 >= (int)((a1[132] - v4) >> 5) )
    {
      v11 = 0;
      si128 = _mm_load_si128((const __m128i *)&xmmword_140662F90);
      LOWORD(v11) = 0;
    }
    else
    {
      sub_1400693B0((__int64)&v11, v4 + 32 * v2);
    }
    v5 = &v11;
    if ( si128.m128i_i64[1] > 7uLL )
      v5 = (__int128 *)v11;
    v6 = sub_1400601C0();
    if ( v6 == nullptr )
      sub_14005FF30(0x80004005);
    v10[0] = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24);
    if ( (unsigned __int8)sub_14005F980(v10, (__int64)v5) == 0 )
    {
      if ( v5 != nullptr )
        v7 = sub_1404ADC20(v5);
      else
        v7 = 0;
      sub_14005FCF0(v10, v5, v7);
    }
    (*(void (__fastcall **)(__int64 *, int **))(v3 + 40))(a1, v10);
    return sub_14005D410((char **)&v11);
  }
}
