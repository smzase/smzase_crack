// EA 0x140093ce0  name sub_140093CE0  size 353
__int64 sub_140093CE0()
{
  __int64 *v0; // rax
  __int64 *v1; // rax
  int *v2; // rsi
  int *v3; // rdi
  signed __int32 v4; // eax
  bool v5; // cc
  __int64 result; // rax
  int *v7; // [rsp+50h] [rbp+8h] BYREF
  int *v8; // [rsp+58h] [rbp+10h] BYREF
  __int64 v9; // [rsp+60h] [rbp+18h] BYREF
  __int64 v10; // [rsp+68h] [rbp+20h] BYREF

  v0 = sub_1400601C0();
  if ( v0 == nullptr )
    sub_14005FF30(0x80004005);
  v8 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v0 + 24))(v0) + 24);
  if ( (unsigned __int8)sub_14005F980(&v8, (__int64)L"BandiView") == 0 )
    sub_14005FCF0(&v8, L"BandiView", 9);
  v1 = sub_1400601C0();
  if ( v1 == nullptr )
    sub_14005FF30(0x80004005);
  v7 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v1 + 24))(v1) + 24);
  if ( (unsigned __int8)sub_14005F980(&v7, (__int64)L"SOFTWARE\\BandiView") == 0 )
    sub_14005FCF0(&v7, L"SOFTWARE\\BandiView", 18);
  v2 = v7;
  v9 = sub_14005F710(v7 - 6) + 24;
  v3 = v8;
  v10 = sub_14005F710(v8 - 6) + 24;
  sub_1400C63C0(&v10, &v9);
  SHChangeNotify(0x8000000, 0x1003u, nullptr, nullptr);
  Sleep(0x3E8u);
  v4 = _InterlockedExchangeAdd(v2 - 2, 0xFFFFFFFF);
  v5 = v4 <= 1;
  result = (unsigned int)(v4 - 1);
  if ( v5 )
    result = (*(__int64 (__fastcall **)(_QWORD, int *))(**((_QWORD **)v2 - 3) + 8LL))(*((_QWORD *)v2 - 3), v2 - 6);
  if ( _InterlockedExchangeAdd(v3 - 2, 0xFFFFFFFF) <= 1 )
    return (*(__int64 (__fastcall **)(_QWORD, int *))(**((_QWORD **)v3 - 3) + 8LL))(*((_QWORD *)v3 - 3), v3 - 6);
  return result;
}
