// EA 0x14007e660  name sub_14007E660  size 184
__int64 *__fastcall sub_14007E660(__int64 *a1)
{
  __int64 *v2; // rax
  __int64 v3; // rax
  int v4; // eax
  DWORD nSize; // [rsp+48h] [rbp+10h] BYREF

  nSize = 1025;
  v2 = sub_1400601C0();
  if ( v2 == nullptr )
    sub_14005FF30(0x80004005);
  v3 = (*(__int64 (__fastcall **)(__int64 *))(*v2 + 24))(v2) + 24;
  *a1 = v3;
  if ( ((*(_DWORD *)(v3 - 12) - 1025) | (1 - *(_DWORD *)(v3 - 8))) < 0 )
    sub_14005FC80(a1, 1025);
  GetComputerNameW((LPWSTR)*a1, &nSize);
  if ( *a1 != 0 )
  {
    v4 = sub_1404ADD70(*a1, *(int *)(*a1 - 12));
    if ( v4 < 0 )
      goto LABEL_10;
  }
  else
  {
    v4 = 0;
  }
  if ( v4 > *(_DWORD *)(*a1 - 12) )
LABEL_10:
    sub_14005FF30(0x80070057);
  *(_DWORD *)(*a1 - 16) = v4;
  *(_WORD *)(*a1 + 2LL * (unsigned int)v4) = 0;
  return a1;
}
