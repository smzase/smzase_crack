// EA 0x1401ba850  name sub_1401BA850  size 449
_QWORD *__fastcall sub_1401BA850(__int64 a1, _QWORD *a2)
{
  __int64 *v4; // rax
  int v5; // ebx
  unsigned int v6; // edi
  _QWORD *v7; // rax
  _QWORD *v8; // rdx
  __int64 *v9; // rax
  _QWORD *v10; // rax
  _QWORD *v11; // rdx
  _QWORD *v12; // rdx
  __int64 *v13; // rax
  _QWORD *v14; // rax
  _QWORD *v15; // rdx
  _QWORD *v16; // rdx
  int v18; // [rsp+20h] [rbp-38h]
  __int64 v19; // [rsp+70h] [rbp+18h] BYREF
  __int64 v20; // [rsp+78h] [rbp+20h] BYREF

  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  *a2 = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24;
  v5 = *(_DWORD *)(a1 + 956);
  v6 = *(_DWORD *)(a1 + 952);
  v7 = (_QWORD *)sub_1401E4C20(&v19, a1 + 928);
  v18 = v5;
  sub_14005EB50((__int64)a2, (__int64)L"%s Line:%d Col:%d", *v7, v6, v18);
  v8 = (_QWORD *)(v19 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v19 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v8 + 8LL))(*v8);
  if ( *(_DWORD *)(*(_QWORD *)(a1 + 936) - 16LL) != 0 )
  {
    v9 = sub_1400609A0(&v20, L" (", (const void **)(a1 + 936));
    v10 = (_QWORD *)sub_140060B30(&v19, v9, L")");
    sub_140069690(a2, *v10, *(unsigned int *)(*v10 - 16LL));
    v11 = (_QWORD *)(v19 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v19 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v11 + 8LL))(*v11);
    v12 = (_QWORD *)(v20 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v20 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v12 + 8LL))(*v12);
  }
  if ( *(_DWORD *)(*(_QWORD *)(a1 + 944) - 16LL) != 0 )
  {
    v13 = sub_1400609A0(&v20, L" (", (const void **)(a1 + 944));
    v14 = (_QWORD *)sub_140060B30(&v19, v13, L")");
    sub_140069690(a2, *v14, *(unsigned int *)(*v14 - 16LL));
    v15 = (_QWORD *)(v19 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v19 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v15 + 8LL))(*v15);
    v16 = (_QWORD *)(v20 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v20 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v16 + 8LL))(*v16);
  }
  return a2;
}
