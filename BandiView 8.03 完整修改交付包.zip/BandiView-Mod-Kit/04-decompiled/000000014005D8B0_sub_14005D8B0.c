// EA 0x14005d8b0  name sub_14005D8B0  size 614
__int64 __fastcall sub_14005D8B0(__int64 a1)
{
  __int64 v2; // rbx
  __int64 v3; // rcx
  __int128 v4; // rax
  __int64 v5; // rdi
  __int64 v6; // rbx
  int *v7; // rax
  __int64 v8; // rdi
  __int128 v9; // rax
  int v10; // edx
  int v11; // r9d
  int yBottom; // eax
  __int64 v13; // rdx
  __int64 v14; // rcx
  LPCWSTR *v15; // rax
  _QWORD *v16; // rdx
  __int16 v18; // [rsp+38h] [rbp-50h]
  __int64 v19; // [rsp+50h] [rbp-38h] BYREF
  __int128 pvParam; // [rsp+58h] [rbp-30h] BYREF

  qword_1406DC820 = (__int64)L"BandiViewADClass";
  dword_1406DC7E4 = 0;
  qword_1406DC810 = 0;
  qword_1406DC800 = 0;
  pvParam = 0;
  SystemParametersInfoW(0x30u, 0, &pvParam, 0);
  v2 = dword_1406DC908;
  v3 = *(int *)sub_1401C0040();
  if ( (_DWORD)v2 != 0 )
    v4 = v2 * v3 * (__int128)0x2AAAAAAAAAAAAAABLL;
  else
    v4 = 380 * v3 * (__int128)0x2AAAAAAAAAAAAAABLL;
  v5 = dword_1406DC90C;
  v6 = (*((_QWORD *)&v4 + 1) >> 63) + (*((__int64 *)&v4 + 1) >> 4);
  v7 = (int *)sub_1401C0040();
  if ( (_DWORD)v5 != 0 )
  {
    v8 = *v7 * v5 / 96;
  }
  else
  {
    v9 = 414LL * *v7 * (__int128)0x2AAAAAAAAAAAAAABLL;
    v8 = (*((_QWORD *)&v9 + 1) >> 63) + (*((__int64 *)&v9 + 1) >> 4);
  }
  v10 = 10LL * *(int *)sub_1401C0040() / 96;
  DWORD2(pvParam) -= v10;
  HIDWORD(pvParam) -= v10;
  SetRect((LPRECT)(a1 + 2008), DWORD2(pvParam) - v6, HIDWORD(pvParam) - v8, SDWORD2(pvParam), SHIDWORD(pvParam));
  v11 = DWORD2(pvParam);
  yBottom = HIDWORD(pvParam);
  *(_DWORD *)(a1 + 2040) = (int)v8 / 20;
  SetRect((LPRECT)(a1 + 2024), v11 - v6, yBottom - (int)v8 / 20, v11, yBottom);
  if ( qword_1406DC830 == 0 )
    qword_1406DC830 = 0;
  v18 = sub_14005F3B0(v14, v13, &unk_1406DC7E0, a1 + 64);
  sub_14005F250(a1, 0, a1 + 2008, L"BandiViewAdWnd", -2037907456, 128, 0, v18);
  sub_14005DB20(a1);
  SetTimer(*(HWND *)(a1 + 8), 0xAu, 0x3E8u, nullptr);
  v15 = (LPCWSTR *)sub_14006EA30(&v19);
  SetCurrentDirectoryW(*v15);
  v16 = (_QWORD *)(v19 - 24);
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v19 - 24 + 16), 0xFFFFFFFF) <= 1 )
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v16 + 8LL))(*v16);
  return 1;
}
