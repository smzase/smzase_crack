// EA 0x14009b970  name sub_14009B970  size 579
__int64 __fastcall sub_14009B970(__int64 a1, __int64 a2, unsigned int a3)
{
  int v6; // ecx
  int v7; // ecx
  __int64 v8; // rsi
  __int64 *v9; // rax
  __int64 v10; // rcx
  __int64 v11; // rcx
  __int64 v12; // rbx
  unsigned int v13; // esi
  _QWORD *v14; // rdx
  __int64 v15; // rdx
  __int64 v16; // rsi
  __int64 v17; // rbp
  __int64 *v18; // rax
  __int64 v19; // rcx
  __int64 v20; // rbx
  volatile signed __int32 *v21; // rdx
  LPCWSTR *v22; // rax
  BOOL v23; // ebx
  _QWORD *v24; // rdx
  _QWORD v25[5]; // [rsp+30h] [rbp-28h] BYREF
  __int64 Data; // [rsp+60h] [rbp+8h] BYREF
  __int64 v27; // [rsp+78h] [rbp+20h] BYREF

  if ( *(_DWORD *)(a1 + 180) == 0 )
    return 0;
  v6 = *(_DWORD *)(a1 + 136) - 1;
  if ( v6 != 0 )
  {
    v7 = v6 - 1;
    if ( v7 != 0 )
    {
      if ( v7 != 1 )
        return 0;
      v8 = *(_QWORD *)sub_140060B30(v25, a1 + 184, a2);
      v9 = sub_1400601C0();
      if ( v9 == nullptr )
        sub_14005FF30(0x80004005);
      Data = (*(__int64 (__fastcall **)(__int64 *))(*v9 + 24))(v9) + 24;
      sub_14009B0E0(v10, &v27, v8);
      sub_14005EB50((__int64)&Data, (__int64)L"\"%s\"=dword:%08x", v27, a3);
      v11 = a1 + 128;
      v12 = Data;
      v13 = sub_14009B050(v11, Data);
      v14 = (_QWORD *)(v27 - 24);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v27 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v14 + 8LL))(*v14);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v12 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v12 - 24) + 8LL))(*(_QWORD *)(v12 - 24));
      v15 = v25[0];
    }
    else
    {
      v16 = *(_QWORD *)sub_140060B30(&v27, a1 + 184, a2);
      v17 = *(_QWORD *)(a1 + 168);
      v18 = sub_1400601C0();
      if ( v18 == nullptr )
        sub_14005FF30(0x80004005);
      Data = (*(__int64 (__fastcall **)(__int64 *))(*v18 + 24))(v18) + 24;
      sub_14005EB50((__int64)&Data, (__int64)L"%d", a3);
      v19 = a1 + 8;
      v20 = Data;
      v13 = sub_1401EA270(v19, v17, v16, Data);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v20 - 24 + 16), 0xFFFFFFFF) <= 1 )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v20 - 24) + 8LL))(*(_QWORD *)(v20 - 24));
      v15 = v27;
    }
    v21 = (volatile signed __int32 *)(v15 - 24);
    if ( _InterlockedExchangeAdd(v21 + 4, 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v21 + 8LL))(*(_QWORD *)v21);
    return v13;
  }
  else
  {
    v22 = (LPCWSTR *)sub_140060B30(&v27, a1 + 184, a2);
    LODWORD(Data) = a3;
    v23 = RegSetValueExW(*(HKEY *)a1, *v22, 0, 4u, (const BYTE *)&Data, 4u) == 0;
    v24 = (_QWORD *)(v27 - 24);
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v27 - 24 + 16), 0xFFFFFFFF) <= 1 )
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v24 + 8LL))(*v24);
    return v23;
  }
}
