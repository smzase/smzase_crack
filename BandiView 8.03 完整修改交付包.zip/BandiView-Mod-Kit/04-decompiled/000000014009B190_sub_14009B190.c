// EA 0x14009b190  name sub_14009B190  size 347
__int64 __fastcall sub_14009B190(__int64 a1, _BYTE *a2)
{
  __int64 *v4; // rax
  __int64 *v5; // rax
  __int64 *v6; // rax
  __int64 *v7; // rax
  int v8; // eax

  *(_QWORD *)a1 = 0;
  *(_QWORD *)(a1 + 8) = 0;
  *(_QWORD *)(a1 + 16) = 0;
  *(_QWORD *)(a1 + 24) = 0;
  *(_QWORD *)(a1 + 32) = 0;
  *(_QWORD *)(a1 + 40) = 0;
  *(_DWORD *)(a1 + 48) = 10;
  *(_QWORD *)(a1 + 96) = 0;
  *(_QWORD *)(a1 + 104) = 0;
  *(_DWORD *)(a1 + 112) = 65001;
  *(_QWORD *)(a1 + 56) = 1;
  *(_DWORD *)(a1 + 64) = 0;
  *(_QWORD *)(a1 + 72) = 0;
  *(_QWORD *)(a1 + 80) = 0;
  *(_QWORD *)(a1 + 88) = 0;
  *(_QWORD *)(a1 + 120) = 0;
  *(_QWORD *)(a1 + 128) = 0;
  v4 = sub_1400601C0();
  if ( v4 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 144) = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 24))(v4) + 24;
  v5 = sub_1400601C0();
  if ( v5 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 160) = (*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24;
  v6 = sub_1400601C0();
  if ( v6 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 168) = (*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24;
  v7 = sub_1400601C0();
  if ( v7 == nullptr )
    sub_14005FF30(0x80004005);
  *(_QWORD *)(a1 + 184) = (*(__int64 (__fastcall **)(__int64 *))(*v7 + 24))(v7) + 24;
  if ( a2 != nullptr )
  {
    v8 = sub_1404ADC20(a2);
    sub_14005FCF0((int **)(a1 + 184), a2, v8);
  }
  *(_DWORD *)(a1 + 136) = 0;
  *(_QWORD *)(a1 + 176) = 0;
  *(_QWORD *)(a1 + 152) = 0;
  return a1;
}
