// EA 0x1400b50c0  name sub_1400B50C0  size 691
__int64 __fastcall sub_1400B50C0(__int64 a1)
{
  __int64 result; // rax
  WPARAM v3; // rsi
  __int64 v4; // rbx
  __int64 *v5; // rax
  __int64 *v6; // rcx
  __int64 v7; // r14
  HWND ActiveWindow; // rbx
  __int64 v9; // rax
  __int64 v10; // rbx
  int *v11; // rdx
  _QWORD v12[2]; // [rsp+30h] [rbp-D0h] BYREF
  _QWORD *v13; // [rsp+40h] [rbp-C0h] BYREF
  DWORD CurrentThreadId; // [rsp+48h] [rbp-B8h]
  __int64 v15; // [rsp+50h] [rbp-B0h]
  __int64 v16; // [rsp+58h] [rbp-A8h]
  __int64 v17; // [rsp+60h] [rbp-A0h]
  int v18; // [rsp+68h] [rbp-98h]
  int v19; // [rsp+70h] [rbp-90h]
  int *v20; // [rsp+78h] [rbp-88h] BYREF
  int v21; // [rsp+80h] [rbp-80h]
  __int64 v22; // [rsp+88h] [rbp-78h]
  __int128 v23; // [rsp+90h] [rbp-70h]
  __int128 v24; // [rsp+A0h] [rbp-60h]
  char v25[160]; // [rsp+B0h] [rbp-50h] BYREF
  __int64 v26; // [rsp+150h] [rbp+50h]
  LPARAM lParam; // [rsp+160h] [rbp+60h] BYREF
  int v28; // [rsp+168h] [rbp+68h]
  int *v29; // [rsp+178h] [rbp+78h]
  int *v30; // [rsp+200h] [rbp+100h] BYREF

  result = sub_1400B3720(*(HWND *)(a1 + 448));
  if ( (int)result >= 0 )
  {
    v3 = (int)result;
    v4 = *(_QWORD *)(a1 + 456);
    if ( 0xAAAAAAAAAAAAAAABuLL * ((*(_QWORD *)(a1 + 464) - v4) >> 3) <= (int)result )
      unknown_libname_5();
    v12[1] = 0;
    v16 = 0;
    v17 = 0;
    v18 = 0;
    v12[0] = &SettingKeyDlg::`vftable';
    v19 = 1;
    v5 = sub_1400601C0();
    if ( v5 == nullptr )
      sub_14005FF30(0x80004005);
    v20 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v5 + 24))(v5) + 24);
    v21 = 0;
    v22 = 0;
    v23 = 0;
    v24 = 0;
    sub_140094680(v25);
    v6 = sub_1400601C0();
    if ( v6 == nullptr )
      sub_14005FF30(0x80004005);
    v7 = 24 * v3;
    v26 = (*(__int64 (__fastcall **)(__int64 *))(*v6 + 24))(v6) + 24;
    v19 = *(_DWORD *)(v4 + 24 * v3);
    sub_14006B500(&v20, (_BYTE **)(24 * v3 + v4 + 8));
    v21 = *(_DWORD *)(v4 + 24 * v3 + 16);
    ActiveWindow = GetActiveWindow();
    v9 = sub_140495D90();
    v16 = v9;
    if ( v9 != 0 )
    {
      sub_140495EC0(v9, 0, 0);
      v13 = v12;
      CurrentThreadId = GetCurrentThreadId();
      EnterCriticalSection(&CriticalSection);
      v15 = qword_1406FBC60;
      qword_1406FBC60 = (__int64)&v13;
      LeaveCriticalSection(&CriticalSection);
      if ( DialogBoxParamW(hInstance, (LPCWSTR)0x90, ActiveWindow, DialogFunc, 0) == 1 )
      {
        v10 = *(_QWORD *)(a1 + 456);
        *(_DWORD *)(v10 + 24 * v3) = v19;
        sub_14006B500((int **)(v7 + v10 + 8), (_BYTE **)&v20);
        *(_DWORD *)(v10 + v7 + 16) = v21;
        sub_14009D4A0(&v30, BYTE1(v21), (unsigned __int8)v21);
        v28 = 0;
        v29 = v30;
        SendMessageW(*(HWND *)(a1 + 448), 0x1074u, v3, (LPARAM)&lParam);
        v28 = 1;
        v29 = v20;
        SendMessageW(*(HWND *)(a1 + 448), 0x1074u, v3, (LPARAM)&lParam);
        v11 = v30 - 6;
        if ( _InterlockedExchangeAdd(v30 - 2, 0xFFFFFFFF) <= 1 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v11 + 8LL))(*(_QWORD *)v11);
      }
    }
    else
    {
      SetLastError(0xEu);
    }
    return sub_14011F1E0(v12);
  }
  return result;
}
