// EA 0x14005d490  name sub_14005D490  size 205
__int64 __fastcall sub_14005D490(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rax
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // rax
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // r8
  __int64 v12; // rax

  *(_QWORD *)a1 = 0;
  *(_DWORD *)(a1 + 8) = 0;
  *(_BYTE *)(a1 + 12) = 0;
  *(_WORD *)(a1 + 20) = 0;
  v4 = sub_1400601C0(a1, a2, a3);
  if ( v4 == 0 )
    sub_14005FF30(2147500037LL);
  *(_QWORD *)(a1 + 72) = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4) + 24;
  v8 = sub_1400601C0(v6, v5, v7);
  if ( v8 == 0 )
    sub_14005FF30(2147500037LL);
  *(_QWORD *)(a1 + 80) = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v8 + 24LL))(v8) + 24;
  *(_DWORD *)(a1 + 117) = 16842753;
  *(_WORD *)(a1 + 121) = 0;
  *(_BYTE *)(a1 + 123) = 1;
  v12 = sub_1400601C0(v10, v9, v11);
  if ( v12 == 0 )
    sub_14005FF30(2147500037LL);
  *(_QWORD *)(a1 + 128) = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v12 + 24LL))(v12) + 24;
  sub_14005D560(a1);
  return a1;
}
