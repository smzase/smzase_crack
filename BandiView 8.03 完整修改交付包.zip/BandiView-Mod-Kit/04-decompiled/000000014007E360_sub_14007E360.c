// EA 0x14007e360  name sub_14007E360  size 279
wint_t **__fastcall sub_14007E360(wint_t **a1)
{
  wint_t *v1; // rbx
  wint_t v3; // cx
  wint_t *v4; // rax
  int v5; // edx
  __int64 v6; // rbx
  wint_t *v7; // r9
  __int64 v8; // rcx
  int v9; // esi
  size_t v10; // r8
  wint_t *v11; // rdx
  unsigned __int64 v12; // rcx

  v1 = *a1;
  if ( iswspace(**a1) != 0 )
  {
    do
    {
      v3 = v1[1];
      ++v1;
    }
    while ( iswspace(v3) != 0 );
  }
  v4 = *a1;
  if ( v1 != *a1 )
  {
    v5 = *((_DWORD *)v4 - 4);
    if ( v5 < 0 )
      goto LABEL_19;
    v6 = v1 - v4;
    if ( ((*((_DWORD *)v4 - 3) - v5) | (1 - *((_DWORD *)v4 - 2))) < 0 )
      sub_14005FC80(a1, v5);
    v7 = *a1;
    v8 = *((unsigned int *)*a1 - 4);
    v9 = *((_DWORD *)*a1 - 4) - v6;
    v10 = 2LL * (v9 + 1);
    if ( v10 != 0 )
    {
      if ( v7 != nullptr && (v11 = &v7[(int)v6]) != nullptr )
      {
        v12 = 2LL * ((int)v8 + 1);
        if ( v12 >= v10 )
        {
          memcpy(*a1, v11, v10);
          goto LABEL_13;
        }
        *(_DWORD *)sub_1404A7740(v12) = 34;
      }
      else
      {
        *(_DWORD *)sub_1404A7740(v8) = 22;
      }
      invalid_parameter_noinfo();
      sub_14005FF30(0x80070057);
    }
LABEL_13:
    if ( v9 >= 0 && v9 <= *((_DWORD *)*a1 - 3) )
    {
      *((_DWORD *)*a1 - 4) = v9;
      (*a1)[v9] = 0;
      return a1;
    }
LABEL_19:
    sub_14005FF30(0x80070057);
  }
  return a1;
}
