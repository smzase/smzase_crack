// EA 0x1400aed30  name sub_1400AED30  size 165
int **__fastcall sub_1400AED30(__int64 a1, int **a2)
{
  __int64 *v3; // rax
  int v4; // eax
  WCHAR String[1032]; // [rsp+30h] [rbp-828h] BYREF

  GetWindowTextW(*(HWND *)(a1 + 8), String, 1024);
  v3 = sub_1400601C0();
  if ( v3 == nullptr )
    sub_14005FF30(0x80004005);
  *a2 = (int *)((*(__int64 (__fastcall **)(__int64 *))(*v3 + 24))(v3) + 24);
  if ( (unsigned __int8)sub_14005F980(a2, (__int64)String) == 0 )
  {
    v4 = sub_1404ADC20(String);
    sub_14005FCF0(a2, String, v4);
  }
  return a2;
}
