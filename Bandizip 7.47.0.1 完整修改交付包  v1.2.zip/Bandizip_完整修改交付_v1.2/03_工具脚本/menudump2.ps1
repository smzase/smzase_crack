param([string]$ProcessName='Bandizip')
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class MenuDump2 {
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    public struct MENUITEMINFO {
        public uint cbSize; public uint fMask; public uint fType; public uint fState;
        public uint wID; public IntPtr hSubMenu; public IntPtr hbmpChecked; public IntPtr hbmpUnchecked;
        public IntPtr dwItemData; public string dwTypeData; public uint cch; public IntPtr hbmpItem;
    }
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr GetMenu(IntPtr hWnd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr GetSubMenu(IntPtr hMenu, int nPos);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetMenuItemCount(IntPtr hMenu);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern bool GetMenuItemInfoW(IntPtr hMenu, uint uItem, bool fByPosition, ref MENUITEMINFO mii);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr hWnd, StringBuilder sb, int n);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    public static string Text(IntPtr h) { var sb=new StringBuilder(512); GetWindowTextW(h,sb,512); return sb.ToString(); }
    public static string Cls(IntPtr h) { var sb=new StringBuilder(256); GetClassNameW(h,sb,256); return sb.ToString(); }
    public static string ItemText(IntPtr hMenu, uint pos, out uint id, out uint state, out uint type) {
        var mii = new MENUITEMINFO(); mii.cbSize=(uint)Marshal.SizeOf(typeof(MENUITEMINFO));
        mii.fMask = 0x00000001|0x00000002|0x00000004|0x00000080|0x00000040; // STATE|ID|TYPE... 
        mii.dwTypeData = new string(' ', 256); mii.cch = 256;
        bool ok = GetMenuItemInfoW(hMenu, pos, true, ref mii);
        id=mii.wID; state=mii.fState; type=mii.fType;
        return ok ? mii.dwTypeData : "<fail>";
    }
}
"@
$procs = @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue)
foreach ($p in $procs) {
    $script:targetPid = $p.Id
    $hwnds = New-Object System.Collections.ArrayList
    $cb = [MenuDump2+EnumWindowsProc]{ param($h,$l)
        $pid2=0; [void][MenuDump2]::GetWindowThreadProcessId($h,[ref]$pid2)
        if ($pid2 -eq $script:targetPid) { [void]$hwnds.Add($h) }
        return $true }
    [void][MenuDump2]::EnumWindows($cb, [IntPtr]::Zero)
    foreach ($h in $hwnds) {
        $menu = [MenuDump2]::GetMenu($h)
        if ($menu -eq [IntPtr]::Zero) { continue }
        Write-Output "=== hwnd=$h class=$([MenuDump2]::Cls($h)) title=$([MenuDump2]::Text($h)) ==="
        $cnt = [MenuDump2]::GetMenuItemCount($menu)
        for ($i=0; $i -lt $cnt; $i++) {
            $id=0;$st=0;$tp=0
            $txt = [MenuDump2]::ItemText($menu, [uint32]$i, [ref]$id, [ref]$st, [ref]$tp)
            Write-Output ("  TOP[{0}] id={1} '{2}'" -f $i, $id, $txt)
            $sub = [MenuDump2]::GetSubMenu($menu, $i)
            if ($sub -ne [IntPtr]::Zero) {
                $scnt = [MenuDump2]::GetMenuItemCount($sub)
                for ($j=0; $j -lt $scnt; $j++) {
                    $id=0;$st=0;$tp=0
                    $txt2 = [MenuDump2]::ItemText($sub, [uint32]$j, [ref]$id, [ref]$st, [ref]$tp)
                    Write-Output ("     [{0}] id={1} state=0x{2:X} '{3}'" -f $j, $id, $st, $txt2)
                }
            }
        }
    }
}
