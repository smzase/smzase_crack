param(
    [string]$ProcessName = 'Bandizip',
    [int]$CommandId = 147,
    [string]$OutFile = 'C:\Users\smz\BandizipWork\shot_dlg.png',
    [string]$DialogTitleMatch = ''
)
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class DlgCap {
    [DllImport("user32.dll")] public static extern IntPtr GetMenu(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
    [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr hWnd, EnumWindowsProc cb, IntPtr lp);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hwnd, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
    [DllImport("user32.dll")] public static extern IntPtr GetDlgItem(IntPtr hDlg, int id);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    public static string Text(IntPtr h) { var sb=new StringBuilder(512); GetWindowTextW(h,sb,512); return sb.ToString(); }
    public static string Cls(IntPtr h) { var sb=new StringBuilder(256); GetClassNameW(h,sb,256); return sb.ToString(); }
}
"@
$p = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $p) { Write-Output 'NO PROCESS'; exit 1 }
$main = $p.MainWindowHandle
if (-not $main) { Write-Output 'NO MAIN WINDOW'; exit 1 }
$menu = [DlgCap]::GetMenu($main)
Write-Output ("main={0} class={1} title={2} menu={3}" -f $main, [DlgCap]::Cls($main), [DlgCap]::Text($main), $menu)
[void][DlgCap]::PostMessageW($main, 0x111, [IntPtr]$CommandId, [IntPtr]::Zero)
Start-Sleep -Seconds 2
# 找出该进程的所有可见窗口
$pids = @($p.Id)
$wins = New-Object System.Collections.ArrayList
$cb = [DlgCap+EnumWindowsProc]{ param($h,$l)
    $pid2 = 0
    [void][DlgCap]::GetWindowThreadProcessId($h, [ref]$pid2)
    if ($pids -contains [int]$pid2) {
        $r = New-Object DlgCap+RECT
        [void][DlgCap]::GetWindowRect($h, [ref]$r)
        [void]$wins.Add([pscustomobject]@{ Hwnd=$h; Title=[DlgCap]::Text($h); Class=[DlgCap]::Cls($h); Visible=[DlgCap]::IsWindowVisible($h); W=($r.Right-$r.Left); H=($r.Bottom-$r.Top) })
    }
    return $true }
[void][DlgCap]::EnumWindows($cb, [IntPtr]::Zero)
$wins | Format-Table -AutoSize | Out-String -Width 240 | Write-Output
$cands = @($wins | Where-Object { $_.Visible -and $_.W -gt 50 -and $_.H -gt 30 -and $_.Hwnd -ne $main })
$target = $null
if ($DialogTitleMatch) { $target = $cands | Where-Object { $_.Title -match $DialogTitleMatch } | Select-Object -First 1 }
if (-not $target) { $target = $cands | Select-Object -First 1 }
if (-not $target) { Write-Output 'NO DIALOG'; exit 2 }
$r = New-Object DlgCap+RECT
[void][DlgCap]::GetWindowRect($target.Hwnd, [ref]$r)
$w = $r.Right-$r.Left; $h = $r.Bottom-$r.Top
Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap $w, $h
$g = [System.Drawing.Graphics]::FromImage($bmp)
$hdc = $g.GetHdc()
$ok = [DlgCap]::PrintWindow($target.Hwnd, $hdc, 2)
$g.ReleaseHdc($hdc); $g.Dispose()
$bmp.Save($OutFile, [System.Drawing.Imaging.ImageFormat]::Png)
Write-Output ("saved={0} ok={1} dlg={2} class={3} {4}x{5}" -f $OutFile, $ok, $target.Title, $target.Class, $w, $h)

