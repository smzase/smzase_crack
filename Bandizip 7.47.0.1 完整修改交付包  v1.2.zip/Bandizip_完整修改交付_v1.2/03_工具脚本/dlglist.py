import pefile, struct, sys, io

def get_res(pe):
    out = []
    def walk(entries, depth=0, path='', typeid=None):
        for e in entries:
            nm = e.name.string.decode('utf-16le', 'replace') if e.name else ''
            label = nm if nm else str(e.id)
            try:
                d = e.directory
                isdir = True
            except Exception:
                isdir = False
            if isdir:
                walk(d.entries, depth + 1, path + '/' + label, e.id if depth == 0 else typeid)
            else:
                out.append((typeid, path + '/' + label, e.data.struct))
    walk(pe.DIRECTORY_ENTRY_RESOURCE.entries)
    return out

class R:
    def __init__(self, data):
        self.d = data; self.p = 0
    def align(self, n=4):
        self.p = (self.p + n - 1) & ~(n - 1)
    def u16(self):
        v, = struct.unpack_from('<H', self.d, self.p); self.p += 2; return v
    def u32(self):
        v, = struct.unpack_from('<I', self.d, self.p); self.p += 4; return v
    def sz(self):
        # null-terminated utf16 with possible 0x0000 prefix codes
        start = self.p
        if self.p + 2 <= len(self.d):
            w, = struct.unpack_from('<H', self.d, self.p)
            if w == 0:
                self.p += 2; return ''
        first = True
        while self.p + 2 <= len(self.d):
            w, = struct.unpack_from('<H', self.d, self.p)
            if w == 0:
                self.p += 2
                return self.d[start:self.p-2].decode('utf-16le', 'replace')
            self.p += 2
        return self.d[start:].decode('utf-16le', 'replace')

def parse_dialog(data, label):
    r = R(data)
    out = []
    # DLGTEMPLATE
    style = r.u32(); ex = r.u32(); cdit = r.u16(); x=r.u16();y=r.u16();cx=r.u16();cy=r.u16()
    menu = r.sz(); cls = r.sz(); title = r.sz()
    if style & 0x40:  # DS_SETFONT
        pts = r.u16(); face = r.sz()
    else:
        pts = 0; face = ''
    out.append('DLG %s style=%08X ex=%08X items=%d title=%r' % (label, style, ex, cdit, title))
    for i in range(cdit):
        r.align(4)
        cstyle = r.u32(); cex = r.u32(); xx=r.u16(); yy=r.u16(); ccx=r.u16(); ccy=r.u16()
        cid = r.u16()
        try:
            cclass = r.sz()
        except Exception:
            cclass = '?'
        ctext = r.sz()
        extra = 0
        if cclass == 'SysListView32' or (cstyle & 0x80):
            pass
        out.append('  item id=%d class=%r text=%r style=%08X ex=%08X rect=(%d,%d,%d,%d)' % (cid, cclass, ctext, cstyle, cex, xx,yy,ccx,ccy))
    return out

pe = pefile.PE(sys.argv[1])
for tid, label, st in get_res(pe):
    if tid != 5: continue
    data = pe.get_data(st.OffsetToData, st.Size)
    try:
        for line in parse_dialog(data, label): print(line)
    except Exception as e:
        print('DLG %s PARSE FAIL %s' % (label, e))
