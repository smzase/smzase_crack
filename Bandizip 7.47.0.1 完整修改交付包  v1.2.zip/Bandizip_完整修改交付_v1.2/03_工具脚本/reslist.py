import pefile, sys

RTYPES = {1:'CURSOR',2:'BITMAP',3:'ICON',4:'MENU',5:'DIALOG',6:'STRING',9:'ACCELERATOR',10:'RCDATA',12:'GROUP_CURSOR',14:'GROUP_ICON',16:'VERSION',24:'MANIFEST'}

def walk(pe, entries, depth=0, path=''):
    for e in entries:
        nm = e.name.string.decode('utf-16le', 'replace') if e.name else ''
        idv = e.id
        label = nm if nm else (RTYPES.get(e.id, 'ID') if depth == 0 else str(e.id))
        try:
            d = e.directory
            isdir = True
        except Exception:
            isdir = False
        if isdir:
            walk(pe, d.entries, depth + 1, path + '/' + label)
        else:
            size = e.data.struct.Size if e.data else 0
            print('%s%s  (size=%d)' % ('  ' * depth, path + '/' + label, size))

pe = pefile.PE(sys.argv[1])
walk(pe, pe.DIRECTORY_ENTRY_RESOURCE.entries)
