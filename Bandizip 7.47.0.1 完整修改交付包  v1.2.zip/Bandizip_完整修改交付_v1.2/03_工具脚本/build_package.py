# -*- coding: utf-8 -*-
"""构建补丁交付包: 生成 bat/README 并从工作目录复制 patch_bandizip.py"""
import os
import shutil

WORK = r'C:\Users\smz\BandizipWork'
OUT = os.path.join(WORK, 'BandizipProPatch')

BAT_APPLY = r'''@echo off
chcp 65001 >nul
setlocal EnableExtensions

rem ===== 目标安装目录: 参数1 或环境变量 BZP_TARGET, 默认 C:\Program Files\Bandizip
set "TARGET="
if not "%~1"=="" if /i not "%~1"=="--elevated" set "TARGET=%~1"
if not defined TARGET if defined BZP_TARGET set "TARGET=%BZP_TARGET%"
if not defined TARGET set "TARGET=C:\Program Files\Bandizip"
if defined TARGET for %%I in ("%TARGET%") do set "TARGET=%%~fI"
pushd "%~dp0"

rem ===== 判断目标目录是否可写, 不可写则请求管理员权限
set "WRITABLE="
echo.>"%TARGET%\.bzpatch_wtest" 2>nul
if exist "%TARGET%\.bzpatch_wtest" set "WRITABLE=1"
if defined WRITABLE del /f /q "%TARGET%\.bzpatch_wtest" >nul 2>&1
if defined WRITABLE goto :run
if /i "%~1"=="--elevated" goto :no_admin

echo 正在请求管理员权限, 请在弹出的 UAC 窗口中点击 "是" ...
set "BZP_TARGET=%TARGET%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -ArgumentList '--elevated' -Verb RunAs"
if errorlevel 1 echo [提示] 未获得管理员权限, 操作已取消。
goto :done

:no_admin
echo [错误] 没有写入 "%TARGET%" 的权限, 无法应用补丁。
goto :done

:run
rem ===== 定位 Python (需要 3.8+)
set "PY="
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
    echo [错误] 未找到 Python。请安装 Python 3.8 或更高版本, 安装时勾选 "Add python.exe to PATH"。
    goto :done
)

rem ===== 关闭正在运行的 Bandizip
tasklist /fi "imagename eq Bandizip.exe" 2>nul | find /i "Bandizip.exe" >nul
if not errorlevel 1 (
    echo 正在关闭 Bandizip ...
    taskkill /f /im Bandizip.exe >nul 2>&1
    timeout /t 1 /nobreak >nul
)

echo.
%PY% "%~dp0patch_bandizip.py" --apply "%TARGET%"
set "RC=%errorlevel%"
echo.
if "%RC%"=="0" (echo 操作完成: Bandizip 已为 Professional 已注册版, 无广告、无更新检查。) else (echo 操作未完成, 错误码 %RC%, 请查看上方提示。)

:done
echo.
if not defined BZP_NOPAUSE pause
popd
exit /b
'''

BAT_RESTORE = r'''@echo off
chcp 65001 >nul
setlocal EnableExtensions

set "TARGET="
if not "%~1"=="" if /i not "%~1"=="--elevated" set "TARGET=%~1"
if not defined TARGET if defined BZP_TARGET set "TARGET=%BZP_TARGET%"
if not defined TARGET set "TARGET=C:\Program Files\Bandizip"
if defined TARGET for %%I in ("%TARGET%") do set "TARGET=%%~fI"
pushd "%~dp0"

set "WRITABLE="
echo.>"%TARGET%\.bzpatch_wtest" 2>nul
if exist "%TARGET%\.bzpatch_wtest" set "WRITABLE=1"
if defined WRITABLE del /f /q "%TARGET%\.bzpatch_wtest" >nul 2>&1
if defined WRITABLE goto :run
if /i "%~1"=="--elevated" goto :no_admin

echo 正在请求管理员权限, 请在弹出的 UAC 窗口中点击 "是" ...
set "BZP_TARGET=%TARGET%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -ArgumentList '--elevated' -Verb RunAs"
if errorlevel 1 echo [提示] 未获得管理员权限, 操作已取消。
goto :done

:no_admin
echo [错误] 没有写入 "%TARGET%" 的权限, 无法还原。
goto :done

:run
set "PY="
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
    echo [错误] 未找到 Python 3。
    goto :done
)

tasklist /fi "imagename eq Bandizip.exe" 2>nul | find /i "Bandizip.exe" >nul
if not errorlevel 1 (
    echo 正在关闭 Bandizip ...
    taskkill /f /im Bandizip.exe >nul 2>&1
    timeout /t 1 /nobreak >nul
)

echo.
%PY% "%~dp0patch_bandizip.py" --revert "%TARGET%"
echo.
echo 若还原失败, 可重新运行官方安装包覆盖安装。

:done
echo.
if not defined BZP_NOPAUSE pause
popd
exit /b
'''

BAT_CHECK = r'''@echo off
chcp 65001 >nul
setlocal EnableExtensions
set "TARGET=%~1"
if not defined TARGET set "TARGET=C:\Program Files\Bandizip"
if defined TARGET for %%I in ("%TARGET%") do set "TARGET=%%~fI"
pushd "%~dp0"
set "PY="
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
    echo [错误] 未找到 Python 3。
    goto :done
)
%PY% "%~dp0patch_bandizip.py" --check "%TARGET%"
:done
echo.
if not defined BZP_NOPAUSE pause
popd
exit /b
'''

BAT_STATUS = r'''@echo off
chcp 65001 >nul
setlocal EnableExtensions
set "TARGET=%~1"
if not defined TARGET set "TARGET=C:\Program Files\Bandizip"
if defined TARGET for %%I in ("%TARGET%") do set "TARGET=%%~fI"
pushd "%~dp0"
set "PY="
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
    echo [错误] 未找到 Python 3。
    goto :done
)
%PY% "%~dp0patch_bandizip.py" --status "%TARGET%"
:done
echo.
if not defined BZP_NOPAUSE pause
popd
exit /b
'''

BAT_AUTO = r'''@echo off
rem 由计划任务在登录时调用: 若 Bandizip 被官方安装包覆盖, 自动重新打补丁。
rem 已打过补丁时会快速跳过, 不会重复修改。
setlocal EnableExtensions
cd /d "%~dp0"
set "TARGET=C:\Program Files\Bandizip"
set "LOG=%~dp0auto_repatch.log"
if not exist "%TARGET%\Bandizip.exe" goto :eof
set "PY="
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)
if not defined PY goto :eof
echo [%date% %time%] 检查/重打 Bandizip 补丁 >> "%LOG%"
%PY% "%~dp0patch_bandizip.py" --apply "%TARGET%" >> "%LOG%" 2>&1
exit /b
'''

BAT_INSTALL_TASK = r'''@echo off
chcp 65001 >nul
setlocal EnableExtensions
pushd "%~dp0"

net session >nul 2>&1
if not errorlevel 1 goto :run
echo 正在请求管理员权限, 请在弹出的 UAC 窗口中点击 "是" ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
goto :done

:run
schtasks /create /f /tn "Bandizip Pro Patch AutoRepatch" /sc onlogon /rl highest /tr "%~dp0auto_repatch.bat"
if errorlevel 1 (
    echo [错误] 创建计划任务失败。
) else (
    echo 已创建登录计划任务: Bandizip Pro Patch AutoRepatch
    echo 每次登录时若发现 Bandizip 已被更新覆盖, 会自动重新打补丁。
)
:done
echo.
if not defined BZP_NOPAUSE pause
popd
exit /b
'''

BAT_REMOVE_TASK = r'''@echo off
chcp 65001 >nul
setlocal EnableExtensions
pushd "%~dp0"

net session >nul 2>&1
if not errorlevel 1 goto :run
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
goto :done

:run
schtasks /delete /f /tn "Bandizip Pro Patch AutoRepatch"
if errorlevel 1 (
    echo [提示] 未找到该计划任务, 或删除失败。
) else (
    echo 已删除计划任务。
)
:done
echo.
if not defined BZP_NOPAUSE pause
popd
exit /b
'''

README = '''Bandizip 去更新/去广告/专业版补丁工具  v1.2
============================================================

一、这个工具做什么
------------------------------------------------------------
针对 Bandizip 7.47.0.1 (build 71912) 的二进制补丁, 打补丁后:

1. 显示为已注册的 Bandizip Professional 版:
   - 主窗口标题显示 "Bandizip (Professional)"
   - 关于对话框显示 "Bandizip Professional (已注册)"
   - 专业版功能可用: 解压/压缩/修改压缩包(添加/删除文件/注释)、
     密码管理器、修复压缩包、密码恢复等
   - 不再出现 "未注册版" 的注册提示/限制引导
2. 彻底移除内置更新:
   - 不再启动 updater.exe, 不再联网检查新版本
   - 关于对话框中的更新栏被隐藏
   - 更新图标(主窗口STATIC_UPDATE)永远隐藏
   - Updater.exe 被改为启动即静默退出
   - 只能通过官方安装包进行更新(见第五节)
3. 彻底移除广告:
   - 不再弹出广告窗口/网页广告
   - 不加载广告模块, 广告模式被强制为 0
4. 不修改注册表、不修改系统服务/计划任务(可选任务见第六节),
   所有改动都只发生在 Bandizip 安装目录内部。

二、环境要求
------------------------------------------------------------
- Windows 10/11 64 位
- Bandizip 7.47.0.1 (build 71912) 官方安装版
- Python 3.8 或更高版本 (安装时勾选 "Add python.exe to PATH")
- 32 位/ARM 版 Bandizip 不适用

三、应用补丁 (推荐方式)
------------------------------------------------------------
1. 关闭所有 Bandizip 窗口 (脚本也会自动关闭)。
2. 双击 apply.bat。
   - 如果 Bandizip 装在 C:\\Program Files\\Bandizip (默认),
     会自动请求管理员权限, 请在 UAC 窗口中点 "是"。
   - 安装在其他目录时: 从命令行运行  apply.bat "D:\\你的\\Bandizip目录"
3. 脚本会先备份原始文件到安装目录下的 _patch_backup\\, 然后打补丁。
4. 看到 "操作完成" 即成功, 重新打开 Bandizip 验证即可。

也可以用命令行:
    python patch_bandizip.py --check  "安装目录"   仅检查能否打补丁
    python patch_bandizip.py --apply  "安装目录"   打补丁
    python patch_bandizip.py --revert "安装目录"   还原
    python patch_bandizip.py --status "安装目录"   查看状态

四、还原
------------------------------------------------------------
双击 restore.bat, 会从 _patch_backup\\ 还原 Bandizip.exe / Updater.exe
以及被替换的语言文件。若还原失败, 直接运行官方安装包覆盖安装即可。

五、关于官方更新 (重要)
------------------------------------------------------------
- 补丁只关闭了 Bandizip 的 "内置自动更新", 不影响手动更新:
  下载官方新安装包并运行安装即可正常升级, 安装程序会覆盖被修改的文件。
- 升级后补丁会被官方文件覆盖, 此时重新运行一次 apply.bat 即可恢复
  "专业版 + 无广告 + 无更新" 状态。
- 工具是幂等的: 已经打过补丁时再次运行会自动跳过, 不会重复修改。
- 工具按特征码定位函数, 若将来的新版结构变化导致定位失败, 工具会
  直接放弃并且不做任何修改(不会写出半成品), 此时需要更新本工具。
- 本工具不修改 Bandizip 的安装信息/卸载信息, 升级、卸载均不受影响。

六、可选: 登录时自动重打补丁
------------------------------------------------------------
如果希望官方升级后自动恢复补丁, 可双击 install_autotask.bat 创建
一个登录计划任务(需要管理员权限)。之后每次登录时若发现 Bandizip
已被新版本覆盖, 会自动重新打补丁(已打过则快速跳过), 日志在
auto_repatch.log。删除该任务: 双击 remove_autotask.bat。

七、验证
------------------------------------------------------------
- check.bat   : 检查当前文件能否被本工具识别并打补丁
- status.bat  : 查看两个 exe 与语言文件的补丁状态
- 手工验证: 打开 Bandizip, 主窗口标题应为 "Bandizip (Professional)",
  主窗口左上角无注册钥匙图标、无更新图标、无广告条;
  "帮助->关于 Bandizip" 显示 "Bandizip Professional (已注册)" 且无更新栏;
  任务管理器中没有 updater.exe 随 Bandizip 启动。

八、注意事项
------------------------------------------------------------
- 修改后 Bandizip.exe 的数字签名失效, 这是正常现象, 不影响运行。
- 部分杀毒软件可能对修改过的程序报警, 如拦截请添加信任/白名单。
- "设置 -> 常规 -> 更新设置" 下拉框仍然显示, 但补丁后该选项已不起作用。
- 点击菜单 "选项 -> 取消注册 Bandizip" 会弹出 "已是已注册版" 的提示,
  不会真的取消注册。
- 备份目录请不要删除, 以便随时还原。

九、文件清单
------------------------------------------------------------
    patch_bandizip.py     补丁主程序 (Python)
    apply.bat             应用补丁 (可自动请求管理员权限)
    restore.bat           还原
    check.bat             补丁可行性检查
    status.bat            补丁状态查看
    install_autotask.bat  可选: 创建登录时自动重打补丁的计划任务
    remove_autotask.bat   可选: 删除上述计划任务
    auto_repatch.bat      计划任务调用的脚本
    README.txt            本说明

十、版本
------------------------------------------------------------
工具版本: 1.2
支持软件: Bandizip 7.47.0.1 (FileVersion 7.47.0.1, build 71912)
         结构相近的 7.4x 版本可尝试, 新版请先运行 check.bat 检查。
'''


def wb(path, text, encoding='utf-8'):
    with open(path, 'wb') as f:
        f.write(text.replace('\r\n', '\n').replace('\n', '\r\n').encode(encoding))


def main():
    os.makedirs(OUT, exist_ok=True)
    shutil.copy2(os.path.join(WORK, 'patch_bandizip.py'),
                 os.path.join(OUT, 'patch_bandizip.py'))
    wb(os.path.join(OUT, 'apply.bat'), BAT_APPLY)
    wb(os.path.join(OUT, 'restore.bat'), BAT_RESTORE)
    wb(os.path.join(OUT, 'check.bat'), BAT_CHECK)
    wb(os.path.join(OUT, 'status.bat'), BAT_STATUS)
    wb(os.path.join(OUT, 'auto_repatch.bat'), BAT_AUTO)
    wb(os.path.join(OUT, 'install_autotask.bat'), BAT_INSTALL_TASK)
    wb(os.path.join(OUT, 'remove_autotask.bat'), BAT_REMOVE_TASK)
    wb(os.path.join(OUT, 'README.txt'), README, encoding='utf-8-sig')
    print('已生成交付包:', OUT)
    for n in sorted(os.listdir(OUT)):
        print('  ', n, os.path.getsize(os.path.join(OUT, n)))


if __name__ == '__main__':
    main()
