param(
    [string]$ProcessName = 'Bandizip',
    [string]$ClassMatch = 'BandizipClass',
    [int]$CommandId = 0,
    [string]$Keys = '',
    [int]$WaitMs = 1500
)
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class CmdSend {
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    public static string Cls(IntPtr h) { var sb=new StringBuilder(256); GetClassNameW(h,sb,256); return sb.ToString(); }
}
"@
$procs = @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue)
if ($procs.Count -eq 0) { Write-Output 'NO PROCESS'; exit 1 }
$pids = @($procs | ForEach-Object { $_.Id })
$targets = New-Object System.Collections.ArrayList
$cb = [CmdSend+EnumWindowsProc]{ param($h,$l)
    $pid2 = 0
    [void][CmdSend]::GetWindowThreadProcessId($h, [ref]$pid2)
    if ($pids -contains [int]$pid2 -and [CmdSend]::IsWindowVisible($h) -and ([CmdSend]::Cls($h) -match $ClassMatch)) {
        [void]$targets.Add($h)
    }
    return $true }
[void][CmdSend]::EnumWindows($cb, [IntPtr]::Zero)
Write-Output ("targets: " + (($targets | ForEach-Object { $_.ToString() }) -join ', '))
if ($targets.Count -eq 0) { Write-Output 'NO TARGET WINDOW'; exit 2 }
$h = $targets[0]
if ($CommandId -ne 0) {
    $ok = [CmdSend]::PostMessageW($h, 0x111, [IntPtr]$CommandId, [IntPtr]::Zero)
    Write-Output ("WM_COMMAND {0} posted={1} hwnd={2}" -f $CommandId, $ok, $h)
}
if ($Keys) {
    [void][CmdSend]::SetForegroundWindow($h)
    [void][CmdSend]::BringWindowToTop($h)
    Start-Sleep -Milliseconds 300
    $wsh = New-Object -ComObject WScript.Shell
    $wsh.SendKeys($Keys)
    Write-Output ("sent keys: " + $Keys)
}
Start-Sleep -Milliseconds $WaitMs
