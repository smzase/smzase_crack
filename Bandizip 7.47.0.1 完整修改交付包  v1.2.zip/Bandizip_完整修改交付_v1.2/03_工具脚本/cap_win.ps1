param(
    [string]$ProcessName = 'Bandizip',
    [string]$ClassMatch = '#32770',
    [string]$TitleMatch = '.*',
    [string]$OutFile = 'C:\Users\smz\BandizipWork\shot_dlg.png',
    [switch]$ListOnly
)
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class WinFind {
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hwnd, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
    [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    public static string Text(IntPtr h) { var sb=new StringBuilder(512); GetWindowTextW(h,sb,512); return sb.ToString(); }
    public static string Cls(IntPtr h) { var sb=new StringBuilder(256); GetClassNameW(h,sb,256); return sb.ToString(); }
}
"@
$procs = @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue)
if ($procs.Count -eq 0) { Write-Output 'NO PROCESS'; exit 1 }
$pids = @($procs | ForEach-Object { $_.Id })
$wins = New-Object System.Collections.ArrayList
$cb = [WinFind+EnumWindowsProc]{ param($h,$l)
    $pid2 = 0
    [void][WinFind]::GetWindowThreadProcessId($h, [ref]$pid2)
    if ($pids -contains [int]$pid2) {
        $r = New-Object WinFind+RECT
        [void][WinFind]::GetWindowRect($h, [ref]$r)
        [void]$wins.Add([pscustomobject]@{ Hwnd=$h; Title=[WinFind]::Text($h); Class=[WinFind]::Cls($h); Visible=[WinFind]::IsWindowVisible($h); W=($r.Right-$r.Left); H=($r.Bottom-$r.Top); X=$r.Left; Y=$r.Top })
    }
    return $true }
[void][WinFind]::EnumWindows($cb, [IntPtr]::Zero)
$wins | Format-Table -AutoSize | Out-String -Width 240 | Write-Output
if ($ListOnly) { exit 0 }
$target = $wins | Where-Object { $_.Visible -and $_.Class -match $ClassMatch -and $_.Title -match $TitleMatch -and $_.W -gt 50 } | Sort-Object { $_.W * $_.H } -Descending | Select-Object -First 1
if (-not $target) { Write-Output 'NO MATCHING WINDOW'; exit 2 }
$r = New-Object WinFind+RECT
[void][WinFind]::GetWindowRect($target.Hwnd, [ref]$r)
$w = $r.Right-$r.Left; $h = $r.Bottom-$r.Top
Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap $w, $h
$g = [System.Drawing.Graphics]::FromImage($bmp)
$hdc = $g.GetHdc()
$ok = [WinFind]::PrintWindow($target.Hwnd, $hdc, 2)
$g.ReleaseHdc($hdc); $g.Dispose()
$bmp.Save($OutFile, [System.Drawing.Imaging.ImageFormat]::Png)
Write-Output ("saved={0} ok={1} hwnd={2} class={3} title={4} {5}x{6}" -f $OutFile, $ok, $target.Hwnd, $target.Class, $target.Title, $w, $h)
