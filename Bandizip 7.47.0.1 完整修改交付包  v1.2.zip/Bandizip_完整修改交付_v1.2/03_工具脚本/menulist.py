import pefile, struct, sys

def get_entries(pe):
    out = {}
    def walk(entries, depth=0, path='', typeid=None):
        for e in entries:
            nm = e.name.string.decode('utf-16le', 'replace') if e.name else ''
            label = nm if nm else str(e.id)
            try:
                d = e.directory
                isdir = True
            except Exception:
                isdir = False
            if isdir:
                walk(d.entries, depth + 1, path + '/' + label, e.id if depth == 0 else typeid)
            else:
                out[(typeid, label)] = e.data.struct
    walk(pe.DIRECTORY_ENTRY_RESOURCE.entries)
    return out

def parse_menu(data, text):
    p = 4  # skip header
    # skip first item usually empty
    items = []
    def read_item(level):
        nonlocal p
        while p + 2 <= len(data):
            flags, iid = struct.unpack_from('<HH', data, p); p += 4
            s = ''
            if flags & 0x10:  # popup
                if p + 2 <= len(data):
                    slen, = struct.unpack_from('<H', data, p); p += 2
                    if slen:
                        raw = data[p:p+slen]; p += slen
                        s = raw.decode('utf-16le', 'replace')
                    else:
                        s = '<noname>'
                items.append(('  '*level) + '[%s] flags=%04X' % (s, flags))
                read_item(level+1)
            else:
                if p + 2 <= len(data):
                    slen, = struct.unpack_from('<H', data, p); p += 2
                    if slen:
                        raw = data[p:p+slen]; p += slen
                        s = raw.decode('utf-16le', 'replace')
                    else:
                        s = '<noname>'
                items.append(('  '*level) + '%s  id=%d flags=%04X' % (s, iid, flags))
    read_item(0)
    return items

pe = pefile.PE(sys.argv[1])
ents = get_entries(pe)
want = sys.argv[2] if len(sys.argv) > 2 else 'MENU'
for (tid, label), st in ents.items():
    if tid != want: continue
    data = pe.get_data(st.OffsetToData, st.Size)
    print('==== %s %s size=%d' % (want, label, len(data)))
    for line in parse_menu(data, label):
        print(line)
