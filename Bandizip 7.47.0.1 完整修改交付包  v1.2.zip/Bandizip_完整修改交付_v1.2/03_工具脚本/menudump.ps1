param([string]$ProcessName='Bandizip')
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class MenuDump {
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr GetMenu(IntPtr hWnd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr GetSubMenu(IntPtr hMenu, int nPos);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetMenuItemCount(IntPtr hMenu);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint GetMenuState(IntPtr hMenu, uint uId, uint uFlags);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetMenuStringW(IntPtr hMenu, uint uIDItem, StringBuilder lpString, int nMaxCount, uint uFlag);
    [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr hWnd, uint uCmd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindowExW(IntPtr parent, IntPtr child, string cls, string win);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    public static string Text(IntPtr h) { var sb=new StringBuilder(512); GetWindowTextW(h,sb,512); return sb.ToString(); }
    public static string Cls(IntPtr h) { var sb=new StringBuilder(256); GetClassNameW(h,sb,256); return sb.ToString(); }
}
"@
$procs = @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue)
foreach ($p in $procs) {
    $hwnds = New-Object System.Collections.ArrayList
    $cb = [MenuDump+EnumWindowsProc]{ param($h,$l)
        $pid2=0; [void][MenuDump]::GetWindowThreadProcessId($h,[ref]$pid2)
        if ($pid2 -eq $script:targetPid -and [MenuDump]::IsWindowVisible($h)) { [void]$hwnds.Add($h) }
        return $true }
    $script:targetPid = $p.Id
    [void][MenuDump]::EnumWindows($cb, [IntPtr]::Zero)
    foreach ($h in $hwnds) {
        $menu = [MenuDump]::GetMenu($h)
        if ($menu -eq [IntPtr]::Zero) { continue }
        Write-Output "=== hwnd=$h class=$([MenuDump]::Cls($h)) title=$([MenuDump]::Text($h)) ==="
        $cnt = [MenuDump]::GetMenuItemCount($menu)
        for ($i=0; $i -lt $cnt; $i++) {
            $sb = New-Object System.Text.StringBuilder 256
            [void][MenuDump]::GetMenuStringW($menu, [uint32]$i, $sb, 256, 0x400)
            $id = [MenuDump]::GetMenuStringW($menu, [uint32]$i, $null, 0, 0x40)
            Write-Output ("  TOP[{0}] '{1}'" -f $i, $sb.ToString())
            $sub = [MenuDump]::GetSubMenu($menu, $i)
            if ($sub -ne [IntPtr]::Zero) {
                $scnt = [MenuDump]::GetMenuItemCount($sub)
                for ($j=0; $j -lt $scnt; $j++) {
                    $sb2 = New-Object System.Text.StringBuilder 256
                    [void][MenuDump]::GetMenuStringW($sub, [uint32]$j, $sb2, 256, 0x400)
                    $idj = [MenuDump]::GetMenuStringW($sub, [uint32]$j, $null, 0, 0x40)
                    $state = [MenuDump]::GetMenuState($sub, [uint32]$j, 0x400)
                    Write-Output ("     [{0}] '{1}' state=0x{2:X}" -f $j, $sb2.ToString(), $state)
                }
            }
        }
    }
}
