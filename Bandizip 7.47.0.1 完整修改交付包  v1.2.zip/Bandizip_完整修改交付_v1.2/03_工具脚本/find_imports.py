import importlib.util
spec = importlib.util.spec_from_file_location('pb', r'C:\Users\smz\BandizipWork\patch_bandizip.py')
pb = importlib.util.module_from_spec(spec); spec.loader.exec_module(pb)
pe = pb.PE(r'C:\Users\smz\BandizipWork\orig\Bandizip.exe')
for fname in ('MessageBoxW', 'MessageBoxA', 'GetDlgItem', 'ShowWindow', 'EnableWindow', 'DeleteMenu', 'GetSubMenu', 'GetMenuItemInfoW', 'SetMenuItemInfoW'):
    try:
        iat = pb.get_import_iat(pe, 'user32.dll', fname)
        print('%-18s IAT=%X' % (fname, iat))
    except Exception as e:
        print('%-18s not found (%s)' % (fname, e))
