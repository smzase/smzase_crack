param(
    [string]$ProcessName = 'Bandizip',
    [string]$OutFile = 'C:\Users\smz\BandizipWork\shot.png',
    [string]$TitleMatch = ''
)
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class WinCap {
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hwnd, IntPtr hdcBlt, uint nFlags);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern int GetWindowTextW(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
    [DllImport("user32.dll")] public static extern int GetClassNameW(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
}
"@
$procs = @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue)
if ($procs.Count -eq 0) { Write-Output "NO PROCESS $ProcessName"; exit 1 }
$pids = $procs | ForEach-Object { $_.Id }
$found = New-Object System.Collections.ArrayList
$cb = [WinCap+EnumWindowsProc]{
    param($hWnd, $lParam)
    $pid2 = 0
    [void][WinCap]::GetWindowThreadProcessId($hWnd, [ref]$pid2)
    if ($pids -contains [int]$pid2) {
        $sb = New-Object System.Text.StringBuilder 512
        [void][WinCap]::GetWindowTextW($hWnd, $sb, 512)
        $cn = New-Object System.Text.StringBuilder 256
        [void][WinCap]::GetClassNameW($hWnd, $cn, 256)
        $r = New-Object WinCap+RECT
        [void][WinCap]::GetWindowRect($hWnd, [ref]$r)
        [void]$found.Add([pscustomobject]@{Hwnd=$hWnd; Pid=$pid2; Title=$sb.ToString(); Class=$cn.ToString(); Visible=[WinCap]::IsWindowVisible($hWnd); Rect="$($r.Left),$($r.Top),$($r.Right),$($r.Bottom)"; W=($r.Right-$r.Left); H=($r.Bottom-$r.Top)})
    }
    return $true
}
[void][WinCap]::EnumWindows($cb, [IntPtr]::Zero)
$found | Format-Table -AutoSize | Out-String -Width 250 | Write-Output
$target = $found | Where-Object { $_.Title -match $TitleMatch -and $_.Visible -eq $true } | Select-Object -First 1
if (-not $target) { $target = $found | Where-Object { $_.Visible -eq $true -and $_.W -gt 100 } | Select-Object -First 1 }
if (-not $target) { Write-Output 'NO VISIBLE WINDOW'; exit 2 }
$r = New-Object WinCap+RECT
[void][WinCap]::GetWindowRect($target.Hwnd, [ref]$r)
$w = $r.Right - $r.Left; $h = $r.Bottom - $r.Top
Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap $w, $h
$g = [System.Drawing.Graphics]::FromImage($bmp)
$hdc = $g.GetHdc()
$ok = [WinCap]::PrintWindow($target.Hwnd, $hdc, 2)
$g.ReleaseHdc($hdc)
$g.Dispose()
$bmp.Save($OutFile, [System.Drawing.Imaging.ImageFormat]::Png)
Write-Output "saved=$OutFile ok=$ok target=$($target.Title) $($target.Class) ${w}x${h}"
