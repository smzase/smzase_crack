param(
    [string]$ProcessName = 'Bandizip',
    [string]$TitleMatch = '选择',
    [string]$Text = '',
    [int]$EditId = 0,
    [int]$ButtonId = 0,
    [string]$ButtonText = ''
)
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class DlgOp {
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
    [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr h, EnumWindowsProc cb, IntPtr lp);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr hWnd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr SendMessageW(IntPtr hWnd, uint msg, IntPtr wParam, string lParam);
    [DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindowExW(IntPtr parent, IntPtr child, string cls, string win);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    public static string T(IntPtr h) { var sb=new StringBuilder(512); GetWindowTextW(h,sb,512); return sb.ToString(); }
    public static string C(IntPtr h) { var sb=new StringBuilder(256); GetClassNameW(h,sb,256); return sb.ToString(); }
}
"@
$procs = @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue)
if ($procs.Count -eq 0) { Write-Output 'NO PROCESS'; exit 1 }
$pids = @($procs | ForEach-Object { $_.Id })
$dlgs = New-Object System.Collections.ArrayList
$cb = [DlgOp+EnumWindowsProc]{ param($h,$l)
    $pid2 = 0
    [void][DlgOp]::GetWindowThreadProcessId($h, [ref]$pid2)
    if ($pids -contains [int]$pid2 -and [DlgOp]::IsWindowVisible($h) -and [DlgOp]::C($h) -eq '#32770' -and [DlgOp]::T($h) -match $TitleMatch) {
        [void]$dlgs.Add($h)
    }
    return $true }
[void][DlgOp]::EnumWindows($cb, [IntPtr]::Zero)
if ($dlgs.Count -eq 0) { Write-Output "NO DIALOG matching $TitleMatch"; exit 2 }
$dlg = $dlgs[0]
Write-Output ("dialog hwnd={0} title={1}" -f $dlg, [DlgOp]::T($dlg))
$children = New-Object System.Collections.ArrayList
$cb2 = [DlgOp+EnumWindowsProc]{ param($h,$l)
    [void]$children.Add([pscustomobject]@{ Hwnd=$h; Id=[DlgOp]::GetDlgCtrlID($h); Class=[DlgOp]::C($h); Text=[DlgOp]::T($h); Visible=[DlgOp]::IsWindowVisible($h) })
    return $true }
[void][DlgOp]::EnumChildWindows($dlg, $cb2, [IntPtr]::Zero)
Write-Output ($children | Format-Table -AutoSize | Out-String -Width 240)
if ($Text -and $EditId) {
    $ed = $children | Where-Object { $_.Id -eq $EditId } | Select-Object -First 1
    if ($ed) {
        # WM_SETTEXT = 0x000C
        [void][DlgOp]::SendMessageW($ed.Hwnd, 0x000C, [IntPtr]::Zero, $Text)
        Write-Output ("set edit id={0} text={1}" -f $EditId, $Text)
    } else { Write-Output "no edit $EditId" }
}
if ($ButtonId -or $ButtonText) {
    $btn = $null
    if ($ButtonId) { $btn = $children | Where-Object { $_.Id -eq $ButtonId } | Select-Object -First 1 }
    if (-not $btn -and $ButtonText) { $btn = $children | Where-Object { $_.Text -match $ButtonText -and $_.Class -eq 'Button' } | Select-Object -First 1 }
    if ($btn) {
        [void][DlgOp]::SendMessageW($btn.Hwnd, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero)
        Write-Output ("clicked hwnd={0} id={1} text={2}" -f $btn.Hwnd, $btn.Id, $btn.Text)
    } else { Write-Output 'button not found' }
}
