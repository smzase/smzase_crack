import importlib.util
spec = importlib.util.spec_from_file_location('pb', r'C:\Users\smz\BandizipWork\patch_bandizip.py')
pb = importlib.util.module_from_spec(spec); spec.loader.exec_module(pb)
pe = pb.PE(r'C:\Program Files\Bandizip\Bandizip.exe')
sites = [
    ('license lea', 0x1401317E5, 7),
    ('license imm', 0x1401317FB, 4),
    ('license online check fn', 0x14015FC90, 6),
    ('updater launch #1', 0x140127870, 6),
    ('updater launch #2', 0x1401475D0, 6),
    ('about update check fn', 0x1400F1100, 6),
    ('setup download fn', 0x1400F22C0, 6),
    ('update download fn', 0x1400F1620, 6),
    ('update icon', 0x140164A82, 6),
    ('popup ad fn', 0x140137F70, 6),
    ('web ad fn', 0x140137DB0, 6),
    ('ad mode fn', 0x1401B3AE0, 6),
    ('reg menu fn', 0x14015F8F0, 6),
    ('reg dialog fn', 0x140134D30, 6),
]
for name, ea, n in sites:
    print('%-26s EA=%X  bytes=%s' % (name, ea, pe.read(ea, n).hex(' ')))
up = pb.PE(r'C:\Program Files\Bandizip\Updater.exe')
ep = up.image_base + up.entry_rva
print('Updater.exe EP EA=%X bytes=%s' % (ep, up.read(ep, 8).hex(' ')))
