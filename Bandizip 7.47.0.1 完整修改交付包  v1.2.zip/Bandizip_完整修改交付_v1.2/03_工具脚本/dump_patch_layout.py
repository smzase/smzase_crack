import importlib.util, struct
spec = importlib.util.spec_from_file_location('pb', r'C:\Users\smz\BandizipWork\patch_bandizip.py')
pb = importlib.util.module_from_spec(spec); spec.loader.exec_module(pb)
pe = pb.PE(r'C:\Program Files\Bandizip\Bandizip.exe')
print('SizeOfImage=%X' % pe.size_image)
for s in pe.sections:
    print('%-10s VA=%08X VS=%08X RAW=%08X RS=%08X CH=%08X' % (s['name'], s['va'], s['vsz'], s['raw'], s['rsz'], s['chars']))
# 打印 .bzp 节字节（十六进制 + 反汇编不便，至少打字节）
s = [x for x in pe.sections if x['name'] == '.bzp'][0]
data = bytes(pe.data[s['raw']:s['raw'] + s['rsz']])
print('--- .bzp size=%d  EA=%X' % (len(data), pe.image_base + s['va']))
print(data.hex(' '))
# 找所有 E9 hook：扫描 .text 中被改成 E9 的位置不易；这里打印已知 cave 引用
# 从 .bzp 里找 E9 目标？改为列出所有指向 .bzp 内的 E9 跳转
cave_lo = pe.image_base + s['va']
cave_hi = cave_lo + len(data)
import re
text = [x for x in pe.sections if x['name'] == '.text'][0]
tdata = bytes(pe.data[text['raw']:text['raw'] + text['rsz']])
hits = []
for i in range(len(tdata) - 5):
    if tdata[i] == 0xE9:
        disp = struct.unpack_from('<i', tdata, i + 1)[0]
        tgt = pe.image_base + text['va'] + i + 5 + disp
        if cave_lo <= tgt < cave_hi:
            hits.append((pe.image_base + text['va'] + i, tgt))
print('--- 指向 .bzp 的 E9 hooks: %d 个' % len(hits))
for ea, tgt in hits:
    print('  EA=%X -> %X' % (ea, tgt))
