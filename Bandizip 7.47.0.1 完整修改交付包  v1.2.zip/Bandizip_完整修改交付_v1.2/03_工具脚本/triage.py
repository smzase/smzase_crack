import pefile, sys, re, os, math, json

BASE = r'C:\Users\smz\BandizipWork\orig'
FILES = ['Bandizip.exe', r'Updater.exe', r'bz.exe', r'ark.x64.dll', r'data\lm.x64.dll',
         r'data\Amsiman.x64.exe', r'data\RegDll.x64.exe', r'data\bzshell.x64.dll',
         r'data\web32.exe', r'data\webview.x86.dll', r'data\WebView2.x64.dll',
         r'bdzshl.x64.dll', r'data\RegPackage.x86.exe']

def entropy(b):
    if not b: return 0
    c = [0]*256
    for x in b: c[x]+=1
    e = 0
    for n in c:
        if n:
            p = n/len(b); e -= p*math.log2(p)
    return e

def strings(data, minlen=4):
    """yield (offset, text, encoding)"""
    # ascii
    res=[]
    cur=bytearray(); start=0
    for i,b in enumerate(data):
        if 32 <= b < 127:
            if not cur: start=i
            cur.append(b)
        else:
            if len(cur)>=minlen: res.append((start,cur.decode('ascii'),'a'))
            cur=bytearray()
    if len(cur)>=minlen: res.append((start,cur.decode('ascii'),'a'))
    # utf-16le
    cur=[]; start=0
    i=0; n=len(data)
    while i+1 < n:
        b0,b1 = data[i],data[i+1]
        if 32 <= b0 < 127 and b1==0:
            if not cur: start=i
            cur.append(chr(b0))
            i+=2
        else:
            if len(cur)>=minlen: res.append((start,''.join(cur),'w'))
            cur=[]; i+=1
    if len(cur)>=minlen: res.append((start,''.join(cur),'w'))
    return res

def main():
    out = {}
    for rel in FILES:
        p = os.path.join(BASE, rel)
        print('='*30, rel)
        pe = pefile.PE(p)
        data = open(p,'rb').read()
        print('ep=0x%X imagebase=0x%X' % (pe.OPTIONAL_HEADER.AddressOfEntryPoint, pe.OPTIONAL_HEADER.ImageBase))
        for s in pe.sections:
            nm = s.Name.decode(errors='replace').strip('\x00')
            print('  %-10s VA=%08X VSize=%08X RawOff=%08X RawSize=%08X ent=%.2f' % (
                nm, s.VirtualAddress, s.Misc_VirtualSize, s.PointerToRawData, s.SizeOfRawData,
                entropy(data[s.PointerToRawData:s.PointerToRawData+s.SizeOfRawData])))
        imps = []
        if hasattr(pe,'DIRECTORY_ENTRY_IMPORT'):
            for d in pe.DIRECTORY_ENTRY_IMPORT:
                imps.append(d.dll.decode(errors='replace'))
        print('  imports(%d): %s' % (len(imps), ', '.join(imps)))
        exps = []
        if hasattr(pe,'DIRECTORY_ENTRY_EXPORT') and pe.DIRECTORY_ENTRY_EXPORT:
            for e in pe.DIRECTORY_ENTRY_EXPORT.symbols:
                exps.append(e.name.decode(errors='replace') if e.name else 'ord%d'%e.ordinal)
        print('  exports(%d): %s' % (len(exps), ', '.join(exps[:40])))
        strs = strings(data, 4)
        print('  strings: ascii+wide=%d' % len(strs))
        with open(os.path.join(os.path.dirname(__file__), 'strings_' + os.path.basename(rel) + '.txt'),'w',encoding='utf-8') as f:
            for off,t,enc in strs:
                f.write('%08X\t%s\t%s\n' % (off, enc, t))
        print()

if __name__ == '__main__':
    main()
