param(
    [string]$ProcessName = 'Bandizip',
    [string]$DialogClass = '#32770',
    [int]$ClickId = 0,
    [string]$ClickText = ''
)
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class ChildDump {
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
    [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr h, EnumWindowsProc cb, IntPtr lp);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    public static string T(IntPtr h) { var sb=new StringBuilder(512); GetWindowTextW(h,sb,512); return sb.ToString(); }
    public static string C(IntPtr h) { var sb=new StringBuilder(256); GetClassNameW(h,sb,256); return sb.ToString(); }
}
"@
$procs = @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue)
if ($procs.Count -eq 0) { Write-Output 'NO PROCESS'; exit 1 }
$pids = @($procs | ForEach-Object { $_.Id })
$dlgs = New-Object System.Collections.ArrayList
$cb = [ChildDump+EnumWindowsProc]{ param($h,$l)
    $pid2 = 0
    [void][ChildDump]::GetWindowThreadProcessId($h, [ref]$pid2)
    if ($pids -contains [int]$pid2 -and [ChildDump]::IsWindowVisible($h) -and ([ChildDump]::C($h) -match $DialogClass)) {
        [void]$dlgs.Add($h)
    }
    return $true }
[void][ChildDump]::EnumWindows($cb, [IntPtr]::Zero)
if ($dlgs.Count -eq 0) { Write-Output 'NO DIALOG'; exit 2 }
$dlg = $dlgs[0]
Write-Output ("dialog hwnd={0} class={1} title={2}" -f $dlg, [ChildDump]::C($dlg), [ChildDump]::T($dlg))
$children = New-Object System.Collections.ArrayList
$cb2 = [ChildDump+EnumWindowsProc]{ param($h,$l)
    [void]$children.Add([pscustomobject]@{ Hwnd=$h; Id=[ChildDump]::GetDlgCtrlID($h); Class=[ChildDump]::C($h); Text=[ChildDump]::T($h); Visible=[ChildDump]::IsWindowVisible($h) })
    return $true }
[void][ChildDump]::EnumChildWindows($dlg, $cb2, [IntPtr]::Zero)
$children | Format-Table -AutoSize | Out-String -Width 240 | Write-Output
if ($ClickId -ne 0) {
    $btn = $children | Where-Object { $_.Id -eq $ClickId } | Select-Object -First 1
    if ($btn) {
        # BM_CLICK = 0x00F5
        [void][ChildDump]::SendMessageW($btn.Hwnd, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero)
        Write-Output ("clicked id={0} hwnd={1} text={2}" -f $ClickId, $btn.Hwnd, $btn.Text)
    } else { Write-Output "no child with id=$ClickId" }
}
if ($ClickText) {
    $btn = $children | Where-Object { $_.Text -match $ClickText } | Select-Object -First 1
    if ($btn) {
        [void][ChildDump]::SendMessageW($btn.Hwnd, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero)
        Write-Output ("clicked text={0} hwnd={1} id={2}" -f $ClickText, $btn.Hwnd, $btn.Id)
    } else { Write-Output "no child matching text=$ClickText" }
}
