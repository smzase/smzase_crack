param(
    [string]$ProcessName = 'Bandizip',
    [string]$ClassMatch = '.+',
    [string]$TitleMatch = '.*',
    [string]$Keys = '',
    [int]$WaitMs = 1500
)
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class KeyWin {
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr hWnd, StringBuilder sb, int n);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int n);
    [DllImport("user32.dll")] public static extern IntPtr SetFocus(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
    [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] public static extern IntPtr GetFocus();
    [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    public static string T(IntPtr h) { var sb=new StringBuilder(512); GetWindowTextW(h,sb,512); return sb.ToString(); }
    public static string C(IntPtr h) { var sb=new StringBuilder(256); GetClassNameW(h,sb,256); return sb.ToString(); }
}
"@
$procs = @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue)
if ($procs.Count -eq 0) { Write-Output 'NO PROCESS'; exit 1 }
$pids = @($procs | ForEach-Object { $_.Id })
$list = New-Object System.Collections.ArrayList
$cb = [KeyWin+EnumWindowsProc]{ param($h,$l)
    $p2 = 0
    [void][KeyWin]::GetWindowThreadProcessId($h, [ref]$p2)
    if ($pids -contains [int]$p2) {
        $c = [KeyWin]::C($h); $t = [KeyWin]::T($h)
        if ($c -match $ClassMatch -and $t -match $TitleMatch) { [void]$list.Add($h) }
    }
    return $true }
[void][KeyWin]::EnumWindows($cb, [IntPtr]::Zero)
if ($list.Count -eq 0) { Write-Output "NO WINDOW matching class=$ClassMatch title=$TitleMatch"; exit 2 }
# prefer visible windows
$vis = @($list | Where-Object { [KeyWin]::IsWindowVisible($_) })
$target = if ($vis.Count -gt 0) { $vis[0] } else { $list[0] }
Write-Output ("target hwnd={0} class={1} title={2} visible={3}" -f $target, [KeyWin]::C($target), [KeyWin]::T($target), [KeyWin]::IsWindowVisible($target))
if ($Keys) {
    [void][KeyWin]::ShowWindow($target, 5)   # SW_SHOW
    [void][KeyWin]::BringWindowToTop($target)
    # attach input threads to allow reliable foreground switch
    $fg = [KeyWin]::GetForegroundWindow()
    $fgPid = 0; $fgTid = 0
    if ($fg -ne [IntPtr]::Zero) { $fgTid = [KeyWin]::GetWindowThreadProcessId($fg, [ref]$fgPid) }
    $tgtPid = 0; $tgtTid = [KeyWin]::GetWindowThreadProcessId($target, [ref]$tgtPid)
    $curTid = [KeyWin]::GetCurrentThreadId()
    if ($fgTid -ne 0) { [void][KeyWin]::AttachThreadInput($curTid, $fgTid, $true) }
    if ($tgtTid -ne 0) { [void][KeyWin]::AttachThreadInput($curTid, $tgtTid, $true) }
    [void][KeyWin]::SetForegroundWindow($target)
    [void][KeyWin]::SetFocus($target)
    Start-Sleep -Milliseconds 300
    $ws = New-Object -ComObject WScript.Shell
    $ws.SendKeys($Keys)
    Start-Sleep -Milliseconds $WaitMs
    if ($fgTid -ne 0) { [void][KeyWin]::AttachThreadInput($curTid, $fgTid, $false) }
    if ($tgtTid -ne 0) { [void][KeyWin]::AttachThreadInput($curTid, $tgtTid, $false) }
    Write-Output ("sent keys: {0}" -f $Keys)
}
