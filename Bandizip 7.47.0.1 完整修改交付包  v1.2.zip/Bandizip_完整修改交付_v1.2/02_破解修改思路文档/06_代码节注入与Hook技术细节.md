# 06 代码节注入与 Hook 技术细节

> 本章说明补丁工具如何在 PE 文件中"凭空"加入可执行代码、挂入口 Hook，
> 以及为什么这种方式对 ASLR/CFG/未来版本比较友好。对应源码：
> `01_交付包\patch_bandizip.py` 中的 `PE`、`CodeBuffer`、`Patcher`,
> `add_section()`、`get_import_iat()`。

## 6.1 为什么需要注入代码

有些补丁不是简单改几个字节能完成的，例如：

- 关于页要"隐藏更新控件 15 并跳过版本检查"——需要在函数入口执行一段
  新逻辑（取控件、ShowWindow、返回 0）；
- 广告模式要"先调 app 单例、再写 [rax+0xD4]=0、再返回"；
- 取消注册菜单要"弹 MessageBox 提示后返回"。

这些逻辑无法塞进原函数空间，因此采用标准做法：
**在文件末尾新增一个可执行节，把机器码放进去，原函数入口用 E9 跳过去。**

## 6.2 新增节（.bzp）的步骤

`add_section(pe, name, content, chars=0x60000020)`：

1. 计算 RVA = 当前 `SizeOfImage`（新节不会与已有映射冲突）；
   7.47 中为 0x361000；
2. 计算文件偏移 raw = 最后一节 `raw + align_up(last.rsz, FileAlignment)`；
   7.47 中最后一节 `.reloc`：raw 0x34B600 + rsz 0x2400 = 0x34DA00；
3. 在节表末尾（`SectionHeader` 表 + NumberOfSections*40）写新节表项：
   名称 `.bzp`、VirtualSize=代码长度、VirtualAddress=步骤 1 的 RVA、
   SizeOfRawData=对齐后长度、PointerToRawData=步骤 2 的偏移、
   Characteristics=0x60000020（`CNT_CODE | MEM_EXECUTE | MEM_READ`）；
4. `NumberOfSections += 1`、`SizeOfImage = align_up(RVA + vsize, SectionAlignment)`；
   7.47 中 0x361000 → 0x362000；
5. 把代码字节写入 raw 位置。

注意事项：

- 节表增长需要 SizeOfHeaders 足够（本程序 SizeOfHeaders=0x400，节表末尾还有空间）；
- 原文件在 0x34DA00 之后是 Authenticode 签名 overlay，新节前 0x200 字节
  （SizeOfRawData）会覆盖签名开头部分——签名本来就因修改而失效，不影响运行；
  还原时整文件从备份恢复，签名也恢复原样；
- 不需要新增 `.reloc` 重定位项（见 6.4）。

## 6.3 入口 Hook（E9 rel32）

`Patcher.hook_ret_zero(desc, ea)` / `p.hooks.append((desc, ea, cave_name))`：

- 在函数入口 `ea` 处写 5 字节 `E9 <rel32>`，目标为 cave 代码地址；
- rel32 = 目标 - (ea + 5)，范围 ±2GB（本程序 .text 与新节都在同一映像内，必然满足）；
- 被覆盖的原入口前 5 字节不保存，因为 cave 代码里**不执行原函数逻辑**
  （我们的 hook 目的都是"替代/提前返回"，不是"执行原逻辑后继续"）；
- 需要"执行原逻辑一部分"的场景（如广告模式），cave 里**手工复制**原函数
  第一条语义（`mov [rax+0xD4],0` 与 app getter 调用），不依赖原函数。

## 6.4 地址无关性（RIP 相对 + 无重定位）

cave 代码中的跨模块引用全部用 RIP 相对寻址：

| 需求 | 编码 | 说明 |
|---|---|---|
| 调 IAT 函数 | `FF 15 <disp32>`（`call qword ptr [rip+disp]`） | disp32 由目标 IAT 地址 - (指令地址+6) 计算；IAT 地址随 ASLR 整体平移，RIP 相对差值不变 |
| 调本映像函数 | `E8 <disp32>`（相对 call） | 如 ad_zero 里 call app getter（0x140131030） |
| 取字符串地址 | `48 8D 15 <disp32>`（lea rdx, [rip+disp]） | 数据直接放在 cave 块内，disp 按块内偏移计算 |

因此：**新节不需要重定位表项**，加载时无需修正；
`DllCharacteristics` 中的 CFG（Control Flow Guard）只检查"通过函数指针的间接调用"，
而 `call [rip+IAT]` 是直接间接调用导入表槽位，不走 CFG 校验，
自建节没有 CFG 函数表也不影响。

## 6.5 CodeBuffer 与确定性生成

`CodeBuffer(base)` 是一个"相对 base 生成机器码"的小汇编器：

- `db('55 48 8B E9')`：直接写字节；
- `call(target)` / `jmp(target)`：生成 E8/E9 + rel32（target 为绝对 EA）；
- `rip_call_ptr(iat_ea)`：生成 `FF 15 disp32`；
- `rel32(op, target)`：通用相对跳转/调用。

`Patcher.commit()` 的流程保证**长度与基址无关**：

1. 先对每个 cave 块用 `gen(0)` 生成一遍，得到每块长度并据此分配
   cave 内各块起始地址（隐藏块的基址不影响长度）；
2. 再用真实基址生成最终字节，写入 `.bzp` 节；
3. 最后安装所有 E9 hook。

这样 hook 距离检查、块内 lea disp 修正都在最终基址下完成，结果稳定可复现
（同一原始文件 → 同一补丁文件 → 固定 SHA256）。

## 6.6 字节补丁与原子写入

- 纯字节替换（不需要新代码）的补丁用 `Patcher.write_bytes(desc, ea, new, expect)`：
  先校验 `expect`（原字节），不匹配就抛错整体放弃，避免"打歪"；
- 所有修改都在内存 `bytearray` 中完成后统一落盘：
  先写临时文件、再 `os.replace()` 原子替换，避免写一半损坏安装；
- 修改前把原始文件复制到 `_patch_backup`（每次 apply 覆盖写入，
  保证备份始终是"当前版本未打补丁"的官方文件）。

## 6.7 失败保护

`patch_bandizip()` 中每个定位步骤都做严格校验：

- 特征命中数必须为 1（或预期数量），否则抛 `PatchError`；
- 定位到函数后用 `.pdata` 边界/字符串内容二次校验（如 STD 字符串必须真为 "STD"）；
- 任意一步失败 → 整个 apply 中止，不写任何文件、不改任何字节。

这保证官方大改版时不会产出半成品（宁可"打不上"，也不"打坏"）。

## 6.8 与"未来更新"的关系

- 官方安装包升级会**整文件覆盖** Bandizip.exe / Updater.exe / langs，
  新节和所有补丁随之消失，程序回到官方状态；
- 重跑本工具会重新按特征码定位、重新新增 `.bzp` 节，
  不依赖旧文件残留，也不会累积（幂等：已有 `.bzp` 则跳过）；
- 还原使用 `_patch_backup` 中的官方原始文件，字节级一致。
