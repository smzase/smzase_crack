@echo off
chcp 65001 >nul
setlocal EnableExtensions
set "TARGET=%~1"
if not defined TARGET set "TARGET=C:\Program Files\Bandizip"
if defined TARGET for %%I in ("%TARGET%") do set "TARGET=%%~fI"
pushd "%~dp0"
set "PY="
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
    echo [错误] 未找到 Python 3。
    goto :done
)
%PY% "%~dp0patch_bandizip.py" --check "%TARGET%"
:done
echo.
if not defined BZP_NOPAUSE pause
popd
exit /b
