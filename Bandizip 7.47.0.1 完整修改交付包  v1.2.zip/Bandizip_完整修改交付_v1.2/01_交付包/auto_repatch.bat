@echo off
rem 由计划任务在登录时调用: 若 Bandizip 被官方安装包覆盖, 自动重新打补丁。
rem 已打过补丁时会快速跳过, 不会重复修改。
setlocal EnableExtensions
cd /d "%~dp0"
set "TARGET=C:\Program Files\Bandizip"
set "LOG=%~dp0auto_repatch.log"
if not exist "%TARGET%\Bandizip.exe" goto :eof
set "PY="
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)
if not defined PY goto :eof
echo [%date% %time%] 检查/重打 Bandizip 补丁 >> "%LOG%"
%PY% "%~dp0patch_bandizip.py" --apply "%TARGET%" >> "%LOG%" 2>&1
exit /b
