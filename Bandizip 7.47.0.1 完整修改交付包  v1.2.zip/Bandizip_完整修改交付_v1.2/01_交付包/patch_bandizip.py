#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bandizip "去更新 / 去广告 / 专业版" 二进制补丁工具
支持版本: Bandizip 7.47.0.1 (build 71912) 及结构相近的后续版本
用途: 使 Bandizip 显示为已注册 Professional 版(无广告、无功能限制),
      彻底禁用内置自动更新与更新检查(含更新弹窗), 仅可通过官方安装包更新。

用法:
  python patch_bandizip.py --check  [安装目录]
  python patch_bandizip.py --apply  [安装目录]
  python patch_bandizip.py --revert [安装目录]
  python patch_bandizip.py --status [安装目录]

说明:
  * 修改前会自动备份原始文件到  <安装目录>\\_patch_backup\\
  * 所有补丁均按特征码/字符串引用定位函数, 不依赖固定文件偏移, 便于适配官方新版本
  * 若某个必需特征在当前版本中找不到, 脚本会整体放弃修改并给出报告(不会写出半成品)
"""
import os
import re
import struct
import sys
import shutil
import hashlib
import subprocess

BANDIZIP_EXE = 'Bandizip.exe'
UPDATER_EXE = 'Updater.exe'
BACKUP_DIR = '_patch_backup'
TOOL_VERSION = '1.2'

# 关于对话框里 "Bandizip 的使用权授予" 的替换文案(写入 langs/*.lang 的 TEXT_REGISTER_INFO)
LANG_TEXT_SIMP = 'Bandizip Professional（已注册）[br]本机已获得完整专业版功能授权。'
LANG_TEXT_TRAD = 'Bandizip Professional（已註冊）[br]本機已獲得完整專業版功能授權。'
LANG_TEXT_EN = 'Bandizip Professional (Registered)[br]This PC is licensed for all Professional features.'
LANG_REPLACED_MARKERS = ('已获得完整专业版功能授权', '已獲得完整專業版功能授權',
                         'licensed for all Professional features')

# 点击 "取消注册 Bandizip" 菜单时弹出的提示(程序显示为已注册专业版, 不允许退订)
UNREG_NOTICE_TITLE = 'Bandizip'
UNREG_NOTICE_TEXT = ('本机安装的 Bandizip 已是 Professional 已注册版。\n'
                     '无需再进行注册或取消注册操作。')

# ---------------------------------------------------------------- PE 基础类

class PE:
    def __init__(self, path):
        self.path = path
        self.data = bytearray(open(path, 'rb').read())
        d = self.data
        self.e_lfanew = struct.unpack_from('<I', d, 0x3C)[0]
        if d[self.e_lfanew:self.e_lfanew + 4] != b'PE\0\0':
            raise ValueError('不是有效的 PE 文件: %s' % path)
        fh = self.e_lfanew + 4
        self.numsec = struct.unpack_from('<H', d, fh + 2)[0]
        self.opt = fh + 20
        magic = struct.unpack_from('<H', d, self.opt)[0]
        if magic != 0x20b:
            raise ValueError('不是 64 位 PE 文件: %s' % path)
        self.entry_rva = struct.unpack_from('<I', d, self.opt + 16)[0]
        self.image_base = struct.unpack_from('<Q', d, self.opt + 24)[0]
        self.sect_align = struct.unpack_from('<I', d, self.opt + 32)[0]
        self.file_align = struct.unpack_from('<I', d, self.opt + 36)[0]
        self.size_image = struct.unpack_from('<I', d, self.opt + 56)[0]
        self.size_headers = struct.unpack_from('<I', d, self.opt + 60)[0]
        self.sect_tab = self.opt + struct.unpack_from('<H', d, fh + 16)[0]
        self.sections = []
        for i in range(self.numsec):
            o = self.sect_tab + i * 40
            name = d[o:o + 8].rstrip(b'\0').decode('latin1')
            vsz, va, rsz, raw = struct.unpack_from('<IIII', d, o + 8)
            chars = struct.unpack_from('<I', d, o + 36)[0]
            self.sections.append(dict(name=name, vsz=vsz, va=va, rsz=rsz,
                                      raw=raw, chars=chars, hdr=o))
        self.pdata = []
        for s in self.sections:
            if s['name'] == '.pdata':
                n = s['vsz'] // 12
                off = s['raw']
                for i in range(n):
                    b, e, u = struct.unpack_from('<III', d, off + i * 12)
                    if b:
                        self.pdata.append((self.image_base + b, self.image_base + e, u))
                self.pdata.sort()
                break

    # -- 地址换算 --
    def sec_of_rva(self, rva):
        for s in self.sections:
            if s['va'] <= rva < s['va'] + max(s['vsz'], s['rsz']):
                return s
        return None

    def rva2off(self, rva):
        s = self.sec_of_rva(rva)
        if not s:
            raise ValueError('RVA %X 不在任何节中' % rva)
        return s['raw'] + (rva - s['va'])

    def ea2off(self, ea):
        return self.rva2off(ea - self.image_base)

    def off2ea(self, off):
        for s in self.sections:
            if s['raw'] <= off < s['raw'] + s['rsz']:
                return self.image_base + s['va'] + (off - s['raw'])
        return None

    def read(self, ea, n):
        return bytes(self.data[self.ea2off(ea):self.ea2off(ea) + n])

    def write(self, ea, b):
        o = self.ea2off(ea)
        old = bytes(self.data[o:o + len(b)])
        self.data[o:o + len(b)] = b
        return old

    def save(self, path):
        open(path, 'wb').write(bytes(self.data))

    # -- 搜索 --
    def find_bytes(self, pat, mask=None):
        d = self.data
        n = len(pat)
        if mask is None:
            mask = b'\xff' * n
        out = []
        first = pat[0]
        i = 0
        while True:
            i = d.find(bytes([first]), i)
            if i < 0 or i + n > len(d):
                break
            ok = True
            for k in range(1, n):
                if mask[k] and d[i + k] != pat[k]:
                    ok = False
                    break
            if ok:
                out.append(i)
            i += 1
        return out

    def find_pat(self, hexpat):
        """hexpat: '48 8B ?? 12' """
        parts = hexpat.split()
        pat = bytearray()
        mask = bytearray()
        for p in parts:
            if p in ('??', '?'):
                pat.append(0)
                mask.append(0)
            else:
                pat.append(int(p, 16))
                mask.append(1)
        res = []
        for off in self.find_bytes(bytes(pat), bytes(mask)):
            ea = self.off2ea(off)
            if ea is not None:
                res.append(ea)
        return res

    # -- 函数与引用 --
    def func_of(self, ea):
        for b, e, u in self.pdata:
            if b <= ea < e:
                return b, e
        return None

    def refs_to_many(self, targets):
        """一次性扫描 .text, 找出所有 RIP 相对寻址(target 出现在指令末尾 disp32)的引用位置.
        返回 {target_ea: [引用指令的结束地址 EA...]}
        原理: x64 中 RIP 相对 disp32 一定位于指令末尾, 因此 4 字节窗口 p 的解码值
              必须等于 target - (p+4). 对随机数据该等式成立概率约 2^-32, 无噪声."""
        out = {t: [] for t in targets}
        tbl = set(targets)
        d = self.data
        for s in self.sections:
            if s['name'] != '.text':
                continue
            start = s['raw']
            n = s['vsz']
            base = self.image_base + s['va']
            unpack = struct.unpack_from
            for q in range(0, n - 3):
                cand = unpack('<I', d, start + q)[0] + base + q + 4
                if cand in tbl:
                    out[cand].append(base + q + 4)
        return out

    def find_wide(self, text):
        pat = text.encode('utf-16le') + b'\x00\x00'
        out = []
        i = 0
        while True:
            i = bytes(self.data).find(pat, i)
            if i < 0:
                break
            ea = self.off2ea(i)
            if ea is not None:
                out.append(ea)
            i += 1
        return out

    def funcs_referencing(self, *texts):
        """返回引用任一给定宽字符串的函数 [(start, end), ...]"""
        all_refs = self.refs_to_many([]) if False else None
        targets = []
        for t in texts:
            targets.extend(self.find_wide(t))
        if not targets:
            return []
        refmap = self.refs_to_many(targets)
        res = []
        for t in targets:
            for ref_end in refmap.get(t, []):
                f = self.func_of(ref_end - 1)
                if f and f[0] not in [r[0] for r in res]:
                    res.append(f)
        return res


# ---------------------------------------------------------------- 汇编小工具

class CodeBuffer:
    def __init__(self, base_ea):
        self.base = base_ea
        self.buf = bytearray()

    def ea(self):
        return self.base + len(self.buf)

    def db(self, *args):
        for a in args:
            if isinstance(a, int):
                self.buf.append(a)
            elif isinstance(a, str):
                self.buf += bytes.fromhex(a)
            else:
                self.buf += bytes(a)

    def rel32(self, op, target):
        """op 为 1 字节操作码(如 E8/E9), 生成 op + rel32"""
        here = self.ea()
        self.buf.append(op)
        self.buf += struct.pack('<i', target - (here + 5))

    def call(self, target):
        self.rel32(0xE8, target)

    def jmp(self, target):
        self.rel32(0xE9, target)

    def rip_call_ptr(self, iat_ea):
        """FF 15 [rip+disp]  -> call qword ptr [iat_ea]"""
        here = self.ea()
        self.buf += b'\xFF\x15'
        self.buf += struct.pack('<i', iat_ea - (here + 6))


# ---------------------------------------------------------------- 补丁描述

class PatchError(Exception):
    pass


def find_section_space(pe, size):
    new_rva = pe.size_image
    new_vsz = size
    align = pe.file_align
    last_raw_end = max(s['raw'] + s['rsz'] for s in pe.sections)
    new_raw = (last_raw_end + align - 1) & ~(align - 1)
    new_rsz = (new_vsz + align - 1) & ~(align - 1)
    hdr_off = pe.sect_tab + pe.numsec * 40
    if hdr_off + 40 > pe.size_headers:
        raise PatchError('PE 头空间不足, 无法添加新节')
    return new_rva, new_raw, new_vsz, new_rsz, hdr_off


def add_section(pe, name, content, chars=0x60000020):
    new_rva, new_raw, new_vsz, new_rsz, hdr_off = find_section_space(pe, len(content))
    hdr = bytearray(40)
    hdr[0:len(name)] = name.encode()
    struct.pack_into('<IIII', hdr, 8, new_vsz, new_rva, new_rsz, new_raw)
    struct.pack_into('<I', hdr, 36, chars)
    pe.data[hdr_off:hdr_off + 40] = hdr
    if new_raw + new_rsz > len(pe.data):
        pe.data.extend(b'\x00' * (new_raw + new_rsz - len(pe.data)))
    pe.data[new_raw:new_raw + len(content)] = content
    struct.pack_into('<H', pe.data, pe.e_lfanew + 4 + 2, pe.numsec + 1)
    new_size = new_rva + ((new_vsz + pe.sect_align - 1) & ~(pe.sect_align - 1))
    struct.pack_into('<I', pe.data, pe.opt + 56, new_size)
    pe.numsec += 1
    pe.sections.append(dict(name=name, vsz=new_vsz, va=new_rva, rsz=new_rsz,
                            raw=new_raw, chars=chars, hdr=hdr_off))
    return pe.image_base + new_rva


def get_import_iat(pe, dllname, funcname):
    d = pe.data
    imp_rva, imp_size = struct.unpack_from('<II', d, pe.opt + 120)
    if not imp_rva:
        raise PatchError('无导入表')
    off = pe.rva2off(imp_rva)
    while True:
        oft_rva, ts, fwd, name_rva, ft_rva = struct.unpack_from('<IIIII', d, off)
        if name_rva == 0:
            break
        dll = d[pe.rva2off(name_rva):].split(b'\x00', 1)[0].decode('latin1')
        if dll.lower() == dllname.lower():
            t = oft_rva if oft_rva else ft_rva
            ftr = ft_rva
            while True:
                ent = struct.unpack_from('<Q', d, pe.rva2off(t))[0]
                if ent == 0:
                    break
                if not (ent & 0x8000000000000000):
                    nm = d[pe.rva2off(ent & 0x7FFFFFFF) + 2:].split(b'\x00', 1)[0].decode('latin1')
                    if nm == funcname:
                        return pe.image_base + ftr
                t += 8
                ftr += 8
        off += 20
    raise PatchError('导入函数 %s!%s 未找到' % (dllname, funcname))


# ---------------------------------------------------------------- 补丁计划

class Patcher:
    def __init__(self, exe_path):
        self.path = exe_path
        self.pe = PE(exe_path)
        self.actions = []          # (描述, callable)
        self.results = []          # (描述, ok, msg)
        self.cave_blocks = []      # (name, assembler-callable producing bytes)
        self.hooks = []            # (desc, ea, cave_name)

    # ------------- 常用操作 -------------
    def ret_zero(self, desc, ea):
        old = self.pe.read(ea, 5)
        self.actions.append((desc, lambda: self.pe.write(ea, b'\x33\xC0\xC3\x90\x90')))
        return 'EA=%X 原字节=%s' % (ea, old.hex(' '))

    def write_bytes(self, desc, ea, new, expect=None):
        old = self.pe.read(ea, len(new))
        if expect is not None and old != expect:
            raise PatchError('%s: 期望字节 %s, 实际 %s (EA=%X)' %
                             (desc, expect.hex(' '), old.hex(' '), ea))
        self.actions.append((desc, lambda: self.pe.write(ea, new)))
        return 'EA=%X 原字节=%s -> %s' % (ea, old.hex(' '), new.hex(' '))

    def hook_ret_zero(self, desc, ea):
        """函数入口改为 ret 0"""
        return self.ret_zero(desc, ea)

    # ------------- 内部: 应用 -------------
    def commit(self):
        out = []
        for desc, fn in self.actions:
            fn()
            out.append('  [OK] ' + desc)
        # 新节 (代码洞)
        if self.cave_blocks:
            cave_base = self.pe.image_base + self.pe.size_image
            # 长度与基址无关(全部为定长编码), 先求各块长度
            sizes = [len(gen(cave_base)) for name, gen in self.cave_blocks]
            addrs = {}
            off = 0
            for (name, gen), sz in zip(self.cave_blocks, sizes):
                addrs[name] = cave_base + off
                off += sz
            buf = bytearray()
            for name, gen in self.cave_blocks:
                buf += gen(addrs[name])
            add_section(self.pe, '.bzp', bytes(buf))
            out.append('  [OK] 新增代码节 .bzp, RVA=%X, 大小=%d' %
                       (self.pe.size_image - ((len(buf) + self.pe.sect_align - 1) & ~(self.pe.sect_align - 1)), len(buf)))
            # 安置入口 hook
            for desc, ea, cave_name in self.hooks:
                tgt = addrs[cave_name]
                old = self.pe.read(ea, 5)
                disp = tgt - (ea + 5)
                if not (-0x80000000 <= disp < 0x80000000):
                    raise PatchError('hook 距离过远: %s' % desc)
                self.pe.write(ea, b'\xE9' + struct.pack('<i', disp))
                out.append('  [OK] %s (EA=%X -> cave %s@%X, 原字节=%s)' %
                           (desc, ea, cave_name, tgt, old.hex(' ')))
        return out

    def save(self, path):
        self.pe.save(path)


# ---------------------------------------------------------------- 主补丁逻辑

def patch_bandizip(exe_path, log):
    p = Patcher(exe_path)
    pe = p.pe
    info = []

    # ---------- 通用定位 ----------
    def app_getter(func_start=None, func_end=None):
        """定位 app 单例获取函数 sub_140131030: 特征为
           call 设置单例; mov rbx,rax; call <app getter>; mov edx,[rax+120h]"""
        hits = pe.find_pat('E8 ?? ?? ?? ?? 48 8B D8 E8 ?? ?? ?? ?? 8B 90 20 01 00 00')
        if func_start is not None:
            hits = [h for h in hits if func_start <= h < func_end]
        if not hits:
            raise PatchError('app 单例获取函数特征未找到')
        call_ea = hits[0] + 8          # 第二个 call (app getter)
        disp = struct.unpack('<i', pe.read(call_ea + 1, 4))[0]
        return call_ea + 5 + disp

    # ---------- 1. 许可证: 强制 Professional ----------
    # 未注册时进入 "STD" 回退分支: call ...; mov r8d,3; lea rdx,"STD"; lea rcx,[rax+0C0h];
    # call sub_140018F50; mov dword ptr [rsi+120h],98h
    hits = pe.find_pat('E8 ?? ?? ?? ?? 41 B8 03 00 00 00 48 8D 15 ?? ?? ?? ?? '
                       '48 8D 88 C0 00 00 00 E8 ?? ?? ?? ?? '
                       'C7 86 20 01 00 00 98 00 00 00')
    if len(hits) != 1:
        raise PatchError('许可证 STD 回退分支特征不唯一 (%d)' % len(hits))
    blk = hits[0]
    lea_ea = blk + 11              # call(5) + mov r8d(6)
    std_str = lea_ea + 7 + struct.unpack('<i', pe.read(lea_ea + 3, 4))[0]
    if read_wide(pe, std_str) != 'STD':
        raise PatchError('STD 字符串定位失败 (EA=%X)' % std_str)
    # 在附近找 PRO 比较分支使用的 "PRO" 宽字符串
    pro_str = None
    for ea in range(lea_ea - 0x300, lea_ea + 0x100, 1):
        try:
            b = pe.read(ea, 7)
        except Exception:
            continue
        if b[:3] == b'\x4C\x8D\x05':
            t = ea + 7 + struct.unpack('<i', b[3:])[0]
            if read_wide(pe, t) == 'PRO':
                pro_str = t
                break
    if pro_str is None:
        # 退而求其次: 全文件找唯一的 "PRO" 宽字符串
        cand = [x for x in pe.find_wide('PRO')]
        if len(cand) != 1:
            raise PatchError('PRO 字符串定位失败')
        pro_str = cand[0]
    new_disp = pro_str - (lea_ea + 7)
    info.append(p.write_bytes('许可证[1] STD 回退字样 -> PRO', lea_ea + 3,
                              struct.pack('<i', new_disp)))
    imm_ea = blk + 36
    info.append(p.write_bytes('许可证[2] 版本代码 152 -> 980 (Professional)', imm_ea,
                              struct.pack('<I', 980), expect=b'\x98\x00\x00\x00'))

    # ---------- 2. 禁用许可证在线校验/回退 ----------
    hits = pe.find_pat('C7 80 20 01 00 00 98 00 00 00')
    if len(hits) != 1:
        raise PatchError('许可证在线校验回退点特征不唯一 (%d)' % len(hits))
    f = pe.func_of(hits[0])
    if not f:
        raise PatchError('无法定位许可证在线校验函数')
    info.append(p.hook_ret_zero('禁用许可证在线校验(含回退 STD)', f[0]))

    # ---------- 3. 禁用 updater.exe 启动 ----------
    launchers = pe.funcs_referencing('updater.exe')
    # 只保留真正启动 updater 的函数(引用 updater.exe 的函数)
    if not launchers:
        raise PatchError('未找到 updater.exe 启动函数')
    for i, (fa, fe) in enumerate(launchers):
        info.append(p.hook_ret_zero('禁用 updater.exe 启动函数 #%d' % (i + 1), fa))

    # ---------- 4. 关于对话框: 隐藏更新栏并禁用版本检查 ----------
    try:
        getdlg = get_import_iat(pe, 'USER32.dll', 'GetDlgItem')
        showwnd = get_import_iat(pe, 'USER32.dll', 'ShowWindow')
    except PatchError:
        getdlg = showwnd = None
    check_funcs = pe.funcs_referencing('TEXT_UPDATE_VERSION_CHECKING')
    if not check_funcs:
        raise PatchError('未找到版本检查函数')
    check_ea = check_funcs[0][0]
    if getdlg and showwnd:
        def gen_hide_update(base):
            c = CodeBuffer(base)
            c.db('55')                      # push rbp
            c.db('48 8B E9')                # mov rbp, rcx
            c.db('48 8B 4D 08')             # mov rcx, [rbp+8]
            c.db('BA 0F 00 00 00')          # mov edx, 15
            c.rip_call_ptr(getdlg)           # call [GetDlgItem]
            c.db('48 85 C0')                # test rax,rax
            jz_pos = len(c.buf)
            c.db('74 00')                   # jz rel8 (fixup)
            c.db('48 8B C8')                # mov rcx, rax
            c.db('33 D2')                   # xor edx, edx
            c.rip_call_ptr(showwnd)          # call [ShowWindow]
            c.buf[jz_pos + 1] = len(c.buf) - (jz_pos + 2)
            c.db('33 C0 5D C3')             # xor eax,eax; pop rbp; ret
            return c.buf
        p.cave_blocks.append(('hide_update', gen_hide_update))
        p.hooks.append(('关于对话框: 隐藏更新栏并禁用版本检查', check_ea, 'hide_update'))
    else:
        info.append(p.hook_ret_zero('关于对话框: 禁用版本检查', check_ea))

    # ---------- 5. 禁止下载/安装更新 ----------
    for anchor, desc in [('StartSetupDownload - url:%s', '禁止启动更新安装包下载'),
                         ('TEXT_UPDATE_DO_DOWNLOAD', '禁止更新下载/安装流程')]:
        fs = pe.funcs_referencing(anchor)
        if not fs:
            raise PatchError('未找到更新下载函数(%s)' % anchor)
        info.append(p.hook_ret_zero(desc, fs[0][0]))

    # ---------- 6. 主窗口更新图标永远隐藏 ----------
    fs = pe.funcs_referencing('STATIC_UPDATE')
    if not fs:
        raise PatchError('未找到更新图标控制函数')
    uf = fs[0][0]
    pat_hits = pe.find_pat('48 8B 8D ?? ?? ?? ?? 44 0F B6 C7')
    pat_hits = [x for x in pat_hits if uf <= x < fs[0][1]]
    if len(pat_hits) == 1:
        ea = pat_hits[0] + 7
        info.append(p.write_bytes('更新图标可见性恒为隐藏', ea, bytes.fromhex('45 31 C0 90')))
    else:
        allc = [x for x in pe.find_pat('44 0F B6 C7') if uf <= x < fs[0][1]]
        if not allc:
            raise PatchError('未找到更新图标可见性指令')
        ea = allc[-1]
        info.append(p.write_bytes('更新图标可见性恒为隐藏(fallback)', ea,
                                  bytes.fromhex('45 31 C0 90')))

    # ---------- 7. 广告: 弹出广告窗口 ----------
    for anchor, desc in [('LaunchPopupAdWindow', '禁用弹出式广告窗口'),
                         ('MgSDKCSharpDLL.dll', '禁用网页内嵌广告主程序')]:
        fs2 = pe.funcs_referencing(anchor)
        if not fs2:
            raise PatchError('未找到广告函数(%s)' % anchor)
        info.append(p.hook_ret_zero(desc, fs2[0][0]))

    # ---------- 8. 广告模式强制为 0 ----------
    hits = pe.find_pat('C7 80 D4 00 00 00 00 00 00 00')
    if len(hits) == 1:
        f = pe.func_of(hits[0])
        if f:
            try:
                app_get_ea = app_getter(uf, fs[0][1])
                def gen_adzero(base):
                    c = CodeBuffer(base)
                    c.db('48 83 EC 28')         # sub rsp,28h
                    c.call(app_get_ea)           # call 取 app 单例
                    c.db('C7 80 D4 00 00 00 00 00 00 00')
                    c.db('33 C0')                # xor eax,eax
                    c.db('48 83 C4 28 C3')       # add rsp,28h; ret
                    return c.buf
                p.cave_blocks.append(('ad_zero', gen_adzero))
                p.hooks.append(('广告模式强制为 0 (无广告)', f[0], 'ad_zero'))
                info.append('广告模式函数 EA=%X (app 单例获取 EA=%X)' % (f[0], app_get_ea))
            except PatchError as ex:
                info.append('跳过广告模式补丁: %s' % ex)
        else:
            info.append('跳过广告模式补丁: 无法定位函数')
    else:
        info.append('跳过广告模式补丁: 特征数=%d' % len(hits))

    # ---------- 9. 注册/取消注册菜单动作 ----------
    # 菜单处理函数同时引用 "/unregLicense" 与 "TEXT_REGISTRATION_ASK";
    # 注意程序中另有大型命令分发函数也引用 /unregLicense, 不能误伤
    unreg = pe.funcs_referencing('/unregLicense')
    ask = pe.funcs_referencing('TEXT_REGISTRATION_ASK')
    ask_starts = set(f[0] for f in ask)
    reg_menu = [f for f in unreg if f[0] in ask_starts]
    if not reg_menu:
        raise PatchError('未找到注册/取消注册菜单处理函数')
    try:
        msgbox = get_import_iat(pe, 'USER32.dll', 'MessageBoxW')
    except PatchError:
        msgbox = None
    for fa, fe in reg_menu:
        if msgbox:
            def gen_unreg_notice(base, _msgbox=msgbox):
                """弹信息框告知已注册, 然后返回 0"""
                c = CodeBuffer(base)
                c.db('48 83 EC 28')                     # sub rsp,28h
                c.db('33 C9')                           # xor ecx,ecx (hwnd=NULL)
                pos_rdx = len(c.buf)
                c.db('48 8D 15 00 00 00 00')            # lea rdx,[rip+正文]
                pos_r8 = len(c.buf)
                c.db('4C 8D 05 00 00 00 00')            # lea r8,[rip+标题]
                c.db('41 B9 40 00 00 00')               # mov r9d, 0x40 (MB_ICONINFORMATION)
                c.rip_call_ptr(_msgbox)                 # call [MessageBoxW]
                c.db('33 C0')                           # xor eax,eax
                c.db('48 83 C4 28 C3')                  # add rsp,28h; ret
                off_text = len(c.buf)
                c.db(UNREG_NOTICE_TEXT.encode('utf-16-le') + b'\x00\x00')
                off_title = len(c.buf)
                c.db(UNREG_NOTICE_TITLE.encode('utf-16-le') + b'\x00\x00')
                for pos, tgt in ((pos_rdx, off_text), (pos_r8, off_title)):
                    struct.pack_into('<i', c.buf, pos + 3, tgt - (pos + 7))
                return c.buf
            cave_name = 'unreg_notice_%X' % fa
            p.cave_blocks.append((cave_name, gen_unreg_notice))
            p.hooks.append(('注册/取消注册菜单: 弹出"已注册"提示', fa, cave_name))
            info.append('注册/取消注册菜单: 改为弹出已注册提示 EA=%X' % fa)
        else:
            info.append(p.hook_ret_zero('注册/取消注册菜单命令无效化 EA=%X' % fa, fa))
    fs = pe.funcs_referencing('TEXT_REGISTRATION_SUCCEED')
    for fa, fe in fs:
        info.append(p.hook_ret_zero('禁用注册对话框 EA=%X' % fa, fa))

    return p, info


def read_wide(pe, ea):
    out = []
    i = ea
    while True:
        try:
            w = pe.read(i, 2)
        except Exception:
            break
        if w == b'\x00\x00':
            break
        out.append(w.decode('utf-16le', 'replace'))
        i += 2
        if len(out) > 64:
            break
    return ''.join(out)


def patch_updater(exe_path, log):
    """Updater.exe: 入口点直接 ExitProcess(0), 任何方式启动都静默退出"""
    pe = PE(exe_path)
    ep = pe.image_base + pe.entry_rva
    try:
        exit_iat = get_import_iat(pe, 'KERNEL32.dll', 'ExitProcess')
    except PatchError:
        exit_iat = None
    if exit_iat:
        code = bytearray()
        code += b'\x33\xC9'                       # xor ecx, ecx
        here = ep + len(code)
        code += b'\xFF\x25' + struct.pack('<i', exit_iat - (here + 6))  # jmp [ExitProcess]
        old = pe.read(ep, len(code))
        pe.write(ep, bytes(code))
        pe.save(exe_path)
        return ['入口点 EA=%X 原字节=%s -> ExitProcess(0)' % (ep, old.hex(' '))]
    else:
        old = pe.read(ep, 3)
        pe.write(ep, b'\x31\xC0\xC3')
        pe.save(exe_path)
        return ['入口点 EA=%X 原字节=%s -> ret 0' % (ep, old.hex(' '))]


def lang_replacement(filename):
    n = filename.lower()
    if n == 'simpchinese.lang':
        return LANG_TEXT_SIMP
    if n == 'tradchinese.lang':
        return LANG_TEXT_TRAD
    return LANG_TEXT_EN


def langs_already_patched(d):
    langs = os.path.join(d, 'langs')
    if not os.path.isdir(langs):
        return False
    try:
        for fn in os.listdir(langs):
            if fn.lower().endswith('.lang'):
                txt = open(os.path.join(langs, fn), 'rb').read().decode('utf-8', 'replace')
                if any(m in txt for m in LANG_REPLACED_MARKERS):
                    return True
    except Exception:
        return False
    return False


def patch_langs(d, log=None):
    """替换 langs/*.lang 的 TEXT_REGISTER_INFO, 让"关于"对话框显示已注册文案"""
    langs = os.path.join(d, 'langs')
    if not os.path.isdir(langs):
        return []
    out = []
    bdir = os.path.join(backup_dir(d), 'langs')
    for fn in sorted(os.listdir(langs)):
        if not fn.lower().endswith('.lang'):
            continue
        path = os.path.join(langs, fn)
        try:
            text = open(path, 'rb').read().decode('utf-8')
        except UnicodeDecodeError:
            out.append('%s: 非 UTF-8 编码, 跳过' % fn)
            continue
        m = re.search(r'^TEXT_REGISTER_INFO[ \t]*=[^\r\n]*', text, re.M)
        if not m:
            continue
        line = 'TEXT_REGISTER_INFO'.ljust(39) + '= ' + lang_replacement(fn)
        if m.group(0) == line:
            continue
        os.makedirs(bdir, exist_ok=True)
        bpath = os.path.join(bdir, fn + '.orig')
        if not os.path.exists(bpath):
            shutil.copy2(path, bpath)
        text = text[:m.start()] + line + text[m.end():]
        with open(path, 'wb') as f:
            f.write(text.encode('utf-8'))
        out.append('%s: TEXT_REGISTER_INFO 已替换' % fn)
    return out


def revert_langs(d):
    langs = os.path.join(d, 'langs')
    bdir = os.path.join(backup_dir(d), 'langs')
    if not os.path.isdir(bdir):
        return []
    out = []
    for fn in sorted(os.listdir(bdir)):
        if not fn.lower().endswith('.orig'):
            continue
        src = os.path.join(bdir, fn)
        dst = os.path.join(langs, fn[:-5])
        shutil.copy2(src, dst)
        out.append(os.path.basename(dst))
    return out


# ---------------------------------------------------------------- 文件处理

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def find_install_dir(arg):
    if arg:
        return os.path.abspath(arg)
    candidates = [r'C:\Program Files\Bandizip', r'C:\Program Files (x86)\Bandizip']
    for c in candidates:
        if os.path.isfile(os.path.join(c, BANDIZIP_EXE)):
            return c
    raise SystemExit('未找到 Bandizip 安装目录, 请手动指定: python patch_bandizip.py --apply "C:\\Program Files\\Bandizip"')


def is_running(proc='Bandizip.exe'):
    try:
        out = subprocess.check_output(['tasklist', '/FI', 'IMAGENAME eq ' + proc],
                                      stderr=subprocess.DEVNULL, creationflags=0x08000000)
        return proc.lower().encode() in out.lower()
    except Exception:
        return False


def exe_patched(path):
    """判断 Bandizip.exe 是否已应用二进制补丁(存在 .bzp 代码节)"""
    try:
        pe = PE(path)
        return any(s['name'] == '.bzp' for s in pe.sections)
    except Exception:
        return False


def updater_patched(path):
    try:
        pe = PE(path)
        return pe.read(pe.image_base + pe.entry_rva, 3) == b'\x33\xC9\xFF'
    except Exception:
        return False


def backup_dir(d):
    b = os.path.join(d, BACKUP_DIR)
    os.makedirs(b, exist_ok=True)
    return b


def do_apply(d):
    print('Bandizip Pro 补丁工具 v%s' % TOOL_VERSION)
    print('安装目录: %s' % d)
    if is_running():
        raise SystemExit('Bandizip 正在运行, 请先退出后再执行。')
    exe = os.path.join(d, BANDIZIP_EXE)
    upd = os.path.join(d, UPDATER_EXE)
    if not os.path.isfile(exe):
        raise SystemExit('未找到 %s' % exe)
    bd = backup_dir(d)

    already = exe_patched(exe)
    if already:
        print('\nBandizip.exe 已应用过二进制补丁, 跳过 (无需重复修改)。')
        if os.path.isfile(upd) and not updater_patched(upd):
            for name in [UPDATER_EXE]:
                shutil.copy2(os.path.join(d, name), os.path.join(bd, name + '.orig'))
            tmp = upd + '.bzpatch_tmp'
            shutil.copy2(upd, tmp)
            for line in patch_updater(tmp, None):
                print('  ' + line)
            os.replace(tmp, upd)
    else:
        # 备份"打补丁前"的原始文件(覆盖旧备份, 保证 --revert 还原到当前版本的原始状态)
        for name in [BANDIZIP_EXE, UPDATER_EXE]:
            src = os.path.join(d, name)
            if not os.path.isfile(src):
                continue
            dst = os.path.join(bd, name + '.orig')
            shutil.copy2(src, dst)
            print('已备份: %s' % dst)

        # 先在内存中完成 Bandizip.exe 的全部补丁
        print('\n分析 Bandizip.exe ...')
        try:
            p, info = patch_bandizip(exe, None)
        except PatchError as ex:
            raise SystemExit('补丁定位失败, 未做任何修改: %s' % ex)
        for line in info:
            print('  ' + line)
        print('\n应用补丁 ...')
        for line in p.commit():
            print(line)
        tmp = exe + '.bzpatch_tmp'
        p.save(tmp)

        print('\n处理 Updater.exe ...')
        upd_tmp = upd + '.bzpatch_tmp'
        if os.path.isfile(upd):
            shutil.copy2(upd, upd_tmp)
            try:
                for line in patch_updater(upd_tmp, None):
                    print('  ' + line)
            except Exception as ex:
                os.unlink(upd_tmp)
                if os.path.exists(tmp):
                    os.unlink(tmp)
                raise SystemExit('Updater.exe 补丁失败: %s' % ex)
        else:
            upd_tmp = None

        # 原子替换
        os.replace(tmp, exe)
        if upd_tmp:
            os.replace(upd_tmp, upd)

    # 语言文件(关于对话框注册信息文案)
    print('\n处理语言文件 (langs\\*.lang) ...')
    lres = patch_langs(d)
    if lres:
        for line in lres:
            print('  ' + line)
    else:
        print('  语言文件已是最新, 无需修改。')

    # 校验
    print('\n完成。输出校验:')
    print('  %s  SHA256=%s' % (exe, sha256_file(exe)))
    if os.path.isfile(upd):
        print('  %s  SHA256=%s' % (upd, sha256_file(upd)))
    print('\n现在可直接启动 Bandizip: 显示为 Professional 已注册版, 无广告、无更新检查。')
    print('提示: 修改后数字签名失效, 属正常现象; 使用官方安装包更新后, 重新运行本工具即可。')


def do_revert(d):
    exe = os.path.join(d, BANDIZIP_EXE)
    bd = os.path.join(d, BACKUP_DIR)
    if is_running():
        raise SystemExit('Bandizip 正在运行, 请先退出后再执行。')
    done = False
    for name in [BANDIZIP_EXE, UPDATER_EXE]:
        src = os.path.join(bd, name + '.orig')
        dst = os.path.join(d, name)
        if os.path.isfile(src):
            shutil.copy2(src, dst)
            print('已还原: %s' % dst)
            done = True
    names = revert_langs(d)
    if names:
        print('已还原语言文件: %s' % ', '.join(names))
        done = True
    if not done:
        raise SystemExit('未找到备份, 无法还原。请通过官方安装包重新安装。')


def do_check(d):
    exe = os.path.join(d, BANDIZIP_EXE)
    if not os.path.isfile(exe):
        raise SystemExit('未找到 %s' % exe)
    if exe_patched(exe):
        print('Bandizip.exe 已应用过补丁 (.bzp 节存在), 无需再次检查。')
        return
    p, info = patch_bandizip(exe, None)
    print('Bandizip.exe 补丁可行性检查: OK')
    for line in info:
        print('  ' + line)
    if p.cave_blocks:
        print('\n计划新增代码节 .bzp (函数入口 hook):')
        for name, gen in p.cave_blocks:
            print('  %-28s %d 字节' % (name, len(gen(p.pe.image_base))))
    if p.hooks:
        print('\n函数入口跳转:')
        for desc, ea, cave in p.hooks:
            print('  %s EA=%X -> %s' % (desc, ea, cave))
    print('\n语言文件: %s' % ('已替换' if langs_already_patched(d) else '待替换 langs\\*.lang 的 TEXT_REGISTER_INFO'))
    print('(以上为目标位置与将写入的字节; 尚未修改任何文件)')


def do_status(d):
    exe = os.path.join(d, BANDIZIP_EXE)
    upd = os.path.join(d, UPDATER_EXE)
    bd = os.path.join(d, BACKUP_DIR)
    print('安装目录: %s' % d)
    for path in (exe, upd):
        if os.path.isfile(path):
            print('  %-14s SHA256=%s' % (os.path.basename(path), sha256_file(path)))
    print('  备份目录: %s (%s)' % (bd, '存在' if os.path.isdir(bd) else '不存在'))
    if os.path.isfile(exe):
        print('  Bandizip.exe 补丁状态: %s' % ('已应用' if exe_patched(exe) else '未应用'))
    if os.path.isfile(upd):
        print('  Updater.exe 补丁状态: %s' % ('已应用' if updater_patched(upd) else '未应用'))
    print('  语言文件状态: %s' % ('已替换' if langs_already_patched(d) else '未替换'))


def main():
    args = sys.argv[1:]
    if not args or args[0] in ('-h', '--help'):
        print(__doc__)
        return
    mode = args[0]
    d = find_install_dir(args[1] if len(args) > 1 else None)
    if mode == '--apply':
        do_apply(d)
    elif mode == '--revert':
        do_revert(d)
    elif mode == '--check':
        do_check(d)
    elif mode == '--status':
        do_status(d)
    else:
        print(__doc__)


if __name__ == '__main__':
    if os.name == 'nt':
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
    main()
