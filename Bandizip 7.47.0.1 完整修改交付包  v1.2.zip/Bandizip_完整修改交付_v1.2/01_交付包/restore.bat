@echo off
chcp 65001 >nul
setlocal EnableExtensions

set "TARGET="
if not "%~1"=="" if /i not "%~1"=="--elevated" set "TARGET=%~1"
if not defined TARGET if defined BZP_TARGET set "TARGET=%BZP_TARGET%"
if not defined TARGET set "TARGET=C:\Program Files\Bandizip"
if defined TARGET for %%I in ("%TARGET%") do set "TARGET=%%~fI"
pushd "%~dp0"

set "WRITABLE="
echo.>"%TARGET%\.bzpatch_wtest" 2>nul
if exist "%TARGET%\.bzpatch_wtest" set "WRITABLE=1"
if defined WRITABLE del /f /q "%TARGET%\.bzpatch_wtest" >nul 2>&1
if defined WRITABLE goto :run
if /i "%~1"=="--elevated" goto :no_admin

echo 正在请求管理员权限, 请在弹出的 UAC 窗口中点击 "是" ...
set "BZP_TARGET=%TARGET%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -ArgumentList '--elevated' -Verb RunAs"
if errorlevel 1 echo [提示] 未获得管理员权限, 操作已取消。
goto :done

:no_admin
echo [错误] 没有写入 "%TARGET%" 的权限, 无法还原。
goto :done

:run
set "PY="
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
    echo [错误] 未找到 Python 3。
    goto :done
)

tasklist /fi "imagename eq Bandizip.exe" 2>nul | find /i "Bandizip.exe" >nul
if not errorlevel 1 (
    echo 正在关闭 Bandizip ...
    taskkill /f /im Bandizip.exe >nul 2>&1
    timeout /t 1 /nobreak >nul
)

echo.
%PY% "%~dp0patch_bandizip.py" --revert "%TARGET%"
echo.
echo 若还原失败, 可重新运行官方安装包覆盖安装。

:done
echo.
if not defined BZP_NOPAUSE pause
popd
exit /b
