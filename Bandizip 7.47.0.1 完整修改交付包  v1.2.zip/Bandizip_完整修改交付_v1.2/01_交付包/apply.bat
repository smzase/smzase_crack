@echo off
chcp 65001 >nul
setlocal EnableExtensions

rem ===== 目标安装目录: 参数1 或环境变量 BZP_TARGET, 默认 C:\Program Files\Bandizip
set "TARGET="
if not "%~1"=="" if /i not "%~1"=="--elevated" set "TARGET=%~1"
if not defined TARGET if defined BZP_TARGET set "TARGET=%BZP_TARGET%"
if not defined TARGET set "TARGET=C:\Program Files\Bandizip"
if defined TARGET for %%I in ("%TARGET%") do set "TARGET=%%~fI"
pushd "%~dp0"

rem ===== 判断目标目录是否可写, 不可写则请求管理员权限
set "WRITABLE="
echo.>"%TARGET%\.bzpatch_wtest" 2>nul
if exist "%TARGET%\.bzpatch_wtest" set "WRITABLE=1"
if defined WRITABLE del /f /q "%TARGET%\.bzpatch_wtest" >nul 2>&1
if defined WRITABLE goto :run
if /i "%~1"=="--elevated" goto :no_admin

echo 正在请求管理员权限, 请在弹出的 UAC 窗口中点击 "是" ...
set "BZP_TARGET=%TARGET%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -ArgumentList '--elevated' -Verb RunAs"
if errorlevel 1 echo [提示] 未获得管理员权限, 操作已取消。
goto :done

:no_admin
echo [错误] 没有写入 "%TARGET%" 的权限, 无法应用补丁。
goto :done

:run
rem ===== 定位 Python (需要 3.8+)
set "PY="
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
    echo [错误] 未找到 Python。请安装 Python 3.8 或更高版本, 安装时勾选 "Add python.exe to PATH"。
    goto :done
)

rem ===== 关闭正在运行的 Bandizip
tasklist /fi "imagename eq Bandizip.exe" 2>nul | find /i "Bandizip.exe" >nul
if not errorlevel 1 (
    echo 正在关闭 Bandizip ...
    taskkill /f /im Bandizip.exe >nul 2>&1
    timeout /t 1 /nobreak >nul
)

echo.
%PY% "%~dp0patch_bandizip.py" --apply "%TARGET%"
set "RC=%errorlevel%"
echo.
if "%RC%"=="0" (echo 操作完成: Bandizip 已为 Professional 已注册版, 无广告、无更新检查。) else (echo 操作未完成, 错误码 %RC%, 请查看上方提示。)

:done
echo.
if not defined BZP_NOPAUSE pause
popd
exit /b
