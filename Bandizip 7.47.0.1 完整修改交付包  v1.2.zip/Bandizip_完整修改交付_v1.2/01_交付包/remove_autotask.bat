@echo off
chcp 65001 >nul
setlocal EnableExtensions
pushd "%~dp0"

net session >nul 2>&1
if not errorlevel 1 goto :run
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
goto :done

:run
schtasks /delete /f /tn "Bandizip Pro Patch AutoRepatch"
if errorlevel 1 (
    echo [提示] 未找到该计划任务, 或删除失败。
) else (
    echo 已删除计划任务。
)
:done
echo.
if not defined BZP_NOPAUSE pause
popd
exit /b
