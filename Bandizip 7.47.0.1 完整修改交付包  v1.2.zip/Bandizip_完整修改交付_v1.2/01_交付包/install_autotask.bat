@echo off
chcp 65001 >nul
setlocal EnableExtensions
pushd "%~dp0"

net session >nul 2>&1
if not errorlevel 1 goto :run
echo 正在请求管理员权限, 请在弹出的 UAC 窗口中点击 "是" ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
goto :done

:run
schtasks /create /f /tn "Bandizip Pro Patch AutoRepatch" /sc onlogon /rl highest /tr "%~dp0auto_repatch.bat"
if errorlevel 1 (
    echo [错误] 创建计划任务失败。
) else (
    echo 已创建登录计划任务: Bandizip Pro Patch AutoRepatch
    echo 每次登录时若发现 Bandizip 已被更新覆盖, 会自动重新打补丁。
)
:done
echo.
if not defined BZP_NOPAUSE pause
popd
exit /b
